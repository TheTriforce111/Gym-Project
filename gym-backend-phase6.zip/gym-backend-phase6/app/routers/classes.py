"""
routers/classes.py — Class Scheduling API Endpoints (Phase 6)

────────────────────────────────────────────────────
CLASS MANAGEMENT
────────────────────────────────────────────────────
POST   /api/classes/                    → Create class (Trainer/Admin)
GET    /api/classes/                    → List upcoming classes
GET    /api/classes/schedule/weekly     → Weekly calendar view
GET    /api/classes/{id}                → Get class details
PATCH  /api/classes/{id}               → Update class (Trainer/Admin)
POST   /api/classes/{id}/cancel-class  → Cancel entire class (Admin)

────────────────────────────────────────────────────
BOOKING
────────────────────────────────────────────────────
POST   /api/classes/{id}/book           → Book a class (Member)
POST   /api/classes/{id}/cancel-booking → Cancel booking (Member)
GET    /api/classes/my-bookings         → My upcoming bookings
GET    /api/classes/my-history          → My past class history

────────────────────────────────────────────────────
WAITLIST
────────────────────────────────────────────────────
GET    /api/classes/{id}/waitlist       → View waitlist (Admin/Trainer)
GET    /api/classes/{id}/my-waitlist    → My waitlist position

────────────────────────────────────────────────────
ATTENDANCE
────────────────────────────────────────────────────
POST   /api/classes/{id}/mark-attendance → Mark who attended (Admin/Trainer)
GET    /api/classes/{id}/bookings        → All bookings for a class (Admin/Trainer)
"""

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin, require_trainer
from app.models.gym_class import ClassCategory, ClassWaitlist
from app.models.user import User
from app.schemas.gym_class import (
    BookingRequest, BookingResponse, CancelBookingRequest,
    GymClassCreate, GymClassResponse, GymClassSummary, GymClassUpdate,
    MarkAttendanceRequest, WaitlistEntryResponse, WaitlistResponse,
    WeeklyScheduleResponse,
)
from app.services.class_service import ClassService

router = APIRouter()


# ====================================================================
# CLASS MANAGEMENT
# ====================================================================

@router.post(
    "/",
    status_code=201,
    summary="Create a gym class (Trainer/Admin)",
)
def create_class(
    body: GymClassCreate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Create a new gym class.

    For one-off classes: set recurrence='none' (default).

    For weekly recurring classes (e.g. every Monday 9am):
    - Set recurrence='weekly'
    - Set recurrence_end_date to the last occurrence date
    - The system creates one record per occurrence automatically

    Example for a 4-week recurring yoga class:
    ```json
    {
      "name": "Morning Yoga",
      "category": "yoga",
      "start_time": "2025-02-03T09:00:00",
      "end_time":   "2025-02-03T10:00:00",
      "max_capacity": 15,
      "recurrence": "weekly",
      "recurrence_end_date": "2025-03-03T09:00:00",
      "location": "Studio A",
      "cancellation_cutoff_hours": 2
    }
    ```
    This creates 5 class instances: Feb 3, 10, 17, 24, Mar 3.
    """
    service = ClassService(db)
    result  = service.create_class(data=body, created_by=trainer)

    # result is either a single GymClass or a list for recurring
    if isinstance(result, list):
        return {
            "message":  f"{len(result)} class instances created successfully.",
            "count":    len(result),
            "class_ids": [c.id for c in result],
            "first_class": result[0],
        }
    return result


@router.get(
    "/",
    response_model=List[GymClassSummary],
    summary="List upcoming gym classes",
)
def list_classes(
    category:    Optional[ClassCategory] = Query(None, description="Filter by class type"),
    trainer_id:  Optional[int]           = Query(None, description="Filter by trainer"),
    date_from:   Optional[str]           = Query(None, description="Start date filter (YYYY-MM-DD)"),
    date_to:     Optional[str]           = Query(None, description="End date filter (YYYY-MM-DD)"),
    upcoming_only: bool                  = Query(True),
    skip:  int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Browse all upcoming gym classes.

    Supports filtering by:
    - category: yoga, hiit, pilates, spinning, zumba, etc.
    - trainer_id: classes by a specific trainer
    - date_from / date_to: classes within a date range

    Returns classes ordered by start time (earliest first).
    The response includes spots_remaining and is_full for each class.
    """
    from datetime import datetime as dt
    service = ClassService(db)
    return service.get_classes(
        category=category,
        trainer_id=trainer_id,
        upcoming_only=upcoming_only,
        date_from=dt.fromisoformat(date_from) if date_from else None,
        date_to=dt.fromisoformat(date_to)     if date_to   else None,
        skip=skip,
        limit=limit,
    )


@router.get(
    "/schedule/weekly",
    response_model=WeeklyScheduleResponse,
    summary="Get the weekly class schedule (calendar view)",
)
def get_weekly_schedule(
    week_offset: int = Query(
        0, ge=-4, le=12,
        description="0=this week, 1=next week, -1=last week"
    ),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the gym's full class schedule for a given week, grouped by day.
    Perfect for rendering a weekly calendar view in the mobile app or web dashboard.

    week_offset:
    - 0 = current week (Mon–Sun)
    - 1 = next week
    - -1 = previous week (up to 4 weeks back)
    """
    service = ClassService(db)
    return service.get_weekly_schedule(week_offset=week_offset)


@router.get(
    "/my-bookings",
    response_model=List[BookingResponse],
    summary="Get my upcoming class bookings",
)
def get_my_bookings(
    include_past: bool = Query(False, description="Include past classes"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns all class bookings for the current user.
    By default shows only upcoming classes.
    Set include_past=true to see attendance history.
    """
    service = ClassService(db)
    return service.get_my_bookings(
        user_id=current_user.id,
        include_past=include_past,
    )


@router.get(
    "/{class_id}",
    response_model=GymClassResponse,
    summary="Get full class details",
)
def get_class(
    class_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Get full details for a specific class including:
    - Class info (name, time, location, trainer)
    - Current capacity (spots_remaining, is_full)
    - Waitlist count
    - Whether the booking window is open (is_bookable)
    """
    from fastapi import HTTPException
    c = db.query(__import__(
        'app.models.gym_class', fromlist=['GymClass']
    ).GymClass).filter_by(id=class_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Class not found.")
    return {
        **{col: getattr(c, col) for col in [
            'id','name','category','difficulty','description','trainer_id',
            'trainer','start_time','end_time','location','max_capacity',
            'waitlist_enabled','recurrence','status','booking_opens_at',
            'booking_closes_at','cancellation_cutoff_hours','what_to_bring',
            'created_at',
        ]},
        'duration_minutes':          c.duration_minutes,
        'confirmed_bookings_count':  c.confirmed_bookings_count,
        'spots_remaining':           c.spots_remaining,
        'is_full':                   c.is_full,
        'is_bookable':               c.is_bookable,
        'waitlist_count':            len(c.waitlist),
    }


@router.patch(
    "/{class_id}",
    response_model=GymClassSummary,
    summary="Update class details (Trainer/Admin)",
)
def update_class(
    class_id: int,
    body: GymClassUpdate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Update a class's name, location, capacity, or other details.
    Only the assigned trainer or an admin can edit.
    """
    service = ClassService(db)
    return service.update_class(
        class_id=class_id,
        data=body,
        requesting_user=trainer,
    )


@router.post(
    "/{class_id}/cancel-class",
    summary="Cancel an entire class (Admin)",
)
def cancel_class(
    class_id: int,
    reason: Optional[str] = None,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Cancel an entire class.

    - All confirmed bookings are cancelled automatically
    - The waitlist is cleared
    - (Phase 8) Email notifications are sent to all affected members

    This action is irreversible. Admin only.
    """
    service = ClassService(db)
    gym_class = service.cancel_class(
        class_id=class_id,
        reason=reason,
        cancelled_by=admin,
    )
    return {
        "message":    f"Class '{gym_class.name}' has been cancelled.",
        "class_id":   class_id,
        "reason":     reason,
    }


# ====================================================================
# BOOKING
# ====================================================================

@router.post(
    "/{class_id}/book",
    status_code=201,
    summary="Book a gym class",
)
def book_class(
    class_id: int,
    body: BookingRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Book a spot in a gym class.

    If the class has space → confirms booking immediately.
    If the class is full and waitlist is enabled → joins the waitlist.
    If the class is full and waitlist is disabled → returns 400.

    Requirements:
    - Must have an active, non-expired membership
    - Cannot book the same class twice
    - Class must be in its booking window
    """
    from app.models.gym_class import ClassWaitlist as WL
    service = ClassService(db)
    result  = service.book_class(
        class_id=class_id,
        user=current_user,
        request=body,
    )

    # Return different responses depending on booking vs waitlist
    if isinstance(result, WL):
        return {
            "type":     "waitlist",
            "message":  f"Class is full. You are #{result.position} on the waitlist.",
            "position": result.position,
            "waitlist_id": result.id,
        }
    return {
        "type":       "booking",
        "message":    "Class booked successfully! See you there. 💪",
        "booking_id": result.id,
        "class_name": result.gym_class.name,
        "start_time": result.gym_class.start_time,
    }


@router.post(
    "/{class_id}/cancel-booking",
    summary="Cancel your booking for a class",
)
def cancel_booking(
    class_id: int,
    body: CancelBookingRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Cancel your booking for a class.

    Rules:
    - Cannot cancel within the class's cancellation_cutoff_hours (default: 2h)
    - Admins can cancel any booking at any time
    - If someone is on the waitlist, they're automatically promoted

    After cancellation, the freed spot is immediately given to the
    next person on the waitlist (if any).
    """
    service = ClassService(db)
    service.cancel_booking(
        class_id=class_id,
        user=current_user,
        request=body,
    )
    return {"message": "Your booking has been cancelled successfully."}


# ====================================================================
# WAITLIST
# ====================================================================

@router.get(
    "/{class_id}/waitlist",
    response_model=List[WaitlistEntryResponse],
    summary="View the waitlist for a class (Admin/Trainer)",
)
def get_waitlist(
    class_id: int,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Returns the full waitlist for a class, ordered by position.
    Trainer and Admin only.
    """
    from fastapi import HTTPException
    from app.models.gym_class import GymClass
    c = db.query(GymClass).filter(GymClass.id == class_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Class not found.")
    return db.query(ClassWaitlist).filter(
        ClassWaitlist.gym_class_id == class_id
    ).order_by(ClassWaitlist.position).all()


@router.get(
    "/{class_id}/my-waitlist",
    summary="Check your waitlist position for a class",
)
def get_my_waitlist_position(
    class_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Check if you're on the waitlist for a class and what your position is.
    Returns 404 if you're not on the waitlist.
    """
    from fastapi import HTTPException
    service = ClassService(db)
    entry = service.get_waitlist_position(
        user_id=current_user.id,
        class_id=class_id,
    )
    if not entry:
        raise HTTPException(
            status_code=404,
            detail="You are not on the waitlist for this class."
        )
    return {
        "position":    entry.position,
        "joined_at":   entry.joined_at,
        "message":     f"You are #{entry.position} on the waitlist.",
    }


# ====================================================================
# ATTENDANCE
# ====================================================================

@router.post(
    "/{class_id}/mark-attendance",
    summary="Mark attendance after a class ends (Admin/Trainer)",
)
def mark_attendance(
    class_id: int,
    body: MarkAttendanceRequest,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Mark which members attended a class after it ends.

    Provide a list of user IDs who were present.
    Members with confirmed bookings who are NOT in the list are marked NO_SHOW.
    The class status is updated to COMPLETED.

    Example:
    ```json
    {
      "attended_user_ids": [12, 34, 56, 78]
    }
    ```
    """
    service = ClassService(db)
    return service.mark_attendance(
        class_id=class_id,
        request=body,
        marked_by=trainer,
    )


@router.get(
    "/{class_id}/bookings",
    response_model=List[BookingResponse],
    summary="Get all bookings for a class (Admin/Trainer)",
)
def get_class_bookings(
    class_id: int,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Returns all booking records for a class.
    Used by trainers to see who's confirmed, attended, cancelled, or no-showed.
    """
    from fastapi import HTTPException
    from app.models.gym_class import ClassBooking, GymClass
    c = db.query(GymClass).filter(GymClass.id == class_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Class not found.")
    return db.query(ClassBooking).filter(
        ClassBooking.gym_class_id == class_id
    ).all()
