"""
schemas/gym_class.py — Class Scheduling Request & Response Schemas (Phase 6)

Covers:
- Creating and updating gym classes
- Booking and cancellation requests
- Rich response schemas with computed fields (spots_remaining, is_full, etc.)
- Waitlist position info
- Class schedule calendar view
"""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, field_validator, model_validator

from app.models.gym_class import (
    BookingStatus, ClassCategory,
    ClassStatus, DifficultyLevel, RecurrenceType,
)


# ============================================================
# GYM CLASS SCHEMAS
# ============================================================

class GymClassCreate(BaseModel):
    """Body for POST /api/classes/ (Trainer/Admin)"""

    name:        str
    category:    ClassCategory    = ClassCategory.OTHER
    difficulty:  DifficultyLevel  = DifficultyLevel.ALL_LEVELS
    description: Optional[str]   = None

    trainer_id:  Optional[int]   = None
    # If not provided, the creating trainer is assigned automatically

    start_time:  datetime
    end_time:    datetime

    location:    Optional[str]   = None
    max_capacity: int = 20
    waitlist_enabled: bool = True

    recurrence:         RecurrenceType = RecurrenceType.NONE
    recurrence_end_date: Optional[datetime] = None

    booking_opens_at:  Optional[datetime] = None
    booking_closes_at: Optional[datetime] = None
    cancellation_cutoff_hours: int = 2

    what_to_bring: Optional[str] = None

    @field_validator("name")
    @classmethod
    def name_not_empty(cls, v):
        if not v.strip():
            raise ValueError("Class name cannot be empty.")
        return v.strip()

    @field_validator("max_capacity")
    @classmethod
    def capacity_positive(cls, v):
        if v < 1:
            raise ValueError("max_capacity must be at least 1.")
        return v

    @model_validator(mode="after")
    def end_after_start(self):
        if self.end_time <= self.start_time:
            raise ValueError("end_time must be after start_time.")
        return self

    @model_validator(mode="after")
    def recurrence_needs_end_date(self):
        if (
            self.recurrence != RecurrenceType.NONE
            and self.recurrence_end_date is None
        ):
            raise ValueError(
                "recurrence_end_date is required for recurring classes."
            )
        return self


class GymClassUpdate(BaseModel):
    """Body for PATCH /api/classes/{id} (Trainer/Admin)"""
    name:         Optional[str]            = None
    description:  Optional[str]            = None
    category:     Optional[ClassCategory]  = None
    difficulty:   Optional[DifficultyLevel]= None
    trainer_id:   Optional[int]            = None
    location:     Optional[str]            = None
    max_capacity: Optional[int]            = None
    status:       Optional[ClassStatus]    = None
    what_to_bring: Optional[str]          = None
    cancellation_cutoff_hours: Optional[int] = None


class TrainerSummary(BaseModel):
    """Minimal trainer info embedded in class responses."""
    id:        int
    full_name: str
    email:     str

    class Config:
        from_attributes = True


class GymClassResponse(BaseModel):
    """
    Full class details returned by the API.
    Includes computed fields: spots_remaining, is_full, is_bookable.
    """
    id:           int
    name:         str
    category:     ClassCategory
    difficulty:   DifficultyLevel
    description:  Optional[str]
    trainer_id:   Optional[int]
    trainer:      Optional[TrainerSummary]
    start_time:   datetime
    end_time:     datetime
    duration_minutes: int              # Computed property
    location:     Optional[str]
    max_capacity: int
    waitlist_enabled: bool
    recurrence:   RecurrenceType
    status:       ClassStatus
    booking_opens_at:  Optional[datetime]
    booking_closes_at: Optional[datetime]
    cancellation_cutoff_hours: int
    what_to_bring: Optional[str]

    # Computed availability fields
    confirmed_bookings_count: int      # Computed property
    spots_remaining:          int      # Computed property
    is_full:                  bool     # Computed property
    is_bookable:              bool     # Computed property
    waitlist_count:           int = 0  # Number of people on waitlist

    created_at: datetime

    class Config:
        from_attributes = True


class GymClassSummary(BaseModel):
    """Lightweight class info for calendar/list views."""
    id:              int
    name:            str
    category:        ClassCategory
    difficulty:      DifficultyLevel
    start_time:      datetime
    end_time:        datetime
    duration_minutes: int
    location:        Optional[str]
    trainer_id:      Optional[int]
    spots_remaining: int
    is_full:         bool
    is_bookable:     bool
    status:          ClassStatus

    class Config:
        from_attributes = True


# ============================================================
# BOOKING SCHEMAS
# ============================================================

class BookingRequest(BaseModel):
    """Body for POST /api/classes/{id}/book"""
    notes: Optional[str] = None
    # Optional note from member: "I might be 5 min late"


class CancelBookingRequest(BaseModel):
    """Body for POST /api/classes/{id}/cancel-booking"""
    reason: Optional[str] = None
    # Optional cancellation reason for record-keeping


class BookingResponse(BaseModel):
    """Returned when a booking is created or retrieved."""
    id:           int
    user_id:      int
    gym_class_id: int
    status:       BookingStatus
    booked_at:    datetime
    cancelled_at: Optional[datetime]
    checked_in_at: Optional[datetime]
    cancellation_reason: Optional[str]

    # Embed basic class info so the frontend doesn't need a second API call
    gym_class: GymClassSummary

    class Config:
        from_attributes = True


class WaitlistResponse(BaseModel):
    """Returned when a member joins the waitlist."""
    id:           int
    user_id:      int
    gym_class_id: int
    position:     int
    joined_at:    datetime
    message:      str = ""  # e.g. "You are #2 on the waitlist"

    class Config:
        from_attributes = True


class WaitlistEntryResponse(BaseModel):
    """Single waitlist entry for admin view."""
    id:           int
    user_id:      int
    gym_class_id: int
    position:     int
    joined_at:    datetime

    class Config:
        from_attributes = True


# ============================================================
# SCHEDULE / CALENDAR SCHEMAS
# ============================================================

class ScheduleDay(BaseModel):
    """All classes for a single day — used in weekly calendar view."""
    date:    str              # "2025-02-10"
    classes: List[GymClassSummary]


class WeeklyScheduleResponse(BaseModel):
    """Seven-day schedule for the gym calendar."""
    week_start: str           # "2025-02-10"
    week_end:   str           # "2025-02-16"
    days:       List[ScheduleDay]


# ============================================================
# ATTENDANCE MARK SCHEMA
# ============================================================

class MarkAttendanceRequest(BaseModel):
    """
    Body for POST /api/classes/{class_id}/mark-attendance
    Admin/Trainer marks which members actually showed up.
    """
    attended_user_ids: List[int]
    # List of user IDs who were present in the class
    # Everyone else with a CONFIRMED booking gets marked NO_SHOW
