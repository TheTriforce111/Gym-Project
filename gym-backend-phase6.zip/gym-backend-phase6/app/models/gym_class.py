"""
models/gym_class.py — Class Scheduling Database Models (Phase 6)

This file defines THREE related tables:

┌──────────────────────────────────────────────────────────────────┐
│  GymClass       → A scheduled class (Yoga at 9am Monday)        │
│  ClassBooking   → A member's confirmed spot in a class          │
│  ClassWaitlist  → Queue when class is full (auto-promote)       │
└──────────────────────────────────────────────────────────────────┘

How it works end-to-end:
  1. Trainer/Admin creates a GymClass (name, time, capacity, location)
  2. Member books the class → ClassBooking record created
  3. If class is full → Member joins waitlist → ClassWaitlist record
  4. If a booking is cancelled → first waitlist entry is auto-promoted
  5. After class ends → admin marks attendance (ATTENDED status)

Key design decisions:
  - RecurrenceType: classes can be one-off or recurring (daily/weekly)
  - Waitlist: position-ordered queue with auto-promotion on cancellation
  - Capacity validation: enforced at the service layer, not just the DB
"""

import enum
from datetime import datetime

from sqlalchemy import (
    Boolean, Column, DateTime, Enum,
    ForeignKey, Integer, String, Text, UniqueConstraint
)
from sqlalchemy.orm import relationship

from app.core.database import Base


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ClassStatus(str, enum.Enum):
    """
    Lifecycle status of a gym class.
    SCHEDULED → ONGOING → COMPLETED (normal flow)
    SCHEDULED → CANCELLED (if class is cancelled before it starts)
    """
    SCHEDULED  = "scheduled"   # Class is upcoming and bookable
    ONGOING    = "ongoing"     # Class is currently in progress
    COMPLETED  = "completed"   # Class has ended
    CANCELLED  = "cancelled"   # Class was cancelled (all bookings refunded)


class ClassCategory(str, enum.Enum):
    """Type/style of gym class."""
    YOGA        = "yoga"
    HIIT        = "hiit"
    PILATES     = "pilates"
    SPINNING    = "spinning"
    ZUMBA       = "zumba"
    BOXING      = "boxing"
    CROSSFIT    = "crossfit"
    STRETCHING  = "stretching"
    SWIMMING    = "swimming"
    STRENGTH    = "strength"
    CARDIO      = "cardio"
    OTHER       = "other"


class DifficultyLevel(str, enum.Enum):
    """Difficulty level of the class."""
    BEGINNER     = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED     = "advanced"
    ALL_LEVELS   = "all_levels"


class RecurrenceType(str, enum.Enum):
    """
    How often the class repeats.
    NONE = one-time class
    DAILY / WEEKLY / MONTHLY = recurring series
    """
    NONE    = "none"      # One-off class
    DAILY   = "daily"     # Every day
    WEEKLY  = "weekly"    # Same day every week (e.g. every Monday at 9am)
    MONTHLY = "monthly"   # Same date every month


class BookingStatus(str, enum.Enum):
    """
    Status of a member's class booking.

    CONFIRMED → Class is upcoming, member has a spot
    ATTENDED  → Member showed up (marked by staff after class)
    CANCELLED → Member cancelled their booking
    NO_SHOW   → Member didn't show and didn't cancel
    """
    CONFIRMED = "confirmed"
    ATTENDED  = "attended"
    CANCELLED = "cancelled"
    NO_SHOW   = "no_show"


# ---------------------------------------------------------------------------
# GymClass Model
# ---------------------------------------------------------------------------

class GymClass(Base):
    """
    A scheduled gym class that members can book.
    Examples: "Yoga with Sarah — Monday 9:00am", "HIIT Bootcamp — Wed 6:00pm"

    Maps to the 'gym_classes' table.
    """
    __tablename__ = "gym_classes"

    id          = Column(Integer, primary_key=True, index=True)

    # --- Identity ---
    name        = Column(String(200), nullable=False)
    # e.g. "Morning Yoga", "Advanced HIIT", "Beginner Pilates"

    description = Column(Text, nullable=True)
    # Class overview shown to members when browsing

    category    = Column(Enum(ClassCategory),   nullable=False, default=ClassCategory.OTHER)
    difficulty  = Column(Enum(DifficultyLevel), nullable=False, default=DifficultyLevel.ALL_LEVELS)

    # --- Trainer ---
    trainer_id  = Column(Integer, ForeignKey("users.id"), nullable=True)
    # The trainer leading this class (role=TRAINER). nullable = class may not have a trainer yet.

    # --- Schedule ---
    start_time  = Column(DateTime, nullable=False)
    end_time    = Column(DateTime, nullable=False)
    # Full datetime for when the class starts and ends
    # e.g. start_time = 2025-02-10 09:00:00, end_time = 2025-02-10 10:00:00

    # --- Recurrence ---
    recurrence  = Column(Enum(RecurrenceType), default=RecurrenceType.NONE)
    # If WEEKLY: use recurrence_end_date to know when the series stops

    recurrence_end_date = Column(DateTime, nullable=True)
    # The last date this recurring class should be created up to

    parent_class_id = Column(Integer, ForeignKey("gym_classes.id"), nullable=True)
    # For recurring classes: child instances link back to the parent template

    # --- Location ---
    location    = Column(String(200), nullable=True)
    # e.g. "Studio A", "Main Gym Floor", "Outdoor Terrace", "Pool"

    # --- Capacity ---
    max_capacity     = Column(Integer, nullable=False, default=20)
    waitlist_enabled = Column(Boolean, default=True)
    # If True: members can join waitlist when class is full
    # If False: class simply shows as "Full" with no option to waitlist

    # --- Status ---
    status      = Column(Enum(ClassStatus), default=ClassStatus.SCHEDULED)

    # --- Booking window ---
    booking_opens_at  = Column(DateTime, nullable=True)
    # Optional: bookings only open at this time (e.g. 48h before class)
    # null = bookings open immediately

    booking_closes_at = Column(DateTime, nullable=True)
    # Optional: bookings close at this time (e.g. 1h before class starts)
    # null = bookings close when class starts

    # --- Cancellation policy ---
    cancellation_cutoff_hours = Column(Integer, default=2)
    # Members cannot cancel within this many hours of the class start time
    # Default: 2 hours notice required to cancel

    # --- Notes ---
    what_to_bring = Column(String(500), nullable=True)
    # Shown to members: "Bring your own yoga mat and water bottle"

    # --- Timestamps ---
    created_at  = Column(DateTime, default=datetime.utcnow)
    updated_at  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # --- Relationships ---
    trainer   = relationship("User",         foreign_keys=[trainer_id])
    bookings  = relationship("ClassBooking", back_populates="gym_class",
                             cascade="all, delete-orphan")
    waitlist  = relationship("ClassWaitlist", back_populates="gym_class",
                             order_by="ClassWaitlist.position",
                             cascade="all, delete-orphan")

    # --- Computed Properties ---

    @property
    def confirmed_bookings_count(self) -> int:
        """Number of confirmed (not cancelled) bookings."""
        return sum(1 for b in self.bookings if b.status == BookingStatus.CONFIRMED)

    @property
    def spots_remaining(self) -> int:
        """Available spots left in the class."""
        return max(0, self.max_capacity - self.confirmed_bookings_count)

    @property
    def is_full(self) -> bool:
        """True when no spots are left."""
        return self.confirmed_bookings_count >= self.max_capacity

    @property
    def is_bookable(self) -> bool:
        """
        True if the class can currently be booked.
        Checks: status is SCHEDULED, class hasn't started,
        and booking window is open (if configured).
        """
        now = datetime.utcnow()
        if self.status != ClassStatus.SCHEDULED:
            return False
        if self.start_time <= now:
            return False
        if self.booking_opens_at and now < self.booking_opens_at:
            return False
        if self.booking_closes_at and now > self.booking_closes_at:
            return False
        return True

    @property
    def duration_minutes(self) -> int:
        """Class duration in minutes."""
        delta = self.end_time - self.start_time
        return int(delta.total_seconds() / 60)

    def __repr__(self):
        return (
            f"<GymClass id={self.id} "
            f"name='{self.name}' "
            f"start={self.start_time}>"
        )


# ---------------------------------------------------------------------------
# ClassBooking Model
# ---------------------------------------------------------------------------

class ClassBooking(Base):
    """
    A confirmed booking for a member in a gym class.

    One member can only have ONE active booking per class
    (enforced by the UniqueConstraint below).

    Maps to the 'class_bookings' table.
    """
    __tablename__ = "class_bookings"

    # Prevent the same user from booking the same class twice
    __table_args__ = (
        UniqueConstraint(
            "user_id", "gym_class_id",
            name="uq_one_booking_per_user_per_class"
        ),
    )

    id           = Column(Integer, primary_key=True, index=True)
    user_id      = Column(Integer, ForeignKey("users.id"),       nullable=False)
    gym_class_id = Column(Integer, ForeignKey("gym_classes.id"), nullable=False)

    # --- Status ---
    status       = Column(Enum(BookingStatus), nullable=False, default=BookingStatus.CONFIRMED)

    # --- Timestamps ---
    booked_at    = Column(DateTime, default=datetime.utcnow)
    cancelled_at = Column(DateTime, nullable=True)
    # When the booking was cancelled (null if not cancelled)

    # --- Attendance ---
    checked_in_at = Column(DateTime, nullable=True)
    # When the member actually checked in to the class (marked by staff)

    # --- Notes ---
    cancellation_reason = Column(String(300), nullable=True)
    # Optional reason the member gave when cancelling

    # --- Relationships ---
    user      = relationship("User",     foreign_keys=[user_id], back_populates="bookings")
    gym_class = relationship("GymClass", back_populates="bookings")

    def __repr__(self):
        return (
            f"<ClassBooking user_id={self.user_id} "
            f"class_id={self.gym_class_id} "
            f"status={self.status}>"
        )


# ---------------------------------------------------------------------------
# ClassWaitlist Model
# ---------------------------------------------------------------------------

class ClassWaitlist(Base):
    """
    A waitlist entry when a class is fully booked.

    When a booking is cancelled, the FIRST person on the waitlist
    (position=1) is automatically promoted to a confirmed booking.
    Their waitlist entry is deleted and a new ClassBooking is created.

    Maps to the 'class_waitlist' table.
    """
    __tablename__ = "class_waitlist"

    # Prevent the same user from joining the same waitlist twice
    __table_args__ = (
        UniqueConstraint(
            "user_id", "gym_class_id",
            name="uq_one_waitlist_per_user_per_class"
        ),
    )

    id           = Column(Integer, primary_key=True, index=True)
    user_id      = Column(Integer, ForeignKey("users.id"),       nullable=False)
    gym_class_id = Column(Integer, ForeignKey("gym_classes.id"), nullable=False)

    position     = Column(Integer, nullable=False)
    # Waitlist position: 1 = first in line, 2 = second, etc.
    # When position-1 is promoted, all others shift up by 1.

    joined_at    = Column(DateTime, default=datetime.utcnow)

    # Whether we've already notified this person they're on the waitlist
    notified     = Column(Boolean, default=False)

    # --- Relationships ---
    user      = relationship("User",     foreign_keys=[user_id])
    gym_class = relationship("GymClass", back_populates="waitlist")

    def __repr__(self):
        return (
            f"<ClassWaitlist user_id={self.user_id} "
            f"class_id={self.gym_class_id} "
            f"position={self.position}>"
        )
