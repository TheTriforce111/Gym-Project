"""
services/class_service.py — Class Scheduling Business Logic (Phase 6)

This service handles:
1. Creating classes (including recurring series generation)
2. Booking validation (capacity, membership, duplicate check, booking window)
3. Waitlist management with auto-promotion
4. Booking cancellation with cutoff enforcement
5. Attendance marking (ATTENDED / NO_SHOW)
6. Weekly calendar schedule
7. Class cancellation (notifies all booked members)

Key design decisions:
  - Waitlist auto-promotion: when a booking is cancelled, the first
    waitlist entry is automatically converted to a confirmed booking.
  - Recurring classes: when recurrence=WEEKLY, we generate individual
    GymClass records for every occurrence up to recurrence_end_date.
  - Cancellation cutoff: members cannot cancel within
    cancellation_cutoff_hours of the class start time.
"""

import logging
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.gym_class import (
    BookingStatus, ClassBooking, ClassStatus,
    ClassWaitlist, GymClass, RecurrenceType,
)
from app.models.membership import Membership, MembershipStatus
from app.models.user import User, UserRole
from app.schemas.gym_class import (
    BookingRequest, CancelBookingRequest,
    GymClassCreate, GymClassUpdate,
    MarkAttendanceRequest,
)

logger = logging.getLogger(__name__)


class ClassService:
    """
    All gym class scheduling operations.
    Instantiate with a DB session: service = ClassService(db)
    """

    def __init__(self, db: Session):
        self.db = db

    # ===================================================================
    # CLASS CREATION
    # ===================================================================

    def create_class(
        self,
        data: GymClassCreate,
        created_by: User,
    ) -> GymClass | List[GymClass]:
        """
        Create one or more gym class instances.

        For non-recurring classes: creates a single GymClass record.
        For recurring classes (WEEKLY, DAILY, MONTHLY): generates
        individual class records for each occurrence up to recurrence_end_date.

        Returns:
          - Single GymClass for non-recurring
          - List[GymClass] for recurring (all instances created)
        """
        # Assign trainer (default to the creating trainer if not specified)
        if not data.trainer_id and created_by.role == UserRole.TRAINER:
            data.trainer_id = created_by.id

        if data.recurrence == RecurrenceType.NONE:
            # Simple one-off class
            gym_class = self._create_single_class(data, parent_id=None)
            self.db.commit()
            self.db.refresh(gym_class)
            logger.info(f"Class created: '{gym_class.name}' at {gym_class.start_time}")
            return gym_class
        else:
            # Recurring: generate all instances
            instances = self._create_recurring_series(data)
            self.db.commit()
            for inst in instances:
                self.db.refresh(inst)
            logger.info(
                f"Recurring class created: '{data.name}' — "
                f"{len(instances)} instances generated"
            )
            return instances

    def _create_single_class(
        self,
        data: GymClassCreate,
        parent_id: Optional[int],
        start_override: Optional[datetime] = None,
        end_override: Optional[datetime] = None,
    ) -> GymClass:
        """Helper that creates one GymClass record."""
        gym_class = GymClass(
            name=data.name,
            category=data.category,
            difficulty=data.difficulty,
            description=data.description,
            trainer_id=data.trainer_id,
            start_time=start_override or data.start_time,
            end_time=end_override or data.end_time,
            location=data.location,
            max_capacity=data.max_capacity,
            waitlist_enabled=data.waitlist_enabled,
            recurrence=data.recurrence,
            recurrence_end_date=data.recurrence_end_date,
            parent_class_id=parent_id,
            booking_opens_at=data.booking_opens_at,
            booking_closes_at=data.booking_closes_at,
            cancellation_cutoff_hours=data.cancellation_cutoff_hours,
            what_to_bring=data.what_to_bring,
            status=ClassStatus.SCHEDULED,
        )
        self.db.add(gym_class)
        return gym_class

    def _create_recurring_series(
        self,
        data: GymClassCreate,
    ) -> List[GymClass]:
        """
        Generate all individual class occurrences for a recurring series.

        Example for WEEKLY:
          start_time = Monday Jan 6 at 9:00am
          recurrence_end_date = Monday Feb 3
          → Creates 5 classes: Jan 6, Jan 13, Jan 20, Jan 27, Feb 3

        The first instance is the "parent" (parent_class_id=None).
        All subsequent instances link back to the parent.
        """
        instances = []
        current_start = data.start_time
        current_end   = data.end_time
        end_limit     = data.recurrence_end_date

        # Determine the step between occurrences
        if data.recurrence == RecurrenceType.DAILY:
            step = timedelta(days=1)
        elif data.recurrence == RecurrenceType.WEEKLY:
            step = timedelta(weeks=1)
        elif data.recurrence == RecurrenceType.MONTHLY:
            step = timedelta(days=30)   # Approximate
        else:
            step = timedelta(weeks=1)

        parent_id = None   # First instance becomes the parent

        while current_start <= end_limit:
            instance = self._create_single_class(
                data,
                parent_id=parent_id,
                start_override=current_start,
                end_override=current_end,
            )
            self.db.flush()  # Get ID before setting parent_id

            # Make the first instance the parent of all others
            if parent_id is None:
                parent_id = instance.id

            instances.append(instance)
            current_start += step
            current_end   += step

        return instances

    # ===================================================================
    # CLASS UPDATES & CANCELLATION
    # ===================================================================

    def update_class(
        self,
        class_id: int,
        data: GymClassUpdate,
        requesting_user: User,
    ) -> GymClass:
        """Update class details. Only creator or admin can edit."""
        gym_class = self._get_class_or_404(class_id)
        self._check_class_edit_permission(gym_class, requesting_user)

        for field, value in data.model_dump(exclude_none=True).items():
            setattr(gym_class, field, value)

        self.db.commit()
        self.db.refresh(gym_class)
        return gym_class

    def cancel_class(
        self,
        class_id: int,
        reason: Optional[str],
        cancelled_by: User,
    ) -> GymClass:
        """
        Cancel an entire class.

        - Marks the class as CANCELLED
        - Cancels all confirmed bookings
        - Clears the waitlist
        - (Phase 8) Would trigger notification emails to all booked members

        Only admins can cancel classes.
        """
        gym_class = self._get_class_or_404(class_id)

        if gym_class.status == ClassStatus.CANCELLED:
            raise HTTPException(
                status_code=400,
                detail="This class is already cancelled."
            )

        # Cancel all confirmed bookings
        cancelled_count = 0
        for booking in gym_class.bookings:
            if booking.status == BookingStatus.CONFIRMED:
                booking.status = BookingStatus.CANCELLED
                booking.cancelled_at = datetime.utcnow()
                booking.cancellation_reason = f"Class cancelled: {reason or 'No reason given'}"
                cancelled_count += 1

        # Clear the waitlist
        for entry in gym_class.waitlist:
            self.db.delete(entry)

        gym_class.status = ClassStatus.CANCELLED

        self.db.commit()
        self.db.refresh(gym_class)

        logger.info(
            f"Class #{class_id} cancelled. "
            f"{cancelled_count} bookings cancelled."
        )

        # TODO Phase 8: Send cancellation notifications to booked members

        return gym_class

    # ===================================================================
    # BOOKING
    # ===================================================================

    def book_class(
        self,
        class_id: int,
        user: User,
        request: BookingRequest,
    ) -> ClassBooking | ClassWaitlist:
        """
        Book a gym class for a member.

        Validation steps (in order):
        1. Class must exist and be SCHEDULED
        2. Class must be bookable (booking window open)
        3. Member must have an ACTIVE, non-expired membership
        4. Member must not have already booked this class
        5. If class is not full → create ClassBooking
        6. If class is full and waitlist_enabled → add to ClassWaitlist
        7. If class is full and no waitlist → raise error

        Returns ClassBooking on success, ClassWaitlist if added to queue.
        """
        gym_class = self._get_class_or_404(class_id)

        # 1. Class status check
        if gym_class.status != ClassStatus.SCHEDULED:
            raise HTTPException(
                status_code=400,
                detail=f"This class cannot be booked. Status: {gym_class.status.value}"
            )

        # 2. Booking window check
        if not gym_class.is_bookable:
            now = datetime.utcnow()
            if gym_class.start_time <= now:
                raise HTTPException(status_code=400, detail="This class has already started.")
            if gym_class.booking_opens_at and now < gym_class.booking_opens_at:
                raise HTTPException(
                    status_code=400,
                    detail=f"Bookings for this class open at {gym_class.booking_opens_at}."
                )
            if gym_class.booking_closes_at and now > gym_class.booking_closes_at:
                raise HTTPException(
                    status_code=400,
                    detail="Bookings for this class are now closed."
                )

        # 3. Membership check
        self._validate_active_membership(user.id)

        # 4. Duplicate booking check
        existing_booking = self.db.query(ClassBooking).filter(
            ClassBooking.user_id      == user.id,
            ClassBooking.gym_class_id == class_id,
            ClassBooking.status       == BookingStatus.CONFIRMED,
        ).first()
        if existing_booking:
            raise HTTPException(
                status_code=409,
                detail="You have already booked this class."
            )

        # Check if user is already on the waitlist
        existing_waitlist = self.db.query(ClassWaitlist).filter(
            ClassWaitlist.user_id      == user.id,
            ClassWaitlist.gym_class_id == class_id,
        ).first()
        if existing_waitlist:
            raise HTTPException(
                status_code=409,
                detail=f"You are already on the waitlist at position #{existing_waitlist.position}."
            )

        # 5 & 6. Book or waitlist
        if not gym_class.is_full:
            return self._create_booking(gym_class, user)
        elif gym_class.waitlist_enabled:
            return self._add_to_waitlist(gym_class, user)
        else:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"This class is fully booked ({gym_class.max_capacity} spots). "
                    "Waitlist is not available for this class."
                )
            )

    def _create_booking(self, gym_class: GymClass, user: User) -> ClassBooking:
        """Create a confirmed booking record."""
        booking = ClassBooking(
            user_id=user.id,
            gym_class_id=gym_class.id,
            status=BookingStatus.CONFIRMED,
        )
        self.db.add(booking)
        self.db.commit()
        self.db.refresh(booking)

        logger.info(
            f"Booking confirmed: user #{user.id} → "
            f"class #{gym_class.id} '{gym_class.name}'"
        )
        return booking

    def _add_to_waitlist(self, gym_class: GymClass, user: User) -> ClassWaitlist:
        """Add a member to the class waitlist at the next available position."""
        # Find the current last position
        last_position = (
            self.db.query(ClassWaitlist)
            .filter(ClassWaitlist.gym_class_id == gym_class.id)
            .count()
        )
        position = last_position + 1

        entry = ClassWaitlist(
            user_id=user.id,
            gym_class_id=gym_class.id,
            position=position,
        )
        self.db.add(entry)
        self.db.commit()
        self.db.refresh(entry)

        logger.info(
            f"Waitlist: user #{user.id} added at position #{position} "
            f"for class #{gym_class.id}"
        )

        # TODO Phase 8: Send "You're on the waitlist" notification
        return entry

    # ===================================================================
    # CANCELLATION WITH AUTO-PROMOTION
    # ===================================================================

    def cancel_booking(
        self,
        class_id: int,
        user: User,
        request: CancelBookingRequest,
    ) -> ClassBooking:
        """
        Cancel a member's booking for a class.

        After cancellation:
        - If there's a waitlist, the first person is automatically promoted
        - A notification is sent to the promoted member (Phase 8)

        Cancellation cutoff:
        - Members cannot cancel within cancellation_cutoff_hours of start time
        - Admins can always cancel regardless of cutoff
        """
        gym_class = self._get_class_or_404(class_id)

        # Find the booking
        booking = self.db.query(ClassBooking).filter(
            ClassBooking.user_id      == user.id,
            ClassBooking.gym_class_id == class_id,
            ClassBooking.status       == BookingStatus.CONFIRMED,
        ).first()

        if not booking:
            raise HTTPException(
                status_code=404,
                detail="No confirmed booking found for this class."
            )

        # Enforce cancellation cutoff (not applied to admins)
        if user.role != UserRole.ADMIN:
            cutoff_time = gym_class.start_time - timedelta(
                hours=gym_class.cancellation_cutoff_hours
            )
            if datetime.utcnow() > cutoff_time:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Cannot cancel within {gym_class.cancellation_cutoff_hours} hours "
                        f"of class start time ({gym_class.start_time.strftime('%H:%M')})."
                    )
                )

        # Cancel the booking
        booking.status              = BookingStatus.CANCELLED
        booking.cancelled_at        = datetime.utcnow()
        booking.cancellation_reason = request.reason

        self.db.flush()

        # Auto-promote the first person on the waitlist
        self._promote_from_waitlist(gym_class)

        self.db.commit()
        self.db.refresh(booking)

        logger.info(
            f"Booking cancelled: user #{user.id}, "
            f"class #{class_id}"
        )
        return booking

    def _promote_from_waitlist(self, gym_class: GymClass) -> None:
        """
        Promote the first person on the waitlist to a confirmed booking.
        Called automatically whenever a booking is cancelled.

        Steps:
        1. Find position=1 on the waitlist
        2. Create a confirmed booking for them
        3. Delete their waitlist entry
        4. Shift all other waitlist positions down by 1
        5. Send "You've been promoted!" notification (Phase 8)
        """
        first_in_line = (
            self.db.query(ClassWaitlist)
            .filter(ClassWaitlist.gym_class_id == gym_class.id)
            .order_by(ClassWaitlist.position.asc())
            .first()
        )

        if not first_in_line:
            return  # No one on the waitlist

        # Create confirmed booking for the promoted member
        new_booking = ClassBooking(
            user_id=first_in_line.user_id,
            gym_class_id=gym_class.id,
            status=BookingStatus.CONFIRMED,
        )
        self.db.add(new_booking)

        # Delete their waitlist entry
        promoted_user_id = first_in_line.user_id
        self.db.delete(first_in_line)

        # Shift remaining waitlist positions down by 1
        remaining = (
            self.db.query(ClassWaitlist)
            .filter(ClassWaitlist.gym_class_id == gym_class.id)
            .order_by(ClassWaitlist.position.asc())
            .all()
        )
        for i, entry in enumerate(remaining):
            entry.position = i + 1  # Re-number from 1

        logger.info(
            f"Waitlist promotion: user #{promoted_user_id} "
            f"promoted to confirmed booking for class #{gym_class.id}"
        )

        # TODO Phase 8: Send "Great news! A spot opened up" notification

    # ===================================================================
    # ATTENDANCE MARKING
    # ===================================================================

    def mark_attendance(
        self,
        class_id: int,
        request: MarkAttendanceRequest,
        marked_by: User,
    ) -> dict:
        """
        Mark attendance after a class ends.

        Staff provides a list of user IDs who attended.
        Everyone else with a CONFIRMED booking is marked NO_SHOW.

        This should be called shortly after the class ends.
        """
        gym_class = self._get_class_or_404(class_id)

        attended_ids = set(request.attended_user_ids)
        attended_count = 0
        no_show_count  = 0

        confirmed_bookings = [
            b for b in gym_class.bookings
            if b.status == BookingStatus.CONFIRMED
        ]

        for booking in confirmed_bookings:
            if booking.user_id in attended_ids:
                booking.status       = BookingStatus.ATTENDED
                booking.checked_in_at = datetime.utcnow()
                attended_count += 1
            else:
                booking.status = BookingStatus.NO_SHOW
                no_show_count  += 1

        # Mark the class as completed
        gym_class.status = ClassStatus.COMPLETED

        self.db.commit()

        logger.info(
            f"Attendance marked for class #{class_id}: "
            f"{attended_count} attended, {no_show_count} no-shows"
        )

        return {
            "class_id":      class_id,
            "attended":      attended_count,
            "no_show":       no_show_count,
            "class_status":  ClassStatus.COMPLETED,
        }

    # ===================================================================
    # QUERIES & SCHEDULE
    # ===================================================================

    def get_classes(
        self,
        category: Optional[str]  = None,
        trainer_id: Optional[int]= None,
        upcoming_only: bool       = True,
        date_from: Optional[datetime] = None,
        date_to:   Optional[datetime] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> List[GymClass]:
        """
        List gym classes with flexible filtering.
        By default returns upcoming scheduled classes only.
        """
        query = self.db.query(GymClass).filter(
            GymClass.status != ClassStatus.CANCELLED
        )

        if upcoming_only:
            query = query.filter(GymClass.start_time >= datetime.utcnow())
        if category:
            query = query.filter(GymClass.category == category)
        if trainer_id:
            query = query.filter(GymClass.trainer_id == trainer_id)
        if date_from:
            query = query.filter(GymClass.start_time >= date_from)
        if date_to:
            query = query.filter(GymClass.start_time <= date_to)

        return (
            query
            .order_by(GymClass.start_time.asc())
            .offset(skip)
            .limit(limit)
            .all()
        )

    def get_weekly_schedule(self, week_offset: int = 0) -> dict:
        """
        Return the gym's class schedule for a specific week.

        week_offset:
          0 = current week (Mon–Sun)
          1 = next week
         -1 = last week

        Returns classes grouped by day for easy calendar rendering.
        """
        now        = datetime.utcnow()
        # Find the Monday of the target week
        days_to_monday = now.weekday()  # 0=Mon, 6=Sun
        week_start = (now - timedelta(days=days_to_monday)
                      + timedelta(weeks=week_offset)).replace(
                          hour=0, minute=0, second=0, microsecond=0
                      )
        week_end   = week_start + timedelta(days=7)

        classes = self.get_classes(
            upcoming_only=False,
            date_from=week_start,
            date_to=week_end,
            limit=500,
        )

        # Group by date
        days_dict: dict[str, list] = {}
        current = week_start
        while current < week_end:
            days_dict[current.strftime("%Y-%m-%d")] = []
            current += timedelta(days=1)

        for cls in classes:
            day_key = cls.start_time.strftime("%Y-%m-%d")
            if day_key in days_dict:
                days_dict[day_key].append(cls)

        return {
            "week_start": week_start.strftime("%Y-%m-%d"),
            "week_end":   (week_end - timedelta(days=1)).strftime("%Y-%m-%d"),
            "days": [
                {"date": date, "classes": class_list}
                for date, class_list in days_dict.items()
            ],
        }

    def get_my_bookings(
        self,
        user_id: int,
        include_past: bool = False,
    ) -> List[ClassBooking]:
        """Get all bookings for a specific user."""
        query = (
            self.db.query(ClassBooking)
            .filter(ClassBooking.user_id == user_id)
            .join(GymClass, ClassBooking.gym_class_id == GymClass.id)
        )

        if not include_past:
            query = query.filter(GymClass.start_time >= datetime.utcnow())

        return query.order_by(GymClass.start_time.asc()).all()

    def get_waitlist_position(
        self,
        user_id: int,
        class_id: int,
    ) -> Optional[ClassWaitlist]:
        """Get a user's waitlist entry for a specific class."""
        return self.db.query(ClassWaitlist).filter(
            ClassWaitlist.user_id      == user_id,
            ClassWaitlist.gym_class_id == class_id,
        ).first()

    # ===================================================================
    # PRIVATE HELPERS
    # ===================================================================

    def _get_class_or_404(self, class_id: int) -> GymClass:
        c = self.db.query(GymClass).filter(GymClass.id == class_id).first()
        if not c:
            raise HTTPException(
                status_code=404,
                detail=f"Class #{class_id} not found."
            )
        return c

    def _validate_active_membership(self, user_id: int) -> None:
        """
        Check the user has an active, non-expired membership.
        Raises HTTP 403 if they don't.
        """
        membership = self.db.query(Membership).filter(
            Membership.user_id == user_id,
            Membership.status  == MembershipStatus.ACTIVE,
        ).first()

        if not membership or not membership.is_valid:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    "You need an active membership to book classes. "
                    "Please visit reception or the app to purchase one."
                )
            )

    def _check_class_edit_permission(
        self,
        gym_class: GymClass,
        user: User,
    ) -> None:
        """Only the assigned trainer or an admin can edit a class."""
        if user.role == UserRole.ADMIN:
            return
        if gym_class.trainer_id != user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only edit classes you are assigned to."
            )
