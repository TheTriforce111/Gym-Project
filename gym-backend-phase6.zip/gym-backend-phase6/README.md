# 📅 Phase 6 — Class Scheduling System

A full class management system: recurring schedules, capacity enforcement, waitlist with auto-promotion, attendance tracking, and cancellation cutoffs.

---

## 📁 New Files in Phase 6

```
app/
├── models/
│   └── gym_class.py          ← 3 models: GymClass, ClassBooking, ClassWaitlist
├── schemas/
│   └── gym_class.py          ← Rich schemas + calendar/schedule types
├── routers/
│   └── classes.py            ← 16 endpoints covering full class lifecycle
└── services/
    └── class_service.py      ← All business logic incl. auto-promotion & recurring generation

tests/
└── test_classes.py           ← Full test suite (booking, waitlist, cutoff, attendance)
```

---

## 📋 Endpoints

| Method | Endpoint                              | Auth          | Description                          |
|--------|---------------------------------------|---------------|--------------------------------------|
| POST   | `/api/classes/`                       | Trainer/Admin | Create class (one-off or recurring)  |
| GET    | `/api/classes/`                       | Any           | List upcoming classes                |
| GET    | `/api/classes/schedule/weekly`        | Any           | Weekly calendar view                 |
| GET    | `/api/classes/my-bookings`            | Any           | My upcoming bookings                 |
| GET    | `/api/classes/{id}`                   | Any           | Full class details + availability    |
| PATCH  | `/api/classes/{id}`                   | Trainer/Admin | Update class details                 |
| POST   | `/api/classes/{id}/cancel-class`      | Admin         | Cancel entire class                  |
| POST   | `/api/classes/{id}/book`              | Member        | Book or join waitlist                |
| POST   | `/api/classes/{id}/cancel-booking`    | Any           | Cancel your booking                  |
| GET    | `/api/classes/{id}/waitlist`          | Trainer/Admin | View full waitlist                   |
| GET    | `/api/classes/{id}/my-waitlist`       | Any           | Check your waitlist position         |
| POST   | `/api/classes/{id}/mark-attendance`   | Trainer/Admin | Mark attended / no-show              |
| GET    | `/api/classes/{id}/bookings`          | Trainer/Admin | All bookings for a class             |

---

## 🔄 Full Booking Lifecycle

```
Member requests to book
        │
        ▼
Is class SCHEDULED & bookable? ──No──► 400 Error
        │ Yes
        ▼
Does member have active membership? ──No──► 403 Error
        │ Yes
        ▼
Already booked? ──Yes──► 409 Conflict
        │ No
        ▼
Is class full?
    │           │
   No          Yes
    │           │
    ▼           ▼
Confirmed   Waitlist enabled?
Booking         │           │
            Yes             No
             │              │
             ▼              ▼
         Waitlist       400 "Class Full"
         Position
```

---

## ❄️ Waitlist Auto-Promotion

When a booking is cancelled, the next person in the waitlist is instantly promoted:

```
Before cancellation:        After member #1 cancels:
  Booking:  member_1 ✅       Booking:  member_2 ✅ (promoted!)
  Waitlist: member_2 (pos 1)  Waitlist: member_3 (pos 1, shifted)
            member_3 (pos 2)            member_4 (pos 2, shifted)
            member_4 (pos 3)
```

---

## 🔁 Recurring Classes

Creating a weekly class auto-generates all instances:

```json
POST /api/classes/
{
  "name": "Monday Yoga",
  "recurrence": "weekly",
  "start_time": "2025-02-03T09:00:00",
  "end_time":   "2025-02-03T10:00:00",
  "recurrence_end_date": "2025-03-03T09:00:00"
}
→ Creates 5 classes: Feb 3, 10, 17, 24, Mar 3
```

Each instance is an independent class (can be individually edited or cancelled).

---

## 📅 Weekly Calendar Response

```json
{
  "week_start": "2025-02-10",
  "week_end":   "2025-02-16",
  "days": [
    {
      "date": "2025-02-10",
      "classes": [
        { "name": "Morning Yoga", "start_time": "09:00", "spots_remaining": 8 }
      ]
    },
    { "date": "2025-02-11", "classes": [] },
    ...
  ]
}
```

---

## ⏰ Cancellation Cutoff

Configurable per class (default: 2 hours):

```
Class starts at 10:00am
Cutoff = 2 hours → must cancel before 8:00am
Member tries to cancel at 9:30am → 400 error

Admins always bypass the cutoff.
```

---

## ➡️ Next: Phase 7 — QR Attendance System

Adds QR code generation per user, scan-to-check-in at the gym entrance, duplicate prevention, and admin attendance reports.
