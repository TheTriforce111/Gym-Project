"""
tests/test_classes.py — Class Scheduling System Tests (Phase 6)

Run with:
    pytest tests/test_classes.py -v

Tests cover:
- Creating one-off and recurring classes
- Booking (success, duplicate, full class)
- Waitlist join and auto-promotion
- Cancellation cutoff enforcement
- Attendance marking (ATTENDED / NO_SHOW)
- Weekly schedule calendar view
- Access control (members can't create classes, etc.)
"""

import pytest
from datetime import datetime, timedelta
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.core.security import hash_password
from app.models.user import User, UserRole
from app.models.membership import Membership, MembershipPlan, MembershipStatus
from app.models.gym_class import (
    GymClass, ClassBooking, ClassWaitlist,
    BookingStatus, ClassStatus,
)

SQLALCHEMY_DATABASE_URL = "sqlite:///./test_classes.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
Base.metadata.create_all(bind=engine)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield


@pytest.fixture
def db():
    s = TestingSessionLocal()
    yield s
    s.close()


def _make_user(db, email, role):
    u = User(
        full_name=f"{role} User",
        email=email,
        hashed_password=hash_password("Pass1234"),
        role=role,
        is_active=True,
    )
    db.add(u)
    db.commit()
    resp = client.post("/api/auth/login", json={"email": email, "password": "Pass1234"})
    return {"user": u, "token": resp.json()["access_token"]}


def _give_membership(db, user_id):
    """Give a user an active membership so they can book classes."""
    m = Membership(
        user_id=user_id,
        plan=MembershipPlan.MONTHLY,
        status=MembershipStatus.ACTIVE,
        start_date=datetime.utcnow(),
        end_date=datetime.utcnow() + timedelta(days=30),
        price_paid=49.99,
    )
    db.add(m)
    db.commit()
    return m


@pytest.fixture
def admin(db):   return _make_user(db, "admin@gym.com",   UserRole.ADMIN)
@pytest.fixture
def trainer(db): return _make_user(db, "trainer@gym.com", UserRole.TRAINER)
@pytest.fixture
def member(db):
    data = _make_user(db, "member@gym.com", UserRole.MEMBER)
    _give_membership(db, data["user"].id)
    return data


def _future_class(trainer_token, name="Yoga Class", capacity=10, offset_hours=24):
    """Helper to create a class in the future via API."""
    start = datetime.utcnow() + timedelta(hours=offset_hours)
    end   = start + timedelta(hours=1)
    resp  = client.post(
        "/api/classes/",
        headers={"Authorization": f"Bearer {trainer_token}"},
        json={
            "name":         name,
            "category":     "yoga",
            "start_time":   start.isoformat(),
            "end_time":     end.isoformat(),
            "max_capacity": capacity,
            "waitlist_enabled": True,
        }
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


# ---------------------------------------------------------------------------
# Class Creation Tests
# ---------------------------------------------------------------------------

class TestClassCreation:

    def test_trainer_creates_class(self, trainer):
        """Trainer can create a single one-off class."""
        result = _future_class(trainer["token"], name="Morning HIIT")
        assert result["name"] == "Morning HIIT"
        assert result["status"] == "scheduled"

    def test_member_cannot_create_class(self, member):
        """Regular members cannot create classes."""
        start = (datetime.utcnow() + timedelta(hours=5)).isoformat()
        end   = (datetime.utcnow() + timedelta(hours=6)).isoformat()
        resp  = client.post(
            "/api/classes/",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={"name": "My Class", "start_time": start, "end_time": end}
        )
        assert resp.status_code == 403

    def test_create_recurring_weekly_class(self, trainer):
        """Creating a weekly recurring class generates multiple instances."""
        start_dt = datetime.utcnow() + timedelta(hours=5)
        end_dt   = start_dt + timedelta(hours=1)
        rec_end  = start_dt + timedelta(weeks=3)

        resp = client.post(
            "/api/classes/",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={
                "name":                 "Weekly Yoga",
                "category":             "yoga",
                "start_time":           start_dt.isoformat(),
                "end_time":             end_dt.isoformat(),
                "max_capacity":         15,
                "recurrence":           "weekly",
                "recurrence_end_date":  rec_end.isoformat(),
            }
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["count"] == 4   # 4 weeks: week 0, 1, 2, 3

    def test_end_time_before_start_rejected(self, trainer):
        """Creating a class where end_time ≤ start_time fails."""
        now  = datetime.utcnow() + timedelta(hours=5)
        resp = client.post(
            "/api/classes/",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={
                "name":       "Bad Class",
                "start_time": now.isoformat(),
                "end_time":   (now - timedelta(hours=1)).isoformat(),
            }
        )
        assert resp.status_code == 422


# ---------------------------------------------------------------------------
# Booking Tests
# ---------------------------------------------------------------------------

class TestBooking:

    def test_member_books_class_successfully(self, trainer, member):
        """Member with active membership can book a class."""
        gym_class = _future_class(trainer["token"], capacity=20)
        resp = client.post(
            f"/api/classes/{gym_class['id']}/book",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={}
        )
        assert resp.status_code == 201
        assert resp.json()["type"] == "booking"

    def test_duplicate_booking_rejected(self, trainer, member):
        """Cannot book the same class twice."""
        gym_class = _future_class(trainer["token"], capacity=20)
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})
        resp = client.post(f"/api/classes/{gym_class['id']}/book",
                           headers={"Authorization": f"Bearer {member['token']}"}, json={})
        assert resp.status_code == 409

    def test_member_without_membership_cannot_book(self, trainer, db):
        """Member with no active membership cannot book."""
        # Create member without a membership
        u = User(
            full_name="No Membership",
            email="nomem@gym.com",
            hashed_password=hash_password("Pass1234"),
            role=UserRole.MEMBER,
            is_active=True,
        )
        db.add(u)
        db.commit()
        resp = client.post("/api/auth/login",
                           json={"email": "nomem@gym.com", "password": "Pass1234"})
        token = resp.json()["access_token"]

        gym_class = _future_class(trainer["token"])
        resp = client.post(
            f"/api/classes/{gym_class['id']}/book",
            headers={"Authorization": f"Bearer {token}"},
            json={}
        )
        assert resp.status_code == 403

    def test_full_class_adds_to_waitlist(self, trainer, member, db):
        """When class is full, booking adds to waitlist instead."""
        # Create class with capacity 1
        gym_class = _future_class(trainer["token"], capacity=1)

        # Create a second member and give them membership
        u2 = _make_user(db, "member2@gym.com", UserRole.MEMBER)
        _give_membership(db, u2["user"].id)

        # First member takes the only spot
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})

        # Second member joins waitlist
        resp = client.post(
            f"/api/classes/{gym_class['id']}/book",
            headers={"Authorization": f"Bearer {u2['token']}"},
            json={}
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["type"] == "waitlist"
        assert data["position"] == 1


# ---------------------------------------------------------------------------
# Waitlist Auto-Promotion Tests
# ---------------------------------------------------------------------------

class TestWaitlistPromotion:

    def test_cancellation_promotes_waitlist(self, trainer, member, db):
        """
        When the only booker cancels, the waitlisted member
        gets automatically promoted to a confirmed booking.
        """
        gym_class = _future_class(trainer["token"], capacity=1)

        # Second member
        u2 = _make_user(db, "member2@gym.com", UserRole.MEMBER)
        _give_membership(db, u2["user"].id)

        # member books the only spot
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})

        # u2 joins waitlist
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {u2['token']}"}, json={})

        # member cancels
        client.post(
            f"/api/classes/{gym_class['id']}/cancel-booking",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={}
        )

        # u2 should now have a confirmed booking
        s = TestingSessionLocal()
        booking = s.query(ClassBooking).filter(
            ClassBooking.user_id      == u2["user"].id,
            ClassBooking.gym_class_id == gym_class["id"],
            ClassBooking.status       == BookingStatus.CONFIRMED,
        ).first()
        s.close()
        assert booking is not None, "Waitlist member was not promoted!"

        # Waitlist should be empty
        s = TestingSessionLocal()
        wl = s.query(ClassWaitlist).filter(
            ClassWaitlist.gym_class_id == gym_class["id"]
        ).all()
        s.close()
        assert len(wl) == 0

    def test_waitlist_positions_shift_after_promotion(self, trainer, member, db):
        """When position 1 is promoted, position 2 shifts to position 1."""
        gym_class = _future_class(trainer["token"], capacity=1)

        u2 = _make_user(db, "m2@gym.com", UserRole.MEMBER)
        u3 = _make_user(db, "m3@gym.com", UserRole.MEMBER)
        _give_membership(db, u2["user"].id)
        _give_membership(db, u3["user"].id)

        # member takes the spot; u2 and u3 waitlist
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {u2['token']}"}, json={})
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {u3['token']}"}, json={})

        # member cancels → u2 promoted, u3 shifts to position 1
        client.post(f"/api/classes/{gym_class['id']}/cancel-booking",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})

        s = TestingSessionLocal()
        u3_waitlist = s.query(ClassWaitlist).filter(
            ClassWaitlist.user_id      == u3["user"].id,
            ClassWaitlist.gym_class_id == gym_class["id"],
        ).first()
        s.close()
        assert u3_waitlist.position == 1


# ---------------------------------------------------------------------------
# Cancellation Cutoff Tests
# ---------------------------------------------------------------------------

class TestCancellationCutoff:

    def test_cannot_cancel_within_cutoff(self, trainer, member, db):
        """Members cannot cancel within the cutoff window."""
        # Class starting in 1 hour — cutoff is 2 hours
        start = datetime.utcnow() + timedelta(hours=1)
        end   = start + timedelta(hours=1)
        resp  = client.post(
            "/api/classes/",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={
                "name":       "Cutoff Test Class",
                "start_time": start.isoformat(),
                "end_time":   end.isoformat(),
                "max_capacity": 10,
                "cancellation_cutoff_hours": 2,
            }
        )
        class_id = resp.json()["id"]

        # Book it
        client.post(f"/api/classes/{class_id}/book",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})

        # Try to cancel within cutoff → should fail
        cancel_resp = client.post(
            f"/api/classes/{class_id}/cancel-booking",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={}
        )
        assert cancel_resp.status_code == 400
        assert "cannot cancel" in cancel_resp.json()["detail"].lower()

    def test_admin_can_always_cancel(self, trainer, admin, member, db):
        """Admins bypass the cancellation cutoff."""
        start = datetime.utcnow() + timedelta(minutes=30)
        end   = start + timedelta(hours=1)
        resp  = client.post(
            "/api/classes/",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={
                "name":       "Admin Cancel Test",
                "start_time": start.isoformat(),
                "end_time":   end.isoformat(),
                "max_capacity": 10,
                "cancellation_cutoff_hours": 24,
            }
        )
        class_id = resp.json()["id"]
        client.post(f"/api/classes/{class_id}/book",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})

        # Admin should be able to cancel despite cutoff
        # (Admin cancels entire class, which bypasses booking cutoff)
        cancel_resp = client.post(
            f"/api/classes/{class_id}/cancel-class",
            headers={"Authorization": f"Bearer {admin['token']}"},
        )
        assert cancel_resp.status_code == 200


# ---------------------------------------------------------------------------
# Attendance Tests
# ---------------------------------------------------------------------------

class TestAttendance:

    def test_mark_attendance(self, trainer, member, db):
        """Trainer can mark members as attended or no-show after class."""
        gym_class = _future_class(trainer["token"], capacity=10)

        # Book with member
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})

        # Mark member as attended
        resp = client.post(
            f"/api/classes/{gym_class['id']}/mark-attendance",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={"attended_user_ids": [member["user"].id]}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["attended"] == 1
        assert data["no_show"]  == 0

        # Booking should now be ATTENDED
        s = TestingSessionLocal()
        booking = s.query(ClassBooking).filter(
            ClassBooking.user_id      == member["user"].id,
            ClassBooking.gym_class_id == gym_class["id"],
        ).first()
        s.close()
        assert booking.status == BookingStatus.ATTENDED

    def test_no_show_marked_for_absent_members(self, trainer, member, db):
        """Members who booked but didn't show get marked NO_SHOW."""
        gym_class = _future_class(trainer["token"], capacity=10)
        client.post(f"/api/classes/{gym_class['id']}/book",
                    headers={"Authorization": f"Bearer {member['token']}"}, json={})

        # Mark attendance with an EMPTY list (no one attended)
        client.post(
            f"/api/classes/{gym_class['id']}/mark-attendance",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={"attended_user_ids": []}
        )

        s = TestingSessionLocal()
        booking = s.query(ClassBooking).filter(
            ClassBooking.user_id      == member["user"].id,
            ClassBooking.gym_class_id == gym_class["id"],
        ).first()
        s.close()
        assert booking.status == BookingStatus.NO_SHOW


# ---------------------------------------------------------------------------
# Schedule Tests
# ---------------------------------------------------------------------------

class TestSchedule:

    def test_weekly_schedule_returns_7_days(self, trainer):
        """Weekly schedule always returns exactly 7 days."""
        resp = client.get(
            "/api/classes/schedule/weekly",
            headers={"Authorization": f"Bearer {trainer['token']}"}
        )
        assert resp.status_code == 200
        assert len(resp.json()["days"]) == 7

    def test_class_appears_in_correct_day(self, trainer):
        """A class created for tomorrow appears in tomorrow's schedule slot."""
        tomorrow = datetime.utcnow() + timedelta(days=1)
        _future_class(trainer["token"], name="Tomorrow's Yoga", offset_hours=24)

        resp = client.get(
            "/api/classes/schedule/weekly",
            headers={"Authorization": f"Bearer {trainer['token']}"}
        )
        days = resp.json()["days"]
        tomorrow_key = tomorrow.strftime("%Y-%m-%d")
        tomorrow_day = next((d for d in days if d["date"] == tomorrow_key), None)

        if tomorrow_day:  # Only assert if tomorrow falls within this week
            names = [c["name"] for c in tomorrow_day["classes"]]
            assert "Tomorrow's Yoga" in names
