"""
tests/test_auth.py — Unit and integration tests for the authentication system

Tests cover:
- User registration (success, duplicate email, weak password)
- Login (success, wrong password, wrong email, deactivated account)
- Token refresh (valid, expired, wrong type)
- Password reset flow (OTP request, OTP verify, new password)
- Protected route access (with/without token, with expired token)
- Rate limiting behavior

How to run tests:
    pytest tests/ -v

Run a single test:
    pytest tests/test_auth.py::test_register_success -v

Run with coverage report:
    pytest tests/ --cov=app --cov-report=html
"""

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from unittest.mock import patch, MagicMock

from app.main import app
from app.core.database import Base, get_db
from app.models.user import User, UserRole
from app.core.security import hash_password

# ---------------------------------------------------------------------------
# Test database setup
# Uses SQLite in-memory for fast, isolated tests
# Each test gets a fresh database
# ---------------------------------------------------------------------------
SQLITE_TEST_URL = "sqlite:///./test.db"

engine = create_engine(
    SQLITE_TEST_URL,
    connect_args={"check_same_thread": False}
)
TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    """Replace the real DB dependency with the test database."""
    db = TestingSession()
    try:
        yield db
    finally:
        db.close()


# Override the database dependency for all tests
app.dependency_overrides[get_db] = override_get_db

# TestClient simulates HTTP requests to the app (no real server needed)
client = TestClient(app, raise_server_exceptions=False)


@pytest.fixture(autouse=True)
def setup_database():
    """
    Before each test: create all tables.
    After each test:  drop all tables (clean slate).
    autouse=True means this runs automatically for every test.
    """
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def sample_user_data():
    """Reusable test user registration data."""
    return {
        "full_name": "John Doe",
        "email": "john@example.com",
        "password": "SecurePass123",
        "phone": "+1234567890",
    }


@pytest.fixture
def registered_user(sample_user_data):
    """Register a user and return their data + tokens."""
    # Mock email so tests don't try to send real emails
    with patch("app.services.auth_service.send_welcome_email", return_value=True):
        response = client.post("/api/auth/register", json=sample_user_data)
    assert response.status_code == 201
    return sample_user_data


@pytest.fixture
def auth_tokens(registered_user):
    """Login and return JWT tokens for an authenticated user."""
    response = client.post("/api/auth/login", json={
        "email": registered_user["email"],
        "password": registered_user["password"],
    })
    assert response.status_code == 200
    return response.json()


# ---------------------------------------------------------------------------
# REGISTRATION TESTS
# ---------------------------------------------------------------------------

class TestRegistration:

    def test_register_success(self, sample_user_data):
        """A new user can register with valid data."""
        with patch("app.services.auth_service.send_welcome_email", return_value=True):
            response = client.post("/api/auth/register", json=sample_user_data)

        assert response.status_code == 201
        data = response.json()
        assert data["email"] == sample_user_data["email"]
        assert data["full_name"] == sample_user_data["full_name"]
        assert data["role"] == "member"        # Default role
        assert "hashed_password" not in data   # Password must NOT be in response
        assert "password" not in data

    def test_register_duplicate_email(self, sample_user_data):
        """Registering with an existing email returns HTTP 400."""
        with patch("app.services.auth_service.send_welcome_email", return_value=True):
            client.post("/api/auth/register", json=sample_user_data)
            response = client.post("/api/auth/register", json=sample_user_data)

        assert response.status_code == 400
        assert "already exists" in response.json()["detail"].lower()

    def test_register_weak_password(self, sample_user_data):
        """Password shorter than 8 characters is rejected."""
        sample_user_data["password"] = "short"
        response = client.post("/api/auth/register", json=sample_user_data)
        assert response.status_code == 422  # Pydantic validation error

    def test_register_invalid_email(self, sample_user_data):
        """Invalid email format is rejected."""
        sample_user_data["email"] = "not-an-email"
        response = client.post("/api/auth/register", json=sample_user_data)
        assert response.status_code == 422

    def test_register_missing_name(self, sample_user_data):
        """Missing full_name is rejected."""
        del sample_user_data["full_name"]
        response = client.post("/api/auth/register", json=sample_user_data)
        assert response.status_code == 422


# ---------------------------------------------------------------------------
# LOGIN TESTS
# ---------------------------------------------------------------------------

class TestLogin:

    def test_login_success(self, registered_user):
        """Valid credentials return access and refresh tokens."""
        response = client.post("/api/auth/login", json={
            "email": registered_user["email"],
            "password": registered_user["password"],
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"

    def test_login_wrong_password(self, registered_user):
        """Wrong password returns HTTP 401."""
        response = client.post("/api/auth/login", json={
            "email": registered_user["email"],
            "password": "wrongpassword",
        })
        assert response.status_code == 401

    def test_login_wrong_email(self):
        """Non-existent email returns HTTP 401 (same as wrong password)."""
        response = client.post("/api/auth/login", json={
            "email": "nobody@example.com",
            "password": "anypassword",
        })
        assert response.status_code == 401

    def test_login_deactivated_account(self, registered_user):
        """A deactivated user cannot log in."""
        # Deactivate the user directly in the database
        db = TestingSession()
        user = db.query(User).filter(User.email == registered_user["email"]).first()
        user.is_active = False
        db.commit()
        db.close()

        response = client.post("/api/auth/login", json={
            "email": registered_user["email"],
            "password": registered_user["password"],
        })
        assert response.status_code == 401


# ---------------------------------------------------------------------------
# TOKEN TESTS
# ---------------------------------------------------------------------------

class TestTokens:

    def test_get_current_user_with_valid_token(self, auth_tokens):
        """A valid access token grants access to /api/auth/me."""
        response = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {auth_tokens['access_token']}"}
        )
        assert response.status_code == 200
        assert "email" in response.json()

    def test_get_current_user_without_token(self):
        """No token returns HTTP 401."""
        response = client.get("/api/auth/me")
        assert response.status_code == 401

    def test_get_current_user_with_invalid_token(self):
        """A fake/tampered token returns HTTP 401."""
        response = client.get(
            "/api/auth/me",
            headers={"Authorization": "Bearer thisisnotavalidjwt"}
        )
        assert response.status_code == 401

    def test_refresh_token_success(self, auth_tokens):
        """A valid refresh token returns new access and refresh tokens."""
        response = client.post("/api/auth/refresh", json={
            "refresh_token": auth_tokens["refresh_token"]
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data

    def test_refresh_with_access_token_fails(self, auth_tokens):
        """Using an access token (not refresh) to refresh should fail."""
        response = client.post("/api/auth/refresh", json={
            "refresh_token": auth_tokens["access_token"]  # Wrong token type
        })
        assert response.status_code == 401

    def test_logout_blacklists_token(self, auth_tokens):
        """After logout, the access token should no longer work."""
        token = auth_tokens["access_token"]

        # Logout
        logout_response = client.post(
            "/api/auth/logout",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert logout_response.status_code == 200

        # Token should now be rejected
        me_response = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert me_response.status_code == 401


# ---------------------------------------------------------------------------
# PASSWORD RESET TESTS
# ---------------------------------------------------------------------------

class TestPasswordReset:

    def test_forgot_password_registered_email(self, registered_user):
        """Requesting OTP for a registered email returns success message."""
        with patch("app.services.auth_service.send_otp_email", return_value=True):
            with patch("app.services.otp_service.is_on_cooldown", return_value=False):
                response = client.post("/api/auth/forgot-password", json={
                    "email": registered_user["email"]
                })
        assert response.status_code == 200

    def test_forgot_password_unregistered_email(self):
        """Requesting OTP for a non-existent email returns same success message."""
        with patch("app.services.otp_service.is_on_cooldown", return_value=False):
            response = client.post("/api/auth/forgot-password", json={
                "email": "ghost@example.com"
            })
        # Same response to prevent email enumeration
        assert response.status_code == 200

    def test_verify_otp_invalid_format(self, registered_user):
        """OTP must be exactly 6 digits — letters are rejected."""
        response = client.post("/api/auth/verify-otp", json={
            "email": registered_user["email"],
            "otp": "abcdef"
        })
        assert response.status_code == 422

    def test_verify_otp_wrong_code(self, registered_user):
        """Wrong OTP returns HTTP 400."""
        with patch("app.services.auth_service.confirm_otp", return_value=(False, "Incorrect OTP. 4 attempt(s) remaining.")):
            response = client.post("/api/auth/verify-otp", json={
                "email": registered_user["email"],
                "otp": "000000"
            })
        assert response.status_code == 400

    def test_full_password_reset_flow(self, registered_user):
        """Happy path: request OTP → verify OTP → set new password."""
        email = registered_user["email"]

        # Step 1: Request OTP
        with patch("app.services.auth_service.send_otp_email", return_value=True):
            with patch("app.services.otp_service.is_on_cooldown", return_value=False):
                r1 = client.post("/api/auth/forgot-password", json={"email": email})
        assert r1.status_code == 200

        # Step 2: Verify OTP (mock the service to say it's correct)
        with patch("app.services.auth_service.confirm_otp", return_value=(True, "OTP verified.")):
            r2 = client.post("/api/auth/verify-otp", json={"email": email, "otp": "123456"})
        assert r2.status_code == 200

        # Step 3: Reset password
        with patch("app.services.auth_service.reset_password", return_value=(True, "Password reset successfully.")):
            r3 = client.post("/api/auth/reset-password", json={
                "email": email,
                "new_password": "NewPass123"
            })
        assert r3.status_code == 200
