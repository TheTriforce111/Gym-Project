# 🏋️ Gym Management System — Backend API

A production-ready backend for a full Gym Management System built with **FastAPI**, **PostgreSQL**, and **SQLAlchemy**.

---

## 📁 Project Structure

```
gym-backend/
├── app/
│   ├── main.py              # App entry point — registers all routes
│   ├── core/
│   │   ├── config.py        # Environment variables & settings
│   │   ├── database.py      # PostgreSQL connection setup
│   │   ├── security.py      # Password hashing & JWT tokens
│   │   └── dependencies.py  # Auth guards (get_current_user, require_admin)
│   ├── models/
│   │   ├── user.py          # User table (admins, trainers, members)
│   │   ├── membership.py    # Membership plans and status
│   │   ├── payment.py       # Payment transaction records
│   │   ├── workout.py       # Exercises, plans, and logs
│   │   ├── gym_class.py     # Gym classes and bookings
│   │   └── attendance.py    # QR check-in records
│   ├── schemas/
│   │   ├── user.py          # Request/response validation for users
│   │   ├── auth.py          # Login, token, OTP schemas
│   │   └── membership.py    # Membership schemas
│   ├── routers/
│   │   ├── auth.py          # /api/auth/* endpoints
│   │   ├── users.py         # /api/users/* endpoints
│   │   ├── memberships.py   # /api/memberships/* endpoints
│   │   ├── workouts.py      # /api/workouts/* endpoints
│   │   ├── classes.py       # /api/classes/* endpoints
│   │   └── attendance.py    # /api/attendance/* endpoints
│   ├── services/            # Business logic (email, payments, notifications)
│   └── utils/               # Helper functions
├── tests/                   # Unit and integration tests
├── .env.example             # Environment variable template
├── docker-compose.yml       # Local dev environment (PostgreSQL + Redis)
├── Dockerfile               # Container configuration
└── requirements.txt         # Python dependencies
```

---

## 🚀 Quick Start

### Option A: With Docker (Recommended)

```bash
# 1. Clone the project
git clone <your-repo-url>
cd gym-backend

# 2. Setup environment
cp .env.example .env
# Edit .env with your values

# 3. Start everything
docker-compose up -d

# 4. API is running at:
# http://localhost:8000
# http://localhost:8000/docs  ← Swagger UI (test all endpoints here)
```

### Option B: Without Docker

```bash
# 1. Create a virtual environment
python -m venv venv
source venv/bin/activate   # Mac/Linux
venv\Scripts\activate      # Windows

# 2. Install dependencies
pip install -r requirements.txt

# 3. Setup environment
cp .env.example .env
# Edit .env — set DATABASE_URL and REDIS_URL to your local instances

# 4. Start PostgreSQL and Redis locally, then run:
uvicorn app.main:app --reload

# API is running at http://localhost:8000
```

---

## 🔐 Authentication Flow

```
1. Register:   POST /api/auth/register     → Create account
2. Login:      POST /api/auth/login        → Get access + refresh tokens
3. Use API:    Add header: Authorization: Bearer <access_token>
4. Refresh:    POST /api/auth/refresh      → Get new access token when expired
```

---

## 👥 User Roles & Permissions

| Feature              | Member | Trainer | Admin |
|---------------------|--------|---------|-------|
| View own profile     | ✅     | ✅      | ✅    |
| Book a class         | ✅     | ✅      | ✅    |
| View own workouts    | ✅     | ✅      | ✅    |
| Create workout plans | ❌     | ✅      | ✅    |
| Create classes       | ❌     | ✅      | ✅    |
| Manage memberships   | ❌     | ❌      | ✅    |
| View all users       | ❌     | ❌      | ✅    |
| View all attendance  | ❌     | ❌      | ✅    |

---

## 📋 API Endpoints Summary

### Auth (`/api/auth`)
| Method | Endpoint            | Description              |
|--------|---------------------|--------------------------|
| POST   | `/register`         | Create new account       |
| POST   | `/login`            | Login, get JWT tokens    |
| POST   | `/refresh`          | Refresh access token     |
| POST   | `/forgot-password`  | Request OTP              |
| POST   | `/verify-otp`       | Verify OTP code          |
| POST   | `/reset-password`   | Set new password         |

### Users (`/api/users`)
| Method | Endpoint               | Description              |
|--------|------------------------|--------------------------|
| GET    | `/me`                  | Get my profile           |
| PUT    | `/me`                  | Update my profile        |
| POST   | `/me/change-password`  | Change my password       |
| GET    | `/`                    | List all users (Admin)   |
| GET    | `/{id}`                | Get user by ID (Admin)   |
| DELETE | `/{id}`                | Deactivate user (Admin)  |

### Memberships (`/api/memberships`)
| Method | Endpoint          | Description               |
|--------|-------------------|---------------------------|
| POST   | `/`               | Create membership (Admin) |
| GET    | `/me`             | Get my membership         |
| PUT    | `/{id}`           | Update membership (Admin) |
| POST   | `/{id}/freeze`    | Freeze membership (Admin) |
| POST   | `/{id}/cancel`    | Cancel membership (Admin) |

### Workouts (`/api/workouts`)
| Method | Endpoint           | Description               |
|--------|--------------------|---------------------------|
| GET    | `/exercises`       | List all exercises        |
| POST   | `/exercises`       | Add exercise (Trainer)    |
| POST   | `/plans`           | Create plan (Trainer)     |
| GET    | `/plans/me`        | My workout plans          |
| GET    | `/plans/{id}`      | Get specific plan         |
| POST   | `/logs`            | Log a workout session     |
| GET    | `/logs/me`         | My workout history        |

### Classes (`/api/classes`)
| Method | Endpoint                    | Description             |
|--------|-----------------------------|-------------------------|
| POST   | `/`                         | Create class (Trainer)  |
| GET    | `/`                         | List all classes        |
| GET    | `/{id}`                     | Get class details       |
| POST   | `/{id}/book`                | Book a class            |
| POST   | `/{id}/cancel-booking`      | Cancel booking          |
| GET    | `/my-bookings/list`         | My bookings             |

### Attendance (`/api/attendance`)
| Method | Endpoint         | Description                   |
|--------|------------------|-------------------------------|
| GET    | `/my-qr`         | Get my QR code (PNG image)    |
| GET    | `/my-qr-base64`  | Get QR code as base64 string  |
| POST   | `/check-in`      | Scan QR & check in            |
| GET    | `/me`            | My attendance history         |
| GET    | `/all`           | All attendance logs (Admin)   |

---

## 🧪 Testing the API

Open Swagger UI in your browser: **http://localhost:8000/docs**

This gives you an interactive interface to test all endpoints without any external tools.

---

## 🔧 Next Steps (Coming Phases)

- **Phase 4**: Stripe payment integration
- **Phase 8**: Email & push notification service (Celery + Firebase)
- **Phase 9**: Admin analytics dashboard endpoints
- **Phase 10**: React admin dashboard (frontend)
- **Phase 11**: Flutter mobile app

---

## 👨‍💻 Team Notes

- Always create a new branch for each feature: `git checkout -b feature/payment-integration`
- Run the server with `--reload` during development — it auto-restarts on code changes
- Use `/docs` endpoint to test APIs before connecting frontend
- All passwords are hashed with bcrypt — never store or log plain-text passwords
- The `.env` file is gitignored — share credentials securely with your team (not via Git)
