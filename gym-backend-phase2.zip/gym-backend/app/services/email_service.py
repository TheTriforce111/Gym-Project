"""
services/email_service.py — Email sending service

This service handles all outgoing emails from the gym system:
- OTP codes for password reset
- Welcome emails after registration
- Membership confirmation emails

We use Python's built-in smtplib with SMTP (Simple Mail Transfer Protocol).
In production you can swap this out for SendGrid, Mailgun, or AWS SES
by changing only this file — the rest of the code stays the same.

How it works:
  1. Connect to SMTP server (e.g. Gmail)
  2. Authenticate with credentials from .env
  3. Send the email using MIMEMultipart (supports HTML + plain text)
"""

import smtplib
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from app.core.config import settings

# Set up a logger for this module
# Logs appear in the terminal when the server is running
logger = logging.getLogger(__name__)


def send_email(to_email: str, subject: str, html_body: str, plain_body: str = "") -> bool:
    """
    Send an email to a single recipient.

    Args:
        to_email:   Recipient's email address
        subject:    Email subject line
        html_body:  HTML version of the email body
        plain_body: Plain text fallback (for email clients that don't render HTML)

    Returns:
        True if email was sent successfully, False if it failed.

    Example:
        success = send_email(
            to_email="member@example.com",
            subject="Your OTP Code",
            html_body="<h1>Your code is: 123456</h1>",
            plain_body="Your code is: 123456"
        )
    """
    try:
        # Create the email message container
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = settings.SMTP_USERNAME
        msg["To"]      = to_email

        # Attach plain text first, then HTML
        # Email clients prefer HTML but fall back to plain text if needed
        if plain_body:
            msg.attach(MIMEText(plain_body, "plain"))
        msg.attach(MIMEText(html_body, "html"))

        # Connect to SMTP server and send
        # SMTP_SSL uses port 465 (encrypted from the start)
        # starttls() is used for port 587 (starts unencrypted, then upgrades)
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
            server.ehlo()                           # Identify ourselves to the server
            server.starttls()                       # Upgrade to encrypted connection
            server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
            server.sendmail(settings.SMTP_USERNAME, to_email, msg.as_string())

        logger.info(f"Email sent successfully to {to_email} | Subject: {subject}")
        return True

    except smtplib.SMTPAuthenticationError:
        logger.error("SMTP authentication failed. Check SMTP_USERNAME and SMTP_PASSWORD in .env")
        return False
    except smtplib.SMTPException as e:
        logger.error(f"SMTP error when sending to {to_email}: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error sending email to {to_email}: {e}")
        return False


# ---------------------------------------------------------------------------
# Pre-built email templates
# ---------------------------------------------------------------------------

def send_otp_email(to_email: str, otp: str, full_name: str = "Member") -> bool:
    """
    Send a password reset OTP code to the user.

    Args:
        to_email:  User's email address
        otp:       The 6-digit OTP code
        full_name: User's name for personalization

    Returns:
        True if sent successfully, False otherwise.
    """
    subject = "🔐 Your Password Reset Code — Gym System"

    html_body = f"""
    <div style="font-family: Arial, sans-serif; max-width: 480px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #1a1a2e;">Password Reset Request</h2>
        <p>Hi <strong>{full_name}</strong>,</p>
        <p>We received a request to reset your password. Use the code below:</p>

        <div style="background: #f0f4ff; border-radius: 8px; padding: 20px; text-align: center; margin: 24px 0;">
            <p style="font-size: 36px; font-weight: bold; letter-spacing: 8px; color: #4f46e5; margin: 0;">
                {otp}
            </p>
            <p style="color: #666; font-size: 13px; margin-top: 8px;">
                This code expires in <strong>10 minutes</strong>
            </p>
        </div>

        <p>If you didn't request this, please ignore this email. Your password won't change.</p>
        <hr style="border: none; border-top: 1px solid #eee; margin: 24px 0;">
        <p style="color: #999; font-size: 12px;">
            This is an automated message from the Gym Management System.
        </p>
    </div>
    """

    plain_body = (
        f"Hi {full_name},\n\n"
        f"Your password reset code is: {otp}\n"
        f"This code expires in 10 minutes.\n\n"
        f"If you didn't request this, please ignore this email."
    )

    return send_email(to_email, subject, html_body, plain_body)


def send_welcome_email(to_email: str, full_name: str) -> bool:
    """
    Send a welcome email to a newly registered user.

    Args:
        to_email:  User's email address
        full_name: User's full name

    Returns:
        True if sent successfully, False otherwise.
    """
    subject = "🏋️ Welcome to the Gym — You're all set!"

    html_body = f"""
    <div style="font-family: Arial, sans-serif; max-width: 480px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #1a1a2e;">Welcome, {full_name}! 💪</h2>
        <p>Your account has been created successfully.</p>
        <p>Here's what you can do next:</p>
        <ul>
            <li>📱 Download the gym app and log in</li>
            <li>🏋️ View your workout plans</li>
            <li>📅 Book gym classes</li>
            <li>📊 Track your attendance with your QR code</li>
        </ul>
        <p>If you have any questions, contact our team at the front desk.</p>
        <p>See you at the gym! 🏃</p>
    </div>
    """

    plain_body = (
        f"Welcome, {full_name}!\n\n"
        f"Your account has been created successfully.\n"
        f"Log in to the gym app to get started.\n\n"
        f"See you at the gym!"
    )

    return send_email(to_email, subject, html_body, plain_body)


def send_membership_confirmation_email(
    to_email: str,
    full_name: str,
    plan: str,
    end_date: str,
    amount_paid: float,
) -> bool:
    """
    Send a membership confirmation email after purchase or renewal.

    Args:
        to_email:    User's email address
        full_name:   User's full name
        plan:        Plan name (e.g. "Monthly", "Yearly")
        end_date:    Membership expiry date as a string (e.g. "January 31, 2026")
        amount_paid: Amount charged (e.g. 150.00)

    Returns:
        True if sent successfully, False otherwise.
    """
    subject = "✅ Membership Confirmed — Gym System"

    html_body = f"""
    <div style="font-family: Arial, sans-serif; max-width: 480px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #1a1a2e;">Membership Confirmed! 🎉</h2>
        <p>Hi <strong>{full_name}</strong>, your membership has been activated.</p>

        <div style="background: #f0fdf4; border-radius: 8px; padding: 20px; margin: 24px 0;">
            <table style="width: 100%; font-size: 15px;">
                <tr>
                    <td style="color: #666; padding: 6px 0;">Plan</td>
                    <td style="font-weight: bold;">{plan}</td>
                </tr>
                <tr>
                    <td style="color: #666; padding: 6px 0;">Valid Until</td>
                    <td style="font-weight: bold;">{end_date}</td>
                </tr>
                <tr>
                    <td style="color: #666; padding: 6px 0;">Amount Paid</td>
                    <td style="font-weight: bold;">${amount_paid:.2f}</td>
                </tr>
            </table>
        </div>

        <p>You can now access all gym facilities. See you soon! 💪</p>
    </div>
    """

    plain_body = (
        f"Hi {full_name},\n\n"
        f"Your {plan} membership is now active.\n"
        f"Valid until: {end_date}\n"
        f"Amount paid: ${amount_paid:.2f}\n\n"
        f"See you at the gym!"
    )

    return send_email(to_email, subject, html_body, plain_body)
