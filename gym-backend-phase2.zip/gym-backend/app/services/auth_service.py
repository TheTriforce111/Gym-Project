"""
services/auth_service.py — Authentication business logic

This service layer sits between the router (HTTP layer) and the database.
Keeping business logic here (instead of directly in the router) means:
- Easier to test (no HTTP context needed)
- Easier to reuse across multiple routes
- Cleaner, more readable route handlers

Functions here handle:
- Registering new users
- Validating login credentials
- Managing the full password reset flow
- Blacklisting tokens on logout (via Redis)
"""

import logging
from datetime import timedelta
from typing import Optional

import redis
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import hash_password, verify_password, create_access_token, create_refresh_token, decode_token
from app.models.user import User, UserRole
from app.schemas.user import UserCreate
from app.services.email_service import send_welcome_email, send_otp_email
from app.services.otp_service import (
    generate_otp,
    store_otp,
    verify_otp,
    is_otp_verified,
    clear_otp_verification,
    is_on_cooldown,
    set_cooldown,
    get_cooldown_remaining,
)

logger = logging.getLogger(__name__)

# Redis client for token blacklisting (logout)
redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

def register_user(db: Session, user_data: UserCreate) -> tuple[Optional[User], Optional[str]]:
    """
    Register a new user account.

    Steps:
    1. Check if email already exists
    2. Hash the password
    3. Save user to database
    4. Send welcome email (non-blocking — failure doesn't stop registration)

    Args:
        db:        Database session
        user_data: Validated registration data (from Pydantic schema)

    Returns:
        (user, None)       on success
        (None, error_msg)  on failure
    """
    # Check for duplicate email (case-insensitive)
    existing = db.query(User).filter(
        User.email == user_data.email.lower().strip()
    ).first()

    if existing:
        return None, "An account with this email already exists."

    # Create the new user
    new_user = User(
        full_name=user_data.full_name.strip(),
        email=user_data.email.lower().strip(),
        phone=user_data.phone,
        hashed_password=hash_password(user_data.password),
        role=user_data.role or UserRole.MEMBER,
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Send welcome email — log warning if it fails, but don't crash the request
    email_sent = send_welcome_email(new_user.email, new_user.full_name)
    if not email_sent:
        logger.warning(f"Welcome email failed to send for {new_user.email} — user still created")

    logger.info(f"New user registered: {new_user.email} (role: {new_user.role})")
    return new_user, None


# ---------------------------------------------------------------------------
# LOGIN
# ---------------------------------------------------------------------------

def authenticate_user(db: Session, email: str, password: str) -> tuple[Optional[User], Optional[str]]:
    """
    Verify login credentials and return the user if valid.

    Security note: We return the same error message whether the email
    doesn't exist OR the password is wrong. This prevents "email enumeration"
    attacks where an attacker could determine if an email is registered.

    Args:
        db:       Database session
        email:    User's submitted email
        password: User's submitted plain-text password

    Returns:
        (user, None)       if credentials are valid
        (None, error_msg)  if invalid
    """
    user = db.query(User).filter(User.email == email.lower().strip()).first()

    # Same error for "not found" and "wrong password"
    if not user or not verify_password(password, user.hashed_password):
        return None, "Incorrect email or password."

    if not user.is_active:
        return None, "Your account has been deactivated. Please contact support."

    return user, None


def create_tokens_for_user(user: User) -> dict:
    """
    Generate both access and refresh JWT tokens for a user.

    The token payload contains:
    - "sub":  the user's ID (standard JWT "subject" claim)
    - "role": the user's role (used for RBAC in dependencies.py)

    Args:
        user: The authenticated User model instance

    Returns:
        Dict with access_token, refresh_token, and token_type
    """
    token_data = {
        "sub":  str(user.id),
        "role": user.role,
    }
    return {
        "access_token":  create_access_token(token_data),
        "refresh_token": create_refresh_token(token_data),
        "token_type":    "bearer",
    }


# ---------------------------------------------------------------------------
# TOKEN BLACKLISTING (Logout)
# ---------------------------------------------------------------------------

def blacklist_token(token: str) -> None:
    """
    Add a JWT token to the Redis blacklist on logout.

    When a user logs out, we store their token in Redis until it expires.
    The auth dependency checks this list on every request.

    Why this is needed:
    JWTs are stateless — they're valid until they expire, even after logout.
    Blacklisting lets us invalidate a token immediately on logout.

    Args:
        token: The JWT access token to invalidate
    """
    payload = decode_token(token)
    if payload:
        # Store in Redis until the token naturally expires
        exp = payload.get("exp")
        if exp:
            import time
            ttl = int(exp - time.time())
            if ttl > 0:
                redis_client.setex(f"blacklist:{token}", ttl, "1")
                logger.info(f"Token blacklisted for user_id={payload.get('sub')}")


def is_token_blacklisted(token: str) -> bool:
    """
    Check if a token has been blacklisted (i.e. user has logged out).

    Args:
        token: The JWT token to check

    Returns:
        True if blacklisted (should be rejected), False if valid.
    """
    return redis_client.exists(f"blacklist:{token}") == 1


# ---------------------------------------------------------------------------
# PASSWORD RESET FLOW
# ---------------------------------------------------------------------------

def request_password_reset(db: Session, email: str) -> tuple[bool, str]:
    """
    Step 1 of password reset: generate and send an OTP to the user's email.

    Security: We return the same message whether the email exists or not,
    to prevent email enumeration attacks.

    Args:
        db:    Database session
        email: The email address to send OTP to

    Returns:
        (True, success_message) or (False, error_message)
    """
    generic_message = "If that email is registered, you will receive an OTP shortly."

    # Rate limiting: prevent OTP spam
    if is_on_cooldown(email):
        seconds = get_cooldown_remaining(email)
        return False, f"Please wait {seconds} seconds before requesting another OTP."

    # Check if user exists (silently fail if not)
    user = db.query(User).filter(User.email == email.lower().strip()).first()
    if not user:
        logger.info(f"Password reset requested for non-existent email: {email}")
        return True, generic_message  # Don't reveal if email exists

    # Generate and store OTP
    otp = generate_otp()
    store_otp(email, otp)
    set_cooldown(email)

    # Send OTP via email
    sent = send_otp_email(email, otp, user.full_name)
    if not sent:
        logger.error(f"Failed to send OTP email to {email}")
        # Still return success to avoid leaking info, but log the failure

    logger.info(f"Password reset OTP sent to {email}")
    return True, generic_message


def confirm_otp(email: str, submitted_otp: str) -> tuple[bool, str]:
    """
    Step 2 of password reset: verify the OTP the user entered.

    Args:
        email:         The user's email
        submitted_otp: The OTP code the user entered

    Returns:
        (True, success_message) or (False, error_message)
    """
    success, message = verify_otp(email, submitted_otp)
    return success, message


def reset_password(db: Session, email: str, new_password: str) -> tuple[bool, str]:
    """
    Step 3 of password reset: set the new password.
    Only works if OTP has been verified in Step 2.

    Args:
        db:           Database session
        email:        The user's email
        new_password: The new plain-text password (will be hashed)

    Returns:
        (True, success_message) or (False, error_message)
    """
    # Verify OTP was confirmed
    if not is_otp_verified(email):
        return False, "OTP not verified. Please complete the verification step first."

    user = db.query(User).filter(User.email == email.lower().strip()).first()
    if not user:
        return False, "User not found."

    # Update the password (always hash — never store plain text)
    user.hashed_password = hash_password(new_password)
    db.commit()

    # Clean up all OTP-related Redis keys for this email
    clear_otp_verification(email)

    logger.info(f"Password reset successfully for user: {email}")
    return True, "Password reset successfully. Please log in with your new password."
