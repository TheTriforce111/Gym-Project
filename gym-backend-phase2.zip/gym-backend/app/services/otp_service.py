"""
services/otp_service.py — OTP (One-Time Password) management service

This service handles everything related to OTP codes:
- Generating secure 6-digit codes
- Storing them in Redis with automatic expiry
- Verifying submitted codes
- Marking codes as "used" to prevent reuse
- Rate limiting OTP requests to prevent abuse

Why Redis?
  Redis is an in-memory key-value store — perfect for temporary data like OTPs.
  We set a TTL (Time To Live) on each key, so expired OTPs are deleted automatically.
  No cleanup jobs needed!

Redis key structure:
  "otp:{email}"          → the OTP code itself (expires in 10 min)
  "otp_verified:{email}" → proof the OTP was verified (expires in 5 min)
  "otp_attempts:{email}" → count of failed attempts (expires in 15 min)
  "otp_cooldown:{email}" → blocks new OTP requests for 1 min after each send
"""

import random
import string
import logging
from datetime import timedelta

import redis

from app.core.config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Connect to Redis
# decode_responses=True means values come back as strings, not bytes
# ---------------------------------------------------------------------------
redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)

# ---------------------------------------------------------------------------
# Configuration constants
# ---------------------------------------------------------------------------
OTP_EXPIRY_MINUTES     = 10   # OTP expires after 10 minutes
VERIFIED_EXPIRY_MINUTES = 5   # Verified status expires after 5 minutes (window to reset password)
MAX_ATTEMPTS           = 5    # Max wrong OTP attempts before lockout
ATTEMPTS_WINDOW_MINUTES = 15  # Attempt counter resets after 15 minutes
COOLDOWN_SECONDS       = 60   # Must wait 60 seconds between OTP requests


def generate_otp(length: int = 6) -> str:
    """
    Generate a cryptographically secure numeric OTP code.

    Args:
        length: Number of digits (default 6)

    Returns:
        A string of random digits, e.g. "482917"

    Why string? Because "042917" would lose the leading zero as an integer.
    """
    return "".join(random.choices(string.digits, k=length))


def store_otp(email: str, otp: str) -> None:
    """
    Store the OTP in Redis with an expiry time.

    Args:
        email: The user's email (used as the key identifier)
        otp:   The generated OTP code to store

    Redis key: "otp:{email}"
    TTL: OTP_EXPIRY_MINUTES (10 minutes)
    """
    key = f"otp:{email}"
    redis_client.setex(key, timedelta(minutes=OTP_EXPIRY_MINUTES), otp)
    logger.info(f"OTP stored for {email} — expires in {OTP_EXPIRY_MINUTES} minutes")


def is_on_cooldown(email: str) -> bool:
    """
    Check if the user must wait before requesting another OTP.
    Prevents spamming the "forgot password" endpoint.

    Returns:
        True if the user is on cooldown (must wait), False if they can request a new OTP.
    """
    key = f"otp_cooldown:{email}"
    return redis_client.exists(key) == 1


def set_cooldown(email: str) -> None:
    """
    Start the cooldown timer after an OTP is sent.
    The user must wait COOLDOWN_SECONDS before requesting a new OTP.

    Args:
        email: The user's email
    """
    key = f"otp_cooldown:{email}"
    redis_client.setex(key, COOLDOWN_SECONDS, "1")


def get_cooldown_remaining(email: str) -> int:
    """
    Get how many seconds remain on the cooldown timer.

    Returns:
        Number of seconds remaining, or 0 if no cooldown.
    """
    key = f"otp_cooldown:{email}"
    ttl = redis_client.ttl(key)
    return max(ttl, 0)


def verify_otp(email: str, submitted_otp: str) -> tuple[bool, str]:
    """
    Verify that the submitted OTP matches the stored one.

    This function also:
    - Tracks failed attempts to prevent brute-force attacks
    - Locks out the user after MAX_ATTEMPTS failures
    - Marks the OTP as verified on success (for the password reset step)
    - Deletes the OTP after successful verification (one-time use)

    Args:
        email:         The user's email
        submitted_otp: The OTP code the user entered

    Returns:
        A tuple of (success: bool, message: str)
        - (True, "OTP verified successfully.")
        - (False, "Invalid OTP. 3 attempts remaining.")
        - (False, "Too many failed attempts. Request a new OTP.")
        - (False, "OTP has expired. Please request a new one.")
    """
    otp_key      = f"otp:{email}"
    attempts_key = f"otp_attempts:{email}"

    # Check if too many failed attempts
    attempts = int(redis_client.get(attempts_key) or 0)
    if attempts >= MAX_ATTEMPTS:
        return False, f"Too many failed attempts. Please request a new OTP."

    # Check if OTP exists (might have expired)
    stored_otp = redis_client.get(otp_key)
    if stored_otp is None:
        return False, "OTP has expired or does not exist. Please request a new one."

    # Check if OTP matches
    if stored_otp != submitted_otp:
        # Increment the failed attempts counter
        redis_client.incr(attempts_key)
        redis_client.expire(attempts_key, timedelta(minutes=ATTEMPTS_WINDOW_MINUTES))

        remaining = MAX_ATTEMPTS - (attempts + 1)
        if remaining <= 0:
            return False, "Too many failed attempts. Please request a new OTP."
        return False, f"Incorrect OTP. {remaining} attempt(s) remaining."

    # ✅ OTP is correct!
    # Delete the OTP so it can't be reused
    redis_client.delete(otp_key)
    redis_client.delete(attempts_key)

    # Mark this email as OTP-verified for the next step (password reset)
    verified_key = f"otp_verified:{email}"
    redis_client.setex(verified_key, timedelta(minutes=VERIFIED_EXPIRY_MINUTES), "true")

    logger.info(f"OTP verified successfully for {email}")
    return True, "OTP verified successfully."


def is_otp_verified(email: str) -> bool:
    """
    Check if the user has completed OTP verification.
    Used before allowing password reset.

    Returns:
        True if verified, False if not (or expired).
    """
    key = f"otp_verified:{email}"
    return redis_client.exists(key) == 1


def clear_otp_verification(email: str) -> None:
    """
    Clear all OTP-related keys for a user after password reset is complete.
    Cleanup after the full password reset flow is done.

    Args:
        email: The user's email
    """
    redis_client.delete(f"otp:{email}")
    redis_client.delete(f"otp_verified:{email}")
    redis_client.delete(f"otp_attempts:{email}")
    logger.info(f"OTP data cleared for {email} after password reset")
