"""
routers/workouts.py — Workout management API endpoints

This router handles:
- GET  /api/workouts/exercises        → List all exercises
- POST /api/workouts/exercises        → Add exercise (Admin/Trainer)
- POST /api/workouts/plans            → Create workout plan (Trainer/Admin)
- GET  /api/workouts/plans/me         → Get current user's plans
- GET  /api/workouts/plans/{id}       → Get a specific plan
- POST /api/workouts/logs             → Log a completed workout
- GET  /api/workouts/logs/me          → Get personal workout history
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_trainer
from app.models.workout import Exercise, WorkoutEntry, WorkoutLog, WorkoutPlan
from app.models.user import User

router = APIRouter()


# ---------------------------------------------------------------------------
# Inline schemas (simple enough to define here)
# ---------------------------------------------------------------------------
class ExerciseCreate(BaseModel):
    name: str
    description: Optional[str] = None
    muscle_group: Optional[str] = None
    equipment: Optional[str] = None
    video_url: Optional[str] = None


class WorkoutEntryCreate(BaseModel):
    exercise_id: int
    sets: int = 3
    reps: int = 10
    weight_kg: Optional[float] = None
    rest_seconds: int = 60
    notes: Optional[str] = None


class WorkoutPlanCreate(BaseModel):
    name: str
    description: Optional[str] = None
    user_id: int         # Who this plan is for
    entries: List[WorkoutEntryCreate]  # List of exercises in the plan


class WorkoutLogCreate(BaseModel):
    plan_id: Optional[int] = None
    duration_minutes: Optional[int] = None
    notes: Optional[str] = None


# ---------------------------------------------------------------------------
# EXERCISE LIBRARY
# ---------------------------------------------------------------------------
@router.get("/exercises")
def list_exercises(
    muscle_group: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Get all exercises in the library.
    Optionally filter by muscle group (e.g. ?muscle_group=Chest).
    """
    query = db.query(Exercise)
    if muscle_group:
        query = query.filter(Exercise.muscle_group.ilike(f"%{muscle_group}%"))
    return query.all()


@router.post("/exercises")
def add_exercise(
    data: ExerciseCreate,
    trainer: User = Depends(require_trainer),  # Only trainers/admins
    db: Session = Depends(get_db),
):
    """Add a new exercise to the library. Trainer/Admin only."""
    # Check for duplicate exercise name
    existing = db.query(Exercise).filter(Exercise.name.ilike(data.name)).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Exercise '{data.name}' already exists.")

    exercise = Exercise(**data.model_dump())
    db.add(exercise)
    db.commit()
    db.refresh(exercise)
    return exercise


# ---------------------------------------------------------------------------
# WORKOUT PLANS
# ---------------------------------------------------------------------------
@router.post("/plans")
def create_workout_plan(
    data: WorkoutPlanCreate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Create a new workout plan and assign it to a member.
    Trainers and Admins only.

    The plan includes a list of exercises with sets, reps, and weights.
    """
    # Create the plan
    plan = WorkoutPlan(
        name=data.name,
        description=data.description,
        user_id=data.user_id,
        created_by=trainer.id,
    )
    db.add(plan)
    db.flush()  # flush to get plan.id before adding entries

    # Add each exercise entry to the plan
    for entry_data in data.entries:
        # Verify the exercise exists
        exercise = db.query(Exercise).filter(Exercise.id == entry_data.exercise_id).first()
        if not exercise:
            raise HTTPException(
                status_code=404,
                detail=f"Exercise with ID {entry_data.exercise_id} not found."
            )
        entry = WorkoutEntry(plan_id=plan.id, **entry_data.model_dump())
        db.add(entry)

    db.commit()
    db.refresh(plan)
    return plan


@router.get("/plans/me")
def get_my_plans(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get all workout plans assigned to the current user."""
    plans = db.query(WorkoutPlan).filter(WorkoutPlan.user_id == current_user.id).all()
    return plans


@router.get("/plans/{plan_id}")
def get_plan(
    plan_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Get a specific workout plan by ID.
    Members can only view their own plans. Trainers/Admins can view any plan.
    """
    plan = db.query(WorkoutPlan).filter(WorkoutPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Workout plan not found.")

    # Access control: members can only view their own plans
    if current_user.role == "member" and plan.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied.")

    return plan


# ---------------------------------------------------------------------------
# WORKOUT LOGS (Progress Tracking)
# ---------------------------------------------------------------------------
@router.post("/logs")
def log_workout(
    data: WorkoutLogCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Log a completed workout session.
    Members call this after finishing a workout to track their progress.
    """
    log = WorkoutLog(
        user_id=current_user.id,
        plan_id=data.plan_id,
        duration_minutes=data.duration_minutes,
        notes=data.notes,
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return log


@router.get("/logs/me")
def get_my_workout_history(
    limit: int = 20,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Get the current user's workout history (most recent first).
    Used for progress tracking on the mobile app.
    """
    logs = (
        db.query(WorkoutLog)
        .filter(WorkoutLog.user_id == current_user.id)
        .order_by(WorkoutLog.date.desc())
        .limit(limit)
        .all()
    )
    return logs
