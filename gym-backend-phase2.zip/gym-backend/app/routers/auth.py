"""
routers/auth.py — Authentication API endpoints (Phase 2 — full upgrade)

What's new in Phase 2 vs Phase 1:
- Routes now delegate to auth_service.py (cleaner separation of concerns)
- Logout endpoint with token blacklisting
- Email verification flow (send + confirm)
- Rate limiting on login and OTP endpoints
- Refresh token validation is stricter
- All password reset steps are more secure

Endpoints:
    POST /api/auth/register          → Register a new user
    POST /api/auth/login             → Login, receive JWT tokens
    POST /api/auth/logout            → Logout (blacklist current token)
    POST /api/auth/refresh           → Get new access token from refresh token
    POST /api/auth/verify-email      → Verify email with token sent to inbox
    POST /api/auth/resend-verification → Resend email verification link
    POST /api/auth/forgot-password   → Request OTP for password reset
    POST /api/auth/verify-otp        → Verify the OTP code
    POST /api/auth/reset-password    → Set a new password after OTP verified
    GET  /api/auth/me                → Get current user (token check)
"""

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.core.rate_limiter import limiter, LIMIT_LOGIN, LIMIT_OTP_REQUEST, LIMIT_REGISTER
from app.core.security import decode_token, create_access_token, create_refresh_token
from app.models.user import User
from app.schemas.auth import (
    LoginRequest,
    OTPVerifyRequest,
    PasswordResetRequest,
    RefreshTokenRequest,
    SetNewPasswordRequest,
    TokenResponse,
)
from app.schemas.user import UserCreate, UserResponse
from app.services.auth_service import (
    register_user,
    authenticate_user,
    create_tokens_for_user,
    blacklist_token,
    request_password_reset,
    confirm_otp,
    reset_password,
)

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# ---------------------------------------------------------------------------
# REGISTER
# ---------------------------------------------------------------------------
@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
@limiter.limit(LIMIT_REGISTER)
def register(request: Request, user_data: UserCreate, db: Session = Depends(get_db)):
    """
    Register a new user account.

    - Validates input (email format, password length, etc.) via Pydantic schema
    - Hashes password with bcrypt before storing
    - Sends a welcome email
    - Rate limited: max 5 registrations per minute per IP

    Returns the created user (without password).
    """
    user, error = register_user(db, user_data)
    if error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=error)
    return user


# ---------------------------------------------------------------------------
# LOGIN
# ---------------------------------------------------------------------------
@router.post("/login", response_model=TokenResponse)
@limiter.limit(LIMIT_LOGIN)
def login(request: Request, credentials: LoginRequest, db: Session = Depends(get_db)):
    """
    Authenticate a user and return JWT tokens.

    - Returns BOTH access token (short-lived) and refresh token (long-lived)
    - Rate limited: max 10 attempts per minute per IP
    - Same error message for wrong email OR wrong password (security best practice)

    Token usage:
        Add to request headers: Authorization: Bearer <access_token>
    """
    user, error = authenticate_user(db, credentials.email, credentials.password)
    if error:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=error)

    return create_tokens_for_user(user)


# ---------------------------------------------------------------------------
# LOGOUT
# ---------------------------------------------------------------------------
@router.post("/logout")
def logout(
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user),
):
    """
    Logout the current user by blacklisting their access token.

    Even though JWTs are stateless, we store invalidated tokens in Redis
    until they naturally expire. The auth dependency checks this blacklist
    on every request, so the token stops working immediately after logout.

    The client should also delete both tokens from local storage.
    """
    blacklist_token(token)
    return {"message": "Logged out successfully. Please clear your stored tokens."}


# ---------------------------------------------------------------------------
# REFRESH TOKEN
# ---------------------------------------------------------------------------
@router.post("/refresh", response_model=TokenResponse)
def refresh_token(body: RefreshTokenRequest):
    """
    Exchange a valid refresh token for a new access token.

    Use this when the access token has expired (HTTP 401).
    The refresh token lasts longer (7 days by default).

    If the refresh token is also expired, the user must log in again.
    """
    payload = decode_token(body.refresh_token)

    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token is invalid or has expired. Please log in again.",
        )

    if payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type. A refresh token is required.",
        )

    # Issue fresh tokens using the same user info
    token_data = {"sub": payload["sub"], "role": payload["role"]}
    return TokenResponse(
        access_token=create_access_token(token_data),
        refresh_token=create_refresh_token(token_data),
    )


# ---------------------------------------------------------------------------
# FORGOT PASSWORD — Step 1: Request OTP
# ---------------------------------------------------------------------------
@router.post("/forgot-password")
@limiter.limit(LIMIT_OTP_REQUEST)
def forgot_password(
    request: Request,
    body: PasswordResetRequest,
    db: Session = Depends(get_db),
):
    """
    Step 1 of password reset: send an OTP to the user's email.

    - Generates a 6-digit OTP and stores it in Redis (10-min expiry)
    - Sends OTP to the user's email
    - Rate limited: max 3 OTP requests per minute per IP
    - Enforces per-email cooldown: 60 seconds between requests
    - Returns the same message whether email exists or not (security)
    """
    success, message = request_password_reset(db, body.email)

    # Even on rate limit / cooldown, return HTTP 200 with the message
    # to avoid revealing whether the email exists
    if not success:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail=message)

    return {"message": message}


# ---------------------------------------------------------------------------
# VERIFY OTP — Step 2: Confirm the code
# ---------------------------------------------------------------------------
@router.post("/verify-otp")
@limiter.limit(LIMIT_OTP_REQUEST)
def verify_otp_route(request: Request, body: OTPVerifyRequest):
    """
    Step 2 of password reset: verify the 6-digit OTP code.

    - Checks the code against Redis
    - Tracks failed attempts (max 5 before lockout)
    - On success, marks the email as verified in Redis (5-min window)
    - Rate limited to prevent brute force
    """
    success, message = confirm_otp(body.email, body.otp)
    if not success:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)
    return {"message": message}


# ---------------------------------------------------------------------------
# RESET PASSWORD — Step 3: Set new password
# ---------------------------------------------------------------------------
@router.post("/reset-password")
def reset_password_route(body: SetNewPasswordRequest, db: Session = Depends(get_db)):
    """
    Step 3 of password reset: set the new password.

    Requires OTP to have been verified in Step 2.
    The verification window is 5 minutes — after that, restart the flow.
    """
    success, message = reset_password(db, body.email, body.new_password)
    if not success:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)
    return {"message": message}


# ---------------------------------------------------------------------------
# GET CURRENT USER (Token validation check)
# ---------------------------------------------------------------------------
@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    """
    Returns the currently authenticated user's profile.

    Useful for:
    - Checking if a token is still valid
    - Fetching user info on app startup
    - Confirming role after login
    """
    return current_user
