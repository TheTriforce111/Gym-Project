"""
routers/users.py — User management API endpoints

This router handles:
- GET  /api/users/me          → Get current user's profile
- PUT  /api/users/me          → Update current user's profile
- POST /api/users/me/change-password → Change own password
- GET  /api/users/            → List all users (Admin only)
- GET  /api/users/{id}        → Get a specific user (Admin only)
- DELETE /api/users/{id}      → Deactivate a user (Admin only)
"""

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.core.security import hash_password, verify_password
from app.models.user import User
from app.schemas.user import ChangePasswordRequest, UserResponse, UserUpdate

router = APIRouter()


# ---------------------------------------------------------------------------
# GET MY PROFILE
# ---------------------------------------------------------------------------
@router.get("/me", response_model=UserResponse)
def get_my_profile(current_user: User = Depends(get_current_user)):
    """
    Returns the profile of the currently logged-in user.
    The user is identified by their JWT access token.
    """
    return current_user


# ---------------------------------------------------------------------------
# UPDATE MY PROFILE
# ---------------------------------------------------------------------------
@router.put("/me", response_model=UserResponse)
def update_my_profile(
    update_data: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Update the current user's own profile (name, phone number).
    Users can only update their own profile, not others.
    """
    # Only update fields that were actually provided
    if update_data.full_name is not None:
        current_user.full_name = update_data.full_name
    if update_data.phone is not None:
        current_user.phone = update_data.phone

    db.commit()
    db.refresh(current_user)
    return current_user


# ---------------------------------------------------------------------------
# CHANGE MY PASSWORD
# ---------------------------------------------------------------------------
@router.post("/me/change-password")
def change_password(
    body: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Allows a logged-in user to change their own password.
    Requires knowing the current password first (for security).
    """
    # Verify current password before allowing the change
    if not verify_password(body.current_password, current_user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect."
        )

    current_user.hashed_password = hash_password(body.new_password)
    db.commit()

    return {"message": "Password changed successfully."}


# ---------------------------------------------------------------------------
# LIST ALL USERS (Admin only)
# ---------------------------------------------------------------------------
@router.get("/", response_model=List[UserResponse])
def list_users(
    skip: int = 0,
    limit: int = 50,
    admin: User = Depends(require_admin),  # Only admins can call this
    db: Session = Depends(get_db),
):
    """
    Returns a paginated list of all users in the system.
    Admin only.

    - skip:  How many records to skip (for pagination)
    - limit: Maximum records to return
    """
    users = db.query(User).offset(skip).limit(limit).all()
    return users


# ---------------------------------------------------------------------------
# GET USER BY ID (Admin only)
# ---------------------------------------------------------------------------
@router.get("/{user_id}", response_model=UserResponse)
def get_user(
    user_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Get a specific user's details by their ID. Admin only."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail=f"User with ID {user_id} not found.")
    return user


# ---------------------------------------------------------------------------
# DEACTIVATE USER (Admin only)
# ---------------------------------------------------------------------------
@router.delete("/{user_id}")
def deactivate_user(
    user_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Deactivate a user account (soft delete — doesn't remove from DB).
    Deactivated users cannot log in.
    Admin only.
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail=f"User with ID {user_id} not found.")

    if user.id == admin.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You cannot deactivate your own admin account."
        )

    user.is_active = False
    db.commit()

    return {"message": f"User '{user.full_name}' has been deactivated."}
