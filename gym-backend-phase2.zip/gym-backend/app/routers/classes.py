"""
routers/classes.py — Gym class scheduling API endpoints

This router handles:
- POST /api/classes/           → Create a class (Trainer/Admin)
- GET  /api/classes/           → List all upcoming classes
- GET  /api/classes/{id}       → Get class details
- POST /api/classes/{id}/book  → Book a class (Member)
- POST /api/classes/{id}/cancel-booking → Cancel a booking (Member)
- GET  /api/classes/my-bookings → Get current user's bookings
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_trainer
from app.models.gym_class import BookingStatus, ClassBooking, GymClass
from app.models.membership import Membership, MembershipStatus
from app.models.user import User

router = APIRouter()


# ---------------------------------------------------------------------------
# Inline schemas
# ---------------------------------------------------------------------------
class GymClassCreate(BaseModel):
    name: str
    description: Optional[str] = None
    trainer_id: Optional[int] = None
    start_time: datetime
    end_time: datetime
    location: Optional[str] = None
    max_capacity: int = 20


# ---------------------------------------------------------------------------
# CREATE CLASS (Trainer/Admin)
# ---------------------------------------------------------------------------
@router.post("/")
def create_class(
    data: GymClassCreate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Create a new gym class and schedule it.
    Trainers can create classes (they'll be assigned as the trainer).
    Admins can create classes for any trainer.
    """
    # Validate times
    if data.end_time <= data.start_time:
        raise HTTPException(status_code=400, detail="End time must be after start time.")

    gym_class = GymClass(
        name=data.name,
        description=data.description,
        trainer_id=data.trainer_id or trainer.id,
        start_time=data.start_time,
        end_time=data.end_time,
        location=data.location,
        max_capacity=data.max_capacity,
    )
    db.add(gym_class)
    db.commit()
    db.refresh(gym_class)
    return gym_class


# ---------------------------------------------------------------------------
# LIST UPCOMING CLASSES
# ---------------------------------------------------------------------------
@router.get("/")
def list_classes(
    upcoming_only: bool = True,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Get all gym classes.
    By default, only returns upcoming classes (start_time > now).
    Set upcoming_only=false to see all classes including past ones.
    """
    query = db.query(GymClass)
    if upcoming_only:
        query = query.filter(GymClass.start_time >= datetime.utcnow())
    return query.order_by(GymClass.start_time.asc()).all()


# ---------------------------------------------------------------------------
# GET CLASS DETAILS
# ---------------------------------------------------------------------------
@router.get("/{class_id}")
def get_class(
    class_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get details for a specific gym class, including current booking count."""
    gym_class = db.query(GymClass).filter(GymClass.id == class_id).first()
    if not gym_class:
        raise HTTPException(status_code=404, detail="Class not found.")

    # Build a response with capacity information
    return {
        "id": gym_class.id,
        "name": gym_class.name,
        "description": gym_class.description,
        "trainer_id": gym_class.trainer_id,
        "start_time": gym_class.start_time,
        "end_time": gym_class.end_time,
        "location": gym_class.location,
        "max_capacity": gym_class.max_capacity,
        "booked_count": gym_class.booked_count,
        "is_full": gym_class.is_full,
        "spots_remaining": gym_class.max_capacity - gym_class.booked_count,
    }


# ---------------------------------------------------------------------------
# BOOK A CLASS (Member)
# ---------------------------------------------------------------------------
@router.post("/{class_id}/book")
def book_class(
    class_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Book a gym class for the current user.

    Validations:
    1. Class must exist
    2. Class must not be in the past
    3. Class must not be full
    4. User must have an active membership
    5. User must not have already booked this class
    """
    gym_class = db.query(GymClass).filter(GymClass.id == class_id).first()
    if not gym_class:
        raise HTTPException(status_code=404, detail="Class not found.")

    # Can't book a class that already started
    if gym_class.start_time <= datetime.utcnow():
        raise HTTPException(status_code=400, detail="This class has already started or ended.")

    # Check capacity
    if gym_class.is_full:
        raise HTTPException(
            status_code=400,
            detail=f"This class is fully booked. Maximum capacity is {gym_class.max_capacity}."
        )

    # Check active membership
    membership = db.query(Membership).filter(
        Membership.user_id == current_user.id,
        Membership.status == MembershipStatus.ACTIVE,
    ).first()
    if not membership or membership.end_date < datetime.utcnow():
        raise HTTPException(
            status_code=403,
            detail="You need an active membership to book classes."
        )

    # Check for duplicate booking
    existing_booking = db.query(ClassBooking).filter(
        ClassBooking.user_id == current_user.id,
        ClassBooking.gym_class_id == class_id,
        ClassBooking.status == BookingStatus.CONFIRMED,
    ).first()
    if existing_booking:
        raise HTTPException(status_code=400, detail="You have already booked this class.")

    booking = ClassBooking(
        user_id=current_user.id,
        gym_class_id=class_id,
        status=BookingStatus.CONFIRMED,
    )
    db.add(booking)
    db.commit()
    db.refresh(booking)
    return {"message": "Class booked successfully!", "booking_id": booking.id}


# ---------------------------------------------------------------------------
# CANCEL BOOKING (Member)
# ---------------------------------------------------------------------------
@router.post("/{class_id}/cancel-booking")
def cancel_booking(
    class_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Cancel the current user's booking for a class."""
    booking = db.query(ClassBooking).filter(
        ClassBooking.user_id == current_user.id,
        ClassBooking.gym_class_id == class_id,
        ClassBooking.status == BookingStatus.CONFIRMED,
    ).first()

    if not booking:
        raise HTTPException(status_code=404, detail="No active booking found for this class.")

    booking.status = BookingStatus.CANCELLED
    booking.cancelled_at = datetime.utcnow()
    db.commit()

    return {"message": "Booking cancelled successfully."}


# ---------------------------------------------------------------------------
# MY BOOKINGS
# ---------------------------------------------------------------------------
@router.get("/my-bookings/list")
def get_my_bookings(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get all class bookings for the current user."""
    bookings = db.query(ClassBooking).filter(
        ClassBooking.user_id == current_user.id
    ).order_by(ClassBooking.booked_at.desc()).all()
    return bookings
