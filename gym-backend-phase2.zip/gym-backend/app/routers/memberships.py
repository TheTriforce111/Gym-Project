"""
routers/memberships.py — Membership management API endpoints

This router handles:
- POST /api/memberships/         → Create a new membership (Admin only)
- GET  /api/memberships/me       → Get current user's membership
- GET  /api/memberships/{id}     → Get membership by ID (Admin only)
- PUT  /api/memberships/{id}     → Update membership status (Admin only)
- POST /api/memberships/{id}/freeze → Freeze a membership
- POST /api/memberships/{id}/cancel → Cancel a membership
"""

from datetime import datetime, timedelta
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.models.membership import Membership, MembershipPlan, MembershipStatus
from app.models.user import User
from app.schemas.membership import MembershipCreate, MembershipResponse, MembershipUpdate

router = APIRouter()


def calculate_end_date(plan: MembershipPlan, start: datetime) -> datetime:
    """
    Calculate the membership end date based on plan type.
    - Monthly: +30 days
    - Yearly:  +365 days
    - Custom:  Admin sets end_date manually
    """
    if plan == MembershipPlan.MONTHLY:
        return start + timedelta(days=30)
    elif plan == MembershipPlan.YEARLY:
        return start + timedelta(days=365)
    else:
        # For custom plans, admin sets the date separately
        return start + timedelta(days=30)  # Default fallback


# ---------------------------------------------------------------------------
# CREATE MEMBERSHIP (Admin only)
# ---------------------------------------------------------------------------
@router.post("/", response_model=MembershipResponse)
def create_membership(
    data: MembershipCreate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Create a new membership for a user. Admin only.
    Automatically calculates the end date based on plan type.
    """
    # Check the user exists
    user = db.query(User).filter(User.id == data.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    # Check if user already has an active membership
    existing = db.query(Membership).filter(
        Membership.user_id == data.user_id,
        Membership.status == MembershipStatus.ACTIVE
    ).first()

    if existing:
        raise HTTPException(
            status_code=400,
            detail="This user already has an active membership. Renew or cancel it first."
        )

    start_date = datetime.utcnow()
    membership = Membership(
        user_id=data.user_id,
        plan=data.plan,
        status=MembershipStatus.ACTIVE,
        start_date=start_date,
        end_date=calculate_end_date(data.plan, start_date),
        price_paid=data.price_paid,
        notes=data.notes,
    )

    db.add(membership)
    db.commit()
    db.refresh(membership)
    return membership


# ---------------------------------------------------------------------------
# GET MY MEMBERSHIP
# ---------------------------------------------------------------------------
@router.get("/me", response_model=MembershipResponse)
def get_my_membership(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Returns the current user's active membership details."""
    membership = db.query(Membership).filter(
        Membership.user_id == current_user.id
    ).first()

    if not membership:
        raise HTTPException(
            status_code=404,
            detail="You don't have a membership yet. Please contact the gym."
        )
    return membership


# ---------------------------------------------------------------------------
# GET MEMBERSHIP BY ID (Admin only)
# ---------------------------------------------------------------------------
@router.get("/{membership_id}", response_model=MembershipResponse)
def get_membership(
    membership_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Get any membership by ID. Admin only."""
    membership = db.query(Membership).filter(Membership.id == membership_id).first()
    if not membership:
        raise HTTPException(status_code=404, detail="Membership not found.")
    return membership


# ---------------------------------------------------------------------------
# UPDATE MEMBERSHIP (Admin only)
# ---------------------------------------------------------------------------
@router.put("/{membership_id}", response_model=MembershipResponse)
def update_membership(
    membership_id: int,
    data: MembershipUpdate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Update a membership's status or end date. Admin only."""
    membership = db.query(Membership).filter(Membership.id == membership_id).first()
    if not membership:
        raise HTTPException(status_code=404, detail="Membership not found.")

    if data.status is not None:
        membership.status = data.status
    if data.end_date is not None:
        membership.end_date = data.end_date
    if data.notes is not None:
        membership.notes = data.notes

    db.commit()
    db.refresh(membership)
    return membership


# ---------------------------------------------------------------------------
# FREEZE MEMBERSHIP (Admin only)
# ---------------------------------------------------------------------------
@router.post("/{membership_id}/freeze")
def freeze_membership(
    membership_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Freeze a membership (e.g. member is injured or traveling).
    Frozen memberships don't allow gym check-in.
    """
    membership = db.query(Membership).filter(Membership.id == membership_id).first()
    if not membership:
        raise HTTPException(status_code=404, detail="Membership not found.")

    membership.status = MembershipStatus.FROZEN
    db.commit()
    return {"message": "Membership has been frozen."}


# ---------------------------------------------------------------------------
# CANCEL MEMBERSHIP (Admin only)
# ---------------------------------------------------------------------------
@router.post("/{membership_id}/cancel")
def cancel_membership(
    membership_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Cancel a membership permanently."""
    membership = db.query(Membership).filter(Membership.id == membership_id).first()
    if not membership:
        raise HTTPException(status_code=404, detail="Membership not found.")

    membership.status = MembershipStatus.CANCELLED
    db.commit()
    return {"message": "Membership has been cancelled."}
