"""
routers/attendance.py — QR Code Attendance System API endpoints

This router handles:
- GET  /api/attendance/my-qr      → Get current user's QR code
- POST /api/attendance/check-in   → Scan QR and check in
- GET  /api/attendance/me         → Get personal attendance history
- GET  /api/attendance/all        → Get all attendance records (Admin only)
"""

from datetime import datetime, date
from io import BytesIO
import base64

import qrcode
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.models.attendance import Attendance
from app.models.membership import Membership, MembershipStatus
from app.models.user import User

router = APIRouter()


def generate_qr_code_image(data: str) -> bytes:
    """
    Generate a QR code image from the given data string.
    Returns the image as bytes (PNG format).

    The QR data for a user is typically their unique user ID or a signed token.
    """
    qr = qrcode.QRCode(
        version=1,              # Size of QR code (1 = smallest)
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,            # Size of each box in pixels
        border=4,               # White border around the QR code
    )
    qr.add_data(data)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# GET MY QR CODE
# ---------------------------------------------------------------------------
@router.get("/my-qr")
def get_my_qr_code(current_user: User = Depends(get_current_user)):
    """
    Returns a PNG QR code image for the current user.
    The QR code encodes the user's ID — staff scan it to check them in.

    Response: PNG image stream
    """
    # The QR code encodes "GYM:user_id" as a simple unique identifier
    qr_data = f"GYM:{current_user.id}"
    image_bytes = generate_qr_code_image(qr_data)

    return StreamingResponse(
        BytesIO(image_bytes),
        media_type="image/png",
        headers={"Content-Disposition": f"inline; filename=qr_{current_user.id}.png"}
    )


@router.get("/my-qr-base64")
def get_my_qr_base64(current_user: User = Depends(get_current_user)):
    """
    Returns the QR code as a base64-encoded string.
    Useful for embedding in mobile apps: <img src="data:image/png;base64,..." />
    """
    qr_data = f"GYM:{current_user.id}"
    image_bytes = generate_qr_code_image(qr_data)
    encoded = base64.b64encode(image_bytes).decode("utf-8")

    return {"qr_code_base64": encoded, "user_id": current_user.id}


# ---------------------------------------------------------------------------
# CHECK IN (scan QR code)
# ---------------------------------------------------------------------------
class CheckInRequest(BaseModel):
    qr_data: str   # The data encoded in the scanned QR code, e.g. "GYM:42"


@router.post("/check-in")
def check_in(
    body: CheckInRequest,
    staff: User = Depends(get_current_user),  # Any staff or admin can scan
    db: Session = Depends(get_db),
):
    """
    Process a QR code scan and check in the member.

    This endpoint is called by staff/admin when they scan a member's QR code.

    Validations:
    1. QR code format must be valid
    2. User must exist
    3. User must have an active, non-expired membership
    4. User must not have already checked in today
    """
    # --- Parse the QR code ---
    if not body.qr_data.startswith("GYM:"):
        raise HTTPException(status_code=400, detail="Invalid QR code format.")

    try:
        user_id = int(body.qr_data.split(":")[1])
    except (IndexError, ValueError):
        raise HTTPException(status_code=400, detail="Invalid QR code data.")

    # --- Find the user ---
    user = db.query(User).filter(User.id == user_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=404, detail="Member not found or account inactive.")

    # --- Check active membership ---
    membership = db.query(Membership).filter(
        Membership.user_id == user_id,
        Membership.status == MembershipStatus.ACTIVE,
    ).first()

    if not membership:
        raise HTTPException(
            status_code=403,
            detail=f"{user.full_name} does not have an active membership."
        )

    if membership.end_date < datetime.utcnow():
        raise HTTPException(
            status_code=403,
            detail=f"{user.full_name}'s membership expired on {membership.end_date.date()}."
        )

    # --- Prevent duplicate check-ins on the same day ---
    today = date.today()
    already_checked_in = db.query(Attendance).filter(
        Attendance.user_id == user_id,
        # Compare only the date part of check_in timestamp
        Attendance.check_in >= datetime(today.year, today.month, today.day),
    ).first()

    if already_checked_in:
        raise HTTPException(
            status_code=400,
            detail=f"{user.full_name} has already checked in today at {already_checked_in.check_in.strftime('%H:%M')}."
        )

    # --- Record the attendance ---
    attendance = Attendance(
        user_id=user_id,
        check_in=datetime.utcnow(),
        method="qr_code",
    )
    db.add(attendance)
    db.commit()
    db.refresh(attendance)

    return {
        "message": f"✅ {user.full_name} checked in successfully!",
        "check_in_time": attendance.check_in,
        "membership_expires": membership.end_date,
    }


# ---------------------------------------------------------------------------
# MY ATTENDANCE HISTORY
# ---------------------------------------------------------------------------
@router.get("/me")
def get_my_attendance(
    limit: int = 30,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get the current user's gym attendance history (most recent first)."""
    records = (
        db.query(Attendance)
        .filter(Attendance.user_id == current_user.id)
        .order_by(Attendance.check_in.desc())
        .limit(limit)
        .all()
    )
    return records


# ---------------------------------------------------------------------------
# ALL ATTENDANCE (Admin only)
# ---------------------------------------------------------------------------
@router.get("/all")
def get_all_attendance(
    date_filter: date = None,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Get all attendance records. Admin only.
    Optionally filter by date: ?date_filter=2025-01-15
    """
    query = db.query(Attendance)

    if date_filter:
        query = query.filter(
            Attendance.check_in >= datetime(date_filter.year, date_filter.month, date_filter.day),
            Attendance.check_in < datetime(date_filter.year, date_filter.month, date_filter.day + 1),
        )

    return query.order_by(Attendance.check_in.desc()).all()
