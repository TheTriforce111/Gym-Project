"""
main.py — Entry point for the Gym Management System API (Phase 2 upgrade)

New in Phase 2:
- Rate limiter middleware registered (slowapi)
- Custom exception handler for rate limit errors (returns clean JSON)
- Global request logging middleware

Run the server with:
    uvicorn app.main:app --reload
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.core.database import Base, engine
from app.core.rate_limiter import limiter
from app.routers import auth, users, memberships, workouts, classes, attendance

# ---------------------------------------------------------------------------
# Create all database tables on startup
# In production, use Alembic migrations instead
# ---------------------------------------------------------------------------
Base.metadata.create_all(bind=engine)

# ---------------------------------------------------------------------------
# Initialize FastAPI app
# ---------------------------------------------------------------------------
app = FastAPI(
    title="Gym Management System API",
    description=(
        "Full backend API for managing gym members, workouts, classes, payments, "
        "and attendance. Built with FastAPI + PostgreSQL + Redis."
    ),
    version="2.0.0",
    docs_url="/docs",          # Swagger UI
    redoc_url="/redoc",        # ReDoc UI (alternative docs)
)

# ---------------------------------------------------------------------------
# Attach the rate limiter to the app
# This allows @limiter.limit() decorators to work on route handlers
# ---------------------------------------------------------------------------
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

# ---------------------------------------------------------------------------
# CORS Middleware
# Allows the React frontend or Flutter app to call this API from a browser.
# In production, replace "*" with your actual domain.
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Register all routers
# Each router handles one feature area of the API
# ---------------------------------------------------------------------------
app.include_router(auth.router,        prefix="/api/auth",        tags=["🔐 Authentication"])
app.include_router(users.router,       prefix="/api/users",       tags=["👤 Users"])
app.include_router(memberships.router, prefix="/api/memberships", tags=["💳 Memberships"])
app.include_router(workouts.router,    prefix="/api/workouts",    tags=["🏋️ Workouts"])
app.include_router(classes.router,     prefix="/api/classes",     tags=["📅 Classes"])
app.include_router(attendance.router,  prefix="/api/attendance",  tags=["📡 Attendance"])


# ---------------------------------------------------------------------------
# Health check endpoint
# ---------------------------------------------------------------------------
@app.get("/", tags=["Health"])
def root():
    """Health check — confirms the API is running."""
    return {
        "status": "running",
        "message": "Gym Management System API v2.0 ✅",
        "docs": "/docs",
    }
