"""
core/rate_limiter.py — Rate limiting for sensitive endpoints

Rate limiting prevents abuse of sensitive endpoints like:
- Login (brute-force password attacks)
- OTP requests (SMS/email spam)
- Registration (account spam)

We use slowapi, which is a FastAPI wrapper around the limits library.
Limits are stored in Redis so they persist across server restarts.

How it works:
    @router.post("/login")
    @limiter.limit("5/minute")   ← max 5 requests per minute per IP
    def login(request: Request, ...):
        ...

Limit format examples:
    "5/minute"   → 5 requests per minute
    "100/hour"   → 100 requests per hour
    "10/day"     → 10 requests per day
    "3/second"   → 3 requests per second
"""

from slowapi import Limiter
from slowapi.util import get_remote_address

from app.core.config import settings

# ---------------------------------------------------------------------------
# Create the rate limiter
# key_func=get_remote_address means limits are per IP address
# storage_uri=REDIS_URL stores counters in Redis (shared across workers)
# ---------------------------------------------------------------------------
limiter = Limiter(
    key_func=get_remote_address,
    storage_uri=settings.REDIS_URL,
    # default_limits=["200/minute"]  # Uncomment to apply a global default
)

# ---------------------------------------------------------------------------
# Pre-defined limit constants for consistency
# Import these in your routers instead of hardcoding strings
# ---------------------------------------------------------------------------
LIMIT_LOGIN        = "10/minute"    # 10 login attempts per minute per IP
LIMIT_OTP_REQUEST  = "3/minute"     # 3 OTP requests per minute per IP
LIMIT_REGISTER     = "5/minute"     # 5 registrations per minute per IP
LIMIT_API_GENERAL  = "60/minute"    # General API rate limit
