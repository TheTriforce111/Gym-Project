"""
core/dependencies.py — FastAPI dependency injection functions (Phase 2 upgrade)

New in Phase 2:
- Token blacklist check (logout support)
- More granular RBAC helpers
- get_optional_user() for public-but-enhanced endpoints
- require_verified() for email-verified-only routes
- require_self_or_admin() for ownership checks

Dependencies are injected into route handlers using FastAPI's Depends().
They run BEFORE the route handler executes.

Usage:
    @router.get("/my-data")
    def my_route(current_user: User = Depends(get_current_user)):
        return current_user
"""

from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import decode_token
from app.models.user import User, UserRole

# ---------------------------------------------------------------------------
# OAuth2 scheme
# Looks for: "Authorization: Bearer <token>" in request headers
# ---------------------------------------------------------------------------
oauth2_scheme          = OAuth2PasswordBearer(tokenUrl="/api/auth/login")
oauth2_scheme_optional = OAuth2PasswordBearer(tokenUrl="/api/auth/login", auto_error=False)


def _get_user_from_token(token: str, db: Session) -> User:
    """
    Internal helper: decode JWT and fetch the user.
    Checks blacklist (logout), token type, and account status.
    """
    from app.services.auth_service import is_token_blacklisted

    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials. Please log in again.",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload = decode_token(token)
    if payload is None:
        raise credentials_exception

    # Only accept access tokens here (not refresh tokens)
    if payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type. Please use an access token.",
        )

    # Reject blacklisted tokens (user has logged out)
    if is_token_blacklisted(token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has been invalidated. Please log in again.",
        )

    user_id: str = payload.get("sub")
    if not user_id:
        raise credentials_exception

    user = db.query(User).filter(User.id == int(user_id)).first()
    if not user:
        raise credentials_exception

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has been deactivated. Please contact support.",
        )

    return user


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    """Require a valid JWT. Returns the authenticated user or raises HTTP 401."""
    return _get_user_from_token(token, db)


def get_optional_user(
    token: Optional[str] = Depends(oauth2_scheme_optional),
    db: Session = Depends(get_db),
) -> Optional[User]:
    """
    Optionally authenticate. Returns user if token provided and valid, else None.
    Use for public endpoints that show extra info to logged-in users.
    """
    if not token:
        return None
    try:
        return _get_user_from_token(token, db)
    except HTTPException:
        return None


def require_admin(current_user: User = Depends(get_current_user)) -> User:
    """Only allow ADMIN role. Raises HTTP 403 for trainers and members."""
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Administrator privileges are required.",
        )
    return current_user


def require_trainer(current_user: User = Depends(get_current_user)) -> User:
    """Allow TRAINER or ADMIN. Raises HTTP 403 for members."""
    if current_user.role not in [UserRole.TRAINER, UserRole.ADMIN]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Trainer or Administrator privileges are required.",
        )
    return current_user


def require_verified(current_user: User = Depends(get_current_user)) -> User:
    """
    Require the user to have a verified email address.
    Use for sensitive actions like payments or profile changes.
    """
    if not current_user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Please verify your email address to access this feature.",
        )
    return current_user


def require_self_or_admin(user_id: int, current_user: User = Depends(get_current_user)) -> User:
    """
    Allow access only to the resource owner OR an admin.
    Call this inside your route handler (not via Depends directly):
        require_self_or_admin(user_id, current_user)
    """
    if current_user.role != UserRole.ADMIN and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. You can only access your own data.",
        )
    return current_user
