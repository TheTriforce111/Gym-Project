"""
core/security.py — Password hashing and JWT token management

This module handles all security-related operations:
1. Hashing passwords before storing them in the database
2. Verifying passwords during login
3. Creating JWT access and refresh tokens
4. Decoding and validating JWT tokens on protected routes
"""

from datetime import datetime, timedelta
from typing import Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

# ---------------------------------------------------------------------------
# Password Hashing
# We use bcrypt — a slow hashing algorithm designed for passwords.
# "Slow" is intentional: it makes brute-force attacks harder.
# ---------------------------------------------------------------------------
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(plain_password: str) -> str:
    """
    Hash a plain-text password before storing it in the database.
    NEVER store plain-text passwords!

    Example:
        hashed = hash_password("mypassword123")
        # returns something like: "$2b$12$eImiTXuWVxfM37uY4JANjQ..."
    """
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Check if the plain-text password matches the stored hashed password.
    Used during login to validate the user's credentials.

    Returns True if they match, False otherwise.
    """
    return pwd_context.verify(plain_password, hashed_password)


# ---------------------------------------------------------------------------
# JWT Token Management
# JWT (JSON Web Token) is used for stateless authentication.
# After login, the user receives a token they send with every request.
# ---------------------------------------------------------------------------

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Create a short-lived JWT access token.

    - 'data' is the payload to encode (usually {"sub": user_id, "role": "member"})
    - The token expires after ACCESS_TOKEN_EXPIRE_MINUTES (default: 30 min)

    Example:
        token = create_access_token({"sub": "42", "role": "admin"})
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def create_refresh_token(data: dict) -> str:
    """
    Create a long-lived JWT refresh token.

    Refresh tokens are used to get a new access token without re-logging in.
    They last longer (default: 7 days) but should be stored securely.
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> Optional[dict]:
    """
    Decode and verify a JWT token.

    Returns the token payload (dict) if valid, or None if expired/invalid.
    The payload contains the user info we encoded when creating the token.
    """
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        # Token is invalid, tampered, or expired
        return None
