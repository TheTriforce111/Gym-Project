"""
core/database.py — PostgreSQL database connection using SQLAlchemy

SQLAlchemy is an ORM (Object-Relational Mapper). It lets us work with
the database using Python classes and objects instead of raw SQL queries.

Key concepts:
- engine:       The connection to the PostgreSQL database
- SessionLocal: A factory that creates new database sessions
- Base:         The parent class all our models inherit from
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from app.core.config import settings

# ---------------------------------------------------------------------------
# Create the database engine
# The engine manages the actual connection pool to PostgreSQL
# ---------------------------------------------------------------------------
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,     # Test connections before using them (avoids stale connections)
    pool_size=10,           # Number of connections to keep open
    max_overflow=20,        # Extra connections allowed beyond pool_size
)

# ---------------------------------------------------------------------------
# SessionLocal — used to create a new DB session for each API request
# autocommit=False: we manually commit transactions
# autoflush=False:  we manually flush changes to avoid premature writes
# ---------------------------------------------------------------------------
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ---------------------------------------------------------------------------
# Base — all SQLAlchemy models (tables) inherit from this class
# ---------------------------------------------------------------------------
Base = declarative_base()


# ---------------------------------------------------------------------------
# Dependency function — injected into route handlers via FastAPI's Depends()
# This ensures each request gets its own DB session and it's closed after
# ---------------------------------------------------------------------------
def get_db():
    """
    Yield a database session for the duration of a single API request.
    The 'finally' block ensures the session is always closed, even if an error occurs.

    Usage in a route:
        def my_route(db: Session = Depends(get_db)):
            ...
    """
    db = SessionLocal()
    try:
        yield db            # Provide the session to the route handler
    finally:
        db.close()          # Always close the session when done
