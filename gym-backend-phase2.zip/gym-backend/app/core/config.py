"""
core/config.py — App configuration loaded from environment variables

All sensitive values (passwords, secret keys, API keys) are stored in
a .env file and loaded here using Pydantic's BaseSettings.

This prevents hardcoding secrets in source code — very important for security.
"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """
    Settings class reads values from the .env file automatically.
    Each attribute here maps to a key in the .env file.
    """

    # --- Database ---
    DATABASE_URL: str = "postgresql://user:password@localhost:5432/gymdb"
    # Format: postgresql://<username>:<password>@<host>:<port>/<database_name>

    # --- JWT Authentication ---
    SECRET_KEY: str = "your-very-secret-key-change-this-in-production"
    # This key is used to sign JWT tokens. Keep it private and complex.

    ALGORITHM: str = "HS256"
    # Hashing algorithm used for JWT signing

    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    # How long an access token lasts before expiring (in minutes)

    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    # How long a refresh token lasts (in days)

    # --- Redis (for OTP and caching) ---
    REDIS_URL: str = "redis://localhost:6379"
    # Redis is used to store temporary OTP codes for password reset

    # --- Stripe Payment Gateway ---
    STRIPE_SECRET_KEY: str = "sk_test_your_stripe_key_here"
    STRIPE_WEBHOOK_SECRET: str = "whsec_your_webhook_secret_here"
    # Get these from your Stripe dashboard at https://dashboard.stripe.com

    # --- Firebase (for push notifications) ---
    FIREBASE_CREDENTIALS_PATH: str = "firebase-credentials.json"
    # Path to your Firebase service account JSON file

    # --- Email (SMTP for sending emails) ---
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = "your-email@gmail.com"
    SMTP_PASSWORD: str = "your-app-password"

    class Config:
        env_file = ".env"           # Load values from the .env file
        env_file_encoding = "utf-8"


# Create a single global settings instance to use throughout the app
settings = Settings()
