"""
models/user.py — User database model (the 'users' table)

SQLAlchemy models define the structure of database tables.
Each class = one table. Each attribute = one column.

This model stores all gym users: admins, trainers, and members.
"""

import enum
from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Enum, Integer, String
from sqlalchemy.orm import relationship

from app.core.database import Base


class UserRole(str, enum.Enum):
    """
    Enum for user roles — controls what each user can access.
    - ADMIN:   Full access (manage everything)
    - TRAINER: Can manage classes and assigned members
    - MEMBER:  Regular gym member (limited access)
    """
    ADMIN   = "admin"
    TRAINER = "trainer"
    MEMBER  = "member"


class User(Base):
    """
    Represents a user in the gym system.
    Maps to the 'users' table in PostgreSQL.
    """
    __tablename__ = "users"

    # --- Primary Key ---
    id = Column(Integer, primary_key=True, index=True)
    # Auto-incrementing unique ID for each user

    # --- Personal Information ---
    full_name = Column(String(100), nullable=False)
    email     = Column(String(150), unique=True, index=True, nullable=False)
    phone     = Column(String(20), nullable=True)
    # index=True speeds up searches by email (very common operation)

    # --- Security ---
    hashed_password = Column(String(255), nullable=False)
    # NEVER store plain-text passwords — always hash them first

    # --- Role-Based Access ---
    role = Column(Enum(UserRole), default=UserRole.MEMBER, nullable=False)
    # Default role is 'member' when a new user registers

    # --- Account Status ---
    is_active   = Column(Boolean, default=True)
    # False = account deactivated (can't log in)

    is_verified = Column(Boolean, default=False)
    # True = user has verified their email address

    # --- QR Code for Attendance ---
    qr_code = Column(String(255), nullable=True)
    # Stores the path or URL to the user's unique QR code image

    # --- Timestamps ---
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    # onupdate automatically updates 'updated_at' whenever the record changes

    # --- Relationships (links to other tables) ---
    membership   = relationship("Membership",   back_populates="user", uselist=False)
    # uselist=False means one-to-one: each user has one membership

    workouts     = relationship("WorkoutPlan",  back_populates="user")
    # One user can have many workout plans

    attendances  = relationship("Attendance",   back_populates="user")
    # One user can have many attendance records

    bookings     = relationship("ClassBooking", back_populates="user")
    # One user can book many classes

    def __repr__(self):
        return f"<User id={self.id} email={self.email} role={self.role}>"
