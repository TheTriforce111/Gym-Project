"""
models/workout.py — Workout-related database models

This file defines three tables:
1. Exercise      — a library of exercises (e.g. Bench Press, Squat)
2. WorkoutPlan   — a named workout plan assigned to a user
3. WorkoutEntry  — a specific exercise within a workout plan (sets/reps/weight)
4. WorkoutLog    — records completed workouts for progress tracking
"""

from datetime import datetime

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.core.database import Base


class Exercise(Base):
    """
    A library of exercises that trainers and admins can manage.
    Examples: Bench Press, Squat, Pull-up, Plank

    Maps to the 'exercises' table.
    """
    __tablename__ = "exercises"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(100), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    # Text = long-form string (no character limit, unlike String)

    muscle_group = Column(String(100), nullable=True)
    # e.g. "Chest", "Back", "Legs", "Core"

    equipment   = Column(String(100), nullable=True)
    # e.g. "Barbell", "Dumbbell", "Bodyweight", "Machine"

    video_url   = Column(String(500), nullable=True)
    # Optional demo video link for form reference

    created_at  = Column(DateTime, default=datetime.utcnow)


class WorkoutPlan(Base):
    """
    A workout plan assigned to a specific gym member.
    A plan has a name and contains multiple WorkoutEntries.

    Maps to the 'workout_plans' table.
    """
    __tablename__ = "workout_plans"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(150), nullable=False)
    # e.g. "Week 1 Strength Training", "Beginner Cardio Plan"

    description = Column(Text, nullable=True)

    # --- Who this plan belongs to ---
    user_id     = Column(Integer, ForeignKey("users.id"), nullable=False)

    # --- Who created it (trainer or admin) ---
    created_by  = Column(Integer, ForeignKey("users.id"), nullable=True)

    created_at  = Column(DateTime, default=datetime.utcnow)
    updated_at  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # --- Relationships ---
    user    = relationship("User", foreign_keys=[user_id], back_populates="workouts")
    entries = relationship("WorkoutEntry", back_populates="plan", cascade="all, delete")
    # cascade="all, delete" means if we delete a plan, all its entries are deleted too
    logs    = relationship("WorkoutLog", back_populates="plan")


class WorkoutEntry(Base):
    """
    One exercise inside a workout plan, with sets, reps, and weight.

    Example: "Bench Press — 4 sets x 10 reps @ 80kg"

    Maps to the 'workout_entries' table.
    """
    __tablename__ = "workout_entries"

    id          = Column(Integer, primary_key=True, index=True)
    plan_id     = Column(Integer, ForeignKey("workout_plans.id"), nullable=False)
    exercise_id = Column(Integer, ForeignKey("exercises.id"),     nullable=False)

    sets        = Column(Integer, nullable=False, default=3)   # Number of sets
    reps        = Column(Integer, nullable=False, default=10)  # Reps per set
    weight_kg   = Column(Float,   nullable=True)               # Weight in kg (null for bodyweight)
    rest_seconds= Column(Integer, nullable=True, default=60)   # Rest between sets in seconds
    notes       = Column(String(300), nullable=True)           # Trainer tips for this exercise

    # --- Relationships ---
    plan     = relationship("WorkoutPlan", back_populates="entries")
    exercise = relationship("Exercise")


class WorkoutLog(Base):
    """
    Records a completed workout session for progress tracking.
    Members log their workouts after completing them.

    Maps to the 'workout_logs' table.
    """
    __tablename__ = "workout_logs"

    id         = Column(Integer, primary_key=True, index=True)
    user_id    = Column(Integer, ForeignKey("users.id"),       nullable=False)
    plan_id    = Column(Integer, ForeignKey("workout_plans.id"), nullable=True)

    date       = Column(DateTime, default=datetime.utcnow)
    # When the workout was completed

    duration_minutes = Column(Integer, nullable=True)
    # Total workout duration in minutes

    notes      = Column(Text, nullable=True)
    # Member can add personal notes: "Felt strong today", "Increased bench press"

    # --- Relationships ---
    user = relationship("User",        foreign_keys=[user_id])
    plan = relationship("WorkoutPlan", back_populates="logs")
