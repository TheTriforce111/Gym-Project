"""
models/gym_class.py — Gym Class and Booking database models

This file defines:
1. GymClass     — a scheduled gym class (Yoga, HIIT, Zumba, etc.)
2. ClassBooking — a member's booking for a specific class
"""

import enum
from datetime import datetime

from sqlalchemy import Column, DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.core.database import Base


class BookingStatus(str, enum.Enum):
    """Status of a class booking."""
    CONFIRMED = "confirmed"   # Member has booked the class
    CANCELLED = "cancelled"   # Member cancelled their booking
    ATTENDED  = "attended"    # Member actually showed up


class GymClass(Base):
    """
    A scheduled gym class that members can book.
    Examples: Yoga at 9am Monday, HIIT at 6pm Wednesday

    Maps to the 'gym_classes' table.
    """
    __tablename__ = "gym_classes"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(150), nullable=False)
    # e.g. "Morning Yoga", "HIIT Bootcamp", "Spin Class"

    description = Column(Text, nullable=True)

    # --- Trainer assignment ---
    trainer_id  = Column(Integer, ForeignKey("users.id"), nullable=True)
    # The trainer leading this class (must have role=TRAINER)

    # --- Schedule ---
    start_time  = Column(DateTime, nullable=False)
    end_time    = Column(DateTime, nullable=False)
    # Full datetime for when the class starts and ends

    location    = Column(String(200), nullable=True)
    # e.g. "Studio A", "Main Floor", "Outdoor Terrace"

    # --- Capacity ---
    max_capacity = Column(Integer, default=20)
    # Maximum number of members that can book this class

    # --- Timestamps ---
    created_at  = Column(DateTime, default=datetime.utcnow)

    # --- Relationships ---
    trainer  = relationship("User",         foreign_keys=[trainer_id])
    bookings = relationship("ClassBooking", back_populates="gym_class")

    @property
    def booked_count(self):
        """Returns the number of confirmed bookings for this class."""
        return sum(1 for b in self.bookings if b.status == BookingStatus.CONFIRMED)

    @property
    def is_full(self):
        """Returns True if the class is at maximum capacity."""
        return self.booked_count >= self.max_capacity

    def __repr__(self):
        return f"<GymClass name={self.name} start={self.start_time}>"


class ClassBooking(Base):
    """
    Records when a member books a gym class.
    A member can only book each class once.

    Maps to the 'class_bookings' table.
    """
    __tablename__ = "class_bookings"

    id           = Column(Integer, primary_key=True, index=True)
    user_id      = Column(Integer, ForeignKey("users.id"),        nullable=False)
    gym_class_id = Column(Integer, ForeignKey("gym_classes.id"),  nullable=False)

    status       = Column(Enum(BookingStatus), default=BookingStatus.CONFIRMED)

    booked_at    = Column(DateTime, default=datetime.utcnow)
    # When the booking was made

    cancelled_at = Column(DateTime, nullable=True)
    # When the booking was cancelled (if applicable)

    # --- Relationships ---
    user      = relationship("User",     back_populates="bookings")
    gym_class = relationship("GymClass", back_populates="bookings")
