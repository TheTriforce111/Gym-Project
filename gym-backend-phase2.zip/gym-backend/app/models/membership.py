"""
models/membership.py — Membership database model

Tracks each user's gym membership: plan type, status, and dates.
Each user has one membership record (one-to-one with User).
"""

import enum
from datetime import datetime

from sqlalchemy import Column, DateTime, Enum, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.core.database import Base


class MembershipPlan(str, enum.Enum):
    """Available membership plan types."""
    MONTHLY = "monthly"   # 1 month
    YEARLY  = "yearly"    # 12 months
    CUSTOM  = "custom"    # Admin-defined duration


class MembershipStatus(str, enum.Enum):
    """Current status of the membership."""
    ACTIVE   = "active"    # Membership is valid and usable
    EXPIRED  = "expired"   # Past the end date
    FROZEN   = "frozen"    # Temporarily paused (e.g. injury)
    CANCELLED = "cancelled" # Manually cancelled


class Membership(Base):
    """
    Represents a user's gym membership.
    Maps to the 'memberships' table in PostgreSQL.
    """
    __tablename__ = "memberships"

    id      = Column(Integer, primary_key=True, index=True)

    # --- Link to the User ---
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    # ForeignKey("users.id") links this to the User table
    # unique=True enforces one membership per user

    # --- Plan Details ---
    plan   = Column(Enum(MembershipPlan), nullable=False)
    status = Column(Enum(MembershipStatus), default=MembershipStatus.ACTIVE)

    # --- Dates ---
    start_date = Column(DateTime, nullable=False, default=datetime.utcnow)
    end_date   = Column(DateTime, nullable=False)
    # end_date is calculated when the membership is created (e.g. +30 days for monthly)

    # --- Pricing ---
    price_paid = Column(Float, nullable=False)
    # Amount the user paid for this membership period (in USD or local currency)

    # --- Notes ---
    notes = Column(String(500), nullable=True)
    # Admin can add notes like "Frozen due to surgery until March 2025"

    # --- Timestamps ---
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # --- Relationships ---
    user     = relationship("User",    back_populates="membership")
    payments = relationship("Payment", back_populates="membership")
    # One membership can have multiple payment records (renewals)

    def __repr__(self):
        return f"<Membership user_id={self.user_id} plan={self.plan} status={self.status}>"
