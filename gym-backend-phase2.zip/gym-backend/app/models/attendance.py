"""
models/attendance.py — Attendance tracking database model

Records each time a member checks into the gym via QR code scan.
Prevents duplicate check-ins on the same day.
"""

from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.core.database import Base


class Attendance(Base):
    """
    Records a gym check-in event for a member.

    Maps to the 'attendances' table in PostgreSQL.
    """
    __tablename__ = "attendances"

    id         = Column(Integer, primary_key=True, index=True)

    # --- Which user checked in ---
    user_id    = Column(Integer, ForeignKey("users.id"), nullable=False)

    # --- When they checked in ---
    check_in   = Column(DateTime, default=datetime.utcnow, nullable=False)

    # --- When they checked out (optional) ---
    check_out  = Column(DateTime, nullable=True)
    # Some gyms track when members leave too

    # --- How they checked in ---
    method     = Column(String(50), default="qr_code")
    # e.g. "qr_code", "manual" (staff manually checks in a member)

    # --- Notes ---
    notes      = Column(String(300), nullable=True)
    # Admin can add notes: "Member forgot QR — verified by ID"

    # --- Relationships ---
    user = relationship("User", back_populates="attendances")

    def __repr__(self):
        return f"<Attendance user_id={self.user_id} check_in={self.check_in}>"
