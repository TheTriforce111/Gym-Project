"""
models/payment.py — Payment database model

Records every payment transaction in the system.
Linked to a membership (what was paid for) and a user (who paid).
"""

import enum
from datetime import datetime

from sqlalchemy import Column, DateTime, Enum, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.core.database import Base


class PaymentStatus(str, enum.Enum):
    """The result/status of a payment transaction."""
    PENDING   = "pending"    # Payment initiated but not confirmed
    SUCCESS   = "success"    # Payment completed successfully
    FAILED    = "failed"     # Payment was declined or failed
    REFUNDED  = "refunded"   # Payment was refunded to the user


class Payment(Base):
    """
    Records a payment transaction.
    Maps to the 'payments' table in PostgreSQL.
    """
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)

    # --- Links ---
    user_id       = Column(Integer, ForeignKey("users.id"),       nullable=False)
    membership_id = Column(Integer, ForeignKey("memberships.id"), nullable=False)

    # --- Stripe Payment Info ---
    stripe_payment_intent_id = Column(String(255), unique=True, nullable=True)
    # Stripe's unique ID for this payment — used for idempotency (no duplicates)

    stripe_charge_id = Column(String(255), nullable=True)
    # The actual charge ID from Stripe after payment is confirmed

    # --- Amount ---
    amount   = Column(Float, nullable=False)    # Total charged
    currency = Column(String(10), default="usd") # e.g. "usd", "sar", "eur"

    # --- Status ---
    status = Column(Enum(PaymentStatus), default=PaymentStatus.PENDING)

    # --- Metadata ---
    description = Column(String(500), nullable=True)
    # e.g. "Monthly membership renewal - January 2025"

    # --- Timestamps ---
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # --- Relationships ---
    user       = relationship("User",       foreign_keys=[user_id])
    membership = relationship("Membership", back_populates="payments")

    def __repr__(self):
        return f"<Payment id={self.id} amount={self.amount} status={self.status}>"
