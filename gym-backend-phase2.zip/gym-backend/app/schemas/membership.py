"""
schemas/membership.py — Pydantic schemas for membership endpoints
"""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel
from app.models.membership import MembershipPlan, MembershipStatus


class MembershipCreate(BaseModel):
    """Request body for creating a new membership."""
    user_id: int
    plan: MembershipPlan
    price_paid: float
    notes: Optional[str] = None
    # end_date is calculated automatically based on the plan type


class MembershipUpdate(BaseModel):
    """Request body for updating an existing membership (admin only)."""
    status: Optional[MembershipStatus] = None
    end_date: Optional[datetime] = None
    notes: Optional[str] = None


class MembershipResponse(BaseModel):
    """Response schema for membership data."""
    id:         int
    user_id:    int
    plan:       MembershipPlan
    status:     MembershipStatus
    start_date: datetime
    end_date:   datetime
    price_paid: float
    notes:      Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True
