"""
schemas/user.py — Pydantic schemas for User data validation

Pydantic schemas are used to:
1. Validate incoming request data (e.g. check email format, password length)
2. Control what data is returned in API responses (e.g. never return the password)

Think of schemas as "contracts" — they define the shape of data going in and out.

Naming convention:
- UserCreate   → used when registering (request body)
- UserUpdate   → used when editing a profile (partial update)
- UserResponse → what the API returns (safe, no password)
"""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr, field_validator

from app.models.user import UserRole


class UserCreate(BaseModel):
    """
    Schema for registering a new user.
    All fields are required (no Optional).
    """
    full_name: str
    email: EmailStr          # Pydantic validates email format automatically
    phone: Optional[str] = None
    password: str
    role: UserRole = UserRole.MEMBER  # Default role is member

    @field_validator("password")
    @classmethod
    def password_strength(cls, v):
        """Enforce minimum password requirements."""
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters long.")
        return v

    @field_validator("full_name")
    @classmethod
    def name_not_empty(cls, v):
        if not v.strip():
            raise ValueError("Full name cannot be empty.")
        return v.strip()


class UserUpdate(BaseModel):
    """
    Schema for updating user profile information.
    All fields are optional — only send what you want to change.
    """
    full_name: Optional[str] = None
    phone:     Optional[str] = None
    is_active: Optional[bool] = None


class UserResponse(BaseModel):
    """
    Schema for returning user data in API responses.
    Excludes sensitive fields like hashed_password.
    """
    id:          int
    full_name:   str
    email:       str
    phone:       Optional[str]
    role:        UserRole
    is_active:   bool
    is_verified: bool
    created_at:  datetime

    class Config:
        from_attributes = True
        # Allows Pydantic to read data from SQLAlchemy model objects directly


class ChangePasswordRequest(BaseModel):
    """Schema for changing a user's own password."""
    current_password: str
    new_password: str

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 8:
            raise ValueError("New password must be at least 8 characters long.")
        return v
