"""
schemas/auth.py — Pydantic schemas for all authentication endpoints (Phase 2)

Schemas define the expected shape of request and response data.
Pydantic validates all fields automatically — wrong data returns a 422 error.
"""

from pydantic import BaseModel, EmailStr, field_validator


class LoginRequest(BaseModel):
    """Request body for POST /api/auth/login"""
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """
    Returned after login or token refresh.
    Store both tokens securely (secure cookie or device keychain — never localStorage).
    """
    access_token:  str            # Short-lived (30 min) — sent with every API request
    refresh_token: str            # Long-lived (7 days) — used to renew access tokens
    token_type:    str = "bearer"


class RefreshTokenRequest(BaseModel):
    """Request body for POST /api/auth/refresh"""
    refresh_token: str


class PasswordResetRequest(BaseModel):
    """Step 1 — User provides their email to receive an OTP."""
    email: EmailStr


class OTPVerifyRequest(BaseModel):
    """Step 2 — User submits the 6-digit OTP code they received by email."""
    email: EmailStr
    otp: str

    @field_validator("otp")
    @classmethod
    def otp_must_be_6_digits(cls, v):
        v = v.strip()
        if not v.isdigit() or len(v) != 6:
            raise ValueError("OTP must be exactly 6 numeric digits.")
        return v


class SetNewPasswordRequest(BaseModel):
    """Step 3 — User sets a new password after OTP is verified."""
    email: EmailStr
    new_password: str

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters.")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one number.")
        return v
