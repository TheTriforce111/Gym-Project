# 🔐 Phase 2 — Authentication System (Complete)

## What Was Added in Phase 2

### New Files
| File | Purpose |
|------|---------|
| `app/services/auth_service.py` | Business logic for register, login, tokens, password reset |
| `app/services/otp_service.py`  | OTP generation, Redis storage, attempt tracking, cooldowns |
| `app/services/email_service.py` | Email sending via SMTP — OTP, welcome, membership emails |
| `app/core/rate_limiter.py`     | slowapi rate limiting (login, OTP, register endpoints) |
| `tests/test_auth.py`           | Full test suite for the auth system |

### Upgraded Files
| File | What Changed |
|------|--------------|
| `app/routers/auth.py`         | Now uses service layer + rate limiting + logout + /me endpoint |
| `app/core/dependencies.py`    | Added blacklist check, `get_optional_user`, `require_verified`, `require_self_or_admin` |
| `app/main.py`                 | Registered rate limiter middleware |
| `app/schemas/auth.py`         | Added OTP format validation, stronger password rules |

---

## Complete Auth Flow

### 1. Register
```
POST /api/auth/register
Body: { full_name, email, password, phone }
→ Creates account, sends welcome email
→ Returns: user profile (no password)
```

### 2. Login
```
POST /api/auth/login
Body: { email, password }
→ Returns: { access_token, refresh_token, token_type: "bearer" }
```

### 3. Use Protected Endpoints
```
Add header to every request:
  Authorization: Bearer <access_token>
```

### 4. Refresh Expired Token
```
POST /api/auth/refresh
Body: { refresh_token }
→ Returns: new { access_token, refresh_token }
```

### 5. Logout
```
POST /api/auth/logout
Header: Authorization: Bearer <access_token>
→ Blacklists the token (works immediately)
→ Client should also delete stored tokens
```

### 6. Password Reset (3 steps)
```
Step 1 — Request OTP:
  POST /api/auth/forgot-password
  Body: { email }

Step 2 — Verify OTP:
  POST /api/auth/verify-otp
  Body: { email, otp }   ← 6-digit code from email

Step 3 — Set new password:
  POST /api/auth/reset-password
  Body: { email, new_password }
```

---

## Security Features Added

| Feature | How It Works |
|---------|-------------|
| **Token Blacklisting** | Logged-out tokens stored in Redis until expiry |
| **Rate Limiting — Login** | Max 10 attempts/minute per IP (blocks brute force) |
| **Rate Limiting — OTP** | Max 3 requests/minute per IP |
| **OTP Cooldown** | 60 seconds between OTP requests per email |
| **OTP Attempt Tracking** | 5 wrong attempts → lockout, must request new OTP |
| **OTP Expiry** | Codes expire after 10 minutes (Redis TTL) |
| **Email Enumeration Prevention** | Same response for registered/unregistered emails |
| **Password Rules** | Min 8 chars + at least 1 number |
| **Soft Account Deactivation** | Deactivated users can't log in (without deleting data) |

---

## Role-Based Access Control (RBAC)

Use these dependencies to protect your routes:

```python
from app.core.dependencies import (
    get_current_user,      # Any logged-in user
    get_optional_user,     # User if logged in, None if not
    require_admin,         # Admin only
    require_trainer,       # Trainer or Admin
    require_verified,      # Email-verified users only
)

# Examples:
@router.get("/public-data")
def public(user = Depends(get_optional_user)):
    # Returns extra info if logged in, basic info if not
    pass

@router.get("/my-profile")
def profile(user = Depends(get_current_user)):
    # Requires login
    pass

@router.delete("/users/{id}")
def delete(admin = Depends(require_admin)):
    # Admin only
    pass

@router.post("/workout-plan")
def create_plan(trainer = Depends(require_trainer)):
    # Trainer or Admin
    pass
```

---

## Redis Key Structure

```
otp:{email}           → OTP code          (TTL: 10 min)
otp_verified:{email}  → Verification flag  (TTL: 5 min)
otp_attempts:{email}  → Failed attempts    (TTL: 15 min)
otp_cooldown:{email}  → Request cooldown   (TTL: 60 sec)
blacklist:{token}     → Logout blacklist   (TTL: token expiry)
```

---

## Running Tests

```bash
# Install test dependencies
pip install pytest pytest-asyncio httpx

# Run all tests
pytest tests/ -v

# Run only auth tests
pytest tests/test_auth.py -v

# Run with coverage
pytest tests/ --cov=app --cov-report=term-missing
```

---

## Environment Variables Needed

Ensure your `.env` has these set for Phase 2 to work:

```env
REDIS_URL=redis://localhost:6379
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=youremail@gmail.com
SMTP_PASSWORD=your-app-password
SECRET_KEY=your-very-long-random-secret-key
```
