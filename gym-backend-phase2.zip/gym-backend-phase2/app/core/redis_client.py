"""
core/redis_client.py — Centralized Redis connection

Redis is an in-memory key-value store. We use it for:
1. OTP storage     — temporary 6-digit codes that expire after 10 minutes
2. Token blacklist — invalidated refresh tokens (for logout)
3. Rate limiting   — track login/OTP attempt counts per IP

Why Redis instead of PostgreSQL for these?
- Speed: Redis operates in memory (microsecond reads/writes)
- Auto-expiry: Redis keys can expire automatically — perfect for OTPs
- No cleanup needed: expired data disappears by itself
"""

import redis
from app.core.config import settings

# ---------------------------------------------------------------------------
# Create a single Redis connection that the whole app shares.
# decode_responses=True means we get strings back instead of bytes.
# ---------------------------------------------------------------------------
redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)


# ---------------------------------------------------------------------------
# OTP Helpers
# ---------------------------------------------------------------------------

OTP_EXPIRY_SECONDS = 10 * 60          # 10 minutes
OTP_VERIFIED_EXPIRY_SECONDS = 5 * 60  # 5 minutes (window to set new password)


def store_otp(email: str, otp: str) -> None:
    """
    Save an OTP in Redis linked to an email address.
    It expires automatically after 10 minutes.

    Key format: "otp:{email}"
    """
    redis_client.setex(f"otp:{email}", OTP_EXPIRY_SECONDS, otp)


def get_otp(email: str) -> str | None:
    """
    Retrieve the stored OTP for an email.
    Returns None if expired or not found.
    """
    return redis_client.get(f"otp:{email}")


def delete_otp(email: str) -> None:
    """Remove the OTP after it has been used (prevents reuse)."""
    redis_client.delete(f"otp:{email}")


def mark_otp_verified(email: str) -> None:
    """
    After OTP verification, mark the email as verified in Redis.
    This unlocks the password reset endpoint for 5 minutes.
    """
    redis_client.setex(f"otp_verified:{email}", OTP_VERIFIED_EXPIRY_SECONDS, "true")


def is_otp_verified(email: str) -> bool:
    """Check if the OTP was recently verified for this email."""
    return redis_client.get(f"otp_verified:{email}") == "true"


def clear_otp_verified(email: str) -> None:
    """Clean up the verified flag after password reset is complete."""
    redis_client.delete(f"otp_verified:{email}")


# ---------------------------------------------------------------------------
# Token Blacklist Helpers (for logout)
# ---------------------------------------------------------------------------

def blacklist_token(token_hash: str, expiry_seconds: int) -> None:
    """
    Add a token to the blacklist so it cannot be used again.

    We store the SHA-256 hash of the token (not the token itself)
    with an expiry matching when the token would have expired anyway.
    Once the token's expiry passes, Redis removes the key automatically.

    Key format: "blacklist:{token_hash}"
    """
    redis_client.setex(f"blacklist:{token_hash}", expiry_seconds, "1")


def is_token_blacklisted(token_hash: str) -> bool:
    """
    Check if a token hash is in the blacklist.
    Returns True if the token was explicitly revoked (user logged out).
    """
    return redis_client.exists(f"blacklist:{token_hash}") > 0


# ---------------------------------------------------------------------------
# Rate Limiting Helpers
# ---------------------------------------------------------------------------

def increment_attempts(key: str, window_seconds: int) -> int:
    """
    Increment a counter for rate limiting (e.g. failed login attempts).
    The counter resets automatically after window_seconds.

    Returns the current attempt count.

    Usage:
        count = increment_attempts(f"login_attempts:{ip}", 300)
        if count > 5:
            raise HTTPException(429, "Too many attempts")
    """
    pipe = redis_client.pipeline()
    pipe.incr(key)
    pipe.expire(key, window_seconds)  # Set expiry only on the first call
    results = pipe.execute()
    return results[0]  # Return the new count


def get_attempts(key: str) -> int:
    """Get the current attempt count for a rate limit key."""
    value = redis_client.get(key)
    return int(value) if value else 0


def reset_attempts(key: str) -> None:
    """Reset the attempt counter (e.g. after a successful login)."""
    redis_client.delete(key)
