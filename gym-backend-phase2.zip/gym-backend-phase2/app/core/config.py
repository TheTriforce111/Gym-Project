"""
core/config.py — Application Configuration (Phase 2)

All sensitive values are loaded from the .env file.
Never hardcode secrets in source code — use environment variables.

To set up:
    cp .env.example .env
    # Edit .env with your actual values
"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):

    # --- Database ---
    DATABASE_URL: str = "postgresql://user:password@localhost:5432/gymdb"

    # --- JWT ---
    SECRET_KEY: str = "change-this-secret-key-in-production-use-64-chars-minimum"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # --- Redis ---
    REDIS_URL: str = "redis://localhost:6379"

    # --- Email (SMTP) ---
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = "yourgym@gmail.com"
    SMTP_PASSWORD: str = "your-app-password"
    # For Gmail: create an App Password at https://myaccount.google.com/apppasswords

    # --- Stripe (Phase 4) ---
    STRIPE_SECRET_KEY: str = "sk_test_placeholder"
    STRIPE_WEBHOOK_SECRET: str = "whsec_placeholder"

    # --- Firebase (Phase 8) ---
    FIREBASE_CREDENTIALS_PATH: str = "firebase-credentials.json"

    # --- App ---
    APP_NAME: str = "Gym Management System"
    DEBUG: bool = False
    # Set DEBUG=True in .env during development for verbose error messages

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
