"""
core/dependencies.py — FastAPI Dependency Injection (Phase 2)

Dependencies are functions that run automatically before a route handler.
They handle authentication, authorization, and rate limiting.

Phase 2 Additions:
- Token blacklist check (supports proper logout)
- Granular role guards for admin, trainer, member
- Optional auth (routes accessible with OR without a token)

How FastAPI Depends() works:
    @router.get("/protected")
    def my_route(user: User = Depends(get_current_user)):
        # FastAPI calls get_current_user() first
        # If it raises HTTPException, the route never runs
        return user
"""

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.redis_client import is_token_blacklisted
from app.core.security import decode_token, get_token_jti
from app.models.user import User, UserRole

# ---------------------------------------------------------------------------
# OAuth2 Bearer Scheme
# FastAPI uses this to extract the token from the Authorization header:
#   Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
# ---------------------------------------------------------------------------
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

# Same but makes the token optional (won't fail if no token is provided)
oauth2_scheme_optional = OAuth2PasswordBearer(
    tokenUrl="/api/auth/login",
    auto_error=False  # Don't raise 401 if token is missing
)


# ---------------------------------------------------------------------------
# Core Auth Dependency
# ---------------------------------------------------------------------------

def get_current_user(
    request: Request,
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    """
    Extract and validate the JWT token, then return the authenticated user.

    Steps:
    1. Decode the JWT token
    2. Verify it's an access token (not a refresh token)
    3. Check the token hasn't been blacklisted (user didn't log out)
    4. Fetch the user from the database
    5. Verify the user's account is still active

    Raises HTTP 401 if any check fails.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token. Please log in again.",
        headers={"WWW-Authenticate": "Bearer"},
    )

    # Step 1: Decode the token
    payload = decode_token(token)
    if payload is None:
        raise credentials_exception

    # Step 2: Ensure it's an access token
    if payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Expected an access token but received a different token type.",
        )

    # Step 3: Check the token blacklist (supports logout)
    token_hash = get_token_jti(token)
    if is_token_blacklisted(token_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="This token has been revoked. Please log in again.",
        )

    # Step 4: Get the user ID from token payload
    user_id: str = payload.get("sub")
    if not user_id:
        raise credentials_exception

    # Step 5: Fetch the user from the database
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user is None:
        raise credentials_exception

    # Step 6: Make sure the account is not deactivated
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has been deactivated. Contact support.",
        )

    return user


def get_optional_user(
    token: str = Depends(oauth2_scheme_optional),
    db: Session = Depends(get_db),
) -> User | None:
    """
    Like get_current_user, but returns None instead of raising 401.
    Use this for routes that work differently for logged-in vs anonymous users.
    """
    if not token:
        return None
    try:
        return get_current_user.__wrapped__(token=token, db=db) if hasattr(get_current_user, '__wrapped__') else None
    except HTTPException:
        return None


# ---------------------------------------------------------------------------
# Role-Based Access Control (RBAC) Dependencies
# ---------------------------------------------------------------------------

def require_admin(current_user: User = Depends(get_current_user)) -> User:
    """
    Only allows ADMIN users to proceed.
    Raises HTTP 403 for trainers and members.

    Usage:
        @router.delete("/users/{id}")
        def delete_user(admin: User = Depends(require_admin)):
            ...
    """
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. This action requires Admin privileges.",
        )
    return current_user


def require_trainer(current_user: User = Depends(get_current_user)) -> User:
    """
    Allows TRAINER and ADMIN users to proceed.
    Raises HTTP 403 for regular members.

    Usage:
        @router.post("/workout-plans")
        def create_plan(trainer: User = Depends(require_trainer)):
            ...
    """
    if current_user.role not in [UserRole.TRAINER, UserRole.ADMIN]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. This action requires Trainer or Admin privileges.",
        )
    return current_user


def require_member(current_user: User = Depends(get_current_user)) -> User:
    """
    Allows all authenticated users (MEMBER, TRAINER, ADMIN).
    Just a semantic alias for get_current_user — used for clarity in routes.
    """
    return current_user


def require_self_or_admin(
    user_id: int,
    current_user: User = Depends(get_current_user),
) -> User:
    """
    Allows a user to access their own data, OR an admin to access any user's data.
    Raises HTTP 403 if a non-admin tries to access another user's data.

    Usage:
        @router.get("/users/{user_id}/profile")
        def get_profile(user_id: int, actor: User = Depends(require_self_or_admin)):
            ...
    """
    if current_user.role != UserRole.ADMIN and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. You can only access your own data.",
        )
    return current_user
