"""
core/security.py — Enhanced Security Module (Phase 2)

Improvements over Phase 1:
- Refresh token blacklisting (logout support via Redis)
- Token fingerprinting (ties token to the device/IP that issued it)
- Stronger password validation
- Helper to extract claims from token without raising exceptions
"""

import hashlib
from datetime import datetime, timedelta
from typing import Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

# ---------------------------------------------------------------------------
# Password Hashing (bcrypt)
# bcrypt is intentionally slow — it makes brute-force attacks impractical.
# ---------------------------------------------------------------------------
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(plain_password: str) -> str:
    """
    Hash a plain-text password using bcrypt before storing in the DB.
    Each hash is unique even for the same password (bcrypt adds a salt).
    """
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a plain password against a stored bcrypt hash.
    Returns True if they match, False otherwise.
    """
    return pwd_context.verify(plain_password, hashed_password)


# ---------------------------------------------------------------------------
# JWT Token Creation
# ---------------------------------------------------------------------------

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Create a short-lived JWT access token.

    The token encodes:
    - 'sub': user ID (subject)
    - 'role': user role (for RBAC checks)
    - 'type': 'access' (to distinguish from refresh tokens)
    - 'exp': expiry timestamp

    Default expiry: ACCESS_TOKEN_EXPIRE_MINUTES from config (e.g. 30 min)
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def create_refresh_token(data: dict) -> str:
    """
    Create a long-lived JWT refresh token.

    Refresh tokens are used to get new access tokens without re-logging in.
    They last longer (e.g. 7 days) and are stored securely on the client.

    When a user logs out, the refresh token is blacklisted in Redis
    so it cannot be reused even if someone intercepts it.
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> Optional[dict]:
    """
    Decode and validate a JWT token.

    Returns the payload dict if valid, or None if:
    - Token is malformed
    - Token has expired
    - Signature doesn't match (tampered token)
    """
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        return payload
    except JWTError:
        return None


def get_token_jti(token: str) -> Optional[str]:
    """
    Get the unique identifier (jti) of a token — used for blacklisting.

    Since not all tokens have a 'jti' claim, we derive a unique ID
    by hashing the token itself. This is safe and consistent.
    """
    return hashlib.sha256(token.encode()).hexdigest()
