"""
routers/auth.py — Authentication API Endpoints (Phase 2)

Endpoints:
    POST /api/auth/register          → Create a new account
    POST /api/auth/login             → Login and receive JWT tokens
    POST /api/auth/refresh           → Get a new access token using refresh token
    POST /api/auth/logout            → Revoke tokens (proper logout)
    POST /api/auth/forgot-password   → Request OTP via email
    POST /api/auth/verify-otp        → Verify the 6-digit OTP
    POST /api/auth/reset-password    → Set new password after OTP verified
    GET  /api/auth/me                → Get current user info (verify token works)

Phase 2 additions vs Phase 1:
- Proper logout with token blacklisting
- IP-based rate limiting on login and OTP endpoints
- Service layer (AuthService) — router is now thin HTTP glue only
- Better error messages and logging
"""

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, EmailStr, field_validator
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.models.user import User, UserRole
from app.schemas.user import UserResponse
from app.services.auth_service import AuthService

router = APIRouter()


# ---------------------------------------------------------------------------
# Request / Response Schemas (defined here for clarity)
# ---------------------------------------------------------------------------

class RegisterRequest(BaseModel):
    """Body for POST /register"""
    full_name: str
    email: EmailStr
    password: str
    phone: str | None = None
    role: UserRole = UserRole.MEMBER

    @field_validator("password")
    @classmethod
    def validate_password(cls, v):
        """
        Enforce password policy:
        - At least 8 characters
        - At least one digit
        - At least one uppercase letter
        """
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters.")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one number.")
        if not any(c.isupper() for c in v):
            raise ValueError("Password must contain at least one uppercase letter.")
        return v

    @field_validator("full_name")
    @classmethod
    def validate_name(cls, v):
        if not v.strip():
            raise ValueError("Full name cannot be empty.")
        if len(v.strip()) < 2:
            raise ValueError("Full name must be at least 2 characters.")
        return v.strip()


class LoginRequest(BaseModel):
    """Body for POST /login"""
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Returned after login or token refresh"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    """Body for POST /refresh"""
    refresh_token: str


class LogoutRequest(BaseModel):
    """Body for POST /logout — send both tokens to revoke them"""
    refresh_token: str | None = None


class ForgotPasswordRequest(BaseModel):
    """Body for POST /forgot-password"""
    email: EmailStr


class VerifyOTPRequest(BaseModel):
    """Body for POST /verify-otp"""
    email: EmailStr
    otp: str


class ResetPasswordRequest(BaseModel):
    """Body for POST /reset-password"""
    email: EmailStr
    otp: str
    new_password: str

    @field_validator("new_password")
    @classmethod
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError("New password must be at least 8 characters.")
        if not any(c.isdigit() for c in v):
            raise ValueError("New password must contain at least one number.")
        if not any(c.isupper() for c in v):
            raise ValueError("New password must contain at least one uppercase letter.")
        return v


# ---------------------------------------------------------------------------
# REGISTER — Create a new account
# ---------------------------------------------------------------------------
@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user",
    description="Creates a new gym account. Sends a welcome email on success.",
)
def register(body: RegisterRequest, db: Session = Depends(get_db)):
    """
    Register a new user.

    - Anyone can register as a MEMBER.
    - Creating ADMIN or TRAINER accounts should be restricted in production
      (remove those roles from the public register endpoint).
    """
    service = AuthService(db)
    user = service.register_user(
        full_name=body.full_name,
        email=body.email,
        password=body.password,
        phone=body.phone,
        role=body.role,
    )
    return user


# ---------------------------------------------------------------------------
# LOGIN — Get JWT tokens
# ---------------------------------------------------------------------------
@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Login and receive JWT tokens",
)
def login(body: LoginRequest, request: Request, db: Session = Depends(get_db)):
    """
    Authenticate with email and password.

    Returns:
    - access_token:  Use in Authorization header for all protected routes
    - refresh_token: Use to get a new access_token when it expires

    Rate limited: 5 failed attempts per IP per 5 minutes.
    """
    # Get client IP for rate limiting
    client_ip = request.client.host if request.client else "unknown"

    service = AuthService(db)
    tokens = service.login(
        email=body.email,
        password=body.password,
        client_ip=client_ip,
    )
    return tokens


# ---------------------------------------------------------------------------
# REFRESH — Get new access token
# ---------------------------------------------------------------------------
@router.post(
    "/refresh",
    response_model=TokenResponse,
    summary="Refresh access token",
    description="Exchange a valid refresh token for a new access token.",
)
def refresh_token(body: RefreshRequest):
    """
    Use the refresh token to get a new access token without logging in again.

    Call this when you receive a 401 response and have a valid refresh token.
    Both a new access token and a new refresh token are returned (token rotation).
    """
    from app.core.database import SessionLocal
    db = SessionLocal()
    try:
        service = AuthService(db)
        return service.refresh_access_token(body.refresh_token)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# LOGOUT — Revoke tokens
# ---------------------------------------------------------------------------
@router.post(
    "/logout",
    summary="Logout and revoke tokens",
    description="Blacklists the current access and refresh tokens.",
)
def logout(
    body: LogoutRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Logout the current user.

    Blacklists the access token so it cannot be used again.
    Optionally blacklists the refresh token too (send it in the body).

    After logout, the client should discard both tokens and redirect to login.
    """
    # Extract the raw token from the Authorization header
    auth_header = request.headers.get("Authorization", "")
    access_token = auth_header.replace("Bearer ", "").strip()

    service = AuthService(db)
    service.logout(
        access_token=access_token,
        refresh_token=body.refresh_token,
    )

    return {"message": "Logged out successfully. Tokens have been revoked."}


# ---------------------------------------------------------------------------
# FORGOT PASSWORD — Step 1: Request OTP
# ---------------------------------------------------------------------------
@router.post(
    "/forgot-password",
    summary="Request password reset OTP",
    description="Sends a 6-digit OTP to the user's email address.",
)
def forgot_password(body: ForgotPasswordRequest, db: Session = Depends(get_db)):
    """
    Trigger the password reset flow.

    1. If the email is registered, a 6-digit OTP is sent to it.
    2. The OTP expires in 10 minutes.
    3. Always returns the same message — doesn't reveal if email is registered.

    Next step: POST /verify-otp
    """
    service = AuthService(db)
    service.request_password_reset(body.email)

    # Always return the same message for security (email enumeration prevention)
    return {
        "message": "If that email address is registered, you will receive an OTP shortly."
    }


# ---------------------------------------------------------------------------
# VERIFY OTP — Step 2: Confirm OTP code
# ---------------------------------------------------------------------------
@router.post(
    "/verify-otp",
    summary="Verify OTP code",
    description="Verifies the 6-digit OTP sent to the user's email.",
)
def verify_otp(body: VerifyOTPRequest, db: Session = Depends(get_db)):
    """
    Verify the OTP submitted by the user.

    On success: opens a 5-minute window to set a new password.
    On failure: returns HTTP 400 with a descriptive error.

    Next step: POST /reset-password
    """
    service = AuthService(db)
    service.verify_otp(email=body.email, otp=body.otp)

    return {"message": "OTP verified successfully. You may now reset your password."}


# ---------------------------------------------------------------------------
# RESET PASSWORD — Step 3: Set new password
# ---------------------------------------------------------------------------
@router.post(
    "/reset-password",
    summary="Set a new password",
    description="Sets a new password after OTP has been verified.",
)
def reset_password(body: ResetPasswordRequest, db: Session = Depends(get_db)):
    """
    Set a new password.

    Requires:
    - OTP was verified via /verify-otp within the last 5 minutes, OR
    - OTP is provided again directly in this request

    After success:
    - Password is updated
    - All OTP-related Redis keys are cleared
    - User must log in again with the new password
    """
    service = AuthService(db)
    service.reset_password(
        email=body.email,
        otp=body.otp,
        new_password=body.new_password,
    )

    return {"message": "Password reset successfully. Please log in with your new password."}


# ---------------------------------------------------------------------------
# GET CURRENT USER — Verify token & get user info
# ---------------------------------------------------------------------------
@router.get(
    "/me",
    response_model=UserResponse,
    summary="Get current authenticated user",
    description="Returns the profile of the currently logged-in user. Use to verify a token is valid.",
)
def get_me(current_user: User = Depends(get_current_user)):
    """
    Returns the currently authenticated user's profile.

    Useful for:
    - Verifying a stored token is still valid
    - Getting user info after login without a separate API call
    - Hydrating the frontend after a page refresh
    """
    return current_user
