"""
utils/rate_limiter.py — Reusable Rate Limiting Utility

Rate limiting prevents abuse by restricting how often an endpoint can be called.
Common use cases in this system:
- Login: max 5 failed attempts per IP per 5 minutes
- OTP requests: max 3 per email per 10 minutes
- Registration: max 10 per IP per hour

This utility wraps the Redis-based attempt tracking from redis_client.py
into a clean, reusable decorator-style function for use in routes.
"""

from fastapi import HTTPException, Request, status
from app.core.redis_client import increment_attempts


def check_rate_limit(
    key: str,
    max_attempts: int,
    window_seconds: int,
    error_message: str = "Too many requests. Please try again later.",
) -> None:
    """
    Check if a rate limit has been exceeded and raise HTTP 429 if so.

    Parameters:
        key:             Unique Redis key for this limit (e.g. "login:192.168.1.1")
        max_attempts:    Maximum number of attempts allowed in the time window
        window_seconds:  How long the time window lasts in seconds
        error_message:   Custom error message to show the user

    Usage in a route:
        @router.post("/login")
        def login(request: Request, ...):
            check_rate_limit(
                key=f"login:{request.client.host}",
                max_attempts=5,
                window_seconds=300,
                error_message="Too many login attempts. Try again in 5 minutes."
            )
            # ... rest of login logic
    """
    count = increment_attempts(key, window_seconds)
    if count > max_attempts:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=error_message,
            headers={"Retry-After": str(window_seconds)},
            # Retry-After header tells the client how long to wait
        )


def get_client_ip(request: Request) -> str:
    """
    Safely extract the client's IP address from the request.

    Checks X-Forwarded-For header first (set by load balancers/proxies like Nginx).
    Falls back to the direct connection IP.
    """
    # X-Forwarded-For contains the real IP when behind a proxy
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        # May contain multiple IPs: "client, proxy1, proxy2" — take the first
        return forwarded_for.split(",")[0].strip()

    # Direct connection IP
    return request.client.host if request.client else "unknown"
