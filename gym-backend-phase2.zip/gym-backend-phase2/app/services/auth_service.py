"""
services/auth_service.py — Authentication Business Logic

This service layer sits between the router (HTTP layer) and the database.
It contains the actual logic for each auth operation.

Why separate services from routers?
- Routers handle HTTP (request/response, status codes)
- Services handle business logic (rules, validation, data manipulation)
- This separation makes code easier to test and reuse

All functions here raise HTTPException on failure so the router
can pass them straight to FastAPI without extra error handling.
"""

import random
import string
import logging
from datetime import timedelta

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.redis_client import (
    blacklist_token,
    clear_otp_verified,
    delete_otp,
    get_otp,
    get_token_jti,
    increment_attempts,
    is_otp_verified,
    is_token_blacklisted,
    mark_otp_verified,
    reset_attempts,
    store_otp,
)
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.models.user import User, UserRole
from app.services.email_service import send_otp_email, send_welcome_email

logger = logging.getLogger(__name__)

# Rate limiting constants
MAX_LOGIN_ATTEMPTS     = 5    # Max failed logins before lockout
MAX_OTP_ATTEMPTS       = 3    # Max wrong OTP attempts
LOGIN_WINDOW_SECONDS   = 300  # 5 minutes
OTP_WINDOW_SECONDS     = 600  # 10 minutes


class AuthService:
    """
    Handles all authentication operations.
    Instantiate with a DB session: service = AuthService(db)
    """

    def __init__(self, db: Session):
        self.db = db

    # -----------------------------------------------------------------------
    # REGISTER
    # -----------------------------------------------------------------------
    def register_user(
        self,
        full_name: str,
        email: str,
        password: str,
        phone: str | None = None,
        role: UserRole = UserRole.MEMBER,
    ) -> User:
        """
        Register a new user account.

        Validations:
        - Email must not already be in use
        - Password is hashed before storage
        - Welcome email is sent (non-blocking)
        """
        # Check for duplicate email (case-insensitive)
        existing = self.db.query(User).filter(
            User.email == email.lower().strip()
        ).first()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An account with this email already exists.",
            )

        # Create user
        user = User(
            full_name=full_name.strip(),
            email=email.lower().strip(),
            phone=phone,
            hashed_password=hash_password(password),
            role=role,
            is_active=True,
            is_verified=False,  # Email verification pending
        )
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)

        # Send welcome email (failure doesn't block registration)
        try:
            send_welcome_email(user.email, user.full_name)
        except Exception as e:
            logger.warning(f"Welcome email failed for {user.email}: {e}")

        logger.info(f"New user registered: {user.email} (role={user.role})")
        return user

    # -----------------------------------------------------------------------
    # LOGIN
    # -----------------------------------------------------------------------
    def login(self, email: str, password: str, client_ip: str = "unknown") -> dict:
        """
        Authenticate a user and return JWT tokens.

        Security features:
        - Rate limiting: max 5 failed attempts per IP per 5 minutes
        - Same error message for "wrong email" and "wrong password"
          (prevents attackers from discovering valid emails)
        - Resets attempt counter on successful login
        """
        rate_key = f"login_attempts:{client_ip}"

        # Check rate limit
        attempts = increment_attempts(rate_key, LOGIN_WINDOW_SECONDS)
        if attempts > MAX_LOGIN_ATTEMPTS:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Too many failed login attempts. Try again in 5 minutes.",
            )

        # Find user
        user = self.db.query(User).filter(
            User.email == email.lower().strip()
        ).first()

        # Validate credentials (same message for both failure cases)
        if not user or not verify_password(password, user.hashed_password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect email or password.",
            )

        # Check account status
        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account is deactivated. Please contact support.",
            )

        # Success — reset the rate limit counter
        reset_attempts(rate_key)

        # Build JWT payload
        token_data = {"sub": str(user.id), "role": user.role.value}

        logger.info(f"User logged in: {user.email}")
        return {
            "access_token":  create_access_token(token_data),
            "refresh_token": create_refresh_token(token_data),
            "token_type":    "bearer",
        }

    # -----------------------------------------------------------------------
    # REFRESH TOKEN
    # -----------------------------------------------------------------------
    def refresh_access_token(self, refresh_token: str) -> dict:
        """
        Exchange a valid refresh token for a new access token.

        Checks:
        - Token must be decodable and not expired
        - Must be a refresh token (not an access token)
        - Must not be blacklisted (user didn't log out)
        """
        payload = decode_token(refresh_token)

        if not payload or payload.get("type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired refresh token. Please log in again.",
            )

        # Check if this refresh token was revoked
        token_hash = get_token_jti(refresh_token)
        if is_token_blacklisted(token_hash):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Refresh token has been revoked. Please log in again.",
            )

        # Issue new access token (and a new refresh token for rotation)
        token_data = {"sub": payload["sub"], "role": payload["role"]}
        return {
            "access_token":  create_access_token(token_data),
            "refresh_token": create_refresh_token(token_data),
            "token_type":    "bearer",
        }

    # -----------------------------------------------------------------------
    # LOGOUT
    # -----------------------------------------------------------------------
    def logout(self, access_token: str, refresh_token: str | None = None) -> None:
        """
        Logout a user by blacklisting their tokens.

        After logout:
        - The access token cannot be used (even if not expired)
        - The refresh token cannot be used to get new access tokens
        - The user must log in again to get new tokens
        """
        # Blacklist the access token
        access_hash = get_token_jti(access_token)
        # Access tokens expire in 30 min — blacklist for same duration
        blacklist_token(access_hash, expiry_seconds=settings_expiry())

        # Blacklist the refresh token too (if provided)
        if refresh_token:
            payload = decode_token(refresh_token)
            if payload:
                refresh_hash = get_token_jti(refresh_token)
                # Refresh tokens expire in 7 days
                blacklist_token(refresh_hash, expiry_seconds=7 * 24 * 3600)

        logger.info("User logged out — tokens blacklisted")

    # -----------------------------------------------------------------------
    # FORGOT PASSWORD
    # -----------------------------------------------------------------------
    def request_password_reset(self, email: str) -> None:
        """
        Generate a 6-digit OTP and send it to the user's email.

        Security note: We return the same message whether the email
        exists or not — this prevents email enumeration attacks.
        """
        user = self.db.query(User).filter(
            User.email == email.lower().strip()
        ).first()

        if not user:
            # Don't reveal whether the email is registered
            logger.info(f"Password reset requested for unknown email: {email}")
            return  # Silently succeed

        # Rate limit: max 3 OTP requests per email per 10 minutes
        rate_key = f"otp_requests:{email}"
        attempts = increment_attempts(rate_key, OTP_WINDOW_SECONDS)
        if attempts > 3:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many OTP requests. Please wait 10 minutes before trying again.",
            )

        # Generate a 6-digit OTP
        otp = "".join(random.choices(string.digits, k=6))

        # Store OTP in Redis (expires in 10 minutes)
        store_otp(email, otp)

        # Send OTP via email
        sent = send_otp_email(email, otp, full_name=user.full_name)
        if not sent:
            logger.error(f"Failed to send OTP email to {email}")
            # Still don't raise — we don't want to reveal the email exists

        logger.info(f"OTP sent to {email}")

    # -----------------------------------------------------------------------
    # VERIFY OTP
    # -----------------------------------------------------------------------
    def verify_otp(self, email: str, otp: str) -> None:
        """
        Verify that the submitted OTP matches what was sent.

        On success: marks the email as "OTP verified" in Redis (5 min window)
        On failure: raises HTTP 400
        """
        stored_otp = get_otp(email)

        if not stored_otp:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="OTP has expired or was not requested. Please request a new one.",
            )

        if stored_otp != otp.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Incorrect OTP. Please double-check and try again.",
            )

        # OTP is correct — mark as verified and remove the OTP
        mark_otp_verified(email)
        delete_otp(email)

        logger.info(f"OTP verified for {email}")

    # -----------------------------------------------------------------------
    # RESET PASSWORD
    # -----------------------------------------------------------------------
    def reset_password(self, email: str, otp: str, new_password: str) -> None:
        """
        Set a new password after OTP verification.

        Requires the OTP to have been verified (within the last 5 minutes).
        Cleans up all Redis keys after a successful reset.
        """
        # Verify OTP one more time inline (for the reset endpoint)
        # This ensures the flow: verify-otp → reset-password is respected
        stored_otp = get_otp(email)
        if stored_otp:
            # OTP was provided again — verify it directly
            if stored_otp != otp.strip():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Incorrect OTP.",
                )
            mark_otp_verified(email)
            delete_otp(email)

        # Check that OTP was verified
        if not is_otp_verified(email):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="OTP not verified. Please complete the /verify-otp step first.",
            )

        # Find user
        user = self.db.query(User).filter(
            User.email == email.lower().strip()
        ).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found.")

        # Update password
        user.hashed_password = hash_password(new_password)
        self.db.commit()

        # Clean up Redis
        clear_otp_verified(email)

        logger.info(f"Password reset successful for {email}")


def settings_expiry() -> int:
    """Helper to get access token expiry in seconds."""
    from app.core.config import settings
    return settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
