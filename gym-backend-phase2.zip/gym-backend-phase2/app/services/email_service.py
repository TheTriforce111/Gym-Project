"""
services/email_service.py — Email Sending Service

This service handles all outgoing emails from the gym system:
- OTP codes for password reset
- Welcome emails after registration
- Membership confirmation emails

We use Python's built-in smtplib for sending emails via SMTP.
In production, consider using SendGrid or Mailgun for better deliverability.

Configuration (set in .env):
    SMTP_HOST=smtp.gmail.com
    SMTP_PORT=587
    SMTP_USERNAME=yourgym@gmail.com
    SMTP_PASSWORD=your-app-password
"""

import smtplib
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from app.core.config import settings

# Set up logging so we can see email errors in the server console
logger = logging.getLogger(__name__)


def _send_email(to_email: str, subject: str, html_body: str) -> bool:
    """
    Internal helper — sends an email using SMTP.

    Parameters:
        to_email:  Recipient email address
        subject:   Email subject line
        html_body: HTML content of the email

    Returns True if sent successfully, False on failure.
    We return False instead of raising to avoid crashing the API
    if the email service is temporarily down.
    """
    try:
        # Create a multipart email (supports both plain text and HTML)
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = settings.SMTP_USERNAME
        msg["To"]      = to_email

        # Attach the HTML body
        msg.attach(MIMEText(html_body, "html"))

        # Connect to the SMTP server and send
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
            server.ehlo()
            server.starttls()   # Upgrade connection to encrypted (TLS)
            server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
            server.sendmail(settings.SMTP_USERNAME, to_email, msg.as_string())

        logger.info(f"Email sent successfully to {to_email}")
        return True

    except Exception as e:
        # Log the error but don't crash the API — email failure is non-critical
        logger.error(f"Failed to send email to {to_email}: {e}")
        return False


# ---------------------------------------------------------------------------
# Public Email Functions
# ---------------------------------------------------------------------------

def send_otp_email(to_email: str, otp: str, full_name: str = "Member") -> bool:
    """
    Send a password reset OTP email to the user.

    The email contains:
    - A clear message explaining what the OTP is for
    - The 6-digit OTP code (styled prominently)
    - Expiry warning (10 minutes)
    - Security note (don't share the code)
    """
    subject = "🔐 Your Gym Password Reset Code"
    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px;">
        <div style="max-width: 500px; margin: auto; background: white;
                    border-radius: 10px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h2 style="color: #1a1a2e;">Password Reset Request</h2>
            <p>Hello <strong>{full_name}</strong>,</p>
            <p>We received a request to reset your gym account password.</p>
            <p>Your one-time verification code is:</p>
            <div style="text-align: center; margin: 30px 0;">
                <span style="font-size: 40px; font-weight: bold; letter-spacing: 10px;
                             color: #e94560; background: #f8f8f8; padding: 15px 25px;
                             border-radius: 8px; border: 2px dashed #e94560;">
                    {otp}
                </span>
            </div>
            <p style="color: #666;">⏰ This code expires in <strong>10 minutes</strong>.</p>
            <p style="color: #666;">🔒 Never share this code with anyone. Our staff will never ask for it.</p>
            <p style="color: #666;">If you didn't request this, please ignore this email — your password is safe.</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
            <p style="color: #999; font-size: 12px;">
                Gym Management System | This is an automated message, please do not reply.
            </p>
        </div>
    </body>
    </html>
    """
    return _send_email(to_email, subject, html_body)


def send_welcome_email(to_email: str, full_name: str) -> bool:
    """
    Send a welcome email when a new user registers.
    Encourages them to verify their account and explore the gym app.
    """
    subject = "🏋️ Welcome to Our Gym!"
    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px;">
        <div style="max-width: 500px; margin: auto; background: white;
                    border-radius: 10px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h2 style="color: #1a1a2e;">Welcome, {full_name}! 💪</h2>
            <p>Your account has been created successfully.</p>
            <p>Here's what you can do with your account:</p>
            <ul>
                <li>📅 Book gym classes</li>
                <li>🏋️ Track your workouts</li>
                <li>📊 View your attendance history</li>
                <li>📱 Use your QR code to check in</li>
            </ul>
            <p>Visit the gym front desk to get your membership activated.</p>
            <p>See you at the gym! 🚀</p>
        </div>
    </body>
    </html>
    """
    return _send_email(to_email, subject, html_body)


def send_membership_confirmation_email(
    to_email: str,
    full_name: str,
    plan: str,
    end_date: str,
    amount: float,
) -> bool:
    """
    Send a confirmation email after a membership is activated or renewed.
    """
    subject = "✅ Membership Confirmed"
    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px;">
        <div style="max-width: 500px; margin: auto; background: white;
                    border-radius: 10px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h2 style="color: #1a1a2e;">Membership Confirmed ✅</h2>
            <p>Hello <strong>{full_name}</strong>, your membership is now active!</p>
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                <tr style="background: #f8f8f8;">
                    <td style="padding: 10px; font-weight: bold;">Plan</td>
                    <td style="padding: 10px; text-transform: capitalize;">{plan}</td>
                </tr>
                <tr>
                    <td style="padding: 10px; font-weight: bold;">Expires</td>
                    <td style="padding: 10px;">{end_date}</td>
                </tr>
                <tr style="background: #f8f8f8;">
                    <td style="padding: 10px; font-weight: bold;">Amount Paid</td>
                    <td style="padding: 10px;">${amount:.2f}</td>
                </tr>
            </table>
            <p>Thank you for being a valued member. Keep crushing your goals! 💪</p>
        </div>
    </body>
    </html>
    """
    return _send_email(to_email, subject, html_body)
