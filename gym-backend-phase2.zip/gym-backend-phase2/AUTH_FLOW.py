"""
AUTH_FLOW.md — Visual Reference for the Authentication System

This document explains the full Phase 2 auth system for the team.
"""

# ============================================================
# PHASE 2 — AUTHENTICATION SYSTEM OVERVIEW
# ============================================================
#
#  ┌─────────────────────────────────────────────────────────┐
#  │              REGISTRATION FLOW                          │
#  └─────────────────────────────────────────────────────────┘
#
#  Client                   API                      Database
#    │                       │                          │
#    │  POST /auth/register   │                          │
#    │──────────────────────>│                          │
#    │  {name, email, pass}   │                          │
#    │                       │─── Check duplicate? ────>│
#    │                       │<── No duplicate ─────────│
#    │                       │─── Hash password         │
#    │                       │─── Save user ───────────>│
#    │                       │<── User saved ───────────│
#    │                       │─── Send welcome email    │
#    │<── 201 {user data} ───│                          │
#
#  ┌─────────────────────────────────────────────────────────┐
#  │              LOGIN FLOW                                 │
#  └─────────────────────────────────────────────────────────┘
#
#  Client                   API                  Redis/DB
#    │                       │                      │
#    │  POST /auth/login      │                      │
#    │──────────────────────>│                      │
#    │  {email, password}     │                      │
#    │                       │─ Check rate limit ──>│ (Redis)
#    │                       │─ Find user by email ─>│ (DB)
#    │                       │─ Verify password      │
#    │                       │─ Reset rate limit ──>│ (Redis)
#    │<── 200 {tokens} ──────│                      │
#    │  access_token (30min)  │                      │
#    │  refresh_token (7days) │                      │
#
#  ┌─────────────────────────────────────────────────────────┐
#  │              PROTECTED ROUTE FLOW                       │
#  └─────────────────────────────────────────────────────────┘
#
#  Client                   API               Redis    DB
#    │                       │                  │       │
#    │  GET /api/workouts/me  │                  │       │
#    │  Authorization: Bearer <token>            │       │
#    │──────────────────────>│                  │       │
#    │                       │─ Decode JWT       │       │
#    │                       │─ Check blacklist ─>│      │
#    │                       │─ Fetch user ──────────────>│
#    │<── 200 {data} ────────│                  │       │
#
#  ┌─────────────────────────────────────────────────────────┐
#  │              PASSWORD RESET FLOW                        │
#  └─────────────────────────────────────────────────────────┘
#
#  Client            API            Redis          Email
#    │                 │               │              │
#    │  POST /forgot   │               │              │
#    │───────────────>│               │              │
#    │                │─ Generate OTP  │              │
#    │                │─ Store OTP ──>│ (10min TTL)  │
#    │                │─ Send email ──────────────────>│
#    │<── 200 "check email" ─│        │              │
#    │                │               │              │
#    │  POST /verify-otp      │        │              │
#    │───────────────>│               │              │
#    │                │─ Check OTP ──>│              │
#    │                │<─ Match ──────│              │
#    │                │─ Mark verified ->│ (5min TTL) │
#    │<── 200 "verified" ─────│       │              │
#    │                │               │              │
#    │  POST /reset-password  │        │              │
#    │───────────────>│               │              │
#    │                │─ Check verified ->│           │
#    │                │─ Hash password  │             │
#    │                │─ Update DB      │             │
#    │                │─ Clear Redis ──>│             │
#    │<── 200 "success" ──────│        │             │
