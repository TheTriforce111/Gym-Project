# 🔐 Phase 2 — Authentication System

This phase builds on Phase 1 with a complete, production-grade auth system.

---

## 📁 New Files in Phase 2

```
app/
├── core/
│   ├── security.py         ← Enhanced: token blacklisting, SHA-256 fingerprinting
│   ├── redis_client.py     ← NEW: centralized Redis helpers (OTP, blacklist, rate limits)
│   ├── dependencies.py     ← Enhanced: blacklist check, role guards (require_admin, etc.)
│   └── config.py           ← Updated: cleaner settings
├── routers/
│   └── auth.py             ← Rebuilt: thin HTTP layer, delegates to AuthService
├── services/
│   ├── auth_service.py     ← NEW: all auth business logic in one place
│   └── email_service.py    ← NEW: HTML emails for OTP, welcome, membership
└── utils/
    └── rate_limiter.py     ← NEW: reusable rate limiting utility

tests/
└── test_auth.py            ← NEW: full test suite for auth endpoints
```

---

## 🔁 Auth Endpoints

| Method | Endpoint                    | Auth Required | Description                        |
|--------|-----------------------------|---------------|------------------------------------|
| POST   | `/api/auth/register`        | No            | Create account                     |
| POST   | `/api/auth/login`           | No            | Login, get tokens                  |
| POST   | `/api/auth/refresh`         | No            | Refresh access token               |
| POST   | `/api/auth/logout`          | ✅ Yes        | Revoke tokens (proper logout)      |
| POST   | `/api/auth/forgot-password` | No            | Request OTP via email              |
| POST   | `/api/auth/verify-otp`      | No            | Verify 6-digit OTP                 |
| POST   | `/api/auth/reset-password`  | No            | Set new password                   |
| GET    | `/api/auth/me`              | ✅ Yes        | Get current user info              |

---

## 🔒 Security Features Added

### 1. Token Blacklisting (Real Logout)
In Phase 1, "logout" just meant deleting the token on the client.
The token was still valid until it expired.

In Phase 2, logout blacklists both tokens in Redis:
```
User logs out → tokens stored in Redis blacklist
Next request → server checks blacklist → 401 Unauthorized
```

### 2. Rate Limiting
- **Login**: 5 failed attempts per IP per 5 minutes → HTTP 429
- **OTP requests**: 3 per email per 10 minutes → HTTP 429
- Counters reset automatically via Redis TTL

### 3. Password Policy
Passwords must have:
- Minimum 8 characters
- At least 1 number
- At least 1 uppercase letter

### 4. Email Enumeration Prevention
Forgot password always returns the same message whether or not the email exists.
This prevents attackers from discovering valid email addresses.

### 5. Service Layer
Business logic is now in `AuthService` — the router only handles HTTP.
This makes the code easier to test and reuse.

---

## 🧪 Running Tests

```bash
# Install test dependencies
pip install pytest httpx

# Run all auth tests
pytest tests/test_auth.py -v

# Run with coverage report
pytest tests/test_auth.py --cov=app --cov-report=html
```

---

## 🔑 How to Use JWT in the Frontend

```javascript
// After login, store tokens
localStorage.setItem('access_token', data.access_token);
localStorage.setItem('refresh_token', data.refresh_token);

// Add token to every API request
const response = await fetch('/api/users/me', {
    headers: {
        'Authorization': `Bearer ${localStorage.getItem('access_token')}`
    }
});

// If 401, try refreshing
if (response.status === 401) {
    const refreshRes = await fetch('/api/auth/refresh', {
        method: 'POST',
        body: JSON.stringify({ refresh_token: localStorage.getItem('refresh_token') })
    });
    if (refreshRes.ok) {
        const newTokens = await refreshRes.json();
        localStorage.setItem('access_token', newTokens.access_token);
        // Retry the original request
    } else {
        // Refresh failed — redirect to login
        window.location.href = '/login';
    }
}
```

---

## 📨 Email Setup (Gmail)

1. Enable 2-Factor Authentication on your Gmail account
2. Go to: https://myaccount.google.com/apppasswords
3. Generate an App Password for "Mail"
4. Add to `.env`:
```
SMTP_USERNAME=yourgym@gmail.com
SMTP_PASSWORD=xxxx xxxx xxxx xxxx   ← the 16-char app password
```

---

## ➡️ Next Phase

- **Phase 3** — Membership System (plans, status, expiry)
- **Phase 4** — Stripe Payment Integration
- **Phase 10** — React Admin Dashboard
