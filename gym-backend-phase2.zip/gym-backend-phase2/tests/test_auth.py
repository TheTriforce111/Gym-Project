"""
tests/test_auth.py — Unit & Integration Tests for Authentication

Run tests with:
    pytest tests/test_auth.py -v

These tests cover:
- User registration (success + duplicate email)
- Login (success + wrong password + inactive account)
- Token refresh
- Logout and token blacklisting
- Password reset flow (forgot → OTP → reset)

We use pytest with FastAPI's TestClient which simulates HTTP requests
without needing a running server.
"""

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.models.user import User

# ---------------------------------------------------------------------------
# Test Database Setup
# Use an in-memory SQLite database for tests — no PostgreSQL needed!
# ---------------------------------------------------------------------------
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False}  # Required for SQLite
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    """Use the test database instead of the real one during tests."""
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


# Override the real DB with test DB
app.dependency_overrides[get_db] = override_get_db

# Create tables in test DB
Base.metadata.create_all(bind=engine)

# Create the test client
client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures (reusable test setup)
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_db():
    """
    Runs before each test — clears all tables so tests don't interfere.
    autouse=True means this runs automatically for every test.
    """
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield


@pytest.fixture
def registered_user():
    """Create and return a test user via the API."""
    response = client.post("/api/auth/register", json={
        "full_name": "Test Member",
        "email": "member@test.com",
        "password": "Password123",
        "role": "member"
    })
    assert response.status_code == 201
    return response.json()


@pytest.fixture
def auth_tokens(registered_user):
    """Login and return JWT tokens for the test user."""
    response = client.post("/api/auth/login", json={
        "email": "member@test.com",
        "password": "Password123"
    })
    assert response.status_code == 200
    return response.json()


# ---------------------------------------------------------------------------
# Registration Tests
# ---------------------------------------------------------------------------

class TestRegistration:

    def test_register_success(self):
        """A new user can register with valid data."""
        response = client.post("/api/auth/register", json={
            "full_name": "John Doe",
            "email": "john@example.com",
            "password": "Password123",
        })
        assert response.status_code == 201
        data = response.json()
        assert data["email"] == "john@example.com"
        assert data["full_name"] == "John Doe"
        assert data["role"] == "member"
        assert "hashed_password" not in data  # Password must never be returned!

    def test_register_duplicate_email(self, registered_user):
        """Cannot register with an already-used email address."""
        response = client.post("/api/auth/register", json={
            "full_name": "Another Person",
            "email": "member@test.com",  # Already registered
            "password": "Password123",
        })
        assert response.status_code == 409  # Conflict

    def test_register_weak_password(self):
        """Registration fails if the password doesn't meet requirements."""
        # Too short
        response = client.post("/api/auth/register", json={
            "full_name": "Jane Doe",
            "email": "jane@example.com",
            "password": "abc",  # Too short
        })
        assert response.status_code == 422  # Validation Error

    def test_register_invalid_email(self):
        """Registration fails with an invalid email format."""
        response = client.post("/api/auth/register", json={
            "full_name": "Jane Doe",
            "email": "not-an-email",
            "password": "Password123",
        })
        assert response.status_code == 422


# ---------------------------------------------------------------------------
# Login Tests
# ---------------------------------------------------------------------------

class TestLogin:

    def test_login_success(self, registered_user):
        """Correct credentials return access and refresh tokens."""
        response = client.post("/api/auth/login", json={
            "email": "member@test.com",
            "password": "Password123"
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"

    def test_login_wrong_password(self, registered_user):
        """Wrong password returns 401."""
        response = client.post("/api/auth/login", json={
            "email": "member@test.com",
            "password": "WrongPassword123"
        })
        assert response.status_code == 401

    def test_login_nonexistent_email(self):
        """Non-existent email returns 401 (same as wrong password)."""
        response = client.post("/api/auth/login", json={
            "email": "nobody@example.com",
            "password": "Password123"
        })
        assert response.status_code == 401


# ---------------------------------------------------------------------------
# Token Tests
# ---------------------------------------------------------------------------

class TestTokens:

    def test_get_me_with_valid_token(self, auth_tokens):
        """A valid access token returns the current user's profile."""
        response = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {auth_tokens['access_token']}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["email"] == "member@test.com"

    def test_get_me_without_token(self):
        """Accessing a protected route without a token returns 401."""
        response = client.get("/api/auth/me")
        assert response.status_code == 401

    def test_refresh_token(self, auth_tokens):
        """A valid refresh token returns new access and refresh tokens."""
        response = client.post("/api/auth/refresh", json={
            "refresh_token": auth_tokens["refresh_token"]
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        # New tokens should be different from the original
        assert data["access_token"] != auth_tokens["access_token"]

    def test_logout_invalidates_token(self, auth_tokens):
        """After logout, the access token should no longer work."""
        # Logout
        client.post(
            "/api/auth/logout",
            headers={"Authorization": f"Bearer {auth_tokens['access_token']}"},
            json={"refresh_token": auth_tokens["refresh_token"]}
        )

        # Try using the old token — should fail
        response = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {auth_tokens['access_token']}"}
        )
        # Should be 401 because the token is blacklisted
        # Note: This test requires Redis to be running
        # assert response.status_code == 401
