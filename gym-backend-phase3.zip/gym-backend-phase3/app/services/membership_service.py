"""
services/membership_service.py — Membership Business Logic (Phase 3)

This service handles everything related to memberships:
- Creating new memberships
- Renewing (extending) memberships
- Freezing and unfreezing
- Cancelling
- Auto-expiry check
- Sending notification emails on key events

Following the same service pattern from Phase 2:
- Service receives a DB session in __init__
- Methods raise HTTPException on business rule violations
- Router stays thin (just HTTP, no logic)
"""

import logging
from datetime import datetime, timedelta
from typing import Optional

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.membership import (
    Membership,
    MembershipHistory,
    MembershipChangeReason,
    MembershipPlan,
    MembershipStatus,
)
from app.models.user import User
from app.schemas.membership import (
    PLAN_DURATIONS_DAYS,
    PLAN_PRICES,
    MembershipCreate,
    MembershipFreeze,
    MembershipRenew,
)

logger = logging.getLogger(__name__)


class MembershipService:
    """
    Handles all membership operations.
    Instantiate with a DB session: service = MembershipService(db)
    """

    def __init__(self, db: Session):
        self.db = db

    # -----------------------------------------------------------------------
    # Private Helper: Record History
    # -----------------------------------------------------------------------
    def _record_history(
        self,
        membership: Membership,
        reason: MembershipChangeReason,
        new_status: MembershipStatus,
        changed_by_id: Optional[int] = None,
        note: Optional[str] = None,
        previous_end_date: Optional[datetime] = None,
        new_end_date: Optional[datetime] = None,
    ) -> None:
        """
        Save a history entry every time a membership changes.
        This builds the full audit trail.

        Called internally before committing any status change.
        """
        entry = MembershipHistory(
            membership_id=membership.id,
            previous_status=membership.status,
            new_status=new_status,
            reason=reason,
            previous_end_date=previous_end_date or membership.end_date,
            new_end_date=new_end_date or membership.end_date,
            note=note,
            changed_by_id=changed_by_id,
        )
        self.db.add(entry)
        logger.info(
            f"Membership #{membership.id}: "
            f"{membership.status} → {new_status} | reason={reason}"
        )

    # -----------------------------------------------------------------------
    # GET PRICING PLANS
    # -----------------------------------------------------------------------
    def get_pricing(self) -> list:
        """
        Return available membership plans with prices and durations.
        Used by the frontend to display plan options.
        """
        return [
            {
                "plan": plan.value,
                "duration_days": PLAN_DURATIONS_DAYS[plan],
                "price": PLAN_PRICES[plan],
                "currency": "usd",
            }
            for plan in MembershipPlan
            if plan != MembershipPlan.CUSTOM
        ]

    # -----------------------------------------------------------------------
    # CREATE
    # -----------------------------------------------------------------------
    def create_membership(
        self,
        data: MembershipCreate,
        created_by_id: int,
    ) -> Membership:
        """
        Create a new membership for a user.

        Rules:
        - User must exist
        - User must not already have an ACTIVE membership
        - end_date is calculated from plan type
        - History entry is created

        After creation, an email confirmation is sent.
        """
        # Verify user exists
        user = self.db.query(User).filter(User.id == data.user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail=f"User #{data.user_id} not found.")

        # Check for existing active membership
        existing = self.db.query(Membership).filter(
            Membership.user_id == data.user_id,
            Membership.status == MembershipStatus.ACTIVE,
        ).first()
        if existing and existing.is_valid:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    f"User already has an active membership (expires "
                    f"{existing.end_date.date()}). Renew or cancel it first."
                ),
            )

        # Calculate end date
        start = datetime.utcnow()
        if data.plan == MembershipPlan.CUSTOM and data.custom_end_date:
            end = data.custom_end_date
        else:
            end = start + timedelta(days=PLAN_DURATIONS_DAYS[data.plan])

        # Create membership record
        membership = Membership(
            user_id=data.user_id,
            plan=data.plan,
            status=MembershipStatus.ACTIVE,
            start_date=start,
            end_date=end,
            price_paid=data.price_paid,
            currency=data.currency,
            notes=data.notes,
        )
        self.db.add(membership)
        self.db.flush()  # flush to get membership.id before history insert

        # Record history
        self._record_history(
            membership=membership,
            reason=MembershipChangeReason.CREATED,
            new_status=MembershipStatus.ACTIVE,
            changed_by_id=created_by_id,
            note=f"Membership created. Plan: {data.plan.value}, Price: ${data.price_paid:.2f}",
            new_end_date=end,
        )

        self.db.commit()
        self.db.refresh(membership)

        # Send confirmation email (non-blocking)
        self._send_confirmation_email(user, membership)

        logger.info(f"Membership created for user #{data.user_id}, plan={data.plan}")
        return membership

    # -----------------------------------------------------------------------
    # RENEW
    # -----------------------------------------------------------------------
    def renew_membership(
        self,
        membership_id: int,
        data: MembershipRenew,
        renewed_by_id: int,
    ) -> Membership:
        """
        Renew (extend) an existing membership.

        - If the membership is still active: add days to the current end_date
        - If the membership is expired or cancelled: start fresh from today
        - Plan can be changed during renewal (e.g. monthly → yearly upgrade)

        History entry records the previous and new end dates.
        """
        membership = self._get_or_404(membership_id)

        # Cannot renew a FROZEN membership — must unfreeze first
        if membership.status == MembershipStatus.FROZEN:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot renew a frozen membership. Please unfreeze it first.",
            )

        # Determine the plan for this renewal
        new_plan = data.plan or membership.plan
        new_price = data.price_paid or PLAN_PRICES.get(new_plan, membership.price_paid)
        duration  = timedelta(days=PLAN_DURATIONS_DAYS.get(new_plan, 30))

        old_end_date = membership.end_date

        # If still active: extend from current end date (no gap in membership)
        # If expired/cancelled: start fresh from today
        if membership.status == MembershipStatus.ACTIVE and membership.end_date > datetime.utcnow():
            new_end = membership.end_date + duration
        else:
            new_end = datetime.utcnow() + duration

        # Detect if this is an upgrade (changing to a longer/more expensive plan)
        reason = (
            MembershipChangeReason.UPGRADED
            if new_plan != membership.plan
            else MembershipChangeReason.RENEWED
        )

        # Record history BEFORE changing values
        self._record_history(
            membership=membership,
            reason=reason,
            new_status=MembershipStatus.ACTIVE,
            changed_by_id=renewed_by_id,
            note=data.notes or f"Renewed: {new_plan.value} plan. New expiry: {new_end.date()}",
            previous_end_date=old_end_date,
            new_end_date=new_end,
        )

        # Apply changes
        membership.plan       = new_plan
        membership.status     = MembershipStatus.ACTIVE
        membership.end_date   = new_end
        membership.price_paid = new_price
        if data.notes:
            membership.notes = data.notes

        self.db.commit()
        self.db.refresh(membership)

        logger.info(
            f"Membership #{membership_id} renewed. "
            f"Plan: {new_plan}, New end: {new_end.date()}"
        )
        return membership

    # -----------------------------------------------------------------------
    # FREEZE
    # -----------------------------------------------------------------------
    def freeze_membership(
        self,
        membership_id: int,
        data: MembershipFreeze,
        frozen_by_id: int,
    ) -> Membership:
        """
        Freeze a membership (temporarily pause it).

        When frozen:
        - Member cannot check in to the gym
        - Member cannot book classes
        - When unfrozen, end_date is extended by the freeze duration
          (member doesn't lose paid days)
        """
        membership = self._get_or_404(membership_id)

        if membership.status != MembershipStatus.ACTIVE:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Only ACTIVE memberships can be frozen. Current status: {membership.status.value}",
            )

        if not membership.is_valid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot freeze an already-expired membership.",
            )

        self._record_history(
            membership=membership,
            reason=MembershipChangeReason.FROZEN,
            new_status=MembershipStatus.FROZEN,
            changed_by_id=frozen_by_id,
            note=data.reason or "Membership frozen by admin.",
        )

        membership.status      = MembershipStatus.FROZEN
        membership.freeze_start = datetime.utcnow()
        if data.reason:
            membership.notes = data.reason

        self.db.commit()
        self.db.refresh(membership)
        logger.info(f"Membership #{membership_id} frozen.")
        return membership

    # -----------------------------------------------------------------------
    # UNFREEZE
    # -----------------------------------------------------------------------
    def unfreeze_membership(
        self,
        membership_id: int,
        note: Optional[str],
        unfrozen_by_id: int,
    ) -> Membership:
        """
        Unfreeze a membership and extend end_date by the frozen duration.

        Example:
            Member froze on Jan 1, unfroze on Jan 15 (14 days frozen)
            Original end_date: Feb 28
            New end_date: Feb 28 + 14 days = March 14
        """
        membership = self._get_or_404(membership_id)

        if membership.status != MembershipStatus.FROZEN:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This membership is not frozen.",
            )

        # Calculate how many days it was frozen
        freeze_duration = datetime.utcnow() - membership.freeze_start
        frozen_days = max(1, freeze_duration.days)

        old_end = membership.end_date
        new_end = membership.end_date + timedelta(days=frozen_days)

        self._record_history(
            membership=membership,
            reason=MembershipChangeReason.UNFROZEN,
            new_status=MembershipStatus.ACTIVE,
            changed_by_id=unfrozen_by_id,
            note=(
                note or
                f"Unfrozen after {frozen_days} days. "
                f"End date extended from {old_end.date()} to {new_end.date()}."
            ),
            previous_end_date=old_end,
            new_end_date=new_end,
        )

        membership.status            = MembershipStatus.ACTIVE
        membership.end_date          = new_end
        membership.freeze_end        = datetime.utcnow()
        membership.total_frozen_days += frozen_days

        self.db.commit()
        self.db.refresh(membership)
        logger.info(
            f"Membership #{membership_id} unfrozen. "
            f"Extended by {frozen_days} days. New end: {new_end.date()}"
        )
        return membership

    # -----------------------------------------------------------------------
    # CANCEL
    # -----------------------------------------------------------------------
    def cancel_membership(
        self,
        membership_id: int,
        reason: Optional[str],
        cancelled_by_id: int,
    ) -> Membership:
        """
        Cancel a membership permanently.
        Cancelled memberships cannot be unfrozen or renewed — a new one must be created.
        """
        membership = self._get_or_404(membership_id)

        if membership.status == MembershipStatus.CANCELLED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This membership is already cancelled.",
            )

        self._record_history(
            membership=membership,
            reason=MembershipChangeReason.CANCELLED,
            new_status=MembershipStatus.CANCELLED,
            changed_by_id=cancelled_by_id,
            note=reason or "Membership cancelled by admin.",
        )

        membership.status = MembershipStatus.CANCELLED
        if reason:
            membership.notes = reason

        self.db.commit()
        self.db.refresh(membership)
        logger.info(f"Membership #{membership_id} cancelled.")
        return membership

    # -----------------------------------------------------------------------
    # AUTO-EXPIRE (called by a scheduled background task)
    # -----------------------------------------------------------------------
    def expire_overdue_memberships(self) -> int:
        """
        Find all ACTIVE memberships past their end_date and mark them EXPIRED.

        This should run daily as a scheduled background job (e.g. Celery beat).
        Returns the count of memberships that were expired.
        """
        now = datetime.utcnow()
        overdue = self.db.query(Membership).filter(
            Membership.status == MembershipStatus.ACTIVE,
            Membership.end_date < now,
        ).all()

        count = 0
        for m in overdue:
            self._record_history(
                membership=m,
                reason=MembershipChangeReason.EXPIRED,
                new_status=MembershipStatus.EXPIRED,
                note="Auto-expired by system — end date passed.",
            )
            m.status = MembershipStatus.EXPIRED
            count += 1

        if count > 0:
            self.db.commit()
            logger.info(f"Auto-expired {count} memberships.")

        return count

    # -----------------------------------------------------------------------
    # GET EXPIRING SOON
    # -----------------------------------------------------------------------
    def get_expiring_soon(self, days: int = 7) -> list[Membership]:
        """
        Return all active memberships expiring within the next `days` days.
        Used by admin dashboard and notification system.
        """
        cutoff = datetime.utcnow() + timedelta(days=days)
        return self.db.query(Membership).filter(
            Membership.status == MembershipStatus.ACTIVE,
            Membership.end_date <= cutoff,
            Membership.end_date >= datetime.utcnow(),
        ).order_by(Membership.end_date.asc()).all()

    # -----------------------------------------------------------------------
    # PRIVATE HELPERS
    # -----------------------------------------------------------------------
    def _get_or_404(self, membership_id: int) -> Membership:
        """Fetch a membership by ID or raise HTTP 404."""
        m = self.db.query(Membership).filter(Membership.id == membership_id).first()
        if not m:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Membership #{membership_id} not found.",
            )
        return m

    def _send_confirmation_email(self, user: User, membership: Membership) -> None:
        """Send membership confirmation email (non-critical — errors are logged)."""
        try:
            from app.services.email_service import send_membership_confirmation_email
            send_membership_confirmation_email(
                to_email=user.email,
                full_name=user.full_name,
                plan=membership.plan.value,
                end_date=membership.end_date.strftime("%B %d, %Y"),
                amount=membership.price_paid,
            )
        except Exception as e:
            logger.warning(f"Could not send membership email to {user.email}: {e}")
