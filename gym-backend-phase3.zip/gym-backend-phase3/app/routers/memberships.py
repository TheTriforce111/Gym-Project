"""
routers/memberships.py — Membership API Endpoints (Phase 3)

Endpoints:
    GET  /api/memberships/pricing           → List plans & prices (public)
    POST /api/memberships/                  → Create membership (Admin)
    GET  /api/memberships/me                → My membership details
    GET  /api/memberships/expiring-soon     → Memberships expiring in 7 days (Admin)
    GET  /api/memberships/all               → All memberships, paginated (Admin)
    GET  /api/memberships/{id}              → Get by ID (Admin)
    PATCH /api/memberships/{id}             → Edit notes/end_date (Admin)
    POST /api/memberships/{id}/renew        → Renew membership (Admin)
    POST /api/memberships/{id}/freeze       → Freeze membership (Admin)
    POST /api/memberships/{id}/unfreeze     → Unfreeze membership (Admin)
    POST /api/memberships/{id}/cancel       → Cancel membership (Admin)
    GET  /api/memberships/{id}/history      → Audit trail (Admin)
    POST /api/memberships/expire-overdue    → Run auto-expire (Admin)
"""

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.models.membership import Membership, MembershipHistory, MembershipStatus
from app.models.user import User
from app.schemas.membership import (
    MembershipCancel,
    MembershipCreate,
    MembershipFreeze,
    MembershipRenew,
    MembershipResponse,
    MembershipUpdate,
    MembershipHistoryResponse,
    MembershipSummary,
    PlanPricingResponse,
)
from app.services.membership_service import MembershipService

router = APIRouter()


# ---------------------------------------------------------------------------
# PRICING — Public endpoint (no auth needed)
# ---------------------------------------------------------------------------
@router.get(
    "/pricing",
    response_model=List[PlanPricingResponse],
    summary="Get available membership plans and prices",
)
def get_pricing():
    """
    Returns all available membership plans with durations and prices.
    This is a public endpoint — no login required.
    Used by the frontend to show plan options before sign-up.
    """
    from app.services.membership_service import MembershipService
    from app.core.database import SessionLocal
    db = SessionLocal()
    try:
        return MembershipService(db).get_pricing()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# CREATE — Admin only
# ---------------------------------------------------------------------------
@router.post(
    "/",
    response_model=MembershipResponse,
    status_code=201,
    summary="Create a new membership for a user (Admin)",
)
def create_membership(
    body: MembershipCreate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Create a new gym membership for a user.

    - Calculates end_date automatically from the plan type.
    - For CUSTOM plans, provide custom_end_date in the body.
    - Sends a confirmation email to the member.
    - Fails if the user already has an active membership.
    """
    service = MembershipService(db)
    return service.create_membership(data=body, created_by_id=admin.id)


# ---------------------------------------------------------------------------
# MY MEMBERSHIP — Authenticated user
# ---------------------------------------------------------------------------
@router.get(
    "/me",
    response_model=MembershipResponse,
    summary="Get my membership details",
)
def get_my_membership(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the currently authenticated user's membership details including:
    - Plan, status, start/end dates
    - Days remaining
    - Whether it's expiring soon (within 7 days)
    - Full status history
    """
    from fastapi import HTTPException
    membership = (
        db.query(Membership)
        .filter(Membership.user_id == current_user.id)
        .first()
    )
    if not membership:
        raise HTTPException(
            status_code=404,
            detail="You don't have a membership yet. Please visit the gym reception.",
        )
    return membership


# ---------------------------------------------------------------------------
# EXPIRING SOON — Admin only
# ---------------------------------------------------------------------------
@router.get(
    "/expiring-soon",
    response_model=List[MembershipSummary],
    summary="Get memberships expiring in the next N days (Admin)",
)
def get_expiring_soon(
    days: int = Query(7, ge=1, le=60, description="Look-ahead window in days"),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns all active memberships expiring within the next `days` days.
    Used by admin to proactively reach out to members before their membership lapses.

    Default look-ahead: 7 days. Max: 60 days.
    """
    service = MembershipService(db)
    return service.get_expiring_soon(days=days)


# ---------------------------------------------------------------------------
# ALL MEMBERSHIPS — Admin only
# ---------------------------------------------------------------------------
@router.get(
    "/all",
    response_model=List[MembershipSummary],
    summary="List all memberships, paginated (Admin)",
)
def list_all_memberships(
    status_filter: Optional[MembershipStatus] = Query(
        None, description="Filter by status (active, expired, frozen, cancelled)"
    ),
    skip:  int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    List all memberships with optional status filtering and pagination.

    Examples:
        /api/memberships/all                         → all memberships
        /api/memberships/all?status_filter=active    → only active ones
        /api/memberships/all?skip=50&limit=50        → page 2
    """
    query = db.query(Membership)
    if status_filter:
        query = query.filter(Membership.status == status_filter)
    return query.offset(skip).limit(limit).all()


# ---------------------------------------------------------------------------
# GET BY ID — Admin only
# ---------------------------------------------------------------------------
@router.get(
    "/{membership_id}",
    response_model=MembershipResponse,
    summary="Get membership by ID with full history (Admin)",
)
def get_membership(
    membership_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Get any membership by ID, including full audit trail."""
    from fastapi import HTTPException
    m = db.query(Membership).filter(Membership.id == membership_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Membership not found.")
    return m


# ---------------------------------------------------------------------------
# UPDATE — Admin only (direct field edit)
# ---------------------------------------------------------------------------
@router.patch(
    "/{membership_id}",
    response_model=MembershipResponse,
    summary="Update membership notes or end date (Admin)",
)
def update_membership(
    membership_id: int,
    body: MembershipUpdate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Directly edit notes or end_date on a membership.
    For status changes, use the specific action endpoints (renew/freeze/cancel).
    """
    from fastapi import HTTPException
    m = db.query(Membership).filter(Membership.id == membership_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Membership not found.")
    if body.notes is not None:
        m.notes = body.notes
    if body.end_date is not None:
        m.end_date = body.end_date
    db.commit()
    db.refresh(m)
    return m


# ---------------------------------------------------------------------------
# RENEW — Admin only
# ---------------------------------------------------------------------------
@router.post(
    "/{membership_id}/renew",
    response_model=MembershipResponse,
    summary="Renew or upgrade a membership (Admin)",
)
def renew_membership(
    membership_id: int,
    body: MembershipRenew,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Extend the membership by another period.

    - Renewing an active membership adds days to the existing end_date
      (no gap — the member gets full value)
    - Renewing an expired membership starts fresh from today
    - You can change the plan during renewal (e.g. monthly → yearly)
    """
    service = MembershipService(db)
    return service.renew_membership(
        membership_id=membership_id,
        data=body,
        renewed_by_id=admin.id,
    )


# ---------------------------------------------------------------------------
# FREEZE — Admin only
# ---------------------------------------------------------------------------
@router.post(
    "/{membership_id}/freeze",
    response_model=MembershipResponse,
    summary="Freeze a membership (Admin)",
)
def freeze_membership(
    membership_id: int,
    body: MembershipFreeze,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Temporarily pause a member's access.

    While frozen:
    - Member cannot check in to the gym
    - Member cannot book new classes

    When unfrozen, the end_date is automatically extended by the frozen duration.
    The member doesn't lose any paid days.
    """
    service = MembershipService(db)
    return service.freeze_membership(
        membership_id=membership_id,
        data=body,
        frozen_by_id=admin.id,
    )


# ---------------------------------------------------------------------------
# UNFREEZE — Admin only
# ---------------------------------------------------------------------------
class UnfreezeBody(BaseModel):
    note: Optional[str] = None


@router.post(
    "/{membership_id}/unfreeze",
    response_model=MembershipResponse,
    summary="Unfreeze a membership and extend end date (Admin)",
)
def unfreeze_membership(
    membership_id: int,
    body: UnfreezeBody,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Resume a frozen membership.

    Automatically calculates how many days it was frozen and extends
    the end_date by that amount. Audit trail records the extension.
    """
    service = MembershipService(db)
    return service.unfreeze_membership(
        membership_id=membership_id,
        note=body.note,
        unfrozen_by_id=admin.id,
    )


# ---------------------------------------------------------------------------
# CANCEL — Admin only
# ---------------------------------------------------------------------------
@router.post(
    "/{membership_id}/cancel",
    response_model=MembershipResponse,
    summary="Cancel a membership permanently (Admin)",
)
def cancel_membership(
    membership_id: int,
    body: MembershipCancel,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Permanently cancel a membership.
    After cancellation, a new membership must be created for the user.
    """
    service = MembershipService(db)
    return service.cancel_membership(
        membership_id=membership_id,
        reason=body.reason,
        cancelled_by_id=admin.id,
    )


# ---------------------------------------------------------------------------
# HISTORY — Admin only
# ---------------------------------------------------------------------------
@router.get(
    "/{membership_id}/history",
    response_model=List[MembershipHistoryResponse],
    summary="Get full audit trail for a membership (Admin)",
)
def get_membership_history(
    membership_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns all status changes for a membership in reverse chronological order.
    Useful for resolving disputes: "When did my membership expire?", "Who froze it?"
    """
    from fastapi import HTTPException
    m = db.query(Membership).filter(Membership.id == membership_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Membership not found.")
    return (
        db.query(MembershipHistory)
        .filter(MembershipHistory.membership_id == membership_id)
        .order_by(MembershipHistory.changed_at.desc())
        .all()
    )


# ---------------------------------------------------------------------------
# AUTO-EXPIRE — Admin only (or trigger from scheduled task)
# ---------------------------------------------------------------------------
@router.post(
    "/expire-overdue",
    summary="Mark overdue memberships as expired (Admin / Cron Job)",
)
def expire_overdue(
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Scans all ACTIVE memberships and marks those past their end_date as EXPIRED.

    This endpoint should be:
    1. Called manually by admin when needed, OR
    2. Triggered automatically by a daily Celery scheduled task (Phase 8)

    Returns the count of memberships that were expired.
    """
    service = MembershipService(db)
    count = service.expire_overdue_memberships()
    return {"message": f"{count} membership(s) marked as expired.", "count": count}
