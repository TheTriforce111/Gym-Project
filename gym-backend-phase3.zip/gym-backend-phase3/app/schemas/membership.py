"""
schemas/membership.py — Membership Request & Response Schemas (Phase 3)

Pydantic schemas define:
- What data is required when calling an endpoint (request body)
- What data is returned in the response (never expose internal fields)

Naming convention:
  MembershipCreate   → POST body to create a new membership
  MembershipRenew    → POST body to renew/extend
  MembershipFreeze   → POST body to freeze
  MembershipUpdate   → PATCH body for admin edits
  MembershipResponse → What the API returns (includes computed fields)
  MembershipHistoryResponse → Single audit trail entry
"""

from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, field_validator, model_validator

from app.models.membership import (
    MembershipPlan,
    MembershipStatus,
    MembershipChangeReason,
)


# ---------------------------------------------------------------------------
# Plan Pricing Map
# Used to validate price or auto-set price when creating memberships.
# In production, fetch this from a database table (PricingPlan).
# ---------------------------------------------------------------------------
PLAN_PRICES = {
    MembershipPlan.MONTHLY:   49.99,
    MembershipPlan.QUARTERLY: 129.99,
    MembershipPlan.YEARLY:    449.99,
    MembershipPlan.CUSTOM:    0.0,   # Admin sets the price manually
}

PLAN_DURATIONS_DAYS = {
    MembershipPlan.MONTHLY:   30,
    MembershipPlan.QUARTERLY: 90,
    MembershipPlan.YEARLY:    365,
    MembershipPlan.CUSTOM:    30,    # Fallback — admin sets end_date manually
}


# ---------------------------------------------------------------------------
# Request Schemas (incoming data from the client)
# ---------------------------------------------------------------------------

class MembershipCreate(BaseModel):
    """
    Body for POST /api/memberships/ (Admin only)
    Creates a new membership for a specific user.
    """
    user_id:    int
    plan:       MembershipPlan
    price_paid: Optional[float] = None
    # If price_paid is not given, we use the default from PLAN_PRICES
    currency:   str = "usd"
    notes:      Optional[str] = None
    custom_end_date: Optional[datetime] = None
    # Only used when plan=CUSTOM — admin sets the exact end date

    @model_validator(mode="after")
    def set_defaults(self):
        """Auto-fill price_paid if not provided."""
        if self.price_paid is None:
            self.price_paid = PLAN_PRICES.get(self.plan, 0.0)
        if self.plan == MembershipPlan.CUSTOM and self.custom_end_date is None:
            raise ValueError("custom_end_date is required when plan is 'custom'.")
        return self

    @field_validator("price_paid")
    @classmethod
    def price_must_be_positive(cls, v):
        if v is not None and v < 0:
            raise ValueError("price_paid cannot be negative.")
        return v


class MembershipRenew(BaseModel):
    """
    Body for POST /api/memberships/{id}/renew (Admin only)
    Extends the membership by another plan period.
    """
    plan:       Optional[MembershipPlan] = None
    # If not given, renew the same plan as current
    price_paid: Optional[float] = None
    notes:      Optional[str] = None


class MembershipFreeze(BaseModel):
    """
    Body for POST /api/memberships/{id}/freeze (Admin only)
    Temporarily pauses the membership.
    """
    reason: Optional[str] = None
    # e.g. "Member injured knee", "Travelling for 3 weeks"

    expected_return_date: Optional[datetime] = None
    # Optional — helps admin plan when to unfreeze


class MembershipUnfreeze(BaseModel):
    """
    Body for POST /api/memberships/{id}/unfreeze (Admin only)
    Resumes the membership and extends end_date by frozen duration.
    """
    note: Optional[str] = None


class MembershipCancel(BaseModel):
    """
    Body for POST /api/memberships/{id}/cancel (Admin only)
    """
    reason: Optional[str] = None
    # e.g. "Member requested cancellation", "Non-payment"


class MembershipUpdate(BaseModel):
    """
    Body for PATCH /api/memberships/{id} (Admin only)
    For direct edits — use specific actions (renew/freeze/cancel) when possible.
    """
    notes:    Optional[str] = None
    end_date: Optional[datetime] = None


# ---------------------------------------------------------------------------
# Response Schemas (outgoing data to the client)
# ---------------------------------------------------------------------------

class MembershipHistoryResponse(BaseModel):
    """A single entry in the membership audit trail."""
    id:               int
    previous_status:  Optional[MembershipStatus]
    new_status:       MembershipStatus
    reason:           MembershipChangeReason
    previous_end_date: Optional[datetime]
    new_end_date:     Optional[datetime]
    note:             Optional[str]
    changed_at:       datetime

    class Config:
        from_attributes = True


class MembershipResponse(BaseModel):
    """
    Full membership details returned by the API.
    Includes computed fields (days_remaining, is_valid, is_expiring_soon)
    that are properties on the model — Pydantic reads them automatically.
    """
    id:                int
    user_id:           int
    plan:              MembershipPlan
    status:            MembershipStatus
    start_date:        datetime
    end_date:          datetime
    price_paid:        float
    currency:          str
    notes:             Optional[str]
    total_frozen_days: int
    freeze_start:      Optional[datetime]
    freeze_end:        Optional[datetime]
    days_remaining:    int          # Computed property from the model
    is_valid:          bool         # Computed property from the model
    is_expiring_soon:  bool         # Computed property from the model
    created_at:        datetime
    updated_at:        datetime
    history:           List[MembershipHistoryResponse] = []

    class Config:
        from_attributes = True


class MembershipSummary(BaseModel):
    """
    Lightweight membership info for embedding in user profile responses.
    Avoids sending full history when it's not needed.
    """
    id:             int
    plan:           MembershipPlan
    status:         MembershipStatus
    end_date:       datetime
    days_remaining: int
    is_valid:       bool

    class Config:
        from_attributes = True


class PlanPricingResponse(BaseModel):
    """Returns available plans and their prices."""
    plan:          str
    duration_days: int
    price:         float
    currency:      str = "usd"
