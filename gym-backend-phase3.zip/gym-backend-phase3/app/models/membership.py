"""
models/membership.py — Membership Database Models (Phase 3)

This file defines two tables:
1. Membership       — The active membership record for each user
2. MembershipHistory — A log of every status change (audit trail)

Phase 3 additions vs Phase 1:
- freeze_start / freeze_end dates for accurate expiry extension
- MembershipHistory table for full audit trail
- days_remaining property for easy frontend display
- is_valid property for quick active-and-not-expired check
"""

import enum
from datetime import datetime, timedelta

from sqlalchemy import (
    Column, DateTime, Enum, Float, ForeignKey,
    Integer, String, Text, Boolean
)
from sqlalchemy.orm import relationship

from app.core.database import Base


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class MembershipPlan(str, enum.Enum):
    """
    The type of membership plan.
    Determines the duration and (optionally) the price.
    """
    MONTHLY = "monthly"   # 30 days
    QUARTERLY = "quarterly" # 90 days
    YEARLY  = "yearly"    # 365 days
    CUSTOM  = "custom"    # Admin-set duration and price


class MembershipStatus(str, enum.Enum):
    """
    Current status of a membership.

    Lifecycle:
        ACTIVE → FROZEN  → ACTIVE   (freeze and unfreeze)
        ACTIVE → EXPIRED            (end_date passes)
        ACTIVE → CANCELLED          (admin cancels)
    """
    ACTIVE    = "active"     # Membership is valid and usable
    EXPIRED   = "expired"    # Past end_date
    FROZEN    = "frozen"     # Temporarily paused — check-ins blocked
    CANCELLED = "cancelled"  # Terminated — no check-ins allowed


class MembershipChangeReason(str, enum.Enum):
    """
    Reason for a membership status change — used in the audit log.
    """
    CREATED   = "created"    # New membership activated
    RENEWED   = "renewed"    # Membership was renewed/extended
    FROZEN    = "frozen"     # Admin froze the membership
    UNFROZEN  = "unfrozen"   # Admin unfroze the membership
    CANCELLED = "cancelled"  # Admin cancelled the membership
    EXPIRED   = "expired"    # System marked it expired automatically
    UPGRADED  = "upgraded"   # Member upgraded from monthly to yearly, etc.


# ---------------------------------------------------------------------------
# Membership Table
# ---------------------------------------------------------------------------

class Membership(Base):
    """
    Represents a user's gym membership.

    One user has one membership record (one-to-one).
    When a membership is renewed, we update this record and add a history entry
    rather than creating a new record — keeps things simple.

    Maps to the 'memberships' table.
    """
    __tablename__ = "memberships"

    id = Column(Integer, primary_key=True, index=True)

    # --- Link to User ---
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    # unique=True = one membership per user

    # --- Plan & Status ---
    plan   = Column(Enum(MembershipPlan),   nullable=False)
    status = Column(Enum(MembershipStatus), nullable=False, default=MembershipStatus.ACTIVE)

    # --- Dates ---
    start_date = Column(DateTime, nullable=False, default=datetime.utcnow)
    end_date   = Column(DateTime, nullable=False)
    # end_date = start_date + plan duration (e.g. +30 days for MONTHLY)

    # --- Freeze Tracking ---
    freeze_start = Column(DateTime, nullable=True)
    freeze_end   = Column(DateTime, nullable=True)
    # When a membership is unfrozen, we extend end_date by the frozen duration
    # so the member doesn't lose paid days.

    total_frozen_days = Column(Integer, default=0)
    # Cumulative days this membership has been frozen (for reporting)

    # --- Pricing ---
    price_paid = Column(Float, nullable=False)
    # Amount paid for the current membership period

    currency = Column(String(10), default="usd")
    # e.g. "usd", "sar", "eur"

    # --- Admin Notes ---
    notes = Column(Text, nullable=True)
    # Free-text notes from the admin: "Member requested freeze due to travel"

    # --- Timestamps ---
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # --- Relationships ---
    user    = relationship("User",              back_populates="membership")
    history = relationship("MembershipHistory", back_populates="membership",
                           order_by="MembershipHistory.changed_at.desc()")
    payments = relationship("Payment",          back_populates="membership")

    # --- Computed Properties ---

    @property
    def days_remaining(self) -> int:
        """
        How many days until the membership expires.
        Returns 0 if already expired.
        Used by the mobile app to show expiry countdown.
        """
        if self.status != MembershipStatus.ACTIVE:
            return 0
        delta = self.end_date - datetime.utcnow()
        return max(0, delta.days)

    @property
    def is_valid(self) -> bool:
        """
        True only if the membership is ACTIVE and not yet expired.
        Use this for check-in and class booking validation.
        """
        return (
            self.status == MembershipStatus.ACTIVE
            and self.end_date > datetime.utcnow()
        )

    @property
    def is_expiring_soon(self) -> bool:
        """
        True if membership expires within the next 7 days.
        Used to trigger renewal reminder notifications.
        """
        return self.is_valid and self.days_remaining <= 7

    def __repr__(self):
        return (
            f"<Membership user_id={self.user_id} "
            f"plan={self.plan} status={self.status} "
            f"expires={self.end_date.date()}>"
        )


# ---------------------------------------------------------------------------
# Membership History Table (Audit Trail)
# ---------------------------------------------------------------------------

class MembershipHistory(Base):
    """
    Records every change made to a membership.

    Why keep history?
    - Dispute resolution: "When did my membership expire?"
    - Reporting: How many renewals this month?
    - Compliance: Full audit trail of admin actions

    Maps to the 'membership_history' table.
    """
    __tablename__ = "membership_history"

    id            = Column(Integer, primary_key=True, index=True)
    membership_id = Column(Integer, ForeignKey("memberships.id"), nullable=False)

    # --- What changed ---
    previous_status = Column(Enum(MembershipStatus), nullable=True)
    new_status      = Column(Enum(MembershipStatus), nullable=False)
    reason          = Column(Enum(MembershipChangeReason), nullable=False)

    # --- Context ---
    previous_end_date = Column(DateTime, nullable=True)
    new_end_date      = Column(DateTime, nullable=True)
    # Track date changes — important for renewals and freeze extensions

    note = Column(String(500), nullable=True)
    # Human-readable note: "Extended by 30 days. Payment ID: #12345"

    # --- Who made the change ---
    changed_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    # The admin/staff who made this change (null = system-automated change)

    changed_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # --- Relationships ---
    membership = relationship("Membership", back_populates="history")
    changed_by = relationship("User",       foreign_keys=[changed_by_id])

    def __repr__(self):
        return (
            f"<MembershipHistory membership_id={self.membership_id} "
            f"{self.previous_status}→{self.new_status} at={self.changed_at}>"
        )
