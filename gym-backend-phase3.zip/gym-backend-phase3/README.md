# 💳 Phase 3 — Membership System

A complete membership management system with plans, freeze/unfreeze, renewal, and full audit trail.

---

## 📁 New Files in Phase 3

```
app/
├── models/
│   └── membership.py         ← Enhanced: freeze dates, history relationship, computed properties
├── schemas/
│   └── membership.py         ← Full request/response schemas with pricing map
├── routers/
│   └── memberships.py        ← All 12 membership endpoints
└── services/
    └── membership_service.py ← All business logic (create, renew, freeze, cancel, auto-expire)

tests/
└── test_memberships.py       ← Full test suite
```

---

## 📋 Endpoints

| Method | Endpoint                             | Auth    | Description                          |
|--------|--------------------------------------|---------|--------------------------------------|
| GET    | `/api/memberships/pricing`           | None    | Get plans & prices                   |
| POST   | `/api/memberships/`                  | Admin   | Create membership                    |
| GET    | `/api/memberships/me`                | Member  | My membership + history              |
| GET    | `/api/memberships/expiring-soon`     | Admin   | Expiring in next N days              |
| GET    | `/api/memberships/all`               | Admin   | All memberships (paginated/filtered) |
| GET    | `/api/memberships/{id}`              | Admin   | Get by ID with history               |
| PATCH  | `/api/memberships/{id}`              | Admin   | Edit notes/end_date                  |
| POST   | `/api/memberships/{id}/renew`        | Admin   | Renew or upgrade plan                |
| POST   | `/api/memberships/{id}/freeze`       | Admin   | Freeze (pause access)                |
| POST   | `/api/memberships/{id}/unfreeze`     | Admin   | Unfreeze + extend end_date           |
| POST   | `/api/memberships/{id}/cancel`       | Admin   | Cancel permanently                   |
| GET    | `/api/memberships/{id}/history`      | Admin   | Full audit trail                     |
| POST   | `/api/memberships/expire-overdue`    | Admin   | Run auto-expiry                      |

---

## 🔄 Membership Lifecycle

```
                    ┌─────────────────────────────┐
                    │                             │
           Create   ▼        Freeze               │ Unfreeze
  ───────► ACTIVE ──────────► FROZEN ─────────────┘
              │
              │ end_date passes (auto-expire)
              ▼
           EXPIRED
              │
              │ Admin cancels (any status)
              ▼
          CANCELLED
```

---

## ❄️ Freeze/Unfreeze Logic

When a member is injured or travelling, admins can freeze their membership.

**Key rule:** The member doesn't lose paid days.

```
Example:
  Membership end_date:  March 31
  Frozen on:            March 1
  Unfrozen on:          March 15  (14 days frozen)
  New end_date:         March 31 + 14 days = April 14  ✅
```

The `MembershipHistory` table records exactly when and why this happened.

---

## 📜 Audit Trail

Every change is recorded in `membership_history`:

```json
[
  {
    "reason": "created",
    "new_status": "active",
    "new_end_date": "2025-02-28",
    "note": "Monthly plan. Price: $49.99",
    "changed_at": "2025-01-29T10:00:00"
  },
  {
    "reason": "frozen",
    "previous_status": "active",
    "new_status": "frozen",
    "note": "Member injured knee",
    "changed_at": "2025-02-01T14:30:00"
  },
  {
    "reason": "unfrozen",
    "new_end_date": "2025-03-07",
    "note": "Extended by 7 days. Old end: Feb 28, New end: Mar 7",
    "changed_at": "2025-02-08T09:00:00"
  }
]
```

---

## 💰 Plan Pricing (configure in schemas/membership.py)

| Plan       | Duration | Default Price |
|------------|----------|---------------|
| Monthly    | 30 days  | $49.99        |
| Quarterly  | 90 days  | $129.99       |
| Yearly     | 365 days | $449.99       |
| Custom     | Admin set| Admin set     |

To use database-driven pricing instead: create a `membership_plans` table and fetch from there.

---

## 🤖 Auto-Expiry (Scheduled Task)

The `/api/memberships/expire-overdue` endpoint marks overdue memberships as expired.

In Phase 8 (Celery), this will run automatically every night at midnight:

```python
# In celery/tasks.py (Phase 8)
@celery_app.task
def auto_expire_memberships():
    db = SessionLocal()
    MembershipService(db).expire_overdue_memberships()
    db.close()
```

---

## ➡️ Next: Phase 4 — Stripe Payment Integration

Phase 4 will connect payments to memberships:
- Member pays via Stripe → membership is created automatically
- Webhook from Stripe confirms payment → updates membership status
- Failed payments are handled gracefully
