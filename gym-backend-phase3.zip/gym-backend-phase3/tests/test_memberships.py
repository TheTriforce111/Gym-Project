"""
tests/test_memberships.py — Membership System Tests (Phase 3)

Run with:
    pytest tests/test_memberships.py -v

Tests cover:
- Creating memberships (success, duplicate, wrong user)
- Getting own membership
- Renewing memberships
- Freezing and unfreezing (with end date extension validation)
- Cancelling memberships
- Expiry auto-detection
- History audit trail
"""

import pytest
from datetime import datetime, timedelta
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.models.user import User, UserRole
from app.models.membership import Membership, MembershipPlan, MembershipStatus
from app.core.security import hash_password

# ---------------------------------------------------------------------------
# Test database setup (SQLite in-memory)
# ---------------------------------------------------------------------------
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_memberships.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
Base.metadata.create_all(bind=engine)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_db():
    """Reset database before each test."""
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield


@pytest.fixture
def db():
    """Provide a DB session directly for setup."""
    session = TestingSessionLocal()
    yield session
    session.close()


@pytest.fixture
def admin_user(db):
    """Create an admin user and return their token."""
    user = User(
        full_name="Admin User",
        email="admin@gym.com",
        hashed_password=hash_password("Admin123"),
        role=UserRole.ADMIN,
        is_active=True,
    )
    db.add(user)
    db.commit()

    # Login to get token
    resp = client.post("/api/auth/login", json={
        "email": "admin@gym.com",
        "password": "Admin123"
    })
    assert resp.status_code == 200
    return {"user": user, "token": resp.json()["access_token"]}


@pytest.fixture
def member_user(db):
    """Create a regular member and return their token."""
    user = User(
        full_name="Test Member",
        email="member@gym.com",
        hashed_password=hash_password("Member123"),
        role=UserRole.MEMBER,
        is_active=True,
    )
    db.add(user)
    db.commit()

    resp = client.post("/api/auth/login", json={
        "email": "member@gym.com",
        "password": "Member123"
    })
    return {"user": user, "token": resp.json()["access_token"]}


# ---------------------------------------------------------------------------
# Pricing Tests
# ---------------------------------------------------------------------------

class TestPricing:

    def test_get_pricing_is_public(self):
        """Pricing endpoint requires no auth."""
        resp = client.get("/api/memberships/pricing")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) >= 3    # monthly, quarterly, yearly
        assert all("plan" in p and "price" in p for p in data)


# ---------------------------------------------------------------------------
# Create Membership Tests
# ---------------------------------------------------------------------------

class TestCreateMembership:

    def test_create_monthly(self, admin_user, member_user):
        """Admin can create a monthly membership."""
        resp = client.post(
            "/api/memberships/",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
            json={
                "user_id": member_user["user"].id,
                "plan": "monthly",
                "price_paid": 49.99,
            }
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["plan"] == "monthly"
        assert data["status"] == "active"
        assert data["days_remaining"] > 0
        assert data["is_valid"] is True

    def test_create_yearly(self, admin_user, member_user):
        """Admin can create a yearly membership."""
        resp = client.post(
            "/api/memberships/",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
            json={"user_id": member_user["user"].id, "plan": "yearly"}
        )
        assert resp.status_code == 201
        assert resp.json()["days_remaining"] > 360

    def test_cannot_create_duplicate(self, admin_user, member_user):
        """Cannot create a second active membership for same user."""
        payload = {"user_id": member_user["user"].id, "plan": "monthly"}
        client.post("/api/memberships/",
                    headers={"Authorization": f"Bearer {admin_user['token']}"},
                    json=payload)
        # Second attempt should fail
        resp = client.post("/api/memberships/",
                           headers={"Authorization": f"Bearer {admin_user['token']}"},
                           json=payload)
        assert resp.status_code == 409  # Conflict

    def test_member_cannot_create(self, member_user):
        """Regular members cannot create memberships."""
        resp = client.post(
            "/api/memberships/",
            headers={"Authorization": f"Bearer {member_user['token']}"},
            json={"user_id": member_user["user"].id, "plan": "monthly"}
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# Get Membership Tests
# ---------------------------------------------------------------------------

class TestGetMembership:

    def test_get_my_membership(self, admin_user, member_user):
        """Member can see their own membership."""
        # Create membership first
        client.post("/api/memberships/",
                    headers={"Authorization": f"Bearer {admin_user['token']}"},
                    json={"user_id": member_user["user"].id, "plan": "monthly"})

        resp = client.get("/api/memberships/me",
                          headers={"Authorization": f"Bearer {member_user['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["plan"] == "monthly"
        assert "history" in data  # includes audit trail

    def test_no_membership_returns_404(self, member_user):
        """Returns 404 if the user has no membership."""
        resp = client.get("/api/memberships/me",
                          headers={"Authorization": f"Bearer {member_user['token']}"})
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Freeze / Unfreeze Tests
# ---------------------------------------------------------------------------

class TestFreezeUnfreeze:

    def test_freeze_and_unfreeze_extends_end_date(self, admin_user, member_user, db):
        """Unfreezing should extend end_date by the frozen duration."""
        # Create membership
        resp = client.post("/api/memberships/",
                           headers={"Authorization": f"Bearer {admin_user['token']}"},
                           json={"user_id": member_user["user"].id, "plan": "monthly"})
        membership_id = resp.json()["id"]
        original_end = resp.json()["end_date"]

        # Freeze it
        freeze_resp = client.post(
            f"/api/memberships/{membership_id}/freeze",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
            json={"reason": "Member injured"}
        )
        assert freeze_resp.json()["status"] == "frozen"

        # Unfreeze it
        unfreeze_resp = client.post(
            f"/api/memberships/{membership_id}/unfreeze",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
            json={}
        )
        assert unfreeze_resp.status_code == 200
        new_end = unfreeze_resp.json()["end_date"]
        # New end date should be AFTER the original
        assert new_end > original_end

    def test_cannot_freeze_expired_membership(self, admin_user, member_user, db):
        """Cannot freeze a membership that's already expired."""
        # Create membership and manually expire it
        resp = client.post("/api/memberships/",
                           headers={"Authorization": f"Bearer {admin_user['token']}"},
                           json={"user_id": member_user["user"].id, "plan": "monthly"})
        membership_id = resp.json()["id"]

        # Force expire in DB
        m = db.query(Membership).filter(Membership.id == membership_id).first()
        m.end_date = datetime.utcnow() - timedelta(days=1)
        db.commit()

        freeze_resp = client.post(
            f"/api/memberships/{membership_id}/freeze",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
            json={}
        )
        assert freeze_resp.status_code == 400


# ---------------------------------------------------------------------------
# Renewal Tests
# ---------------------------------------------------------------------------

class TestRenewal:

    def test_renew_active_membership(self, admin_user, member_user):
        """Renewing an active membership extends the end date."""
        resp = client.post("/api/memberships/",
                           headers={"Authorization": f"Bearer {admin_user['token']}"},
                           json={"user_id": member_user["user"].id, "plan": "monthly"})
        mid = resp.json()["id"]
        original_end = resp.json()["end_date"]

        renew_resp = client.post(
            f"/api/memberships/{mid}/renew",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
            json={"plan": "monthly"}
        )
        assert renew_resp.status_code == 200
        new_end = renew_resp.json()["end_date"]
        assert new_end > original_end

    def test_history_is_recorded(self, admin_user, member_user):
        """Every action creates a history entry."""
        resp = client.post("/api/memberships/",
                           headers={"Authorization": f"Bearer {admin_user['token']}"},
                           json={"user_id": member_user["user"].id, "plan": "monthly"})
        mid = resp.json()["id"]

        hist_resp = client.get(
            f"/api/memberships/{mid}/history",
            headers={"Authorization": f"Bearer {admin_user['token']}"}
        )
        assert hist_resp.status_code == 200
        history = hist_resp.json()
        assert len(history) >= 1   # At least the "created" entry
        assert history[0]["reason"] == "created"
