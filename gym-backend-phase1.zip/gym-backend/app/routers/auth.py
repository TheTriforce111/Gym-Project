"""
routers/auth.py — Authentication API endpoints

This router handles:
- POST /api/auth/register     → Create a new user account
- POST /api/auth/login        → Login and receive JWT tokens
- POST /api/auth/refresh      → Get a new access token using a refresh token
- POST /api/auth/forgot-password → Request an OTP for password reset
- POST /api/auth/verify-otp   → Verify the OTP code
- POST /api/auth/reset-password → Set a new password after OTP verification
"""

import random
import string
from datetime import timedelta

import redis
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.models.user import User
from app.schemas.auth import (
    LoginRequest,
    OTPVerifyRequest,
    PasswordResetRequest,
    RefreshTokenRequest,
    SetNewPasswordRequest,
    TokenResponse,
)
from app.schemas.user import UserCreate, UserResponse

# Create the router for this module
router = APIRouter()

# Connect to Redis for OTP storage
# Redis stores temporary data with automatic expiry — perfect for OTP codes
redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)


# ---------------------------------------------------------------------------
# REGISTER
# ---------------------------------------------------------------------------
@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """
    Register a new user account.

    Steps:
    1. Check if the email is already in use
    2. Hash the password
    3. Create the user in the database
    4. Return the new user (without password)
    """
    # Check if email already exists
    existing_user = db.query(User).filter(User.email == user_data.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email already exists."
        )

    # Create new user object
    new_user = User(
        full_name=user_data.full_name,
        email=user_data.email,
        phone=user_data.phone,
        hashed_password=hash_password(user_data.password),  # Never store plain text!
        role=user_data.role,
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)  # Refresh to get the auto-generated ID and timestamps

    return new_user


# ---------------------------------------------------------------------------
# LOGIN
# ---------------------------------------------------------------------------
@router.post("/login", response_model=TokenResponse)
def login(credentials: LoginRequest, db: Session = Depends(get_db)):
    """
    Authenticate a user and return JWT tokens.

    Steps:
    1. Find the user by email
    2. Verify the password
    3. Create access + refresh tokens
    4. Return the tokens
    """
    # Find user by email
    user = db.query(User).filter(User.email == credentials.email).first()

    # Check credentials — same error for both "not found" and "wrong password"
    # This prevents attackers from knowing if an email is registered
    if not user or not verify_password(credentials.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password."
        )

    # Check if the account is active
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has been deactivated. Please contact support."
        )

    # Create the token payload — this data is encoded inside the JWT
    token_data = {"sub": str(user.id), "role": user.role}

    return TokenResponse(
        access_token=create_access_token(token_data),
        refresh_token=create_refresh_token(token_data),
    )


# ---------------------------------------------------------------------------
# REFRESH TOKEN
# ---------------------------------------------------------------------------
@router.post("/refresh", response_model=TokenResponse)
def refresh_token(body: RefreshTokenRequest):
    """
    Exchange a valid refresh token for a new access token.
    Used when the access token expires but the user shouldn't be logged out.
    """
    payload = decode_token(body.refresh_token)

    if not payload or payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token. Please log in again."
        )

    # Issue new tokens
    token_data = {"sub": payload["sub"], "role": payload["role"]}
    return TokenResponse(
        access_token=create_access_token(token_data),
        refresh_token=create_refresh_token(token_data),
    )


# ---------------------------------------------------------------------------
# FORGOT PASSWORD — Step 1: Request OTP
# ---------------------------------------------------------------------------
@router.post("/forgot-password")
def forgot_password(body: PasswordResetRequest, db: Session = Depends(get_db)):
    """
    Send an OTP (One-Time Password) to the user's email for password reset.

    The OTP is stored in Redis with a 10-minute expiry.
    In production, send the OTP via email (SMTP) or SMS.
    """
    user = db.query(User).filter(User.email == body.email).first()

    # Don't reveal whether the email exists — security best practice
    if not user:
        return {"message": "If that email is registered, you'll receive an OTP shortly."}

    # Generate a 6-digit OTP
    otp = "".join(random.choices(string.digits, k=6))

    # Store OTP in Redis: key="otp:{email}", value=otp, expires in 10 minutes
    redis_client.setex(f"otp:{body.email}", timedelta(minutes=10), otp)

    # TODO: Send OTP via email using SMTP (see notification service)
    # For development, we return the OTP directly (REMOVE in production!)
    print(f"[DEV ONLY] OTP for {body.email}: {otp}")

    return {"message": "If that email is registered, you'll receive an OTP shortly."}


# ---------------------------------------------------------------------------
# VERIFY OTP — Step 2: Confirm the OTP
# ---------------------------------------------------------------------------
@router.post("/verify-otp")
def verify_otp(body: OTPVerifyRequest):
    """
    Verify that the OTP provided by the user is correct and not expired.
    """
    stored_otp = redis_client.get(f"otp:{body.email}")

    if not stored_otp or stored_otp != body.otp:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired OTP. Please request a new one."
        )

    # Mark OTP as verified (give 5 min to set new password)
    redis_client.setex(f"otp_verified:{body.email}", timedelta(minutes=5), "true")

    return {"message": "OTP verified. You may now reset your password."}


# ---------------------------------------------------------------------------
# RESET PASSWORD — Step 3: Set the new password
# ---------------------------------------------------------------------------
@router.post("/reset-password")
def reset_password(body: SetNewPasswordRequest, db: Session = Depends(get_db)):
    """
    Set a new password after OTP verification.
    Requires the OTP to have been verified in the previous step.
    """
    # Check that OTP was verified
    verified = redis_client.get(f"otp_verified:{body.email}")
    if not verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="OTP not verified. Please complete the verification step first."
        )

    # Find user and update password
    user = db.query(User).filter(User.email == body.email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    user.hashed_password = hash_password(body.new_password)
    db.commit()

    # Clean up Redis keys
    redis_client.delete(f"otp:{body.email}")
    redis_client.delete(f"otp_verified:{body.email}")

    return {"message": "Password reset successfully. Please log in with your new password."}
