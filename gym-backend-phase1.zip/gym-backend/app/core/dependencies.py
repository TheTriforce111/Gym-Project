"""
core/dependencies.py — Reusable FastAPI dependency functions

Dependencies are functions that run before a route handler executes.
They're used to:
- Extract and validate JWT tokens from request headers
- Fetch the current user from the database
- Enforce role-based access control (RBAC)

Usage in a route:
    @router.get("/protected")
    def protected_route(current_user: User = Depends(get_current_user)):
        return {"user": current_user.email}
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import decode_token
from app.models.user import User, UserRole

# ---------------------------------------------------------------------------
# OAuth2 scheme — tells FastAPI to look for a Bearer token in the
# Authorization header of each request: "Authorization: Bearer <token>"
# ---------------------------------------------------------------------------
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    """
    Decode the JWT token and return the currently authenticated user.

    Raises HTTP 401 if:
    - The token is missing or malformed
    - The token is expired
    - The user no longer exists in the database
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials. Please log in again.",
        headers={"WWW-Authenticate": "Bearer"},
    )

    # Decode the token to extract the payload
    payload = decode_token(token)
    if payload is None:
        raise credentials_exception

    # Extract the user ID from the token payload ("sub" = subject)
    user_id: str = payload.get("sub")
    if user_id is None:
        raise credentials_exception

    # Make sure this is an access token, not a refresh token
    if payload.get("type") != "access":
        raise credentials_exception

    # Fetch the user from the database
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user is None:
        raise credentials_exception

    # Make sure the account is active (not banned/deactivated)
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has been deactivated. Please contact support.",
        )

    return user


def require_admin(current_user: User = Depends(get_current_user)) -> User:
    """
    Dependency that only allows admin users to access the route.
    Use this to protect admin-only endpoints.

    Example:
        @router.delete("/users/{id}")
        def delete_user(admin: User = Depends(require_admin)):
            ...
    """
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Admin privileges required.",
        )
    return current_user


def require_trainer(current_user: User = Depends(get_current_user)) -> User:
    """
    Dependency that allows trainers and admins to access the route.
    Members cannot access trainer-only endpoints.
    """
    if current_user.role not in [UserRole.TRAINER, UserRole.ADMIN]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Trainer or Admin privileges required.",
        )
    return current_user
