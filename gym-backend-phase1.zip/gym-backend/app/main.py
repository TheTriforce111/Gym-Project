"""
main.py — Entry point for the Gym Management System API

This file starts the FastAPI application, registers all routes (routers),
and sets up middleware like CORS (Cross-Origin Resource Sharing).

Run the server with:
    uvicorn app.main:app --reload
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.database import Base, engine
from app.routers import auth, users, memberships, workouts, classes, attendance

# ---------------------------------------------------------------------------
# Create all database tables on startup (if they don't already exist)
# In production, use Alembic migrations instead of this
# ---------------------------------------------------------------------------
Base.metadata.create_all(bind=engine)

# ---------------------------------------------------------------------------
# Initialize the FastAPI app with project metadata
# ---------------------------------------------------------------------------
app = FastAPI(
    title="Gym Management System API",
    description="Backend API for managing gym members, workouts, classes, and more.",
    version="1.0.0",
)

# ---------------------------------------------------------------------------
# CORS Middleware
# Allows the React frontend or Flutter app to make requests to this API.
# In production, replace "*" with your actual frontend domain.
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],        # Allow all origins (restrict in production)
    allow_credentials=True,
    allow_methods=["*"],        # Allow GET, POST, PUT, DELETE, etc.
    allow_headers=["*"],        # Allow all headers including Authorization
)

# ---------------------------------------------------------------------------
# Register all routers (each module handles its own group of endpoints)
# ---------------------------------------------------------------------------
app.include_router(auth.router,        prefix="/api/auth",        tags=["Authentication"])
app.include_router(users.router,       prefix="/api/users",       tags=["Users"])
app.include_router(memberships.router, prefix="/api/memberships", tags=["Memberships"])
app.include_router(workouts.router,    prefix="/api/workouts",    tags=["Workouts"])
app.include_router(classes.router,     prefix="/api/classes",     tags=["Classes"])
app.include_router(attendance.router,  prefix="/api/attendance",  tags=["Attendance"])


# ---------------------------------------------------------------------------
# Root health check endpoint — useful for verifying the server is running
# ---------------------------------------------------------------------------
@app.get("/", tags=["Health"])
def root():
    return {"message": "Gym Management System API is running ✅"}
