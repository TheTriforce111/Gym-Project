"""
schemas/auth.py — Pydantic schemas for authentication endpoints

These schemas handle login, token response, and password reset flows.
"""

from typing import Optional
from pydantic import BaseModel, EmailStr


class LoginRequest(BaseModel):
    """Request body for user login."""
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """
    Response returned after successful login.
    Contains both access and refresh tokens.
    """
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    # token_type is always "bearer" for JWT


class RefreshTokenRequest(BaseModel):
    """Request body for refreshing an expired access token."""
    refresh_token: str


class PasswordResetRequest(BaseModel):
    """Step 1: User requests a password reset by providing their email."""
    email: EmailStr


class OTPVerifyRequest(BaseModel):
    """Step 2: User submits the OTP code they received via email/SMS."""
    email: EmailStr
    otp: str


class SetNewPasswordRequest(BaseModel):
    """Step 3: User sets a new password after OTP is verified."""
    email: EmailStr
    otp: str
    new_password: str
