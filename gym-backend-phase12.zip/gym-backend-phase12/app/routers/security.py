"""
routers/security.py — Security Management Endpoints (Phase 12)

Admin-only endpoints for managing security:
  POST /api/security/revoke-user-sessions/{user_id}  → Force logout all devices
  GET  /api/security/active-sessions/{user_id}        → List active token families
  POST /api/security/rotate-my-token                 → Force token rotation
  GET  /api/security/audit-log                       → Recent security events (Admin)
  POST /api/security/unlock-account                  → Unlock rate-limited account (Admin)

These give admins tools to respond to security incidents:
  - Suspicious activity → revoke all sessions
  - Stolen device → revoke specific token family
  - Compromised account → force re-login + password reset
"""

import json
import logging
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.core.token_rotation import revoke_all_user_families, revoke_family
from app.models.user import User
import redis

router = APIRouter()
logger = logging.getLogger(__name__)
_redis = redis.from_url(settings.REDIS_URL, decode_responses=True)


# ---------------------------------------------------------------------------
# Revoke ALL sessions for a user (Admin — for incident response)
# ---------------------------------------------------------------------------
class RevokeSessionsRequest(BaseModel):
    reason: Optional[str] = None


@router.post(
    "/revoke-user-sessions/{user_id}",
    summary="Force logout all devices for a user (Admin)",
)
def revoke_user_sessions(
    user_id: int,
    body: RevokeSessionsRequest,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Immediately invalidate ALL active sessions for a user.

    Use this when:
    - Suspicious login activity detected
    - User reports their account was compromised
    - User is suspended or banned
    - Admin needs to force re-authentication

    The user will be logged out of every device and must log in again.
    """
    # Verify target user exists
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail=f"User #{user_id} not found.")

    # Prevent admin from locking themselves out
    if user_id == admin.id:
        raise HTTPException(
            status_code=400,
            detail="You cannot revoke your own sessions via this endpoint.",
        )

    count = revoke_all_user_families(user_id)

    logger.info(
        f"SECURITY: All sessions revoked for user #{user_id} "
        f"by admin #{admin.id}. "
        f"Reason: {body.reason or 'Not specified'}. "
        f"Families revoked: {count}"
    )

    return {
        "message":         f"All sessions for {target.full_name} have been revoked.",
        "user_id":         user_id,
        "families_revoked": count,
        "reason":          body.reason,
    }


# ---------------------------------------------------------------------------
# Revoke my own sessions (authenticated user — self-service)
# ---------------------------------------------------------------------------
@router.post(
    "/revoke-my-sessions",
    summary="Log out all my devices (authenticated user)",
)
def revoke_my_sessions(
    request: Request,
    current_user: User = Depends(get_current_user),
):
    """
    Log out of all devices at once.
    Useful if: user thinks their account was compromised, they lost a device, etc.
    """
    count = revoke_all_user_families(current_user.id)

    logger.info(
        f"User #{current_user.id} self-revoked all sessions. "
        f"Families revoked: {count}"
    )

    return {
        "message":         f"All your sessions have been revoked. Please log in again.",
        "families_revoked": count,
    }


# ---------------------------------------------------------------------------
# Get active sessions for a user (Admin)
# ---------------------------------------------------------------------------
@router.get(
    "/active-sessions/{user_id}",
    summary="List active token families for a user (Admin)",
)
def get_active_sessions(
    user_id: int,
    admin: User = Depends(require_admin),
):
    """
    Returns all active (non-revoked) token families for a user.
    Each family represents a unique device/session.
    Shows: when each session was created, and its last token rotation time.
    """
    sessions = []
    for key in _redis.scan_iter("token_family:*", count=100):
        try:
            data = json.loads(_redis.get(key) or "{}")
            if data.get("user_id") == user_id and not data.get("revoked"):
                family_id = key.split(":", 1)[1]
                sessions.append({
                    "family_id":    family_id,
                    "created_at":   data.get("created"),
                    "token_count":  len(data.get("tokens", [])),
                    # Number of rotations = proxy for session activity
                })
        except Exception:
            continue

    return {
        "user_id":       user_id,
        "active_sessions": len(sessions),
        "sessions":      sessions,
    }


# ---------------------------------------------------------------------------
# Unlock rate-limited account (Admin — manual override)
# ---------------------------------------------------------------------------
class UnlockAccountRequest(BaseModel):
    user_ip: Optional[str] = None
    # IP address to unlock (if IP-based rate limiting is blocking the user)


@router.post(
    "/unlock-account",
    summary="Clear rate limit counters for an IP (Admin)",
)
def unlock_account(
    body: UnlockAccountRequest,
    admin: User = Depends(require_admin),
):
    """
    Clear all rate limit counters for an IP address.
    Use when: a legitimate user is locked out after too many failed attempts,
    and you've verified their identity through other means.
    """
    if not body.user_ip:
        raise HTTPException(status_code=400, detail="user_ip is required.")

    # Clear all rate limit keys for this IP
    cleared = []
    for key in _redis.scan_iter(f"*:{body.user_ip}", count=50):
        _redis.delete(key)
        cleared.append(key)

    logger.info(
        f"Rate limit cleared for IP {body.user_ip} "
        f"by admin #{admin.id}. "
        f"Keys cleared: {cleared}"
    )

    return {
        "message":       f"Rate limit counters cleared for IP {body.user_ip}.",
        "keys_cleared":  len(cleared),
        "ip":            body.user_ip,
    }


# ---------------------------------------------------------------------------
# Security health check (Admin)
# ---------------------------------------------------------------------------
@router.get(
    "/health",
    summary="Security posture summary (Admin)",
)
def security_health(
    admin: User = Depends(require_admin),
):
    """
    Returns a summary of the current security posture:
    - Active token families count
    - Recent rate limit violations
    - Revoked families in last 24 hours
    - Configuration checks

    Use this to monitor for unusual activity patterns.
    """
    now = datetime.utcnow()

    # Count active vs revoked families
    active_count  = 0
    revoked_count = 0
    recent_revocations = []

    for key in _redis.scan_iter("token_family:*", count=200):
        try:
            data = json.loads(_redis.get(key) or "{}")
            if data.get("revoked"):
                revoked_count += 1
                revoked_at = data.get("revoked_at", "")
                if revoked_at:
                    try:
                        revoke_dt = datetime.fromisoformat(revoked_at)
                        if (now - revoke_dt).total_seconds() < 86400:
                            recent_revocations.append({
                                "user_id": data.get("user_id"),
                                "reason":  data.get("revoke_reason"),
                                "at":      revoked_at,
                            })
                    except ValueError:
                        pass
            else:
                active_count += 1
        except Exception:
            continue

    # Count rate limit violations in last hour
    rate_limit_keys = list(_redis.scan_iter("ratelimit:*", count=200))

    # Security config checks
    config_warnings = []
    if settings.SECRET_KEY in ["your-very-secret-key-change-this-in-production", "change-this-secret-key-in-production-use-64-chars-minimum"]:
        config_warnings.append("⚠️  DEFAULT SECRET_KEY detected — change immediately in production!")
    if settings.DEBUG:
        config_warnings.append("⚠️  DEBUG mode is enabled — disable in production.")
    if not settings.STRIPE_SECRET_KEY.startswith("sk_live_"):
        config_warnings.append("ℹ️  Using Stripe test mode (sk_test_). Switch to live keys for production.")

    return {
        "timestamp":           now.isoformat(),
        "active_sessions":     active_count,
        "revoked_sessions":    revoked_count,
        "recent_revocations":  len(recent_revocations),
        "revocations_detail":  recent_revocations[:10],  # Last 10
        "rate_limit_buckets":  len(rate_limit_keys),
        "config_warnings":     config_warnings,
        "security_headers":    "enabled",
        "token_rotation":      "enabled",
        "rate_limiting":       "enabled (sliding window)",
        "input_validation":    "enabled",
        "webhook_verification": "enabled",
    }
