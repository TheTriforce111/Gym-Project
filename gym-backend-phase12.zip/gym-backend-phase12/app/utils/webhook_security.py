"""
utils/webhook_security.py — Webhook Signature Verification (Phase 12)

All incoming webhooks MUST be verified before processing.
This module provides verification utilities for each webhook source.

──────────────────────────────────────────────────────────────────
STRIPE WEBHOOKS
──────────────────────────────────────────────────────────────────
Stripe signs every webhook with HMAC-SHA256 using your endpoint's
signing secret. The signature is in the Stripe-Signature header:

  Stripe-Signature: t=1614853200,v1=abc123...,v1=def456...

  Format: t=<timestamp>,v1=<signature>
  Payload: <timestamp>.<raw_body>
  Signature: HMAC-SHA256(payload, webhook_secret)

Security checks we perform:
  1. Signature verification (cryptographic — prevents forgery)
  2. Timestamp validation (prevents replay attacks — reject if >5 min old)
  3. Raw body integrity (parse AFTER verification, not before)

Why timing matters:
  An attacker who captures a valid webhook could replay it hours later.
  The timestamp check ensures we only accept events within a 5-minute window.
  Stripe also de-duplicates events by ID, but the timestamp is a first line.

──────────────────────────────────────────────────────────────────
FIREBASE WEBHOOKS (for future use)
──────────────────────────────────────────────────────────────────
Firebase uses Google's service account JWT verification.
Tokens are verified using Google's public keys.

──────────────────────────────────────────────────────────────────
GENERIC HMAC WEBHOOK VERIFICATION
──────────────────────────────────────────────────────────────────
For any webhook that uses HMAC-SHA256:
  - Extract raw body (bytes)
  - Compute expected = HMAC-SHA256(body, secret)
  - Compare using hmac.compare_digest() — timing-safe!
  - Never use == for comparing signatures (timing attack vulnerability)
"""

import hashlib
import hmac
import json
import logging
import time
from typing import Optional

from fastapi import HTTPException, Request, status

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Stripe webhook verification
# ---------------------------------------------------------------------------

STRIPE_TIMESTAMP_TOLERANCE_SECONDS = 300  # 5 minutes


def verify_stripe_webhook(
    payload: bytes,
    sig_header: str,
    webhook_secret: str,
) -> dict:
    """
    Verify a Stripe webhook signature and return the parsed event.

    This is a manual implementation that mirrors what stripe.Webhook.construct_event()
    does internally, giving us full control and auditability.

    Args:
        payload:        Raw request body bytes (NOT parsed JSON)
        sig_header:     Value of the "Stripe-Signature" header
        webhook_secret: Your endpoint's signing secret (whsec_...)

    Returns:
        The parsed event dict if valid.

    Raises:
        HTTPException(400) if signature is invalid or timestamp is too old.
    """
    if not sig_header:
        logger.warning("Stripe webhook: Missing Stripe-Signature header")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing Stripe-Signature header.",
        )

    # ── Parse the signature header ────────────────────────────────────────
    # Format: t=<timestamp>,v1=<sig1>,v1=<sig2>
    sig_parts = {}
    for part in sig_header.split(","):
        if "=" in part:
            key, value = part.split("=", 1)
            if key in sig_parts:
                # Multiple v1 values — Stripe supports signature rollover
                if isinstance(sig_parts[key], list):
                    sig_parts[key].append(value)
                else:
                    sig_parts[key] = [sig_parts[key], value]
            else:
                sig_parts[key] = value

    timestamp_str = sig_parts.get("t")
    v1_sigs       = sig_parts.get("v1", [])
    if isinstance(v1_sigs, str):
        v1_sigs = [v1_sigs]

    if not timestamp_str or not v1_sigs:
        logger.warning("Stripe webhook: Malformed Stripe-Signature header")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Malformed webhook signature header.",
        )

    # ── Timestamp validation (replay attack prevention) ───────────────────
    try:
        timestamp = int(timestamp_str)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid webhook timestamp.")

    age_seconds = int(time.time()) - timestamp
    if abs(age_seconds) > STRIPE_TIMESTAMP_TOLERANCE_SECONDS:
        logger.warning(
            f"Stripe webhook: Timestamp too old/future: "
            f"age={age_seconds}s tolerance={STRIPE_TIMESTAMP_TOLERANCE_SECONDS}s"
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Webhook timestamp is {age_seconds} seconds old. "
                f"Maximum allowed: {STRIPE_TIMESTAMP_TOLERANCE_SECONDS} seconds."
            ),
        )

    # ── Signature verification ────────────────────────────────────────────
    # Stripe's signed payload = "<timestamp>.<raw_body>"
    signed_payload = f"{timestamp_str}.".encode() + payload

    expected_sig = hmac.new(
        key=webhook_secret.encode("utf-8"),
        msg=signed_payload,
        digestmod=hashlib.sha256,
    ).hexdigest()

    # Check if expected matches any of the provided v1 signatures
    # Using hmac.compare_digest() to prevent timing attacks
    is_valid = any(
        hmac.compare_digest(expected_sig, sig)
        for sig in v1_sigs
    )

    if not is_valid:
        logger.critical(
            "Stripe webhook: SIGNATURE VERIFICATION FAILED. "
            "Possible forgery or wrong webhook secret."
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Webhook signature verification failed.",
        )

    # ── Parse and return the event ────────────────────────────────────────
    try:
        event = json.loads(payload)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON in webhook body.")

    logger.info(
        f"Stripe webhook verified: "
        f"event_id={event.get('id')} "
        f"type={event.get('type')}"
    )
    return event


# ---------------------------------------------------------------------------
# Generic HMAC webhook verification
# For any webhook provider that uses HMAC-SHA256 (GitHub, Shopify, etc.)
# ---------------------------------------------------------------------------

def verify_hmac_webhook(
    payload: bytes,
    signature_header: str,
    secret: str,
    algorithm: str = "sha256",
    header_prefix: str = "sha256=",
) -> bool:
    """
    Verify a generic HMAC webhook signature.

    Args:
        payload:          Raw request body bytes
        signature_header: Value of the signature header
        secret:           Shared webhook secret
        algorithm:        Hash algorithm (sha256, sha1, sha512)
        header_prefix:    Prefix in the signature header (e.g. "sha256=")

    Returns:
        True if valid.

    Raises:
        HTTPException(400) if signature is invalid.

    Example (GitHub):
        verify_hmac_webhook(
            payload=body,
            signature_header=request.headers["X-Hub-Signature-256"],
            secret=GITHUB_WEBHOOK_SECRET,
            header_prefix="sha256=",
        )
    """
    if not signature_header:
        raise HTTPException(status_code=400, detail="Missing webhook signature.")

    # Remove prefix
    received_sig = signature_header
    if header_prefix and received_sig.startswith(header_prefix):
        received_sig = received_sig[len(header_prefix):]

    # Compute expected signature
    digestmod_map = {
        "sha256": hashlib.sha256,
        "sha1":   hashlib.sha1,
        "sha512": hashlib.sha512,
    }
    digestmod = digestmod_map.get(algorithm, hashlib.sha256)

    expected_sig = hmac.new(
        key=secret.encode("utf-8"),
        msg=payload,
        digestmod=digestmod,
    ).hexdigest()

    if not hmac.compare_digest(expected_sig, received_sig):
        logger.warning("Generic webhook: Signature verification failed")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Webhook signature verification failed.",
        )

    return True


# ---------------------------------------------------------------------------
# Webhook IP allowlisting (optional additional layer)
# ---------------------------------------------------------------------------

# Stripe's published IP ranges for webhook delivery
# Keep this updated — check https://stripe.com/docs/ips
STRIPE_IP_RANGES = [
    "3.18.12.63",
    "3.130.192.231",
    "13.235.14.237",
    "13.235.122.149",
    "18.211.135.69",
    "35.154.171.200",
    "52.15.183.38",
    "54.187.174.169",
    "54.187.205.235",
    "54.187.216.72",
    "54.241.31.99",
    "54.241.31.102",
    "54.241.34.107",
]


def verify_stripe_ip(request: Request) -> bool:
    """
    Optional: Verify the request comes from Stripe's known IP ranges.
    Use as an additional layer on top of signature verification.

    Note: This should be ADDITIONAL to signature verification, not a replacement.
    IP allowlisting alone is insufficient because IPs can be spoofed.
    """
    forwarded = request.headers.get("X-Forwarded-For", "")
    client_ip = (
        forwarded.split(",")[0].strip()
        if forwarded
        else (request.client.host if request.client else "")
    )

    if client_ip not in STRIPE_IP_RANGES:
        logger.warning(
            f"Stripe webhook from unexpected IP: {client_ip}. "
            "This may be legitimate if behind a proxy. "
            "Relying on signature verification instead."
        )
        # Return False but don't block — signature verification is the real guard
        return False

    return True
