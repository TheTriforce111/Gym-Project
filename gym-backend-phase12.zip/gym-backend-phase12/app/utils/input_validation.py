"""
utils/input_validation.py — Input Validation & Sanitization (Phase 12)

Defense-in-depth: even though Pydantic validates schema types and formats,
we add a second layer of sanitization to catch:
  - SQL injection patterns in string fields
  - XSS payloads (script tags, event handlers)
  - Path traversal sequences (../../etc/passwd)
  - Null bytes that can truncate strings
  - Excessively long inputs that could cause DoS

Why sanitize if we use Pydantic + SQLAlchemy?
  - SQLAlchemy parameterized queries already prevent SQL injection
  - But defense-in-depth means multiple independent layers
  - Custom validators catch edge cases Pydantic misses
  - Sanitizing user-visible output prevents stored XSS

Key design principle: REJECT, don't silently modify.
  If input looks malicious, raise a clear error.
  Never silently strip dangerous content — the user should know.
"""

import re
import html
import unicodedata
from typing import Optional
from pydantic import field_validator


# ---------------------------------------------------------------------------
# Pattern library — compiled once at module load for performance
# ---------------------------------------------------------------------------

# SQL injection: common patterns that indicate an attempt to break out of a query
_SQL_INJECTION = re.compile(
    r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|CREATE|EXEC|"
    r"UNION|CAST|CONVERT|DECLARE|WAITFOR|SLEEP|BENCHMARK)\b"
    r"|--|;.*--|/\*|\*/|xp_|0x[0-9a-fA-F]+)",
    re.IGNORECASE,
)

# XSS: script injection and event handler injection
_XSS_PATTERNS = re.compile(
    r"(<script|</script|javascript:|vbscript:|data:text/html|"
    r"on\w+=|<iframe|<object|<embed|<link\s|<meta\s|"
    r"expression\s*\(|eval\s*\(|document\.|window\.)",
    re.IGNORECASE,
)

# Path traversal: attempts to navigate directory structure
_PATH_TRAVERSAL = re.compile(r"\.\./|\.\.\\|%2e%2e|%252e%252e", re.IGNORECASE)

# Null bytes: can truncate strings in C-based systems, bypassing length checks
_NULL_BYTES = re.compile(r"\x00|%00")

# Control characters: non-printable chars that shouldn't appear in user input
_CONTROL_CHARS = re.compile(r"[\x01-\x08\x0b\x0c\x0e-\x1f\x7f]")

# Email validation (RFC 5322 simplified)
_EMAIL_PATTERN = re.compile(
    r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9]"
    r"(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9]"
    r"(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$"
)

# Phone: digits, spaces, hyphens, parentheses, plus sign
_PHONE_PATTERN = re.compile(r"^[\d\s\-\+\(\)\.]{7,20}$")


# ---------------------------------------------------------------------------
# Core sanitizer
# ---------------------------------------------------------------------------

def sanitize_string(
    value: str,
    field_name: str = "field",
    max_length: int = 500,
    allow_html: bool = False,
) -> str:
    """
    Sanitize and validate a string input.

    Steps:
    1. Remove null bytes
    2. Remove control characters
    3. Normalize Unicode (NFKC) — prevents homograph attacks
    4. Strip leading/trailing whitespace
    5. Check maximum length
    6. Check for path traversal
    7. Check for SQL injection patterns
    8. Check for XSS patterns (if allow_html=False)
    9. HTML-escape the result

    Args:
        value:      The input string to sanitize
        field_name: Used in error messages to tell the user which field failed
        max_length: Maximum allowed length after stripping
        allow_html: If True, skip XSS check (for fields that allow markup)

    Returns:
        The sanitized string, safe to store in the database.

    Raises:
        ValueError: With a descriptive message if the input is suspicious.
    """
    if not isinstance(value, str):
        return value

    # Step 1: Remove null bytes
    value = _NULL_BYTES.sub("", value)

    # Step 2: Remove control characters (keep \n and \t for multi-line fields)
    value = _CONTROL_CHARS.sub("", value)

    # Step 3: Unicode normalization — prevents homograph attacks where
    # visually identical characters (e.g. Cyrillic 'а' vs Latin 'a')
    # are used to bypass filters
    value = unicodedata.normalize("NFKC", value)

    # Step 4: Strip whitespace
    value = value.strip()

    # Step 5: Length check
    if len(value) > max_length:
        raise ValueError(
            f"'{field_name}' is too long. Maximum {max_length} characters allowed."
        )

    # Step 6: Path traversal
    if _PATH_TRAVERSAL.search(value):
        raise ValueError(
            f"'{field_name}' contains invalid characters."
        )

    # Step 7: SQL injection patterns
    # We check but don't block legitimate business words (SELECT can appear in
    # descriptions), so only flag if combined with injection operators
    if _SQL_INJECTION.search(value) and any(c in value for c in ["'", '"', ";", "--", "/*"]):
        raise ValueError(
            f"'{field_name}' contains characters that are not allowed."
        )

    # Step 8: XSS patterns
    if not allow_html and _XSS_PATTERNS.search(value):
        raise ValueError(
            f"'{field_name}' contains HTML or script content that is not allowed."
        )

    # Step 9: HTML-escape the result
    # This converts < > & " ' to their HTML entities, safe for display
    # Note: SQLAlchemy parameterized queries make this optional for DB storage,
    # but it protects against stored XSS if data is ever rendered without escaping
    if not allow_html:
        value = html.escape(value, quote=True)

    return value


# ---------------------------------------------------------------------------
# Specific validators (use these in Pydantic schemas)
# ---------------------------------------------------------------------------

def validate_email(email: str) -> str:
    """
    Validate and normalize an email address.
    - Converts to lowercase
    - Strips whitespace
    - Validates format against RFC 5322 simplified pattern
    - Maximum 254 characters (RFC 5321 limit)
    """
    email = email.strip().lower()

    if len(email) > 254:
        raise ValueError("Email address is too long.")

    if not _EMAIL_PATTERN.match(email):
        raise ValueError("Enter a valid email address (e.g. user@example.com).")

    return email


def validate_phone(phone: Optional[str]) -> Optional[str]:
    """
    Validate a phone number.
    Allows: digits, spaces, hyphens, parentheses, plus sign.
    Returns None if empty, validated string otherwise.
    """
    if not phone:
        return None

    phone = phone.strip()
    if not _PHONE_PATTERN.match(phone):
        raise ValueError(
            "Phone number can only contain digits, spaces, hyphens, "
            "and parentheses (e.g. +1 555-123-4567)."
        )
    return phone


def validate_password(password: str) -> str:
    """
    Enforce password policy:
    - Minimum 8 characters
    - At least 1 uppercase letter
    - At least 1 lowercase letter
    - At least 1 digit
    - At least 1 special character (recommended, not required)
    - Maximum 128 characters (prevent bcrypt DoS — bcrypt truncates at 72 bytes
      but very long inputs still waste CPU time)
    - No null bytes or control characters
    """
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters.")

    if len(password) > 128:
        raise ValueError("Password cannot exceed 128 characters.")

    if _NULL_BYTES.search(password):
        raise ValueError("Password contains invalid characters.")

    if not re.search(r"[A-Z]", password):
        raise ValueError("Password must contain at least one uppercase letter (A-Z).")

    if not re.search(r"[a-z]", password):
        raise ValueError("Password must contain at least one lowercase letter (a-z).")

    if not re.search(r"\d", password):
        raise ValueError("Password must contain at least one digit (0-9).")

    return password


def validate_name(name: str, field: str = "Name") -> str:
    """
    Validate a person's name.
    - 2-100 characters
    - Only letters, spaces, hyphens, apostrophes, periods
    - Sanitized against injection
    """
    name = name.strip()

    if len(name) < 2:
        raise ValueError(f"{field} must be at least 2 characters.")

    if len(name) > 100:
        raise ValueError(f"{field} cannot exceed 100 characters.")

    # Allow international characters (Unicode letters) + common name punctuation
    if not re.match(r"^[\w\s\-'.]+$", name, re.UNICODE):
        raise ValueError(
            f"{field} can only contain letters, spaces, hyphens, "
            "apostrophes, and periods."
        )

    return sanitize_string(name, field_name=field, max_length=100)


def validate_text_content(text: str, field: str = "text", max_length: int = 1000) -> str:
    """
    Validate free-text content like notes, descriptions, etc.
    More permissive than name validation — allows punctuation and special chars,
    but still sanitizes against XSS and injection.
    """
    if not text:
        return text

    return sanitize_string(text.strip(), field_name=field, max_length=max_length)


def validate_positive_number(value: float, field: str = "amount") -> float:
    """Ensure a numeric value is positive and reasonable."""
    if value < 0:
        raise ValueError(f"{field} cannot be negative.")
    if value > 1_000_000:
        raise ValueError(f"{field} exceeds the maximum allowed value.")
    return round(value, 2)


# ---------------------------------------------------------------------------
# Pydantic validator decorator helpers
# Use these in schema classes for consistent validation
# ---------------------------------------------------------------------------

class SecureUserCreate:
    """
    Mixin providing secure Pydantic validators for user creation schemas.

    Usage:
        class UserCreate(BaseModel, SecureUserCreate):
            full_name: str
            email: EmailStr
            password: str
            phone: Optional[str] = None

            _validate_name     = SecureUserCreate.name_validator('full_name')
            _validate_email    = SecureUserCreate.email_validator('email')
            _validate_password = SecureUserCreate.password_validator('password')
            _validate_phone    = SecureUserCreate.phone_validator('phone')
    """

    @staticmethod
    def name_validator(field: str):
        @field_validator(field)
        @classmethod
        def _v(cls, v):
            return validate_name(v, field)
        return _v

    @staticmethod
    def email_validator(field: str = "email"):
        @field_validator(field)
        @classmethod
        def _v(cls, v):
            return validate_email(v)
        return _v

    @staticmethod
    def password_validator(field: str = "password"):
        @field_validator(field)
        @classmethod
        def _v(cls, v):
            return validate_password(v)
        return _v

    @staticmethod
    def phone_validator(field: str = "phone"):
        @field_validator(field)
        @classmethod
        def _v(cls, v):
            return validate_phone(v)
        return _v
