"""
core/rbac.py — Role-Based Access Control (RBAC) Enforcement (Phase 12)

This module provides fine-grained permission checking beyond just role checks.

Phase 1-11 had basic role guards (require_admin, require_trainer).
Phase 12 upgrades to a permission-based system:

  OLD: if user.role != 'admin': raise 403
  NEW: if not has_permission(user, Permission.MANAGE_MEMBERS): raise 403

Why permissions are better than raw role checks:
  - "Trainer" should be able to create workout plans but NOT process refunds
  - "Admin" may have sub-roles (billing admin vs. operations admin)
  - Permissions make it easy to audit exactly what each role can do
  - Adding a new role doesn't require searching all route handlers

Permission Matrix:

  Permission                  | Admin | Trainer | Member
  ─────────────────────────── | ──────│─────────│───────
  VIEW_OWN_PROFILE            |   ✅  |   ✅    |  ✅
  EDIT_OWN_PROFILE            |   ✅  |   ✅    |  ✅
  VIEW_ANY_PROFILE            |   ✅  |   ✅    |  ❌
  MANAGE_MEMBERS              |   ✅  |   ❌    |  ❌
  VIEW_MEMBERSHIPS            |   ✅  |   ❌    |  ❌ (own only)
  MANAGE_MEMBERSHIPS          |   ✅  |   ❌    |  ❌
  VIEW_ALL_PAYMENTS           |   ✅  |   ❌    |  ❌ (own only)
  PROCESS_REFUNDS             |   ✅  |   ❌    |  ❌
  MANAGE_EXERCISES            |   ✅  |   ✅    |  ❌
  CREATE_WORKOUT_PLANS        |   ✅  |   ✅    |  ❌
  VIEW_ANY_WORKOUT_PLAN       |   ✅  |   ✅    |  ❌ (own only)
  CREATE_CLASSES              |   ✅  |   ✅    |  ❌
  MANAGE_ANY_CLASS            |   ✅  |   ✅*   |  ❌ (*own classes only)
  BOOK_CLASSES                |   ✅  |   ✅    |  ✅
  VIEW_ATTENDANCE             |   ✅  |   ✅    |  ❌ (own only)
  MANUAL_CHECKIN              |   ✅  |   ✅    |  ❌
  INVALIDATE_QR               |   ✅  |   ❌    |  ❌
  VIEW_ANALYTICS              |   ✅  |   ❌    |  ❌
  SEND_ANNOUNCEMENTS          |   ✅  |   ❌    |  ❌
  MANAGE_NOTIFICATIONS        |   ✅  |   ❌    |  ❌
"""

import enum
import logging
from functools import lru_cache
from typing import Set

from fastapi import Depends, HTTPException, status

from app.core.dependencies import get_current_user
from app.models.user import User, UserRole

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Permission Enum
# ---------------------------------------------------------------------------

class Permission(str, enum.Enum):
    """
    All available permissions in the system.
    Using string enum so permissions can be serialized to JSON.
    """
    # Profile
    VIEW_OWN_PROFILE     = "view_own_profile"
    EDIT_OWN_PROFILE     = "edit_own_profile"
    VIEW_ANY_PROFILE     = "view_any_profile"
    MANAGE_MEMBERS       = "manage_members"

    # Memberships
    VIEW_OWN_MEMBERSHIP  = "view_own_membership"
    VIEW_ALL_MEMBERSHIPS = "view_all_memberships"
    MANAGE_MEMBERSHIPS   = "manage_memberships"

    # Payments
    VIEW_OWN_PAYMENTS    = "view_own_payments"
    VIEW_ALL_PAYMENTS    = "view_all_payments"
    PROCESS_REFUNDS      = "process_refunds"
    CREATE_PAYMENT_INTENTS = "create_payment_intents"

    # Workouts
    MANAGE_EXERCISES     = "manage_exercises"
    CREATE_WORKOUT_PLANS = "create_workout_plans"
    VIEW_ANY_WORKOUT_PLAN = "view_any_workout_plan"
    LOG_WORKOUTS         = "log_workouts"

    # Classes
    CREATE_CLASSES       = "create_classes"
    MANAGE_ANY_CLASS     = "manage_any_class"
    BOOK_CLASSES         = "book_classes"
    MARK_ATTENDANCE      = "mark_attendance"

    # Attendance / QR
    VIEW_OWN_ATTENDANCE  = "view_own_attendance"
    VIEW_ALL_ATTENDANCE  = "view_all_attendance"
    MANUAL_CHECKIN       = "manual_checkin"
    INVALIDATE_QR        = "invalidate_qr"

    # Analytics
    VIEW_ANALYTICS       = "view_analytics"

    # Notifications
    SEND_ANNOUNCEMENTS   = "send_announcements"
    MANAGE_NOTIFICATIONS = "manage_notifications"
    VIEW_OWN_NOTIFICATIONS = "view_own_notifications"


# ---------------------------------------------------------------------------
# Role → Permission mapping
# ---------------------------------------------------------------------------

_ROLE_PERMISSIONS: dict[UserRole, Set[Permission]] = {

    UserRole.MEMBER: {
        Permission.VIEW_OWN_PROFILE,
        Permission.EDIT_OWN_PROFILE,
        Permission.VIEW_OWN_MEMBERSHIP,
        Permission.VIEW_OWN_PAYMENTS,
        Permission.CREATE_PAYMENT_INTENTS,
        Permission.LOG_WORKOUTS,
        Permission.BOOK_CLASSES,
        Permission.VIEW_OWN_ATTENDANCE,
        Permission.VIEW_OWN_NOTIFICATIONS,
    },

    UserRole.TRAINER: {
        # Trainers have all Member permissions, plus:
        Permission.VIEW_OWN_PROFILE,
        Permission.EDIT_OWN_PROFILE,
        Permission.VIEW_ANY_PROFILE,
        Permission.VIEW_OWN_MEMBERSHIP,
        Permission.VIEW_OWN_PAYMENTS,
        Permission.CREATE_PAYMENT_INTENTS,
        Permission.MANAGE_EXERCISES,
        Permission.CREATE_WORKOUT_PLANS,
        Permission.VIEW_ANY_WORKOUT_PLAN,
        Permission.LOG_WORKOUTS,
        Permission.CREATE_CLASSES,
        Permission.MANAGE_ANY_CLASS,      # Own classes only — enforced at service layer
        Permission.BOOK_CLASSES,
        Permission.MARK_ATTENDANCE,
        Permission.VIEW_OWN_ATTENDANCE,
        Permission.VIEW_ALL_ATTENDANCE,
        Permission.MANUAL_CHECKIN,
        Permission.VIEW_OWN_NOTIFICATIONS,
    },

    UserRole.ADMIN: {
        # Admins have ALL permissions
        p for p in Permission
    },
}


# ---------------------------------------------------------------------------
# Permission checking functions
# ---------------------------------------------------------------------------

@lru_cache(maxsize=None)
def get_role_permissions(role: UserRole) -> frozenset:
    """
    Get all permissions for a role. Cached for performance.
    Returns a frozenset (immutable, hashable).
    """
    return frozenset(_ROLE_PERMISSIONS.get(role, set()))


def has_permission(user: User, permission: Permission) -> bool:
    """
    Check if a user has a specific permission.

    Usage:
        if not has_permission(current_user, Permission.VIEW_ANALYTICS):
            raise HTTPException(403, "Access denied")
    """
    return permission in get_role_permissions(user.role)


def require_permission(permission: Permission):
    """
    FastAPI dependency factory that checks a specific permission.

    Usage:
        @router.get("/analytics/dashboard")
        def dashboard(
            _: None = Depends(require_permission(Permission.VIEW_ANALYTICS)),
            current_user: User = Depends(get_current_user),
        ):
    """
    def _check(current_user: User = Depends(get_current_user)) -> User:
        if not has_permission(current_user, permission):
            logger.warning(
                f"Permission denied: user=#{current_user.id} "
                f"role={current_user.role} "
                f"required={permission}"
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    f"Access denied. Your role ({current_user.role.value}) "
                    f"does not have permission for this action."
                ),
            )
        return current_user
    return _check


def require_any_permission(*permissions: Permission):
    """
    Require at least ONE of the given permissions (OR logic).

    Usage:
        @router.get("/workouts/plans/{id}")
        def get_plan(
            _: None = Depends(require_any_permission(
                Permission.VIEW_ANY_WORKOUT_PLAN,
                Permission.LOG_WORKOUTS,   # Members can view their own
            )),
        ):
    """
    def _check(current_user: User = Depends(get_current_user)) -> User:
        user_perms = get_role_permissions(current_user.role)
        if not any(p in user_perms for p in permissions):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. Insufficient permissions.",
            )
        return current_user
    return _check


# ---------------------------------------------------------------------------
# Resource ownership checking
# ---------------------------------------------------------------------------

def check_resource_ownership(
    resource_user_id: int,
    requesting_user: User,
    allow_roles: tuple = (UserRole.ADMIN, UserRole.TRAINER),
) -> None:
    """
    Verify that the requesting user either owns the resource OR has
    an elevated role that allows accessing others' resources.

    This is the "can I access this specific resource?" check,
    separate from the "do I have the general permission?" check.

    Usage:
        # In a workout plan endpoint:
        check_resource_ownership(
            resource_user_id=plan.user_id,
            requesting_user=current_user,
        )
        # Members can only access their own plans.
        # Trainers and Admins can access any plan.
    """
    if requesting_user.id == resource_user_id:
        return  # User owns the resource — always allowed

    if requesting_user.role in allow_roles:
        return  # Elevated role — can access others' resources

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Access denied. You can only access your own data.",
    )


# ---------------------------------------------------------------------------
# Audit logging helper
# ---------------------------------------------------------------------------

def log_sensitive_action(
    action: str,
    user: User,
    target_id: Optional[int] = None,
    details: Optional[str] = None,
) -> None:
    """
    Log security-sensitive actions for audit trail purposes.
    In production, write these to a dedicated audit log table or SIEM.

    Actions to log:
    - Admin actions on other users (deactivate, change role)
    - Payment operations (refunds)
    - QR invalidation
    - Failed permission checks
    - Suspicious activity
    """
    logger.info(
        f"AUDIT: action={action} "
        f"actor=#{user.id}({user.role.value}) "
        f"target={'#' + str(target_id) if target_id else 'n/a'} "
        f"details={details or ''}"
    )


from typing import Optional  # noqa: E402 — needed for log_sensitive_action
