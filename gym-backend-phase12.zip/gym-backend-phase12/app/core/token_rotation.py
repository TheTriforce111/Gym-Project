"""
core/token_rotation.py — JWT Refresh Token Rotation (Phase 12)

TOKEN ROTATION: Every time a refresh token is used, it is replaced with a NEW
refresh token. The old one is immediately invalidated.

Why rotation matters:
  WITHOUT rotation:
    - Attacker steals refresh token → unlimited access forever
    - The legitimate user has no way to detect or stop it

  WITH rotation:
    - Attacker uses the stolen token → generates new pair
    - Legitimate user's old refresh token is now INVALID
    - On next API call, legitimate user gets 401 → they must re-login
    - Both tokens are detected as potentially stolen → whole family revoked
    - Attacker also loses access

TOKEN FAMILY TRACKING:
  We track "token families" — all refresh tokens that descend from
  the same original login. If we detect reuse of an already-used token
  (which means someone has an old copy), we revoke the ENTIRE family,
  logging out all sessions for that user.

  This is the REUSE DETECTION feature:
    1. User logs in → Family A created → RT-A1 issued
    2. RT-A1 used → RT-A2 issued, RT-A1 marked USED
    3. Attacker uses stolen RT-A1 → ALARM: RT-A1 already used!
    4. Entire Family A revoked → legitimate user also logged out
    5. User notices forced logout → contacts support → attacker neutralized

Storage in Redis:
  "token_family:{family_id}" → {
    "user_id": 42,
    "tokens": [RT-A1-hash, RT-A2-hash, RT-A3-hash],  # all tokens in family
    "current": RT-A3-hash,       # only this one is valid
    "revoked": false
  }
  Key expires after REFRESH_TOKEN_EXPIRE_DAYS.
"""

import hashlib
import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Optional

import redis
from fastapi import HTTPException, status

from app.core.config import settings
from app.core.security import create_access_token, create_refresh_token, decode_token

logger = logging.getLogger(__name__)

_redis = redis.from_url(settings.REDIS_URL, decode_responses=True)

FAMILY_TTL_SECONDS = settings.REFRESH_TOKEN_EXPIRE_DAYS * 86400


# ---------------------------------------------------------------------------
# Token family operations
# ---------------------------------------------------------------------------

def _token_hash(token: str) -> str:
    """SHA-256 hash of a token — stored in Redis instead of the raw token."""
    return hashlib.sha256(token.encode()).hexdigest()


def create_token_family(user_id: int, user_role: str) -> dict:
    """
    Create a new token family at login.
    Returns both tokens and the family_id (embedded in the refresh token payload).
    """
    family_id = str(uuid.uuid4())

    token_data = {
        "sub":       str(user_id),
        "role":      user_role,
        "family_id": family_id,
    }

    access_token  = create_access_token(token_data)
    refresh_token = create_refresh_token(token_data)
    rt_hash       = _token_hash(refresh_token)

    # Store family in Redis
    family_data = {
        "user_id":  user_id,
        "role":     user_role,
        "tokens":   [rt_hash],     # All tokens ever issued in this family
        "current":  rt_hash,       # Only this one is valid right now
        "revoked":  False,
        "created":  datetime.utcnow().isoformat(),
    }
    _redis.setex(
        f"token_family:{family_id}",
        FAMILY_TTL_SECONDS,
        json.dumps(family_data),
    )

    logger.info(f"Token family created: family_id={family_id} user_id={user_id}")

    return {
        "access_token":  access_token,
        "refresh_token": refresh_token,
        "token_type":    "bearer",
    }


def rotate_refresh_token(old_refresh_token: str) -> dict:
    """
    Exchange an old refresh token for a new token pair.

    Steps:
    1. Decode the old refresh token (verify signature + expiry)
    2. Extract family_id from payload
    3. Load the family from Redis
    4. Check if this token is the CURRENT valid token
       - If NOT current → reuse detected → revoke entire family → 401
       - If family already revoked → 401
    5. Issue new access + refresh tokens
    6. Update family: mark old token as used, set new token as current

    Returns new {access_token, refresh_token, token_type}
    Raises HTTPException(401) if token is invalid, expired, or reused.
    """
    # Step 1: Decode
    payload = decode_token(old_refresh_token)
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token. Please log in again.",
        )

    family_id = payload.get("family_id")
    if not family_id:
        # Old token format without family tracking — reject
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token format not supported. Please log in again.",
        )

    # Step 2: Load family
    family_key  = f"token_family:{family_id}"
    family_json = _redis.get(family_key)

    if not family_json:
        # Family expired or never existed
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session expired. Please log in again.",
        )

    family = json.loads(family_json)

    # Step 3: Check if already revoked
    if family.get("revoked"):
        logger.warning(
            f"Attempt to use revoked token family: "
            f"family_id={family_id} user_id={family['user_id']}"
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="This session has been revoked. Please log in again.",
        )

    # Step 4: Verify this is the CURRENT valid token
    old_rt_hash = _token_hash(old_refresh_token)
    if old_rt_hash != family["current"]:
        # REUSE DETECTED! Someone is using an old token.
        # Revoke the entire family immediately.
        family["revoked"] = True
        family["revoke_reason"] = "token_reuse_detected"
        family["revoked_at"]    = datetime.utcnow().isoformat()
        _redis.setex(family_key, FAMILY_TTL_SECONDS, json.dumps(family))

        logger.critical(
            f"SECURITY ALERT: Refresh token reuse detected! "
            f"family_id={family_id} user_id={family['user_id']}. "
            f"Entire token family revoked."
        )

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Security alert: This token has already been used. "
                "Your session has been terminated for safety. "
                "Please log in again."
            ),
        )

    # Step 5: Issue new tokens
    user_id   = family["user_id"]
    user_role = family["role"]

    token_data = {
        "sub":       str(user_id),
        "role":      user_role,
        "family_id": family_id,
    }
    new_access  = create_access_token(token_data)
    new_refresh = create_refresh_token(token_data)
    new_rt_hash = _token_hash(new_refresh)

    # Step 6: Update family — rotate
    family["tokens"].append(new_rt_hash)   # Audit trail of all tokens
    family["current"] = new_rt_hash        # Only new token is valid
    _redis.setex(family_key, FAMILY_TTL_SECONDS, json.dumps(family))

    logger.info(
        f"Token rotated: family_id={family_id} user_id={user_id}"
    )

    return {
        "access_token":  new_access,
        "refresh_token": new_refresh,
        "token_type":    "bearer",
    }


def revoke_family(family_id: str, reason: str = "logout") -> None:
    """
    Revoke an entire token family (all tokens in it become invalid).
    Called on logout to ensure refresh tokens can't be reused.
    """
    family_key  = f"token_family:{family_id}"
    family_json = _redis.get(family_key)

    if not family_json:
        return  # Already expired

    family = json.loads(family_json)
    family["revoked"]      = True
    family["revoke_reason"] = reason
    family["revoked_at"]   = datetime.utcnow().isoformat()

    _redis.setex(family_key, FAMILY_TTL_SECONDS, json.dumps(family))
    logger.info(f"Token family revoked: family_id={family_id} reason={reason}")


def revoke_all_user_families(user_id: int) -> int:
    """
    Revoke ALL token families for a user — logs them out of every device.
    Use when: password changed, account suspended, security breach detected.
    Returns the count of families revoked.
    """
    # This requires scanning Redis — use with care (O(N) scan)
    # In high-scale production, maintain a separate index:
    # "user_families:{user_id}" → set of family_ids
    pattern = "token_family:*"
    count   = 0

    for key in _redis.scan_iter(pattern, count=100):
        try:
            data = json.loads(_redis.get(key) or "{}")
            if data.get("user_id") == user_id and not data.get("revoked"):
                data["revoked"]      = True
                data["revoke_reason"] = "admin_revocation"
                data["revoked_at"]   = datetime.utcnow().isoformat()
                _redis.setex(key, FAMILY_TTL_SECONDS, json.dumps(data))
                count += 1
        except Exception:
            continue

    logger.info(f"All token families revoked for user #{user_id}: {count} families")
    return count
