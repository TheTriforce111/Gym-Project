"""
middleware/security_headers.py — HTTP Security Headers Middleware (Phase 12)

Security headers protect against common web attacks by instructing browsers
on how to behave when loading content from our API.

Headers we add to EVERY response:

1. X-Content-Type-Options: nosniff
   Prevents MIME-type sniffing. Without this, browsers can interpret
   a response as a different content type, enabling XSS attacks.

2. X-Frame-Options: DENY
   Prevents clickjacking — embedding our API responses in an <iframe>
   on a malicious site to trick users into clicking hidden elements.

3. X-XSS-Protection: 1; mode=block
   Legacy XSS filter for older browsers (modern ones use CSP instead).

4. Referrer-Policy: strict-origin-when-cross-origin
   Controls how much referrer information is sent with requests.
   Prevents leaking sensitive URL paths to third-party servers.

5. Permissions-Policy
   Disables browser features we don't need (camera, microphone, etc.)
   Limits the attack surface if our frontend is ever compromised.

6. Strict-Transport-Security (HSTS)
   Tells browsers to ONLY use HTTPS for our domain for 1 year.
   Prevents SSL stripping attacks.
   NOTE: Only add in production — breaks local HTTP development.

7. Content-Security-Policy (CSP)
   The most powerful XSS defense. Whitelists exactly which sources
   can load scripts, styles, images, etc.
   For an API, we use a strict policy since we don't serve HTML.

These are added at the middleware level so every endpoint gets them
automatically — no need to add them to individual route handlers.
"""

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from app.core.config import settings


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Starlette middleware that injects security headers into every response.
    Applied to the FastAPI app in main.py:
        app.add_middleware(SecurityHeadersMiddleware)
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        response = await call_next(request)

        # ── Prevent MIME sniffing ─────────────────────────────────────────
        response.headers["X-Content-Type-Options"] = "nosniff"

        # ── Prevent clickjacking ──────────────────────────────────────────
        response.headers["X-Frame-Options"] = "DENY"

        # ── Legacy XSS filter ────────────────────────────────────────────
        response.headers["X-XSS-Protection"] = "1; mode=block"

        # ── Referrer policy ───────────────────────────────────────────────
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

        # ── Permissions policy ────────────────────────────────────────────
        # Disables features we never use
        response.headers["Permissions-Policy"] = (
            "accelerometer=(), camera=(), geolocation=(), "
            "gyroscope=(), magnetometer=(), microphone=(), "
            "payment=(), usb=()"
        )

        # ── HSTS (HTTPS only) ─────────────────────────────────────────────
        # Only in production to avoid breaking local HTTP dev
        if not settings.DEBUG:
            response.headers["Strict-Transport-Security"] = (
                "max-age=31536000; includeSubDomains; preload"
                # max-age=31536000 = 1 year in seconds
                # includeSubDomains: apply to all subdomains too
                # preload: allow inclusion in browser HSTS preload lists
            )

        # ── Content Security Policy ───────────────────────────────────────
        # For a pure API (no HTML), this is strict — no scripts/styles needed
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; "      # Block everything by default
            "frame-ancestors 'none'; "  # Equivalent to X-Frame-Options: DENY
            "base-uri 'none'; "         # Prevent base tag injection
            "form-action 'none'"        # No form submissions allowed
        )

        # ── Cache control for sensitive endpoints ─────────────────────────
        # Prevent browsers/proxies from caching auth responses
        if any(path in request.url.path for path in ["/auth/", "/users/me", "/payments/"]):
            response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
            response.headers["Pragma"] = "no-cache"

        return response
