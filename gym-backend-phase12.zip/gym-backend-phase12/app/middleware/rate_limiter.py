"""
middleware/rate_limiter.py — Advanced Rate Limiting Middleware (Phase 12)

We implement the SLIDING WINDOW algorithm using Redis sorted sets.

Why sliding window instead of fixed window?
  Fixed window:  Reset counter at :00, :30, :00, :30...
    Problem: A burst of 100 requests at :29 and 100 more at :31 bypasses
             a "100 per minute" limit because they're in different windows.

  Sliding window: Always count requests in the last N seconds from RIGHT NOW.
    The window moves forward with time — no burst bypass possible.

How it works (Redis sorted set):
  1. Each request adds its timestamp to a sorted set keyed by IP+route
  2. Remove all entries older than the window size
  3. Count remaining entries — that's the request count
  4. If count > limit → reject with 429
  5. Set key expiry = window_size so Redis cleans up inactive clients

Rate limit tiers in this system:
  - Login:        5  requests / 5  minutes  (brute force protection)
  - OTP request:  3  requests / 10 minutes  (prevents OTP spam)
  - Registration: 10 requests / 60 minutes  (prevents account farming)
  - API general:  200 requests / 60 seconds (abuse protection)
  - Webhook:      No limit (Stripe server IP only)

The middleware is applied per-route using FastAPI dependencies,
giving us fine-grained control without a global blanket limit.
"""

import time
import hashlib
import logging
from typing import Callable, Optional

import redis
from fastapi import HTTPException, Request, status

from app.core.config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Redis connection (reuse from existing redis_client)
# ---------------------------------------------------------------------------
_redis = redis.from_url(settings.REDIS_URL, decode_responses=True)


# ---------------------------------------------------------------------------
# Core sliding window function
# ---------------------------------------------------------------------------

def check_rate_limit(
    key:            str,
    max_requests:   int,
    window_seconds: int,
) -> dict:
    """
    Sliding window rate limit check using Redis sorted sets.

    Args:
        key:            Unique identifier for this limit bucket
                        (e.g. "ratelimit:login:192.168.1.1")
        max_requests:   Maximum allowed requests in the window
        window_seconds: Width of the sliding window in seconds

    Returns:
        {
            "allowed":    bool,   # True if request is within limit
            "count":      int,    # Current request count in window
            "remaining":  int,    # Requests remaining before limit
            "reset_in":   int,    # Seconds until oldest entry expires
        }

    Raises:
        HTTPException(429) if limit exceeded
    """
    now = time.time()
    window_start = now - window_seconds

    pipe = _redis.pipeline()
    pipe.zremrangebyscore(key, 0, window_start)          # Remove old entries
    pipe.zadd(key, {str(now): now})                       # Add current request
    pipe.zcard(key)                                       # Count in window
    pipe.expire(key, window_seconds + 1)                  # Auto-cleanup
    results = pipe.execute()

    current_count = results[2]
    remaining     = max(0, max_requests - current_count)
    allowed       = current_count <= max_requests

    if not allowed:
        # Find when the oldest entry in the window will expire
        oldest = _redis.zrange(key, 0, 0, withscores=True)
        reset_in = int(window_seconds - (now - oldest[0][1])) if oldest else window_seconds

        logger.warning(
            f"Rate limit exceeded: key={key} "
            f"count={current_count}/{max_requests} "
            f"reset_in={reset_in}s"
        )
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many requests. Try again in {reset_in} seconds.",
            headers={
                "X-RateLimit-Limit":     str(max_requests),
                "X-RateLimit-Remaining": "0",
                "X-RateLimit-Reset":     str(int(now) + reset_in),
                "Retry-After":           str(reset_in),
            },
        )

    return {
        "allowed":   True,
        "count":     current_count,
        "remaining": remaining,
        "reset_in":  window_seconds,
    }


# ---------------------------------------------------------------------------
# IP Extraction
# ---------------------------------------------------------------------------

def get_client_ip(request: Request) -> str:
    """
    Extract the real client IP, accounting for reverse proxies.

    In production behind Nginx / load balancer:
        X-Forwarded-For: <client>, <proxy1>, <proxy2>
    We take the first (leftmost) IP — the real client.

    Direct connection:
        request.client.host
    """
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        # Take first IP in the chain (real client, not proxy)
        return forwarded.split(",")[0].strip()
    if request.client:
        return request.client.host
    return "unknown"


# ---------------------------------------------------------------------------
# FastAPI dependency factories
# Each returns a dependency function for use with Depends()
# ---------------------------------------------------------------------------

def rate_limit(
    max_requests: int,
    window_seconds: int,
    key_prefix: str = "ratelimit",
    by_user: bool = False,
) -> Callable:
    """
    Factory that creates a FastAPI dependency for rate limiting.

    Args:
        max_requests:   Max requests in the window
        window_seconds: Window size in seconds
        key_prefix:     Prefix for Redis key (helps with monitoring/debugging)
        by_user:        If True, limit per user ID instead of per IP

    Usage:
        @router.post("/login")
        async def login(
            request: Request,
            _: None = Depends(rate_limit(max_requests=5, window_seconds=300, key_prefix="login"))
        ):
    """
    async def _check(request: Request):
        if by_user:
            # Limit per user (after auth is resolved)
            # Use Authorization header hash as identifier
            auth = request.headers.get("Authorization", "")
            identifier = hashlib.sha256(auth.encode()).hexdigest()[:16]
        else:
            identifier = get_client_ip(request)

        route  = request.url.path.replace("/", "_")
        key    = f"{key_prefix}:{route}:{identifier}"
        check_rate_limit(key, max_requests, window_seconds)

    return _check


# ---------------------------------------------------------------------------
# Pre-configured rate limiters for common endpoints
# Import and use as: Depends(login_rate_limit)
# ---------------------------------------------------------------------------

# Brute force protection for login — 5 attempts per 5 minutes per IP
login_rate_limit = rate_limit(
    max_requests=5,
    window_seconds=300,
    key_prefix="login",
)

# OTP spam protection — 3 requests per 10 minutes per IP
otp_rate_limit = rate_limit(
    max_requests=3,
    window_seconds=600,
    key_prefix="otp",
)

# Registration rate limit — 10 per hour per IP
register_rate_limit = rate_limit(
    max_requests=10,
    window_seconds=3600,
    key_prefix="register",
)

# General API — 200 requests per minute per IP (anti-scraping)
api_rate_limit = rate_limit(
    max_requests=200,
    window_seconds=60,
    key_prefix="api",
)

# Strict limit for sensitive operations (password change, etc.)
sensitive_rate_limit = rate_limit(
    max_requests=10,
    window_seconds=600,
    key_prefix="sensitive",
)
