# 🔐 Phase 12 — Security Hardening

A complete security upgrade across authentication, API protection, input validation, and webhook security.

---

## 📁 New Files in Phase 12

```
app/
├── middleware/
│   ├── rate_limiter.py         ← Sliding window rate limiting via Redis sorted sets
│   └── security_headers.py    ← HTTP security headers (CSP, HSTS, X-Frame, etc.)
├── utils/
│   ├── input_validation.py    ← XSS, SQL injection, null byte, path traversal defense
│   └── webhook_security.py    ← Hardened Stripe webhook verification with replay protection
├── core/
│   ├── token_rotation.py      ← Refresh token rotation with reuse detection
│   └── rbac.py                ← Permission-based access control (21 permissions)
└── routers/
    └── security.py            ← Security management endpoints (Admin)

SECURITY_INTEGRATION.py        ← Step-by-step integration guide
tests/
└── test_security.py           ← 35+ security tests
```

---

## 🛡️ Security Controls Added

### 1. Sliding Window Rate Limiting

Uses Redis sorted sets for the most accurate rate limiting algorithm:

```
Fixed window problem:        Sliding window fix:
  :00 → :30 window            Always last N seconds from NOW
  Request at :29: count=1     No burst bypass possible
  Request at :31: count=1 ←  
  Combined = 2, limit = 5     
  → Burst allowed! ❌          → Burst blocked ✅
```

| Endpoint | Limit | Window |
|---|---|---|
| POST /auth/login | 5 requests | 5 minutes |
| POST /auth/forgot-password | 3 requests | 10 minutes |
| POST /auth/register | 10 requests | 60 minutes |
| Sensitive actions | 10 requests | 10 minutes |
| General API | 200 requests | 60 seconds |

---

### 2. Refresh Token Rotation + Reuse Detection

Every use of a refresh token issues a brand-new pair:

```
Login               → Family created, RT-1 issued
RT-1 used           → RT-2 issued, RT-1 invalidated
RT-2 used           → RT-3 issued, RT-2 invalidated

Attacker uses RT-2  → ALARM: RT-2 was already used!
                    → Entire token family REVOKED
                    → Both attacker AND legitimate user logged out
                    → User must re-login (attacker loses access too)
```

**Token families** track all tokens that descend from one login event. Any reuse of a retired token triggers full family revocation — the nuclear option that guarantees the attacker loses access.

---

### 3. Input Validation & Sanitization

6-layer sanitization pipeline on every string input:

```
Input
  → Remove null bytes (\x00)        ← String truncation attacks
  → Remove control characters        ← Hidden content injection
  → Unicode normalization (NFKC)     ← Homograph attacks (а vs a)
  → Strip whitespace
  → Length enforcement               ← DoS via huge inputs
  → Pattern checks:
      XSS: <script>, javascript:, onerror=
      Path traversal: ../../
      SQL: SELECT/UNION/DROP + injection operators
  → HTML-escape output               ← Stored XSS prevention
Output: safe string
```

Password policy: 8+ chars, uppercase, lowercase, digit, max 128 chars (bcrypt DoS prevention).

---

### 4. HTTP Security Headers

Every response gets these headers automatically:

| Header | Value | Protects Against |
|---|---|---|
| X-Content-Type-Options | nosniff | MIME sniffing attacks |
| X-Frame-Options | DENY | Clickjacking |
| X-XSS-Protection | 1; mode=block | Legacy XSS filter |
| Referrer-Policy | strict-origin-when-cross-origin | URL leakage |
| Permissions-Policy | camera=(), microphone=()... | Feature abuse |
| Strict-Transport-Security | max-age=31536000 | SSL stripping (prod only) |
| Content-Security-Policy | default-src 'none' | XSS, data injection |
| Cache-Control | no-store (auth routes) | Token caching |

---

### 5. Hardened Webhook Verification

Manual Stripe webhook verification with extra security:

```python
# What we verify:
1. HMAC-SHA256 signature (cryptographic — prevents forgery)
2. Timestamp ≤ 5 minutes old (prevents replay attacks)
3. Timing-safe comparison (prevents timing attacks)
4. Raw bytes (verify BEFORE parsing — prevents parser attacks)
5. Structured error logging (security team can monitor)
```

The timestamp check is critical: without it, an attacker who captures a valid "payment succeeded" webhook could replay it hours later to activate memberships without paying.

---

### 6. Permission-Based RBAC (21 Permissions)

Replaces raw role checks with granular permissions:

```python
# Before (Phase 1-11):
if user.role != 'admin':
    raise 403

# After (Phase 12):
if not has_permission(user, Permission.VIEW_ANALYTICS):
    raise 403
```

Full permission matrix: 6 admin-only, 8 trainer+admin, 7 member+all.

---

## 🔧 Security Management API

| Endpoint | Who | What it does |
|---|---|---|
| POST `/api/security/revoke-user-sessions/{id}` | Admin | Force logout all devices for a user |
| POST `/api/security/revoke-my-sessions` | Any | Log out of all my devices |
| GET `/api/security/active-sessions/{id}` | Admin | List active sessions for a user |
| POST `/api/security/unlock-account` | Admin | Clear rate limit for locked-out user |
| GET `/api/security/health` | Admin | Security posture dashboard |

---

## 🧪 Running Tests

```bash
pytest tests/test_security.py -v

# Run specific test class:
pytest tests/test_security.py::TestInputValidation -v
pytest tests/test_security.py::TestWebhookSecurity -v
pytest tests/test_security.py::TestTokenRotation -v
```

---

## 📋 Security Checklist

Before going to production, verify:

- [ ] `SECRET_KEY` is a random 64-character string (not the default)
- [ ] `DEBUG=False` in production `.env`
- [ ] Stripe live keys (`sk_live_...`) configured
- [ ] Firebase production credentials configured
- [ ] PostgreSQL password is strong and unique
- [ ] Redis is not exposed to the internet (bind to localhost)
- [ ] HTTPS is enabled (HSTS requires this)
- [ ] Security headers test: https://securityheaders.com
- [ ] Rate limits tuned to production traffic patterns
- [ ] Webhook endpoint URL registered in Stripe dashboard
- [ ] `STRIPE_WEBHOOK_SECRET` is from production webhook, not test

---

## ➡️ Next: Phase 13 — Deployment

Dockerize the complete system, configure PostgreSQL + Redis for production, set up CI/CD, and provide deployment guides for AWS and GCP.
