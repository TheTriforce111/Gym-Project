"""
SECURITY_INTEGRATION.py — How to wire Phase 12 security into your app

This file shows exactly what to add to main.py and each router
to enable all Phase 12 security features.

Copy the relevant sections into your existing code.
"""

# ============================================================
# 1. UPDATE main.py
# ============================================================

MAIN_PY_ADDITIONS = '''
# ── Add these imports ──────────────────────────────────────────────────────
from app.middleware.security_headers import SecurityHeadersMiddleware
from app.middleware.rate_limiter import api_rate_limit
from app.routers import security as security_router

# ── Add middleware (BEFORE existing middleware) ────────────────────────────
app.add_middleware(SecurityHeadersMiddleware)

# ── Register the security router ──────────────────────────────────────────
app.include_router(
    security_router.router,
    prefix="/api/security",
    tags=["Security"],
)
'''

# ============================================================
# 2. UPDATE auth router — use token rotation + rate limiting
# ============================================================

AUTH_ROUTER_CHANGES = '''
# ── Replace the login endpoint ─────────────────────────────────────────────
from app.middleware.rate_limiter import login_rate_limit, otp_rate_limit, register_rate_limit
from app.core.token_rotation import create_token_family, rotate_refresh_token, revoke_family

@router.post("/login")
def login(
    body: LoginRequest,
    request: Request,
    db: Session = Depends(get_db),
    _: None = Depends(login_rate_limit),   # ← Add this
):
    # ... existing validation ...

    # Replace:  create_access_token() + create_refresh_token()
    # With:     create_token_family() — includes reuse detection
    return create_token_family(user_id=user.id, user_role=user.role.value)


# ── Replace the refresh endpoint ──────────────────────────────────────────
@router.post("/refresh")
def refresh_token(body: RefreshTokenRequest):
    # Replace the existing refresh logic with:
    return rotate_refresh_token(body.refresh_token)
    # This handles: signature check, expiry check, family lookup,
    # reuse detection, token rotation all in one call.


# ── Update logout to revoke the token family ──────────────────────────────
@router.post("/logout")
def logout(request: Request, current_user: User = Depends(get_current_user)):
    # Extract family_id from the refresh token
    from app.core.security import decode_token
    refresh_token_str = request.headers.get("X-Refresh-Token", "")
    if refresh_token_str:
        payload = decode_token(refresh_token_str)
        if payload and payload.get("family_id"):
            revoke_family(payload["family_id"], reason="logout")

    return {"message": "Logged out successfully."}


# ── Add rate limiting to OTP endpoint ─────────────────────────────────────
@router.post("/forgot-password")
def forgot_password(
    body: PasswordResetRequest,
    db: Session = Depends(get_db),
    _: None = Depends(otp_rate_limit),   # ← Add this
):
    ...


# ── Add rate limiting to registration ─────────────────────────────────────
@router.post("/register")
def register(
    body: UserCreate,
    db: Session = Depends(get_db),
    _: None = Depends(register_rate_limit),  # ← Add this
):
    ...
'''

# ============================================================
# 3. UPDATE users router — apply input validation
# ============================================================

USERS_ROUTER_CHANGES = '''
# ── Update UserCreate schema to use secure validators ─────────────────────
from app.utils.input_validation import validate_name, validate_email, validate_password, validate_phone
from pydantic import field_validator

class UserCreate(BaseModel):
    full_name: str
    email: EmailStr
    password: str
    phone: Optional[str] = None

    @field_validator("full_name")
    @classmethod
    def secure_name(cls, v):
        return validate_name(v, "Full name")

    @field_validator("email")
    @classmethod
    def secure_email(cls, v):
        return validate_email(v)

    @field_validator("password")
    @classmethod
    def secure_password(cls, v):
        return validate_password(v)

    @field_validator("phone")
    @classmethod
    def secure_phone(cls, v):
        return validate_phone(v)
'''

# ============================================================
# 4. UPDATE payments webhook — use manual verification
# ============================================================

PAYMENTS_WEBHOOK_CHANGES = '''
# ── Replace stripe.Webhook.construct_event with manual verification ───────
from app.utils.webhook_security import verify_stripe_webhook

@router.post("/webhook")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload   = await request.body()
    signature = request.headers.get("Stripe-Signature", "")

    # Use our hardened verification instead of Stripe's SDK method
    # Adds timestamp validation, structured error logging, IP logging
    event = verify_stripe_webhook(
        payload=payload,
        sig_header=signature,
        webhook_secret=settings.STRIPE_WEBHOOK_SECRET,
    )
    # event is now the verified, parsed dict
    service = PaymentService(db)
    result  = service.handle_verified_webhook_event(event)
    return {"received": True, "result": result}
'''

# ============================================================
# 5. UPDATE analytics router — use RBAC permissions
# ============================================================

ANALYTICS_RBAC_CHANGES = '''
# ── Replace require_admin with granular permission check ──────────────────
from app.core.rbac import require_permission, Permission

# Before:
@router.get("/dashboard")
def get_dashboard(admin: User = Depends(require_admin)):
    ...

# After:
@router.get("/dashboard")
def get_dashboard(
    user: User = Depends(require_permission(Permission.VIEW_ANALYTICS))
):
    ...
# This is equivalent for now, but allows future role flexibility
# (e.g. a "reports" role that can view analytics but not manage members)
'''

# ============================================================
# 6. ADD rate limiting to all sensitive endpoints
# ============================================================

RATE_LIMIT_ADDITIONS = '''
# Apply to these endpoints:

# Login (already shown above)
_: None = Depends(login_rate_limit)   # 5 per 5min per IP

# OTP request
_: None = Depends(otp_rate_limit)     # 3 per 10min per IP

# Registration
_: None = Depends(register_rate_limit)  # 10 per hour per IP

# Password change
_: None = Depends(sensitive_rate_limit)  # 10 per 10min per IP

# Payment intent creation
_: None = Depends(sensitive_rate_limit)  # Prevent card testing attacks

# General API endpoints (optional global protection)
_: None = Depends(api_rate_limit)     # 200 per minute per IP
'''

print("Phase 12 Security Integration Guide")
print("=" * 60)
print("Files to update:")
print("  1. app/main.py          — Add SecurityHeadersMiddleware")
print("  2. app/routers/auth.py  — Token rotation + rate limiting")
print("  3. app/schemas/user.py  — Input validation")
print("  4. app/routers/payments.py — Hardened webhook verification")
print("  5. app/routers/analytics.py — RBAC permissions")
print()
print("New files added:")
print("  app/middleware/rate_limiter.py    — Sliding window rate limiting")
print("  app/middleware/security_headers.py — HTTP security headers")
print("  app/utils/input_validation.py     — XSS/SQLi/null byte sanitization")
print("  app/utils/webhook_security.py     — Hardened webhook verification")
print("  app/core/token_rotation.py        — Refresh token rotation + reuse detection")
print("  app/core/rbac.py                  — Permission-based access control")
print("  app/routers/security.py           — Security management endpoints")
