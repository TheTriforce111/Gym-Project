# 💳 Phase 4 — Stripe Payment Integration

Connects real payments to memberships using Stripe's API.
A member pays → Stripe processes the card → our webhook activates their membership.

---

## 📁 New Files in Phase 4

```
app/
├── models/
│   └── payment.py               ← Full payment model with Stripe fields, idempotency key
├── schemas/
│   └── payment.py               ← Request/response schemas + revenue stats
├── routers/
│   └── payments.py              ← All 7 payment endpoints incl. webhook
└── services/
    └── payment_service.py       ← Full Stripe integration (intent, webhook, refund, stats)

tests/
└── test_payments.py             ← Full test suite with mocked Stripe calls

STRIPE_FRONTEND_GUIDE.js         ← How to use Stripe in React and Flutter
```

---

## 📋 Endpoints

| Method | Endpoint                         | Auth    | Description                             |
|--------|----------------------------------|---------|-----------------------------------------|
| POST   | `/api/payments/create-intent`    | Member  | Start checkout → get client_secret      |
| POST   | `/api/payments/webhook`          | Stripe  | Receive payment results from Stripe     |
| GET    | `/api/payments/me`               | Member  | My payment history                      |
| GET    | `/api/payments/all`              | Admin   | All payments (filterable)               |
| GET    | `/api/payments/revenue-stats`    | Admin   | Revenue totals and counts               |
| GET    | `/api/payments/{id}`             | Admin   | Full payment details                    |
| POST   | `/api/payments/{id}/refund`      | Admin   | Full or partial refund                  |

---

## 🔄 Complete Payment Flow

```
Member                  Our API                  Stripe               Database
  │                        │                        │                     │
  │  POST /create-intent   │                        │                     │
  │───────────────────────>│                        │                     │
  │                        │─ PaymentIntent.create ─>│                    │
  │                        │<─ {id, client_secret} ──│                    │
  │                        │─ Save pending payment ──────────────────────>│
  │<── {client_secret} ────│                        │                     │
  │                        │                        │                     │
  │  (enters card details in Stripe form)           │                     │
  │────────────────────────────────────────────────>│                     │
  │<─────────────────── payment confirmed ──────────│                     │
  │                        │                        │                     │
  │                        │<── webhook: succeeded ──│                    │
  │                        │─ Verify signature       │                     │
  │                        │─ Update payment SUCCESS ────────────────────>│
  │                        │─ Activate membership ───────────────────────>│
  │                        │── return HTTP 200 ──────│                    │
```

---

## 🔐 Webhook Security

The webhook endpoint verifies Stripe's cryptographic signature on every request.

```python
# This line does the verification:
event = stripe.Webhook.construct_event(
    payload=raw_body,
    sig_header=stripe_signature_header,
    secret=STRIPE_WEBHOOK_SECRET,
)
# If the signature is wrong → raises SignatureVerificationError → HTTP 400
```

Without this, anyone could POST fake "payment succeeded" events and get free memberships.

---

## 🔁 Idempotency — No Duplicate Charges

We generate an idempotency key before calling Stripe:

```python
idempotency_key = sha256(f"{user_id}:{plan}:{hour_bucket}")
```

- If a user clicks "Pay" twice quickly → same key → Stripe returns the same PaymentIntent
- If there's a network error and the client retries → same key → no duplicate charge
- The `hour_bucket` resets every hour → allows retry after an hour

---

## 🛠️ Local Development Setup

### 1. Get Stripe test keys
1. Go to https://dashboard.stripe.com
2. Make sure you're in **Test mode** (toggle at top-left)
3. Go to **Developers → API keys**
4. Copy `Secret key` (sk_test_...) → `STRIPE_SECRET_KEY` in `.env`
5. Copy `Publishable key` (pk_test_...) → use in React/Flutter frontend

### 2. Set up webhook forwarding (Stripe CLI)
```bash
# Install: https://stripe.com/docs/stripe-cli
stripe login
stripe listen --forward-to localhost:8000/api/payments/webhook
# Copy the webhook signing secret it prints → STRIPE_WEBHOOK_SECRET in .env
```

### 3. Test a payment
```bash
# Trigger a test success event:
stripe trigger payment_intent.succeeded

# Or test with the API:
curl -X POST http://localhost:8000/api/payments/create-intent \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"membership_plan": "monthly"}'
# Returns client_secret → use in Stripe.js or test via Stripe dashboard
```

### Test Cards
| Card Number          | Result                  |
|----------------------|-------------------------|
| 4242 4242 4242 4242  | Always succeeds ✅       |
| 4000 0000 0000 0002  | Always declined ❌       |
| 4000 0000 0000 9995  | Insufficient funds ❌    |
| 4000 0025 0000 3155  | Requires 3D Secure      |

Use any future expiry (e.g. `12/34`) and any 3-digit CVC (e.g. `123`).

---

## 🧪 Running Tests

```bash
# Tests mock Stripe — no real API key needed
pytest tests/test_payments.py -v
```

---

## ➡️ Next: Phase 5 — Workout Management System

Adds the exercise library, workout plan creation, assignment to members, and progress logging.
