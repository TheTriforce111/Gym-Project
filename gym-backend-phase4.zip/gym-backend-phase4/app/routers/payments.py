"""
routers/payments.py — Payment API Endpoints (Phase 4)

Endpoints:
    POST /api/payments/create-intent        → Create Stripe PaymentIntent
    POST /api/payments/webhook              → Stripe webhook receiver
    GET  /api/payments/me                   → My payment history
    GET  /api/payments/all                  → All payments (Admin)
    GET  /api/payments/revenue-stats        → Revenue summary (Admin)
    GET  /api/payments/{id}                 → Get payment by ID (Admin)
    POST /api/payments/{id}/refund          → Refund a payment (Admin)

IMPORTANT — Webhook Setup:
    The /webhook endpoint MUST receive the raw request body (bytes),
    not the parsed JSON body. This is required for Stripe's signature
    verification to work. We use Request.body() for this.

    In production:
    1. Go to https://dashboard.stripe.com/webhooks
    2. Add endpoint: https://yourdomain.com/api/payments/webhook
    3. Select events: payment_intent.succeeded, payment_intent.payment_failed, charge.refunded
    4. Copy the "Signing secret" (whsec_...) to your .env as STRIPE_WEBHOOK_SECRET

    For local development, use Stripe CLI:
        stripe listen --forward-to localhost:8000/api/payments/webhook
"""

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.models.payment import Payment, PaymentStatus
from app.models.user import User
from app.schemas.payment import (
    CreatePaymentIntentRequest,
    PaymentIntentResponse,
    PaymentResponse,
    PaymentSummary,
    RefundRequest,
    RevenueStatsResponse,
)
from app.services.payment_service import PaymentService

router = APIRouter()


# ---------------------------------------------------------------------------
# CREATE PAYMENT INTENT
# ---------------------------------------------------------------------------
@router.post(
    "/create-intent",
    response_model=PaymentIntentResponse,
    summary="Create a Stripe PaymentIntent to begin checkout",
)
def create_payment_intent(
    body: CreatePaymentIntentRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Initiates the payment flow for a membership purchase.

    Returns a `client_secret` which the frontend passes to Stripe.js to
    render the card input form and process the payment securely.

    Frontend flow (React / Flutter):
    ```
    1. Call this endpoint → get client_secret
    2. Pass client_secret to Stripe SDK (stripe.confirmPayment)
    3. Stripe handles card input and 3D Secure authentication
    4. Stripe calls our /webhook with the result
    5. Membership is activated automatically on success
    ```

    Use Stripe test cards during development:
    - Success:  4242 4242 4242 4242
    - Decline:  4000 0000 0000 0002
    - 3D Secure: 4000 0025 0000 3155
    """
    service = PaymentService(db)
    result  = service.create_payment_intent(
        user=current_user,
        membership_plan=body.membership_plan,
        currency=body.currency,
    )
    return result


# ---------------------------------------------------------------------------
# STRIPE WEBHOOK
# ---------------------------------------------------------------------------
@router.post(
    "/webhook",
    summary="Stripe webhook receiver (called by Stripe, not by users)",
    include_in_schema=False,
    # include_in_schema=False hides this from Swagger docs
    # — it's not meant to be called manually
)
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Receives and processes webhook events from Stripe.

    IMPORTANT:
    - This endpoint is called by Stripe's servers, not by your frontend.
    - We read the raw body (bytes) because Stripe's signature is computed
      over the raw payload. Parsing it as JSON first would break verification.
    - Configure this URL in your Stripe dashboard under Developers → Webhooks.

    Do NOT add authentication to this endpoint — Stripe doesn't send tokens.
    Security is handled by verifying the Stripe-Signature header.
    """
    # Read raw bytes — MUST NOT use body: dict = Body(...) here
    payload   = await request.body()
    signature = request.headers.get("Stripe-Signature", "")

    if not signature:
        raise HTTPException(
            status_code=400,
            detail="Missing Stripe-Signature header."
        )

    service = PaymentService(db)
    result  = service.handle_webhook(payload=payload, stripe_signature=signature)

    # Stripe expects HTTP 200 to confirm receipt.
    # If we return non-200, Stripe will retry the webhook.
    return {"received": True, "result": result}


# ---------------------------------------------------------------------------
# MY PAYMENT HISTORY
# ---------------------------------------------------------------------------
@router.get(
    "/me",
    response_model=List[PaymentSummary],
    summary="Get current user's payment history",
)
def get_my_payments(
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the current user's payment history, most recent first.
    Members can see their own payments but not other users'.
    """
    payments = (
        db.query(Payment)
        .filter(Payment.user_id == current_user.id)
        .order_by(Payment.created_at.desc())
        .limit(limit)
        .all()
    )
    return payments


# ---------------------------------------------------------------------------
# ALL PAYMENTS — Admin only
# ---------------------------------------------------------------------------
@router.get(
    "/all",
    response_model=List[PaymentSummary],
    summary="List all payments, with optional filters (Admin)",
)
def list_all_payments(
    status_filter: Optional[PaymentStatus] = Query(
        None, description="Filter by status (pending, success, failed, refunded)"
    ),
    user_id: Optional[int] = Query(None, description="Filter by specific user ID"),
    skip:  int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    List all payment transactions with optional filtering.

    Examples:
        /api/payments/all                        → all payments
        /api/payments/all?status_filter=failed   → only failed payments
        /api/payments/all?user_id=42             → payments for user #42
    """
    query = db.query(Payment)
    if status_filter:
        query = query.filter(Payment.status == status_filter)
    if user_id:
        query = query.filter(Payment.user_id == user_id)

    return (
        query
        .order_by(Payment.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


# ---------------------------------------------------------------------------
# REVENUE STATS — Admin only
# ---------------------------------------------------------------------------
@router.get(
    "/revenue-stats",
    response_model=RevenueStatsResponse,
    summary="Get revenue statistics (Admin)",
)
def get_revenue_stats(
    currency: str = Query("usd", description="Currency to filter by"),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns financial summary for the admin dashboard:
    - Total revenue from successful payments
    - Total amount refunded
    - Net revenue (revenue minus refunds)
    - Count of successful, failed, and pending payments
    """
    service = PaymentService(db)
    return service.get_revenue_stats(currency=currency)


# ---------------------------------------------------------------------------
# GET PAYMENT BY ID — Admin only
# ---------------------------------------------------------------------------
@router.get(
    "/{payment_id}",
    response_model=PaymentResponse,
    summary="Get full payment details by ID (Admin)",
)
def get_payment(
    payment_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns full details for a specific payment including Stripe IDs,
    failure reason (if any), and refund information.
    Useful for debugging and customer support.
    """
    payment = db.query(Payment).filter(Payment.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found.")
    return payment


# ---------------------------------------------------------------------------
# REFUND — Admin only
# ---------------------------------------------------------------------------
@router.post(
    "/{payment_id}/refund",
    response_model=PaymentResponse,
    summary="Refund a payment (Admin)",
)
def refund_payment(
    payment_id: int,
    body: RefundRequest,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Issue a full or partial refund for a successful payment.

    - If `amount` is not provided → full refund
    - If `amount` is provided → partial refund for that amount
    - The refund is processed immediately via Stripe's API
    - Stripe will also fire a `charge.refunded` webhook to confirm

    Note: Refunds may take 5-10 business days to appear on the customer's statement.
    """
    service = PaymentService(db)
    return service.refund_payment(
        payment_id=payment_id,
        reason=body.reason,
        amount=body.amount,
    )
