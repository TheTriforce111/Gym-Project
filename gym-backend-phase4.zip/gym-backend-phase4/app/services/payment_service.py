"""
services/payment_service.py — Stripe Payment Integration (Phase 4)

This service handles the full payment lifecycle:

1. CREATE INTENT   → User wants to pay → we create a Stripe PaymentIntent
                      → return client_secret to the frontend
                      → frontend shows Stripe card form

2. CONFIRM PAYMENT → User enters card details on frontend
                      → Stripe processes the payment
                      → Stripe calls our webhook with the result

3. WEBHOOK HANDLER → We verify the webhook signature (security!)
                      → Update payment status in our database
                      → Activate/renew the membership on success
                      → Record failure reason on failure

4. REFUND          → Admin issues a refund via our API
                      → We call Stripe's refund API
                      → Update payment record

KEY SECURITY CONCEPT — Webhook Signature Verification:
  Anyone on the internet could call our webhook endpoint and fake a
  "payment succeeded" event. Stripe signs every webhook with a secret key.
  We verify this signature before trusting the event. If the signature
  doesn't match, we reject the request with HTTP 400.
"""

import hashlib
import logging
import time
from datetime import datetime, timedelta
from typing import Optional

import stripe
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.membership import (
    Membership, MembershipHistory,
    MembershipChangeReason, MembershipPlan,
    MembershipStatus,
)
from app.models.payment import Payment, PaymentStatus, PaymentType
from app.models.user import User
from app.schemas.membership import PLAN_DURATIONS_DAYS, PLAN_PRICES

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configure Stripe with our secret key
# This must be the SECRET key (sk_...), never the publishable key (pk_...)
# ---------------------------------------------------------------------------
stripe.api_key = settings.STRIPE_SECRET_KEY

# Map from plan name to Stripe amount (Stripe uses cents, not dollars)
# $49.99 → 4999 cents
STRIPE_AMOUNTS = {
    "monthly":   int(PLAN_PRICES["monthly"]   * 100),
    "quarterly": int(PLAN_PRICES["quarterly"] * 100),
    "yearly":    int(PLAN_PRICES["yearly"]    * 100),
}

PLAN_DESCRIPTIONS = {
    "monthly":   "Monthly Gym Membership (30 days)",
    "quarterly": "Quarterly Gym Membership (90 days)",
    "yearly":    "Annual Gym Membership (365 days)",
}


class PaymentService:
    """
    Handles all payment operations with Stripe.
    Instantiate with a DB session: service = PaymentService(db)
    """

    def __init__(self, db: Session):
        self.db = db

    # -----------------------------------------------------------------------
    # STEP 1: CREATE PAYMENT INTENT
    # -----------------------------------------------------------------------
    def create_payment_intent(
        self,
        user: User,
        membership_plan: str,
        currency: str = "usd",
    ) -> dict:
        """
        Create a Stripe PaymentIntent and a pending payment record.

        What is a PaymentIntent?
        - It represents an ATTEMPT to collect payment.
        - It has a 'client_secret' the frontend needs to show the card form.
        - It is NOT a charge yet — the user still needs to enter card details.

        Idempotency:
        - We generate a unique key before calling Stripe.
        - If the same key is sent twice (e.g. network error + retry),
          Stripe returns the SAME PaymentIntent instead of creating a duplicate.
        - This prevents double-charging the user.

        Returns the client_secret and our internal payment_id.
        """
        amount_cents = STRIPE_AMOUNTS.get(membership_plan)
        if not amount_cents:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown membership plan: '{membership_plan}'."
            )

        # Generate idempotency key: unique per user + plan + time window (1 hour)
        # If the user tries to pay again within 1 hour for the same plan,
        # they get the same PaymentIntent (no duplicate charge)
        hour_bucket = int(time.time() // 3600)
        idempotency_key = hashlib.sha256(
            f"{user.id}:{membership_plan}:{hour_bucket}".encode()
        ).hexdigest()

        # Check if we already have a pending payment with this key
        existing_payment = self.db.query(Payment).filter(
            Payment.idempotency_key == idempotency_key,
            Payment.status == PaymentStatus.PENDING,
        ).first()

        if existing_payment and existing_payment.stripe_payment_intent_id:
            # Retrieve the existing PaymentIntent from Stripe
            try:
                intent = stripe.PaymentIntent.retrieve(
                    existing_payment.stripe_payment_intent_id
                )
                logger.info(f"Returning existing PaymentIntent for user #{user.id}")
                return {
                    "payment_id":         existing_payment.id,
                    "client_secret":      intent.client_secret,
                    "amount":             amount_cents / 100,
                    "currency":           currency,
                    "payment_intent_id":  intent.id,
                }
            except stripe.error.StripeError:
                pass  # Fall through to create a new one

        # Create the PaymentIntent in Stripe
        try:
            intent = stripe.PaymentIntent.create(
                amount=amount_cents,          # Amount in cents
                currency=currency,
                description=PLAN_DESCRIPTIONS.get(membership_plan, "Gym Membership"),
                metadata={
                    # Metadata is stored in Stripe — visible in their dashboard
                    # and sent back in webhook events
                    "user_id":    str(user.id),
                    "user_email": user.email,
                    "plan":       membership_plan,
                },
                # automatic_payment_methods lets Stripe decide the best
                # payment method for the user's region
                automatic_payment_methods={"enabled": True},
                idempotency_key=idempotency_key,
            )
        except stripe.error.StripeError as e:
            logger.error(f"Stripe PaymentIntent creation failed: {e}")
            raise HTTPException(
                status_code=502,
                detail=f"Payment service error. Please try again. ({str(e)})"
            )

        # Store a pending payment record in our database
        payment = Payment(
            user_id=user.id,
            payment_type=PaymentType.NEW_MEMBERSHIP,
            stripe_payment_intent_id=intent.id,
            amount=amount_cents / 100,
            currency=currency,
            status=PaymentStatus.PENDING,
            description=PLAN_DESCRIPTIONS.get(membership_plan),
            idempotency_key=idempotency_key,
            is_test=settings.STRIPE_SECRET_KEY.startswith("sk_test_"),
        )
        self.db.add(payment)
        self.db.commit()
        self.db.refresh(payment)

        logger.info(
            f"PaymentIntent created: {intent.id} "
            f"for user #{user.id}, plan={membership_plan}"
        )

        return {
            "payment_id":        payment.id,
            "client_secret":     intent.client_secret,
            "amount":            amount_cents / 100,
            "currency":          currency,
            "payment_intent_id": intent.id,
        }

    # -----------------------------------------------------------------------
    # STEP 2: HANDLE STRIPE WEBHOOK
    # -----------------------------------------------------------------------
    def handle_webhook(self, payload: bytes, stripe_signature: str) -> dict:
        """
        Process incoming Stripe webhook events.

        CRITICAL SECURITY STEP:
        We verify the webhook signature BEFORE doing anything.
        Without this check, anyone could call this endpoint and fake a
        'payment_succeeded' event to get a free membership.

        Stripe signs each webhook with our STRIPE_WEBHOOK_SECRET.
        We use stripe.Webhook.construct_event() to verify the signature.
        If it doesn't match, we raise an exception.

        Events we handle:
        - payment_intent.succeeded    → Activate/renew membership
        - payment_intent.payment_failed → Mark payment as failed
        - charge.refunded             → Update refund amount
        """
        # ---------------------------------------------------------------
        # 1. Verify the webhook signature
        # ---------------------------------------------------------------
        try:
            event = stripe.Webhook.construct_event(
                payload=payload,
                sig_header=stripe_signature,
                secret=settings.STRIPE_WEBHOOK_SECRET,
            )
        except ValueError:
            # Invalid payload (malformed JSON)
            logger.warning("Webhook: Invalid payload received")
            raise HTTPException(status_code=400, detail="Invalid webhook payload.")
        except stripe.error.SignatureVerificationError:
            # Signature mismatch — reject the request
            logger.warning("Webhook: Signature verification FAILED — possible forgery attempt")
            raise HTTPException(status_code=400, detail="Invalid webhook signature.")

        logger.info(f"Webhook received: {event['type']} | id={event['id']}")

        # ---------------------------------------------------------------
        # 2. Route to the correct handler based on event type
        # ---------------------------------------------------------------
        event_type = event["type"]
        event_data = event["data"]["object"]

        if event_type == "payment_intent.succeeded":
            return self._on_payment_succeeded(event_data)

        elif event_type == "payment_intent.payment_failed":
            return self._on_payment_failed(event_data)

        elif event_type == "charge.refunded":
            return self._on_charge_refunded(event_data)

        else:
            # We received an event type we don't handle — that's fine, just ignore it
            logger.info(f"Webhook: Unhandled event type '{event_type}' — ignoring")
            return {"status": "ignored", "event_type": event_type}

    # -----------------------------------------------------------------------
    # WEBHOOK SUB-HANDLERS
    # -----------------------------------------------------------------------

    def _on_payment_succeeded(self, intent_data: dict) -> dict:
        """
        Called when Stripe confirms a payment was successful.

        Steps:
        1. Find our payment record by Stripe's PaymentIntent ID
        2. Mark payment as SUCCESS
        3. Extract the membership plan from Stripe's metadata
        4. Create or renew the user's membership
        5. Link the payment to the membership
        """
        intent_id = intent_data["id"]

        # Find our payment record
        payment = self.db.query(Payment).filter(
            Payment.stripe_payment_intent_id == intent_id
        ).first()

        if not payment:
            # This can happen if the webhook fires before our DB write completes
            # (rare race condition). Log and return — Stripe will retry.
            logger.warning(f"Webhook: No payment record found for PI {intent_id}")
            return {"status": "payment_not_found"}

        # Skip if already processed (Stripe can send the same webhook multiple times)
        if payment.status == PaymentStatus.SUCCESS:
            logger.info(f"Webhook: Payment {payment.id} already processed — skipping")
            return {"status": "already_processed"}

        # Extract charge ID from the intent
        charge_id = None
        if intent_data.get("latest_charge"):
            charge_id = intent_data["latest_charge"]

        # Update payment record
        payment.status       = PaymentStatus.SUCCESS
        payment.completed_at = datetime.utcnow()
        if charge_id:
            payment.stripe_charge_id = charge_id

        # Get user and plan from metadata
        user_id = int(intent_data["metadata"].get("user_id", payment.user_id))
        plan    = intent_data["metadata"].get("plan", "monthly")

        # Create or renew the membership
        membership = self._activate_membership(user_id=user_id, plan=plan, payment=payment)
        payment.membership_id = membership.id

        self.db.commit()

        logger.info(
            f"Payment SUCCESS: payment_id={payment.id} "
            f"user_id={user_id} plan={plan} "
            f"membership_id={membership.id}"
        )
        return {"status": "membership_activated", "membership_id": membership.id}

    def _on_payment_failed(self, intent_data: dict) -> dict:
        """
        Called when Stripe reports a payment failure (card declined, etc.)

        We store the failure reason so the admin can see why it failed.
        The user will need to retry with a different payment method.
        """
        intent_id = intent_data["id"]

        payment = self.db.query(Payment).filter(
            Payment.stripe_payment_intent_id == intent_id
        ).first()

        if not payment:
            logger.warning(f"Webhook: No payment record for failed PI {intent_id}")
            return {"status": "payment_not_found"}

        if payment.status in [PaymentStatus.SUCCESS, PaymentStatus.FAILED]:
            return {"status": "already_processed"}

        # Extract the failure reason from Stripe
        last_error = intent_data.get("last_payment_error", {})
        failure_reason = (
            last_error.get("message")
            or last_error.get("code")
            or "Payment failed. Please try again."
        )

        payment.status         = PaymentStatus.FAILED
        payment.failure_reason = failure_reason
        payment.completed_at   = datetime.utcnow()

        self.db.commit()

        logger.info(
            f"Payment FAILED: payment_id={payment.id} "
            f"reason='{failure_reason}'"
        )
        return {"status": "payment_failed", "reason": failure_reason}

    def _on_charge_refunded(self, charge_data: dict) -> dict:
        """
        Called when a charge is refunded (either via our API or Stripe dashboard).
        Updates our payment record with the refunded amount.
        """
        charge_id = charge_data["id"]

        payment = self.db.query(Payment).filter(
            Payment.stripe_charge_id == charge_id
        ).first()

        if not payment:
            logger.warning(f"Webhook: No payment found for charge {charge_id}")
            return {"status": "payment_not_found"}

        # amount_refunded is in cents — convert to dollars
        amount_refunded = charge_data.get("amount_refunded", 0) / 100
        payment.amount_refunded = amount_refunded

        if payment.is_fully_refunded:
            payment.status = PaymentStatus.REFUNDED

        self.db.commit()

        logger.info(
            f"Charge refunded: payment_id={payment.id} "
            f"amount_refunded={amount_refunded}"
        )
        return {"status": "refund_recorded", "amount_refunded": amount_refunded}

    # -----------------------------------------------------------------------
    # MEMBERSHIP ACTIVATION (called after successful payment)
    # -----------------------------------------------------------------------
    def _activate_membership(
        self,
        user_id: int,
        plan: str,
        payment: Payment,
    ) -> Membership:
        """
        Create a new membership or renew an existing one after payment.

        Logic:
        - If user has no membership or it's expired/cancelled → create new
        - If user has an active membership → extend end_date (renewal)
        """
        plan_enum = MembershipPlan(plan)
        duration  = timedelta(days=PLAN_DURATIONS_DAYS.get(plan_enum, 30))

        existing = self.db.query(Membership).filter(
            Membership.user_id == user_id
        ).first()

        if existing and existing.status == MembershipStatus.ACTIVE:
            # RENEWAL: extend current end_date
            old_end = existing.end_date

            if existing.end_date > datetime.utcnow():
                new_end = existing.end_date + duration
            else:
                new_end = datetime.utcnow() + duration

            # Record history
            history = MembershipHistory(
                membership_id=existing.id,
                previous_status=existing.status,
                new_status=MembershipStatus.ACTIVE,
                reason=MembershipChangeReason.RENEWED,
                previous_end_date=old_end,
                new_end_date=new_end,
                note=f"Renewed via payment #{payment.id}. "
                     f"Extended from {old_end.date()} to {new_end.date()}.",
            )
            self.db.add(history)

            existing.plan       = plan_enum
            existing.end_date   = new_end
            existing.price_paid = payment.amount

            return existing

        elif existing:
            # REACTIVATE: was expired or cancelled — reuse the record
            start = datetime.utcnow()
            new_end = start + duration

            history = MembershipHistory(
                membership_id=existing.id,
                previous_status=existing.status,
                new_status=MembershipStatus.ACTIVE,
                reason=MembershipChangeReason.RENEWED,
                new_end_date=new_end,
                note=f"Reactivated via payment #{payment.id}.",
            )
            self.db.add(history)

            existing.plan       = plan_enum
            existing.status     = MembershipStatus.ACTIVE
            existing.start_date = start
            existing.end_date   = new_end
            existing.price_paid = payment.amount

            return existing

        else:
            # NEW MEMBERSHIP: first time this user is paying
            start  = datetime.utcnow()
            new_end = start + duration

            membership = Membership(
                user_id=user_id,
                plan=plan_enum,
                status=MembershipStatus.ACTIVE,
                start_date=start,
                end_date=new_end,
                price_paid=payment.amount,
                currency=payment.currency,
            )
            self.db.add(membership)
            self.db.flush()

            history = MembershipHistory(
                membership_id=membership.id,
                previous_status=None,
                new_status=MembershipStatus.ACTIVE,
                reason=MembershipChangeReason.CREATED,
                new_end_date=new_end,
                note=f"Created via payment #{payment.id}.",
            )
            self.db.add(history)

            return membership

    # -----------------------------------------------------------------------
    # REFUND
    # -----------------------------------------------------------------------
    def refund_payment(
        self,
        payment_id: int,
        reason: Optional[str] = None,
        amount: Optional[float] = None,
    ) -> Payment:
        """
        Issue a full or partial refund for a payment.

        Steps:
        1. Find the payment
        2. Validate it can be refunded
        3. Call Stripe's refund API
        4. Update our payment record

        The webhook (charge.refunded) will also fire and update the record,
        but we update it here too for immediate consistency.
        """
        payment = self.db.query(Payment).filter(Payment.id == payment_id).first()
        if not payment:
            raise HTTPException(status_code=404, detail="Payment not found.")

        if payment.status != PaymentStatus.SUCCESS:
            raise HTTPException(
                status_code=400,
                detail=f"Only successful payments can be refunded. "
                       f"Current status: {payment.status.value}"
            )

        if payment.is_fully_refunded:
            raise HTTPException(
                status_code=400,
                detail="This payment has already been fully refunded."
            )

        if not payment.stripe_charge_id:
            raise HTTPException(
                status_code=400,
                detail="No Stripe charge ID found. Cannot process refund."
            )

        # Calculate refund amount (partial or full)
        max_refundable = payment.amount - payment.amount_refunded
        refund_amount  = amount or max_refundable
        if refund_amount > max_refundable:
            raise HTTPException(
                status_code=400,
                detail=f"Refund amount ${refund_amount:.2f} exceeds "
                       f"refundable amount ${max_refundable:.2f}."
            )

        # Call Stripe to process the refund
        try:
            stripe_refund = stripe.Refund.create(
                charge=payment.stripe_charge_id,
                amount=int(refund_amount * 100),  # Convert back to cents
                reason="requested_by_customer",
                metadata={
                    "payment_id": str(payment_id),
                    "refund_reason": reason or "Admin-initiated refund",
                },
            )
        except stripe.error.StripeError as e:
            logger.error(f"Stripe refund failed for payment #{payment_id}: {e}")
            raise HTTPException(
                status_code=502,
                detail=f"Stripe refund failed: {str(e)}"
            )

        # Update payment record immediately
        payment.amount_refunded += refund_amount
        payment.stripe_refund_id = stripe_refund.id
        if payment.is_fully_refunded:
            payment.status = PaymentStatus.REFUNDED

        self.db.commit()
        self.db.refresh(payment)

        logger.info(
            f"Refund processed: payment_id={payment_id} "
            f"amount=${refund_amount:.2f} "
            f"stripe_refund_id={stripe_refund.id}"
        )
        return payment

    # -----------------------------------------------------------------------
    # REVENUE STATS
    # -----------------------------------------------------------------------
    def get_revenue_stats(self, currency: str = "usd") -> dict:
        """
        Calculate revenue statistics for the admin dashboard.
        Returns totals for successful, refunded, failed, and pending payments.
        """
        from sqlalchemy import func

        payments = self.db.query(Payment).filter(
            Payment.currency == currency
        ).all()

        successful = [p for p in payments if p.status == PaymentStatus.SUCCESS]
        failed     = [p for p in payments if p.status == PaymentStatus.FAILED]
        pending    = [p for p in payments if p.status == PaymentStatus.PENDING]

        total_revenue  = sum(p.amount for p in successful)
        total_refunded = sum(p.amount_refunded for p in successful)

        return {
            "total_revenue":  round(total_revenue, 2),
            "total_refunded": round(total_refunded, 2),
            "net_revenue":    round(total_revenue - total_refunded, 2),
            "payment_count":  len(successful),
            "failed_count":   len(failed),
            "pending_count":  len(pending),
            "currency":       currency,
        }
