"""
models/payment.py — Payment Database Model (Phase 4)

This table records every payment transaction in the system.
It acts as the financial ledger — every charge, refund, and failure is stored here.

Why keep a payments table separate from memberships?
- One membership can have multiple payments (renewals over time)
- Failed payments need to be tracked for debugging
- Refunds create new records linked to the original payment
- Full financial history is required for accounting/reporting

Fields prefixed with 'stripe_' come directly from Stripe's API.
"""

import enum
from datetime import datetime

from sqlalchemy import (
    Column, DateTime, Enum, Float,
    ForeignKey, Integer, String, Text, Boolean
)
from sqlalchemy.orm import relationship

from app.core.database import Base


class PaymentStatus(str, enum.Enum):
    """
    Lifecycle of a payment transaction.

    Flow:
      PENDING → SUCCESS  (payment confirmed by Stripe webhook)
      PENDING → FAILED   (card declined, insufficient funds, etc.)
      SUCCESS → REFUNDED (admin issued a refund)
    """
    PENDING   = "pending"    # Payment intent created, awaiting confirmation
    SUCCESS   = "success"    # Payment confirmed — membership can be activated
    FAILED    = "failed"     # Payment was declined or errored
    REFUNDED  = "refunded"   # Full or partial refund was issued
    CANCELLED = "cancelled"  # Payment intent was cancelled before completion


class PaymentType(str, enum.Enum):
    """What the payment is for."""
    NEW_MEMBERSHIP  = "new_membership"   # First-time membership purchase
    RENEWAL         = "renewal"          # Renewing an existing membership
    UPGRADE         = "upgrade"          # Upgrading plan (monthly → yearly)
    REFUND          = "refund"           # Refund transaction (negative amount)


class Payment(Base):
    """
    Records a single payment transaction.
    Maps to the 'payments' table in PostgreSQL.
    """
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)

    # --- Who paid ---
    user_id       = Column(Integer, ForeignKey("users.id"),       nullable=False)

    # --- What they paid for ---
    membership_id = Column(Integer, ForeignKey("memberships.id"), nullable=True)
    # nullable=True because payment record is created BEFORE membership is activated

    payment_type  = Column(Enum(PaymentType), nullable=False, default=PaymentType.NEW_MEMBERSHIP)

    # -----------------------------------------------------------------------
    # Stripe-specific fields
    # These come directly from Stripe's API responses
    # -----------------------------------------------------------------------

    stripe_payment_intent_id = Column(String(255), unique=True, nullable=True, index=True)
    # Stripe's unique ID for the payment intent (e.g. "pi_3OxxxxxxxYYY")
    # This is what we use to identify a payment in Stripe's dashboard.
    # unique=True enforces idempotency — no two DB records for the same Stripe charge

    stripe_charge_id = Column(String(255), nullable=True)
    # The actual charge ID created when payment succeeds (e.g. "ch_3OxxxxxxxYYY")

    stripe_customer_id = Column(String(255), nullable=True)
    # If we store the user as a Stripe Customer (for saved cards), this is their ID

    stripe_refund_id = Column(String(255), nullable=True)
    # If this payment was refunded, this holds the Stripe refund ID

    # -----------------------------------------------------------------------
    # Financial details
    # -----------------------------------------------------------------------

    amount          = Column(Float,       nullable=False)
    # Amount charged in the base currency unit (e.g. 49.99 for $49.99)

    currency        = Column(String(10),  nullable=False, default="usd")
    # ISO 4217 currency code: "usd", "sar", "eur", etc.

    amount_refunded = Column(Float,       nullable=False, default=0.0)
    # Amount that has been refunded (can be partial)

    # -----------------------------------------------------------------------
    # Status & Metadata
    # -----------------------------------------------------------------------

    status      = Column(Enum(PaymentStatus), nullable=False, default=PaymentStatus.PENDING)
    description = Column(String(500),         nullable=True)
    # e.g. "Monthly membership — January 2025"

    failure_reason = Column(Text, nullable=True)
    # Stripe's error message when a payment fails
    # e.g. "Your card has insufficient funds."

    is_test = Column(Boolean, default=False)
    # True if this was a Stripe test-mode payment (during development)

    # -----------------------------------------------------------------------
    # Idempotency
    # -----------------------------------------------------------------------

    idempotency_key = Column(String(255), unique=True, nullable=True)
    # We generate this before calling Stripe to prevent duplicate charges.
    # If the same key is sent twice, Stripe returns the existing result.
    # Format: "pay_{user_id}_{membership_plan}_{timestamp}"

    # -----------------------------------------------------------------------
    # Timestamps
    # -----------------------------------------------------------------------

    created_at    = Column(DateTime, default=datetime.utcnow)
    updated_at    = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at  = Column(DateTime, nullable=True)
    # Set when status changes to SUCCESS or FAILED

    # -----------------------------------------------------------------------
    # Relationships
    # -----------------------------------------------------------------------

    user       = relationship("User",       foreign_keys=[user_id])
    membership = relationship("Membership", back_populates="payments")

    # -----------------------------------------------------------------------
    # Computed Properties
    # -----------------------------------------------------------------------

    @property
    def net_amount(self) -> float:
        """Amount after any refunds. Used for revenue reporting."""
        return round(self.amount - self.amount_refunded, 2)

    @property
    def is_fully_refunded(self) -> bool:
        """True if the entire payment has been refunded."""
        return self.amount_refunded >= self.amount

    def __repr__(self):
        return (
            f"<Payment id={self.id} "
            f"user_id={self.user_id} "
            f"amount={self.amount}{self.currency} "
            f"status={self.status}>"
        )
