"""
schemas/payment.py — Payment Request & Response Schemas (Phase 4)

These schemas define:
- What data is sent when initiating a payment
- What data the API returns about a payment
- What data Stripe sends in webhook events

Key concepts for the team:
- PaymentIntent: A Stripe object representing an ATTEMPT to collect payment.
  It has a 'client_secret' that the frontend uses to show the card form.
- Webhook: Stripe calls our /webhook endpoint to confirm payment results.
  We must verify the webhook signature to avoid fake notifications.
"""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, field_validator
from app.models.payment import PaymentStatus, PaymentType


# ---------------------------------------------------------------------------
# Request Schemas
# ---------------------------------------------------------------------------

class CreatePaymentIntentRequest(BaseModel):
    """
    Body for POST /api/payments/create-intent

    The client sends this when a user wants to pay for a membership.
    We create a Stripe PaymentIntent and return the client_secret
    which the frontend uses to render Stripe's card input form.
    """
    membership_plan: str
    # e.g. "monthly", "quarterly", "yearly"

    currency: str = "usd"
    # ISO currency code — must match your Stripe account's currency settings

    @field_validator("membership_plan")
    @classmethod
    def valid_plan(cls, v):
        allowed = ["monthly", "quarterly", "yearly"]
        if v not in allowed:
            raise ValueError(f"membership_plan must be one of: {allowed}")
        return v

    @field_validator("currency")
    @classmethod
    def valid_currency(cls, v):
        # Only allow common currencies — expand this list as needed
        allowed = ["usd", "eur", "sar", "gbp", "aed"]
        if v.lower() not in allowed:
            raise ValueError(f"currency must be one of: {allowed}")
        return v.lower()


class RefundRequest(BaseModel):
    """
    Body for POST /api/payments/{payment_id}/refund
    Admin provides a reason and optionally a partial refund amount.
    """
    reason: Optional[str] = None
    # e.g. "Member cancelled within 24 hours", "Duplicate charge"

    amount: Optional[float] = None
    # If None → full refund. If provided → partial refund.

    @field_validator("amount")
    @classmethod
    def amount_positive(cls, v):
        if v is not None and v <= 0:
            raise ValueError("Refund amount must be greater than 0.")
        return v


# ---------------------------------------------------------------------------
# Response Schemas
# ---------------------------------------------------------------------------

class PaymentIntentResponse(BaseModel):
    """
    Returned after creating a Stripe PaymentIntent.
    The frontend needs client_secret to render the Stripe payment form.
    """
    payment_id: int
    # Our internal payment record ID

    client_secret: str
    # Stripe's client secret — used by Stripe.js on the frontend
    # IMPORTANT: This is safe to send to the client — it only allows
    # completing THIS specific payment, not others.

    amount: float
    currency: str
    payment_intent_id: str
    # Stripe's PI ID (e.g. "pi_3OxxxxxxxYYY") — useful for debugging


class PaymentResponse(BaseModel):
    """Full payment record returned by the API."""
    id:                      int
    user_id:                 int
    membership_id:           Optional[int]
    payment_type:            PaymentType
    amount:                  float
    currency:                str
    amount_refunded:         float
    net_amount:              float           # Computed property
    status:                  PaymentStatus
    description:             Optional[str]
    failure_reason:          Optional[str]
    stripe_payment_intent_id: Optional[str]
    stripe_charge_id:        Optional[str]
    is_test:                 bool
    created_at:              datetime
    completed_at:            Optional[datetime]

    class Config:
        from_attributes = True


class PaymentSummary(BaseModel):
    """Lightweight payment info for lists."""
    id:         int
    amount:     float
    currency:   str
    status:     PaymentStatus
    payment_type: PaymentType
    created_at: datetime

    class Config:
        from_attributes = True


class RevenueStatsResponse(BaseModel):
    """Revenue summary for admin dashboard."""
    total_revenue:    float   # All successful payments
    total_refunded:   float   # All refunded amounts
    net_revenue:      float   # total_revenue - total_refunded
    payment_count:    int     # Number of successful payments
    failed_count:     int     # Number of failed payments
    pending_count:    int     # Payments awaiting confirmation
    currency:         str
