/**
 * STRIPE_FRONTEND_GUIDE.js
 * ========================
 * How to integrate Stripe payments in the React Admin Panel
 * and Flutter Mobile App.
 *
 * This file is documentation — not actual runnable code.
 * Copy the relevant sections into your frontend project.
 */

// ============================================================
// REACT (Web) — Using Stripe.js + React Stripe.js
// ============================================================

/**
 * Step 1: Install Stripe packages
 *   npm install @stripe/stripe-js @stripe/react-stripe-js
 *
 * Step 2: Wrap your app with StripeProvider (in App.jsx or index.jsx)
 */

// App.jsx
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";

// Use your PUBLISHABLE key (pk_...) — safe to expose in frontend
// NEVER use the secret key (sk_...) on the frontend
const stripePromise = loadStripe("pk_test_your_publishable_key_here");

function App() {
  return (
    <Elements stripe={stripePromise}>
      {/* Your app routes here */}
    </Elements>
  );
}


/**
 * Step 3: Payment form component
 * This component handles the complete payment flow.
 */

// components/PaymentForm.jsx
import { useState } from "react";
import { useStripe, useElements, PaymentElement } from "@stripe/react-stripe-js";

function PaymentForm({ membershipPlan, onSuccess }) {
  const stripe   = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setLoading(true);
    setError(null);

    // Step 1: Ask our backend to create a PaymentIntent
    const intentRes = await fetch("/api/payments/create-intent", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${localStorage.getItem("access_token")}`,
      },
      body: JSON.stringify({ membership_plan: membershipPlan }),
    });

    if (!intentRes.ok) {
      setError("Failed to initialize payment. Please try again.");
      setLoading(false);
      return;
    }

    const { client_secret } = await intentRes.json();

    // Step 2: Confirm the payment using Stripe.js
    // Stripe handles card validation, 3D Secure, etc.
    const result = await stripe.confirmPayment({
      elements,
      clientSecret: client_secret,
      confirmParams: {
        // Redirect here after payment (for 3D Secure redirect flows)
        return_url: `${window.location.origin}/payment-success`,
      },
      redirect: "if_required",
      // redirect: "if_required" — only redirect if the payment method needs it
      // (e.g. 3D Secure). Otherwise, stay on the page.
    });

    if (result.error) {
      // Card was declined, insufficient funds, etc.
      setError(result.error.message);
    } else if (result.paymentIntent?.status === "succeeded") {
      // Payment was confirmed — Stripe will call our webhook to activate membership
      // The webhook may take a few seconds — show a success message
      onSuccess();
    }

    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* PaymentElement renders Stripe's hosted card form */}
      {/* It handles card number, expiry, CVC, and billing details */}
      <PaymentElement />

      {error && <p style={{ color: "red" }}>{error}</p>}

      <button type="submit" disabled={!stripe || loading}>
        {loading ? "Processing..." : `Pay for ${membershipPlan} membership`}
      </button>
    </form>
  );
}


// ============================================================
// FLUTTER — Using flutter_stripe package
// ============================================================

/*
 * Step 1: Add to pubspec.yaml
 *   flutter_stripe: ^10.0.0
 *   http: ^1.1.0
 *
 * Step 2: Configure in main.dart
 */

// main.dart
/*
import 'package:flutter_stripe/flutter_stripe.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Set your PUBLISHABLE key
  Stripe.publishableKey = 'pk_test_your_publishable_key_here';
  await Stripe.instance.applySettings();

  runApp(MyApp());
}
*/

// payment_screen.dart
/*
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PaymentScreen extends StatefulWidget {
  final String membershipPlan;
  const PaymentScreen({required this.membershipPlan});

  @override
  _PaymentScreenState createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {

  Future<void> _startPayment() async {
    try {
      // Step 1: Get PaymentIntent from our backend
      final response = await http.post(
        Uri.parse('https://yourapi.com/api/payments/create-intent'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode({'membership_plan': widget.membershipPlan}),
      );

      final data = jsonDecode(response.body);
      final clientSecret = data['client_secret'];

      // Step 2: Initialize payment sheet
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'Gym Management System',
        ),
      );

      // Step 3: Present the payment sheet (Stripe handles the UI)
      await Stripe.instance.presentPaymentSheet();

      // Step 4: Success! Webhook will activate membership
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Payment successful! Your membership is now active.')),
      );

    } on StripeException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Payment failed: ${e.error.message}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Purchase Membership')),
      body: Center(
        child: ElevatedButton(
          onPressed: _startPayment,
          child: Text('Pay Now'),
        ),
      ),
    );
  }
}
*/


// ============================================================
// TEST CARDS (Development Only)
// Use these in Stripe test mode — no real money is charged
// ============================================================

const TEST_CARDS = {
  success:         "4242 4242 4242 4242",  // Always succeeds
  declined:        "4000 0000 0000 0002",  // Always declined
  insufficient:    "4000 0000 0000 9995",  // Insufficient funds
  requires3DS:     "4000 0025 0000 3155",  // Requires 3D Secure auth
  expiredCard:     "4000 0000 0000 0069",  // Expired card
  // Use any future expiry date (e.g. 12/34) and any 3-digit CVC (e.g. 123)
};


// ============================================================
// LOCAL DEVELOPMENT — Stripe CLI for webhook testing
// ============================================================

/*
  Without the Stripe CLI, your /webhook endpoint won't receive events
  because Stripe can't reach localhost. The CLI forwards events to your server.

  Install Stripe CLI:
    https://stripe.com/docs/stripe-cli

  Run this command while developing:
    stripe listen --forward-to localhost:8000/api/payments/webhook

  The CLI will print a webhook signing secret (whsec_...).
  Add it to your .env as:
    STRIPE_WEBHOOK_SECRET=whsec_...

  Trigger a test event manually:
    stripe trigger payment_intent.succeeded
*/
