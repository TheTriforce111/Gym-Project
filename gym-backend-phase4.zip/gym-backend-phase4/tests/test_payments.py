"""
tests/test_payments.py — Payment System Tests (Phase 4)

Run with:
    pytest tests/test_payments.py -v

We use unittest.mock to patch Stripe API calls so tests run without
a real Stripe account or internet connection.

This is best practice for payment testing:
- Unit tests mock Stripe (fast, no external calls)
- Integration tests use Stripe's test mode (slower, needs STRIPE_SECRET_KEY)

Tests cover:
- Creating payment intents
- Webhook processing (success, failure, refund)
- Idempotency (no duplicate payments)
- Refund logic
- Revenue statistics
- Security: fake webhook signatures are rejected
"""

import hashlib
import json
import time
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.core.security import hash_password
from app.models.membership import Membership, MembershipPlan, MembershipStatus
from app.models.payment import Payment, PaymentStatus
from app.models.user import User, UserRole

# ---------------------------------------------------------------------------
# Test database (SQLite in-memory)
# ---------------------------------------------------------------------------
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_payments.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
Base.metadata.create_all(bind=engine)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield


@pytest.fixture
def db():
    session = TestingSessionLocal()
    yield session
    session.close()


@pytest.fixture
def member_user(db):
    """Create a member and return their auth token."""
    user = User(
        full_name="Pay Member",
        email="paymember@gym.com",
        hashed_password=hash_password("Member123"),
        role=UserRole.MEMBER,
        is_active=True,
    )
    db.add(user)
    db.commit()
    resp = client.post("/api/auth/login", json={
        "email": "paymember@gym.com",
        "password": "Member123"
    })
    return {"user": user, "token": resp.json()["access_token"]}


@pytest.fixture
def admin_user(db):
    """Create an admin and return their auth token."""
    user = User(
        full_name="Admin",
        email="admin@gym.com",
        hashed_password=hash_password("Admin123"),
        role=UserRole.ADMIN,
        is_active=True,
    )
    db.add(user)
    db.commit()
    resp = client.post("/api/auth/login", json={
        "email": "admin@gym.com",
        "password": "Admin123"
    })
    return {"user": user, "token": resp.json()["access_token"]}


# ---------------------------------------------------------------------------
# Helper: Build a fake Stripe PaymentIntent object
# ---------------------------------------------------------------------------
def fake_payment_intent(
    intent_id="pi_test_123",
    amount=4999,
    currency="usd",
    user_id=1,
    plan="monthly",
):
    """Returns a mock that looks like a Stripe PaymentIntent object."""
    mock = MagicMock()
    mock.id             = intent_id
    mock.client_secret  = f"{intent_id}_secret_test"
    mock.amount         = amount
    mock.currency       = currency
    mock.metadata       = {"user_id": str(user_id), "plan": plan}
    mock.latest_charge  = "ch_test_123"
    mock.last_payment_error = None
    return mock


# ---------------------------------------------------------------------------
# Create Payment Intent Tests
# ---------------------------------------------------------------------------

class TestCreatePaymentIntent:

    @patch("stripe.PaymentIntent.create")
    def test_create_intent_monthly(self, mock_create, member_user):
        """Creating a monthly payment intent returns client_secret."""
        mock_create.return_value = fake_payment_intent(
            user_id=member_user["user"].id
        )

        resp = client.post(
            "/api/payments/create-intent",
            headers={"Authorization": f"Bearer {member_user['token']}"},
            json={"membership_plan": "monthly", "currency": "usd"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "client_secret" in data
        assert "payment_id" in data
        assert data["amount"] == 49.99
        assert data["currency"] == "usd"

    @patch("stripe.PaymentIntent.retrieve")
    @patch("stripe.PaymentIntent.create")
    def test_idempotency_returns_same_intent(
        self, mock_create, mock_retrieve, member_user
    ):
        """
        Calling create-intent twice within the same hour returns the same intent.
        This prevents duplicate charges.
        """
        mock_pi = fake_payment_intent(user_id=member_user["user"].id)
        mock_create.return_value  = mock_pi
        mock_retrieve.return_value = mock_pi

        # First call
        resp1 = client.post(
            "/api/payments/create-intent",
            headers={"Authorization": f"Bearer {member_user['token']}"},
            json={"membership_plan": "monthly"},
        )
        # Second call (same hour — should reuse)
        resp2 = client.post(
            "/api/payments/create-intent",
            headers={"Authorization": f"Bearer {member_user['token']}"},
            json={"membership_plan": "monthly"},
        )

        # Both should succeed
        assert resp1.status_code == 200
        assert resp2.status_code == 200
        # Stripe create should only be called once (second call reuses)
        assert mock_create.call_count == 1

    def test_invalid_plan_rejected(self, member_user):
        """Unknown plan names are rejected with 422."""
        resp = client.post(
            "/api/payments/create-intent",
            headers={"Authorization": f"Bearer {member_user['token']}"},
            json={"membership_plan": "invalid_plan"},
        )
        assert resp.status_code == 422


# ---------------------------------------------------------------------------
# Webhook Tests
# ---------------------------------------------------------------------------

class TestWebhook:

    def _build_webhook_payload(self, event_type: str, data: dict) -> tuple[bytes, str]:
        """
        Build a fake but properly signed webhook payload.
        In tests, we mock stripe.Webhook.construct_event instead of
        actually signing with the secret.
        """
        payload = json.dumps({
            "id": "evt_test_123",
            "type": event_type,
            "data": {"object": data},
        }).encode()
        # We'll mock the verification — signature doesn't matter here
        return payload, "t=123,v1=fakesig"

    @patch("stripe.Webhook.construct_event")
    def test_webhook_payment_succeeded_activates_membership(
        self, mock_construct, member_user, db
    ):
        """
        Receiving a payment_intent.succeeded webhook activates the membership.
        """
        user = member_user["user"]

        # Create a pending payment in DB first
        payment = Payment(
            user_id=user.id,
            stripe_payment_intent_id="pi_test_webhook_success",
            amount=49.99,
            currency="usd",
            status=PaymentStatus.PENDING,
            idempotency_key="test_key_webhook",
        )
        db.add(payment)
        db.commit()

        # Mock Stripe's event verification to return a success event
        mock_construct.return_value = {
            "type": "payment_intent.succeeded",
            "id":   "evt_test_success",
            "data": {
                "object": {
                    "id":            "pi_test_webhook_success",
                    "latest_charge": "ch_test_456",
                    "metadata": {
                        "user_id": str(user.id),
                        "plan":    "monthly",
                    },
                }
            }
        }

        payload, sig = self._build_webhook_payload(
            "payment_intent.succeeded",
            {"id": "pi_test_webhook_success"}
        )
        resp = client.post(
            "/api/payments/webhook",
            content=payload,
            headers={"Stripe-Signature": sig, "Content-Type": "application/json"},
        )
        assert resp.status_code == 200

        # Verify payment was marked as success
        db.refresh(payment)
        assert payment.status == PaymentStatus.SUCCESS

        # Verify membership was created
        membership = db.query(Membership).filter(
            Membership.user_id == user.id
        ).first()
        assert membership is not None
        assert membership.status == MembershipStatus.ACTIVE

    @patch("stripe.Webhook.construct_event")
    def test_webhook_payment_failed(self, mock_construct, member_user, db):
        """Failed payment webhook marks payment as FAILED with reason."""
        user = member_user["user"]
        payment = Payment(
            user_id=user.id,
            stripe_payment_intent_id="pi_test_failed",
            amount=49.99,
            currency="usd",
            status=PaymentStatus.PENDING,
            idempotency_key="test_key_fail",
        )
        db.add(payment)
        db.commit()

        mock_construct.return_value = {
            "type": "payment_intent.payment_failed",
            "id":   "evt_test_fail",
            "data": {
                "object": {
                    "id": "pi_test_failed",
                    "last_payment_error": {
                        "message": "Your card has insufficient funds."
                    }
                }
            }
        }

        payload, sig = self._build_webhook_payload("payment_intent.payment_failed", {})
        resp = client.post(
            "/api/payments/webhook",
            content=payload,
            headers={"Stripe-Signature": sig},
        )
        assert resp.status_code == 200

        db.refresh(payment)
        assert payment.status == PaymentStatus.FAILED
        assert "insufficient funds" in payment.failure_reason.lower()

    def test_webhook_rejects_invalid_signature(self):
        """Webhook with invalid signature is rejected with 400."""
        # Don't mock construct_event — let it actually fail
        resp = client.post(
            "/api/payments/webhook",
            content=b'{"type": "fake_event"}',
            headers={"Stripe-Signature": "invalid_signature"},
        )
        assert resp.status_code == 400

    def test_webhook_rejects_missing_signature(self):
        """Webhook without Stripe-Signature header is rejected."""
        resp = client.post(
            "/api/payments/webhook",
            content=b'{"type": "fake_event"}',
        )
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Refund Tests
# ---------------------------------------------------------------------------

class TestRefunds:

    @patch("stripe.Refund.create")
    def test_admin_can_refund(self, mock_refund_create, admin_user, member_user, db):
        """Admin can issue a full refund for a successful payment."""
        # Create a successful payment
        user = member_user["user"]
        payment = Payment(
            user_id=user.id,
            stripe_payment_intent_id="pi_test_refund",
            stripe_charge_id="ch_test_refund",
            amount=49.99,
            currency="usd",
            status=PaymentStatus.SUCCESS,
            idempotency_key="test_key_refund",
        )
        db.add(payment)
        db.commit()

        mock_refund_create.return_value = MagicMock(id="re_test_123")

        resp = client.post(
            f"/api/payments/{payment.id}/refund",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
            json={"reason": "Customer requested cancellation"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["amount_refunded"] == 49.99
        assert data["status"] == "refunded"

    def test_cannot_refund_failed_payment(self, admin_user, member_user, db):
        """Cannot refund a payment that never succeeded."""
        user = member_user["user"]
        payment = Payment(
            user_id=user.id,
            stripe_payment_intent_id="pi_test_cannot_refund",
            amount=49.99,
            currency="usd",
            status=PaymentStatus.FAILED,
            idempotency_key="test_key_no_refund",
        )
        db.add(payment)
        db.commit()

        resp = client.post(
            f"/api/payments/{payment.id}/refund",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
            json={},
        )
        assert resp.status_code == 400

    def test_member_cannot_refund(self, member_user, db):
        """Regular members cannot issue refunds — admin only."""
        user = member_user["user"]
        payment = Payment(
            user_id=user.id,
            stripe_payment_intent_id="pi_test_member_refund",
            amount=49.99,
            currency="usd",
            status=PaymentStatus.SUCCESS,
            idempotency_key="test_key_member_refund",
        )
        db.add(payment)
        db.commit()

        resp = client.post(
            f"/api/payments/{payment.id}/refund",
            headers={"Authorization": f"Bearer {member_user['token']}"},
            json={},
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# Revenue Stats Tests
# ---------------------------------------------------------------------------

class TestRevenueStats:

    def test_revenue_stats(self, admin_user, member_user, db):
        """Revenue stats correctly sum successful payments."""
        user = member_user["user"]
        # Add two successful payments
        for i, amount in enumerate([49.99, 129.99]):
            db.add(Payment(
                user_id=user.id,
                amount=amount,
                currency="usd",
                status=PaymentStatus.SUCCESS,
                idempotency_key=f"test_rev_{i}",
            ))
        # Add one failed payment (should not count toward revenue)
        db.add(Payment(
            user_id=user.id,
            amount=49.99,
            currency="usd",
            status=PaymentStatus.FAILED,
            idempotency_key="test_rev_failed",
        ))
        db.commit()

        resp = client.get(
            "/api/payments/revenue-stats",
            headers={"Authorization": f"Bearer {admin_user['token']}"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["payment_count"] == 2
        assert data["total_revenue"] == pytest.approx(179.98, rel=1e-2)
        assert data["failed_count"] == 1
        assert data["net_revenue"] == pytest.approx(179.98, rel=1e-2)
