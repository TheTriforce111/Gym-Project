# 📱 Phase 11 — Flutter Mobile App (GymOS)

Member-facing mobile app for the GymOS gym management system.

---

## 📁 Project Structure

```
gym-flutter-app/
├── lib/
│   ├── main.dart                      ← Entry point, Firebase + FCM setup
│   ├── router.dart                    ← GoRouter with auth guards + bottom nav shell
│   ├── theme/
│   │   └── app_theme.dart             ← Colors, typography, component styles
│   ├── models/
│   │   └── models.dart                ← Data classes matching backend schemas
│   ├── services/
│   │   └── api_service.dart           ← Dio HTTP client with JWT auto-refresh
│   ├── widgets/
│   │   └── widgets.dart               ← GymCard, KPICard, Badge, Button, etc.
│   └── screens/
│       ├── auth/
│       │   └── login_screen.dart      ← Login + Register screens
│       ├── home/
│       │   └── home_screen.dart       ← Dashboard (greeting, membership, stats, upcoming)
│       ├── attendance/
│       │   └── qr_screen.dart         ← QR check-in code + history
│       ├── workout/
│       │   └── workout_screen.dart    ← My Plans | Log Session | Progress tabs
│       ├── classes/
│       │   └── classes_screen.dart    ← Browse + book classes with waitlist
│       └── notifications/
│           └── notifications_screen.dart ← Notification inbox + Profile screen
├── pubspec.yaml                       ← All dependencies
└── README.md
```

---

## 🚀 Quick Start

### Prerequisites
- Flutter 3.16+ (`flutter --version`)
- Android Studio or Xcode (for emulator/simulator)
- FastAPI backend running on your machine

### Steps

```bash
# 1. Navigate to project
cd gym-flutter-app

# 2. Install dependencies
flutter pub get

# 3. Run on Android emulator
flutter run

# 4. Run on iOS simulator
flutter run -d ios
```

### Backend Connection

The app connects to `http://10.0.2.2:8000/api` by default.
- `10.0.2.2` = Android emulator's localhost alias
- For a real device, change to your machine's local IP in `api_service.dart`:

```dart
const _baseUrl = 'http://192.168.1.YOUR_IP:8000/api';
```

---

## 📱 Screens

| Screen | Route | What it shows |
|--------|-------|---------------|
| Login | `/login` | Email + password form |
| Register | `/register` | New account creation |
| Home | `/` | Greeting, membership card, stats, quick actions, upcoming classes |
| Workout | `/workout` | My Plans → Log Session → Progress tabs |
| Classes | `/classes` | Browse + book classes, filter by category |
| My QR | `/attendance` | QR code for gym check-in + visit history |
| Notifications | `/notifications` | Inbox with push + email notification history |
| Profile | `/profile` | Account info, membership details, sign out |

---

## 🔐 Authentication Flow

```
App launch
  → Check for stored JWT token (flutter_secure_storage)
  → Token found → /home
  → No token   → /login

Login
  → POST /api/auth/login
  → Store access + refresh tokens securely
  → Navigate to /home

Auto-refresh
  → API call returns 401
  → POST /api/auth/refresh with refresh token
  → Store new tokens
  → Replay original request (transparent to UI)

Logout
  → POST /api/auth/logout (blacklists tokens)
  → Clear stored tokens
  → Navigate to /login
```

---

## 🔔 Push Notifications (Firebase)

### Setup Steps

1. Create a Firebase project at https://console.firebase.google.com

2. Register your Android app:
   - Package name: `com.gymapp.gymapp` (change in `android/app/build.gradle`)
   - Download `google-services.json` → place in `android/app/`

3. Register your iOS app:
   - Bundle ID: `com.gymapp.gymapp`
   - Download `GoogleService-Info.plist` → place in `ios/Runner/`

4. Configure Android:
   ```
   android/build.gradle       → add google-services classpath
   android/app/build.gradle   → apply google-services plugin
   ```

5. Run the app → it auto-registers the FCM token with the backend

### What notifications you'll receive

| Event | When |
|-------|------|
| Membership expiring | 7, 3, 1 day before expiry |
| Membership expired | When auto-expired |
| Payment confirmed | After successful payment |
| Class booked | Immediately after booking |
| Class reminder | 1 hour before class starts |
| Class cancelled | When admin cancels your class |
| Waitlist promoted | When a spot opens up |
| Personal best | When you set a new PR |
| Attendance milestones | At 10, 25, 50, 100 visits |

---

## 🎨 Design System

**Colors:**
- Background:  `#0E0E16` (near-black)
- Card surface: `#16161F`
- Primary blue: `#3B6BFF` (CTAs, active QR pulse)
- Success green: `#00D97E`
- Warning amber: `#FFB020`
- Danger red:   `#FF3B5C`

**Fonts:** Inter (system fallback on iOS = SF Pro, Android = Roboto)

**Key design choices:**
- Membership card uses a gradient and progress bar for visual urgency
- QR code has a subtle breathing/pulse animation to show it's live
- Personal best detection triggers a green shimmer on the workout log entry
- Empty states use large icons + actionable copy, not apologies

---

## 🏗️ Architecture

```
Screens (UI)
    ↓ calls
api_service.dart (Dio + JWT interceptors)
    ↓ HTTP
FastAPI backend (Phases 1–9)
```

State management: local `setState` per screen (simple, no Riverpod/Bloc needed for this scope). Add Riverpod for shared state when the app grows.

---

## ➡️ Next: Phase 12 — Security Hardening

Rate limiting, JWT refresh token rotation, role enforcement audit, webhook signature verification, and input sanitization across all endpoints.
