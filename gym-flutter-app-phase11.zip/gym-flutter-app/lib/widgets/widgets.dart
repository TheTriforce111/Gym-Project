// lib/widgets/widgets.dart
//
// Shared UI components used across all screens.
// Import this file wherever widgets are needed.

import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

// ────────────────────────────────────────────────────────────────────────────
// GYM CARD — standard card container
// ────────────────────────────────────────────────────────────────────────────
class GymCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final VoidCallback? onTap;
  final Color? color;

  const GymCard({
    super.key,
    required this.child,
    this.padding,
    this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: color ?? AppColors.surface,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.lg,
        child: Padding(
          padding: padding ?? AppSpacing.cardPadding,
          child: child,
        ),
      ),
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// KPI CARD — metric display with label and trend
// ────────────────────────────────────────────────────────────────────────────
class KPICard extends StatelessWidget {
  final String label;
  final String value;
  final String? sublabel;
  final Color? valueColor;
  final IconData? icon;
  final Color? iconColor;

  const KPICard({
    super.key,
    required this.label,
    required this.value,
    this.sublabel,
    this.valueColor,
    this.icon,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return GymCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Text(label, style: AppText.label.copyWith(
                color: AppColors.textMuted, letterSpacing: 0.5,
              )),
            ),
            if (icon != null)
              Icon(icon!, size: 16, color: iconColor ?? AppColors.primary),
          ]),
          const SizedBox(height: 8),
          Text(value, style: AppText.display.copyWith(
            fontSize: 28,
            color: valueColor ?? AppColors.textPrimary,
          )),
          if (sublabel != null) ...[
            const SizedBox(height: 4),
            Text(sublabel!, style: AppText.small),
          ],
        ],
      ),
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// STATUS BADGE
// ────────────────────────────────────────────────────────────────────────────
class StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final Color? backgroundColor;

  const StatusBadge({
    super.key,
    required this.label,
    required this.color,
    this.backgroundColor,
  });

  factory StatusBadge.membership(String status) {
    final configs = {
      'active':    (AppColors.green,  AppColors.greenDim),
      'expired':   (AppColors.red,    AppColors.redDim),
      'frozen':    (AppColors.primary, AppColors.primaryDim),
      'cancelled': (AppColors.textMuted, AppColors.surfaceAlt),
    };
    final (c, bg) = configs[status] ?? (AppColors.textMuted, AppColors.surfaceAlt);
    return StatusBadge(label: status, color: c, backgroundColor: bg);
  }

  factory StatusBadge.classStatus(String status) {
    final configs = {
      'scheduled': (AppColors.green,   AppColors.greenDim),
      'ongoing':   (AppColors.amber,   AppColors.amberDim),
      'completed': (AppColors.textMuted, AppColors.surfaceAlt),
      'cancelled': (AppColors.red,     AppColors.redDim),
    };
    final (c, bg) = configs[status] ?? (AppColors.textMuted, AppColors.surfaceAlt);
    return StatusBadge(label: status, color: c, backgroundColor: bg);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: backgroundColor ?? color.withOpacity(0.15),
        borderRadius: AppRadius.full,
      ),
      child: Text(
        label.toUpperCase(),
        style: AppText.label.copyWith(color: color, fontSize: 10),
      ),
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// PRIMARY BUTTON
// ────────────────────────────────────────────────────────────────────────────
class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final IconData? icon;
  final Color? backgroundColor;

  const PrimaryButton({
    super.key,
    required this.label,
    this.onPressed,
    this.loading = false,
    this.icon,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: loading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor ?? AppColors.primary,
        ),
        child: loading
          ? const SizedBox(
              width: 20, height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2, color: Colors.white,
              ),
            )
          : Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[Icon(icon!, size: 18), const SizedBox(width: 8)],
                Text(label),
              ],
            ),
      ),
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// SECTION HEADER
// ────────────────────────────────────────────────────────────────────────────
class SectionHeader extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onAction;

  const SectionHeader({super.key, required this.title, this.action, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: Text(title, style: AppText.h3)),
      if (action != null)
        TextButton(
          onPressed: onAction,
          child: Text(action!, style: AppText.small.copyWith(color: AppColors.primary)),
        ),
    ]);
  }
}

// ────────────────────────────────────────────────────────────────────────────
// EMPTY STATE
// ────────────────────────────────────────────────────────────────────────────
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: AppColors.textSubtle),
            const SizedBox(height: 16),
            Text(title, style: AppText.h3, textAlign: TextAlign.center),
            if (subtitle != null) ...[
              const SizedBox(height: 8),
              Text(subtitle!, style: AppText.bodyMuted, textAlign: TextAlign.center),
            ],
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 24),
              ElevatedButton(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ],
        ),
      ),
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// SHIMMER LOADING
// ────────────────────────────────────────────────────────────────────────────
class ShimmerBox extends StatefulWidget {
  final double width;
  final double height;
  final BorderRadius? borderRadius;

  const ShimmerBox({
    super.key,
    required this.width,
    required this.height,
    this.borderRadius,
  });

  @override
  State<ShimmerBox> createState() => _ShimmerBoxState();
}

class _ShimmerBoxState extends State<ShimmerBox> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat();
    _animation = Tween<double>(begin: -2, end: 2).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutSine),
    );
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, _) {
        return Container(
          width: widget.width, height: widget.height,
          decoration: BoxDecoration(
            borderRadius: widget.borderRadius ?? AppRadius.sm,
            gradient: LinearGradient(
              begin: Alignment(_animation.value, 0),
              end:   Alignment(_animation.value + 1, 0),
              colors: const [AppColors.surfaceAlt, AppColors.border, AppColors.surfaceAlt],
            ),
          ),
        );
      },
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// AVATAR — user initials circle
// ────────────────────────────────────────────────────────────────────────────
class UserAvatar extends StatelessWidget {
  final String initials;
  final double size;
  final Color? color;

  const UserAvatar({super.key, required this.initials, this.size = 40, this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        color: (color ?? AppColors.primary).withOpacity(0.15),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          initials,
          style: TextStyle(
            fontSize: size * 0.35,
            fontWeight: FontWeight.w700,
            color: color ?? AppColors.primary,
          ),
        ),
      ),
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// CATEGORY CHIP — for class/muscle group filtering
// ────────────────────────────────────────────────────────────────────────────
class CategoryChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const CategoryChip({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.surfaceAlt,
          borderRadius: AppRadius.full,
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.border,
          ),
        ),
        child: Text(
          label,
          style: AppText.small.copyWith(
            color:      selected ? Colors.white : AppColors.textMuted,
            fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// FEELING SELECTOR — 1-5 emoji rating for workout quality
// ────────────────────────────────────────────────────────────────────────────
class FeelingSelectorWidget extends StatelessWidget {
  final int? selected;
  final ValueChanged<int> onSelect;

  const FeelingSelectorWidget({super.key, this.selected, required this.onSelect});

  static const _emojis = ['😞', '😐', '😊', '😄', '🔥'];
  static const _labels = ['Rough', 'OK', 'Good', 'Great', 'Beast'];

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(5, (i) {
        final val    = i + 1;
        final active = selected == val;
        return GestureDetector(
          onTap: () => onSelect(val),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: active ? AppColors.primaryDim : Colors.transparent,
              borderRadius: AppRadius.md,
              border: Border.all(
                color: active ? AppColors.primary : AppColors.border,
                width: active ? 1.5 : 1,
              ),
            ),
            child: Column(children: [
              Text(_emojis[i], style: const TextStyle(fontSize: 22)),
              const SizedBox(height: 2),
              Text(_labels[i], style: AppText.label.copyWith(
                color: active ? AppColors.primary : AppColors.textSubtle,
                fontSize: 9,
              )),
            ]),
          ),
        );
      }),
    );
  }
}
