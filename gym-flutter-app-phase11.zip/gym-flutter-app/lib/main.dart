// lib/main.dart
//
// GymOS Flutter App — Entry point
//
// Setup:
//  1. Firebase initialization (for push notifications)
//  2. App theme (dark gym aesthetic)
//  3. GoRouter (declarative navigation with auth guards)
//  4. FCM token registration with the backend

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'router.dart';
import 'theme/app_theme.dart';
import 'services/api_service.dart';

// ---------------------------------------------------------------------------
// Background message handler — must be a top-level function
// ---------------------------------------------------------------------------
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Called when app is in background/terminated and a message arrives.
  // Keep it lightweight — just log here. The message is shown by FCM itself.
  debugPrint('Background FCM message: ${message.messageId}');
}

// ---------------------------------------------------------------------------
// Local notifications plugin (for showing notifications when app is in foreground)
// ---------------------------------------------------------------------------
final _localNotifications = FlutterLocalNotificationsPlugin();

// ---------------------------------------------------------------------------
// App entry point
// ---------------------------------------------------------------------------
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Force portrait orientation
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Transparent status bar
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:            Colors.transparent,
    statusBarIconBrightness:   Brightness.light,
    systemNavigationBarColor:  AppColors.surface,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  // Initialize Firebase
  // NOTE: You must add google-services.json (Android) and
  // GoogleService-Info.plist (iOS) to your project before Firebase works.
  // See: https://firebase.google.com/docs/flutter/setup
  try {
    await Firebase.initializeApp();
    await _setupFirebaseMessaging();
  } catch (e) {
    // Firebase not configured yet — app still works, just no push notifications
    debugPrint('Firebase not configured: $e');
  }

  runApp(const GymApp());
}

// ---------------------------------------------------------------------------
// Firebase Messaging Setup
// ---------------------------------------------------------------------------
Future<void> _setupFirebaseMessaging() async {
  final fcm = FirebaseMessaging.instance;

  // Request permission (required on iOS, harmless on Android)
  await fcm.requestPermission(
    alert:     true,
    badge:     true,
    sound:     true,
    provisional: false,
  );

  // Set background handler
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Setup local notifications for foreground messages
  const androidChannel = AndroidNotificationChannel(
    'gym_notifications',      // Channel ID
    'Gym Notifications',      // Name shown in settings
    description:  'GymOS app notifications',
    importance:   Importance.high,
    showBadge:    true,
  );

  await _localNotifications.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS:     DarwinInitializationSettings(),
    ),
  );

  // Show notification when app is in foreground
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    final notification = message.notification;
    if (notification == null) return;

    _localNotifications.show(
      notification.hashCode,
      notification.title,
      notification.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          androidChannel.id,
          androidChannel.name,
          channelDescription: androidChannel.description,
          importance:  Importance.high,
          priority:    Priority.high,
          icon:        '@mipmap/ic_launcher',
        ),
        iOS: const DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
    );
  });

  // Get the FCM token and register with our backend
  // The token identifies this specific device for push notifications
  final token = await fcm.getToken();
  if (token != null) {
    try {
      await api.registerDeviceToken(
        token,
        deviceType: 'android', // Detect platform in real app using dart:io Platform
        appVersion: '1.0.0',
      );
      debugPrint('FCM token registered with backend');
    } catch (e) {
      // Token registration failed — push won't work until next app launch
      debugPrint('FCM token registration failed: $e');
    }
  }

  // Refresh token when Firebase rotates it
  fcm.onTokenRefresh.listen((newToken) async {
    try {
      await api.registerDeviceToken(newToken);
    } catch (_) { /* Fail silently */ }
  });
}

// ---------------------------------------------------------------------------
// Root App Widget
// ---------------------------------------------------------------------------
class GymApp extends StatelessWidget {
  const GymApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title:        'GymOS',
      debugShowCheckedModeBanner: false,
      theme:        AppTheme.dark,

      // GoRouter handles all navigation
      routerConfig: buildRouter(),
    );
  }
}
