// lib/services/api_service.dart
//
// Centralized Dio HTTP client for all backend API calls.
//
// Features:
// - JWT injection via interceptor (access token on every request)
// - Auto-refresh: when a 401 is received, silently refresh the token
//   and replay the original request — the UI never sees the error
// - Secure token storage via flutter_secure_storage
// - Type-safe response parsing matching the backend schemas

import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../models/models.dart';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const _baseUrl = 'http://10.0.2.2:8000/api';
// 10.0.2.2 is the Android emulator's alias for localhost.
// For a real device, use your machine's local IP: e.g. 192.168.1.10:8000
// For production, replace with your deployed API URL.

const _storage = FlutterSecureStorage(
  aOptions: AndroidOptions(encryptedSharedPreferences: true),
  // encryptedSharedPreferences uses Android Keystore for encryption
);

// ---------------------------------------------------------------------------
// ApiService
// ---------------------------------------------------------------------------
class ApiService {
  late final Dio _dio;
  bool _isRefreshing = false;

  ApiService() {
    _dio = Dio(BaseOptions(
      baseUrl:        _baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 15),
      headers: {'Content-Type': 'application/json'},
    ));

    // ── Request interceptor: attach JWT access token ──────────────────────
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await _storage.read(key: 'access_token');
        if (token != null) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        handler.next(options);
      },

      // ── Response error interceptor: auto-refresh on 401 ──────────────
      onError: (DioException error, handler) async {
        // Only retry on 401, and not for auth endpoints themselves
        final path = error.requestOptions.path;
        if (error.response?.statusCode == 401 &&
            !path.contains('/auth/') &&
            !_isRefreshing) {

          _isRefreshing = true;

          try {
            final refreshToken = await _storage.read(key: 'refresh_token');
            if (refreshToken == null) {
              // No refresh token — user must log in again
              await _clearTokens();
              return handler.next(error);
            }

            // Request a new access token
            final response = await Dio().post(
              '$_baseUrl/auth/refresh',
              data: {'refresh_token': refreshToken},
            );

            final newAccess  = response.data['access_token']  as String;
            final newRefresh = response.data['refresh_token'] as String;

            // Save the new tokens
            await _saveTokens(access: newAccess, refresh: newRefresh);

            // Replay the original request with the new token
            error.requestOptions.headers['Authorization'] = 'Bearer $newAccess';
            final retried = await _dio.fetch(error.requestOptions);
            return handler.resolve(retried);

          } catch (_) {
            // Refresh failed — force logout
            await _clearTokens();
            return handler.next(error);
          } finally {
            _isRefreshing = false;
          }
        }

        handler.next(error);
      },
    ));
  }

  // ── Token helpers ─────────────────────────────────────────────────────────

  Future<void> _saveTokens({required String access, required String refresh}) async {
    await Future.wait([
      _storage.write(key: 'access_token',  value: access),
      _storage.write(key: 'refresh_token', value: refresh),
    ]);
  }

  Future<void> _clearTokens() async {
    await Future.wait([
      _storage.delete(key: 'access_token'),
      _storage.delete(key: 'refresh_token'),
    ]);
  }

  Future<bool> hasValidToken() async {
    final token = await _storage.read(key: 'access_token');
    return token != null && token.isNotEmpty;
  }

  // =========================================================================
  // AUTH
  // =========================================================================

  /// Login with email + password. Saves tokens on success.
  Future<User> login(String email, String password) async {
    final res = await _dio.post('/auth/login', data: {
      'email':    email,
      'password': password,
    });
    final tokens = AuthTokens.fromJson(res.data as Map<String, dynamic>);
    await _saveTokens(access: tokens.accessToken, refresh: tokens.refreshToken);

    // Fetch the user profile
    return getMe();
  }

  /// Register a new member account.
  Future<User> register({
    required String fullName,
    required String email,
    required String password,
    String? phone,
  }) async {
    final res = await _dio.post('/auth/register', data: {
      'full_name': fullName,
      'email':     email,
      'password':  password,
      if (phone != null) 'phone': phone,
      'role': 'member',
    });
    return User.fromJson(res.data as Map<String, dynamic>);
  }

  /// Get the currently authenticated user's profile.
  Future<User> getMe() async {
    final res = await _dio.get('/auth/me');
    return User.fromJson(res.data as Map<String, dynamic>);
  }

  /// Logout — clears stored tokens.
  Future<void> logout() async {
    try {
      // Send logout request to blacklist the tokens
      await _dio.post('/auth/logout', data: {});
    } catch (_) { /* Ignore — clear local tokens regardless */ }
    await _clearTokens();
  }

  /// Request a password reset OTP.
  Future<void> forgotPassword(String email) async {
    await _dio.post('/auth/forgot-password', data: {'email': email});
  }

  /// Verify the OTP code.
  Future<void> verifyOTP(String email, String otp) async {
    await _dio.post('/auth/verify-otp', data: {'email': email, 'otp': otp});
  }

  /// Set a new password after OTP verification.
  Future<void> resetPassword(String email, String otp, String newPassword) async {
    await _dio.post('/auth/reset-password', data: {
      'email':        email,
      'otp':          otp,
      'new_password': newPassword,
    });
  }

  // =========================================================================
  // MEMBERSHIP
  // =========================================================================

  /// Get the current user's membership.
  Future<Membership> getMyMembership() async {
    final res = await _dio.get('/memberships/me');
    return Membership.fromJson(res.data as Map<String, dynamic>);
  }

  /// Get available membership plans with pricing.
  Future<List<Map<String, dynamic>>> getMembershipPricing() async {
    final res = await _dio.get('/memberships/pricing');
    return (res.data as List).cast<Map<String, dynamic>>();
  }

  // =========================================================================
  // WORKOUTS
  // =========================================================================

  /// Get all exercises, optionally filtered by muscle group.
  Future<List<Exercise>> getExercises({String? muscleGroup}) async {
    final res = await _dio.get('/workouts/exercises',
      queryParameters: muscleGroup != null ? {'muscle_group': muscleGroup} : null,
    );
    return (res.data as List)
        .map((e) => Exercise.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// Get the current user's assigned workout plans.
  Future<List<WorkoutPlan>> getMyPlans() async {
    final res = await _dio.get('/workouts/plans/me');
    return (res.data as List)
        .map((p) => WorkoutPlan.fromJson(p as Map<String, dynamic>))
        .toList();
  }

  /// Get a specific workout plan by ID (includes exercises).
  Future<WorkoutPlan> getPlan(int planId) async {
    final res = await _dio.get('/workouts/plans/$planId');
    return WorkoutPlan.fromJson(res.data as Map<String, dynamic>);
  }

  /// Log a completed workout session.
  Future<WorkoutLog> logWorkout({
    int? planId,
    int? durationMinutes,
    int? overallFeeling,
    double? bodyWeightKg,
    String? notes,
    required List<Map<String, dynamic>> exercises,
  }) async {
    final res = await _dio.post('/workouts/logs', data: {
      if (planId != null)          'plan_id': planId,
      if (durationMinutes != null) 'duration_minutes': durationMinutes,
      if (overallFeeling != null)  'overall_feeling': overallFeeling,
      if (bodyWeightKg != null)    'body_weight_kg': bodyWeightKg,
      if (notes != null)           'notes': notes,
      'exercises': exercises,
    });
    return WorkoutLog.fromJson(res.data as Map<String, dynamic>);
  }

  /// Get the current user's workout history.
  Future<List<WorkoutLog>> getMyWorkoutHistory({int limit = 20}) async {
    final res = await _dio.get('/workouts/logs/me', queryParameters: {'limit': limit});
    return (res.data as List)
        .map((l) => WorkoutLog.fromJson(l as Map<String, dynamic>))
        .toList();
  }

  /// Get progress data for a specific exercise.
  Future<Map<String, dynamic>> getExerciseProgress(int exerciseId, {int days = 90}) async {
    final res = await _dio.get('/workouts/progress/$exerciseId',
      queryParameters: {'days': days},
    );
    return res.data as Map<String, dynamic>;
  }

  /// Get personal bests for all tracked exercises.
  Future<List<Map<String, dynamic>>> getPersonalBests() async {
    final res = await _dio.get('/workouts/personal-bests');
    return (res.data as List).cast<Map<String, dynamic>>();
  }

  /// Get workout frequency and streak stats.
  Future<Map<String, dynamic>> getWorkoutStats() async {
    final res = await _dio.get('/workouts/stats');
    return res.data as Map<String, dynamic>;
  }

  // =========================================================================
  // CLASSES
  // =========================================================================

  /// Get upcoming gym classes.
  Future<List<GymClass>> getClasses({String? category}) async {
    final res = await _dio.get('/classes/', queryParameters: {
      'upcoming_only': true,
      if (category != null) 'category': category,
    });
    return (res.data as List)
        .map((c) => GymClass.fromJson(c as Map<String, dynamic>))
        .toList();
  }

  /// Get the weekly class schedule.
  Future<Map<String, dynamic>> getWeeklySchedule({int weekOffset = 0}) async {
    final res = await _dio.get('/classes/schedule/weekly',
      queryParameters: {'week_offset': weekOffset},
    );
    return res.data as Map<String, dynamic>;
  }

  /// Book a gym class.
  Future<Map<String, dynamic>> bookClass(int classId) async {
    final res = await _dio.post('/classes/$classId/book', data: {});
    return res.data as Map<String, dynamic>;
  }

  /// Cancel a class booking.
  Future<void> cancelBooking(int classId, {String? reason}) async {
    await _dio.post('/classes/$classId/cancel-booking', data: {
      if (reason != null) 'reason': reason,
    });
  }

  /// Get the current user's upcoming bookings.
  Future<List<Map<String, dynamic>>> getMyBookings({bool includePast = false}) async {
    final res = await _dio.get('/classes/my-bookings',
      queryParameters: {'include_past': includePast},
    );
    return (res.data as List).cast<Map<String, dynamic>>();
  }

  // =========================================================================
  // ATTENDANCE / QR
  // =========================================================================

  /// Get or generate the member's QR token for check-in.
  Future<QRToken> getMyQRCode() async {
    final res = await _dio.get('/attendance/my-qr');
    return QRToken.fromJson(res.data as Map<String, dynamic>);
  }

  /// Force-refresh the QR token (get a new one).
  Future<QRToken> refreshQRCode() async {
    await _dio.post('/attendance/my-qr/refresh');
    return getMyQRCode();
  }

  /// Get the current user's attendance history.
  Future<List<AttendanceRecord>> getMyAttendance({int limit = 30}) async {
    final res = await _dio.get('/attendance/me', queryParameters: {'limit': limit});
    return (res.data as List)
        .map((a) => AttendanceRecord.fromJson(a as Map<String, dynamic>))
        .toList();
  }

  /// Get the current user's attendance stats (streak, monthly count, etc.).
  Future<MemberStats> getMyAttendanceStats() async {
    final res = await _dio.get('/attendance/me/summary');
    return MemberStats.fromJson(res.data as Map<String, dynamic>);
  }

  // =========================================================================
  // NOTIFICATIONS
  // =========================================================================

  /// Register an FCM device token for push notifications.
  Future<void> registerDeviceToken(String token, {
    String? deviceType,
    String? deviceName,
    String? appVersion,
  }) async {
    await _dio.post('/notifications/device-token', data: {
      'token':        token,
      if (deviceType != null) 'device_type': deviceType,
      if (deviceName != null) 'device_name': deviceName,
      if (appVersion != null) 'app_version': appVersion,
    });
  }

  /// Get the notification inbox.
  Future<List<AppNotification>> getNotifications({
    bool unreadOnly = false,
    int limit = 20,
  }) async {
    final res = await _dio.get('/notifications/', queryParameters: {
      'unread_only': unreadOnly,
      'limit':       limit,
    });
    return (res.data as List)
        .map((n) => AppNotification.fromJson(n as Map<String, dynamic>))
        .toList();
  }

  /// Get the unread notification count (for badge display).
  Future<int> getUnreadCount() async {
    final res = await _dio.get('/notifications/unread-count');
    return res.data['unread_count'] as int;
  }

  /// Mark notifications as read.
  Future<void> markNotificationsRead({List<int>? ids}) async {
    await _dio.post('/notifications/mark-read', data: {
      if (ids != null) 'notification_ids': ids,
    });
  }

  // =========================================================================
  // USER PROFILE
  // =========================================================================

  /// Update the current user's profile.
  Future<User> updateProfile({String? fullName, String? phone}) async {
    final res = await _dio.put('/users/me', data: {
      if (fullName != null) 'full_name': fullName,
      if (phone    != null) 'phone':     phone,
    });
    return User.fromJson(res.data as Map<String, dynamic>);
  }

  /// Change the current user's password.
  Future<void> changePassword(String current, String newPassword) async {
    await _dio.post('/users/me/change-password', data: {
      'current_password': current,
      'new_password':     newPassword,
    });
  }
}

// Global singleton — import and use anywhere
final api = ApiService();
