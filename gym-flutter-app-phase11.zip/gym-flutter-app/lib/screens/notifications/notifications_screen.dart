// lib/screens/notifications/notifications_screen.dart

import 'package:flutter/material.dart';
import '../../models/models.dart';
import '../../services/api_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import 'package:timeago/timeago.dart' as timeago;

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<AppNotification> _notifications = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      _notifications = await api.getNotifications(limit: 50);
    } catch (_) { }
    finally { setState(() => _loading = false); }
  }

  Future<void> _markAllRead() async {
    await api.markNotificationsRead();
    setState(() {
      _notifications = _notifications.map((n) => AppNotification(
        id: n.id, title: n.title, body: n.body,
        notificationType: n.notificationType, channel: n.channel,
        status: 'read', isRead: true, createdAt: n.createdAt,
      )).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final unread = _notifications.where((n) => !n.isRead).length;

    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const Text('Notifications'),
          if (unread > 0) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: AppColors.red, borderRadius: AppRadius.full,
              ),
              child: Text('$unread', style: const TextStyle(fontSize: 11, color: Colors.white, fontWeight: FontWeight.w700)),
            ),
          ],
        ]),
        actions: [
          if (unread > 0)
            TextButton(onPressed: _markAllRead, child: const Text('Mark all read')),
        ],
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
        : _notifications.isEmpty
          ? const EmptyState(
              icon: Icons.notifications_none,
              title: 'No notifications',
              subtitle: 'You\'re all caught up!',
            )
          : RefreshIndicator(
              onRefresh: _load,
              color: AppColors.primary,
              child: ListView.separated(
                itemCount: _notifications.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (ctx, i) {
                  final n = _notifications[i];
                  final typeIcons = {
                    'membership_expiring': (Icons.warning_amber_outlined, AppColors.amber),
                    'payment_success':     (Icons.check_circle_outline,   AppColors.green),
                    'payment_failed':      (Icons.error_outline,          AppColors.red),
                    'class_booking_confirmed': (Icons.calendar_today, AppColors.purple),
                    'class_cancelled':     (Icons.cancel_outlined,        AppColors.red),
                    'personal_best':       (Icons.emoji_events_outlined,  AppColors.amber),
                    'attendance_milestone':(Icons.stars_outlined,         AppColors.amber),
                  };
                  final (icon, color) = typeIcons[n.notificationType] ??
                    (Icons.notifications_outlined, AppColors.primary);

                  return ListTile(
                    tileColor: n.isRead ? null : AppColors.primaryDim.withOpacity(0.3),
                    leading: Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.15), shape: BoxShape.circle,
                      ),
                      child: Icon(icon, color: color, size: 20),
                    ),
                    title: Text(n.title, style: AppText.body.copyWith(
                      fontWeight: n.isRead ? FontWeight.w400 : FontWeight.w600,
                    )),
                    subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(n.body, style: AppText.small, maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 2),
                      Text(timeago.format(n.createdAt), style: AppText.label),
                    ]),
                    onTap: () async {
                      if (!n.isRead) await api.markNotificationsRead(ids: [n.id]);
                    },
                  );
                },
              ),
            ),
    );
  }
}


// ────────────────────────────────────────────────────────────────────────────
// PROFILE SCREEN
// ────────────────────────────────────────────────────────────────────────────

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  User?       _user;
  Membership? _membership;
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([
        api.getMe(),
        api.getMyMembership().catchError((_) => null),
      ]);
      _user       = results[0] as User;
      _membership = results[1] as Membership?;
    } catch (_) { }
    finally { setState(() => _loading = false); }
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Sign out?'),
        content: const Text('You\'ll need to log in again to access your account.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.red),
            child: const Text('Sign out'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await api.logout();
      if (mounted) Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
        : ListView(
            padding: const EdgeInsets.all(20),
            children: [
              // Avatar + name
              Center(child: Column(children: [
                UserAvatar(initials: _user?.initials ?? '?', size: 72),
                const SizedBox(height: 12),
                Text(_user?.fullName ?? '', style: AppText.h2),
                Text(_user?.email ?? '', style: AppText.bodyMuted),
                const SizedBox(height: 8),
                StatusBadge(
                  label: _user?.role.name.toUpperCase() ?? 'MEMBER',
                  color: AppColors.primary,
                ),
              ])),

              const SizedBox(height: 32),

              // Membership summary
              if (_membership != null) ...[
                Text('Membership', style: AppText.label.copyWith(
                  color: AppColors.textMuted, letterSpacing: 0.8,
                )),
                const SizedBox(height: 8),
                GymCard(child: Column(children: [
                  _InfoRow(label: 'Plan',     value: _membership!.plan.name.toUpperCase()),
                  _InfoRow(label: 'Status',   value: _membership!.status.name),
                  _InfoRow(label: 'Expires',  value: _membership!.endDate.toString().split(' ')[0]),
                  _InfoRow(label: 'Days Left', value: '${_membership!.daysRemaining} days',
                    highlight: _membership!.isExpiringSoon),
                ])),
                const SizedBox(height: 24),
              ],

              // Account info
              Text('Account', style: AppText.label.copyWith(
                color: AppColors.textMuted, letterSpacing: 0.8,
              )),
              const SizedBox(height: 8),
              GymCard(child: Column(children: [
                _InfoRow(label: 'Full Name', value: _user?.fullName ?? ''),
                _InfoRow(label: 'Email',     value: _user?.email ?? ''),
                _InfoRow(label: 'Phone',     value: _user?.phone ?? '—'),
                _InfoRow(label: 'Verified',  value: _user?.isVerified == true ? 'Yes' : 'No'),
              ])),

              const SizedBox(height: 24),

              // Sign out
              GymCard(
                onTap: _logout,
                color: AppColors.redDim,
                child: Row(children: [
                  const Icon(Icons.logout, color: AppColors.red, size: 20),
                  const SizedBox(width: 12),
                  Text('Sign Out', style: AppText.body.copyWith(
                    color: AppColors.red, fontWeight: FontWeight.w600,
                  )),
                  const Spacer(),
                  const Icon(Icons.chevron_right, color: AppColors.red, size: 18),
                ]),
              ),

              const SizedBox(height: 32),
              Center(child: Text('GymOS v1.0.0', style: AppText.label)),
            ],
          ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final bool highlight;
  const _InfoRow({required this.label, required this.value, this.highlight = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(children: [
        Expanded(child: Text(label, style: AppText.small)),
        Text(value, style: AppText.body.copyWith(
          fontWeight: FontWeight.w600,
          color: highlight ? AppColors.amber : AppColors.textPrimary,
        )),
      ]),
    );
  }
}
