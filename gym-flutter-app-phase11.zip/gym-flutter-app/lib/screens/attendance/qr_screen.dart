// lib/screens/attendance/qr_screen.dart
//
// QR Code check-in screen.
//
// The screen shows the member's QR code which staff scan at the gym entrance.
// It auto-refreshes before the token expires, and shows a countdown timer.

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../../models/models.dart';
import '../../services/api_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import 'package:intl/intl.dart';

class QRScreen extends StatefulWidget {
  const QRScreen({super.key});
  @override
  State<QRScreen> createState() => _QRScreenState();
}

class _QRScreenState extends State<QRScreen> with SingleTickerProviderStateMixin {
  QRToken?       _qrToken;
  List<AttendanceRecord> _history  = [];
  MemberStats?   _stats;
  bool           _loading = true;
  bool           _refreshing = false;
  String?        _error;
  Timer?         _countdownTimer;
  int            _secondsLeft = 0;

  // Pulse animation for the QR code to signal it's active
  late AnimationController _pulseCtrl;
  late Animation<double>   _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.03).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _loadAll();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    setState(() { _loading = true; _error = null; });
    try {
      final results = await Future.wait([
        api.getMyQRCode(),
        api.getMyAttendance(limit: 10),
        api.getMyAttendanceStats(),
      ]);
      _qrToken = results[0] as QRToken;
      _history = results[1] as List<AttendanceRecord>;
      _stats   = results[2] as MemberStats;
      _startCountdown();
    } catch (e) {
      _error = 'Could not load QR code. Check your connection.';
    } finally {
      setState(() => _loading = false);
    }
  }

  void _startCountdown() {
    _countdownTimer?.cancel();
    if (_qrToken == null) return;

    _secondsLeft = _qrToken!.expiresAt.difference(DateTime.now()).inSeconds;
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) { timer.cancel(); return; }
      setState(() => _secondsLeft--);

      // Auto-refresh 60 seconds before expiry
      if (_secondsLeft <= 60 && !_refreshing) {
        _autoRefresh();
      }
      if (_secondsLeft <= 0) timer.cancel();
    });
  }

  Future<void> _autoRefresh() async {
    setState(() => _refreshing = true);
    try {
      final token = await api.getMyQRCode();
      setState(() => _qrToken = token);
      _startCountdown();
    } catch (_) { /* fail silently */ }
    finally { setState(() => _refreshing = false); }
  }

  Future<void> _manualRefresh() async {
    setState(() => _refreshing = true; _error = null);
    try {
      final token = await api.refreshQRCode();
      setState(() => _qrToken = token);
      _startCountdown();
    } catch (_) {
      setState(() => _error = 'Could not refresh QR code.');
    } finally {
      setState(() => _refreshing = false);
    }
  }

  String _formatCountdown() {
    if (_secondsLeft <= 0) return 'Expired';
    final m = _secondsLeft ~/ 60;
    final s = _secondsLeft % 60;
    return '${m}m ${s.toString().padLeft(2, '0')}s';
  }

  Color _countdownColor() {
    if (_secondsLeft > 300) return AppColors.green;
    if (_secondsLeft > 60)  return AppColors.amber;
    return AppColors.red;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My QR Code'),
        actions: [
          IconButton(
            icon: _refreshing
              ? const SizedBox(width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary))
              : const Icon(Icons.refresh_outlined),
            onPressed: _refreshing ? null : _manualRefresh,
            tooltip: 'Generate new QR',
          ),
        ],
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
        : _error != null
          ? EmptyState(icon: Icons.qr_code_2, title: _error!,
              actionLabel: 'Retry', onAction: _loadAll)
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(children: [

                // ── QR Code Card ──────────────────────────────────────────
                GymCard(
                  padding: const EdgeInsets.all(24),
                  child: Column(children: [
                    // Expiry countdown
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.timer_outlined, size: 14,
                        color: _countdownColor()),
                      const SizedBox(width: 6),
                      Text(
                        'Refreshes in ${_formatCountdown()}',
                        style: AppText.small.copyWith(color: _countdownColor()),
                      ),
                    ]),
                    const SizedBox(height: 20),

                    // QR code with pulse animation
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: AppRadius.lg,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withOpacity(0.2),
                              blurRadius: 20, spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: _qrToken != null
                          ? QrImageView(
                              data:            _qrToken!.token,
                              size:            220,
                              backgroundColor: Colors.white,
                              eyeStyle:        const QrEyeStyle(
                                eyeShape:  QrEyeShape.square,
                                color:     Color(0xFF0E0E16),
                              ),
                              dataModuleStyle: const QrDataModuleStyle(
                                dataModuleShape: QrDataModuleShape.square,
                                color:           Color(0xFF0E0E16),
                              ),
                            )
                          : const SizedBox(width: 220, height: 220),
                      ),
                    ),
                    const SizedBox(height: 16),

                    Text(
                      'Show this QR code at the gym entrance',
                      style: AppText.bodyMuted,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Each code is unique and time-limited for security',
                      style: AppText.small,
                      textAlign: TextAlign.center,
                    ),
                  ]),
                ),

                const SizedBox(height: 24),

                // ── Stats Row ─────────────────────────────────────────────
                if (_stats != null) ...[
                  Row(children: [
                    Expanded(child: KPICard(
                      label: 'Total Visits',
                      value: '${_stats!.totalVisits}',
                      icon: Icons.check_circle_outline,
                      iconColor: AppColors.green,
                    )),
                    const SizedBox(width: 12),
                    Expanded(child: KPICard(
                      label: 'This Month',
                      value: '${_stats!.visitsThisMonth}',
                      icon: Icons.calendar_month_outlined,
                      iconColor: AppColors.primary,
                    )),
                    const SizedBox(width: 12),
                    Expanded(child: KPICard(
                      label: 'Streak',
                      value: '${_stats!.currentStreak}d',
                      icon: Icons.local_fire_department_outlined,
                      iconColor: AppColors.amber,
                    )),
                  ]),
                  const SizedBox(height: 24),
                ],

                // ── Recent Check-ins ──────────────────────────────────────
                const SectionHeader(title: 'Recent Visits'),
                const SizedBox(height: 12),

                if (_history.isEmpty)
                  const EmptyState(
                    icon: Icons.history,
                    title: 'No visits yet',
                    subtitle: 'Your check-in history will appear here.',
                  )
                else
                  ...(_history.map((record) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: GymCard(
                      child: Row(children: [
                        Container(
                          width: 40, height: 40,
                          decoration: BoxDecoration(
                            color: AppColors.greenDim,
                            borderRadius: AppRadius.md,
                          ),
                          child: const Icon(Icons.check, color: AppColors.green, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(
                            DateFormat('EEE, MMM d').format(record.checkInTime),
                            style: AppText.body.copyWith(fontWeight: FontWeight.w600),
                          ),
                          Text(
                            DateFormat('HH:mm').format(record.checkInTime) +
                            (record.durationMinutes != null
                              ? ' · ${record.durationMinutes}min session'
                              : ''),
                            style: AppText.small,
                          ),
                        ])),
                        Icon(
                          record.method == 'qr_scan' ? Icons.qr_code_scanner : Icons.touch_app,
                          size: 16, color: AppColors.textSubtle,
                        ),
                      ]),
                    ),
                  ))).toList(),

                const SizedBox(height: 32),
              ]),
            ),
    );
  }
}
