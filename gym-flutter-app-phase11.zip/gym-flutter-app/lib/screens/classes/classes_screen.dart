// lib/screens/classes/classes_screen.dart
//
// Gym class booking screen.
// Browse upcoming classes by category, view details, book or join waitlist.

import 'package:flutter/material.dart';
import '../../models/models.dart';
import '../../services/api_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import 'package:intl/intl.dart';

class ClassesScreen extends StatefulWidget {
  const ClassesScreen({super.key});
  @override
  State<ClassesScreen> createState() => _ClassesScreenState();
}

class _ClassesScreenState extends State<ClassesScreen> {
  List<GymClass> _classes  = [];
  bool           _loading  = true;
  String?        _category;

  final _categories = ['All', 'Yoga', 'HIIT', 'Pilates', 'Spinning', 'Boxing', 'CrossFit', 'Cardio'];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      _classes = await api.getClasses(
        category: _category?.toLowerCase(),
      );
    } catch (_) { }
    finally { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Classes')),
      body: Column(children: [

        // Category filter chips
        SizedBox(
          height: 48,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            itemCount: _categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (ctx, i) {
              final cat = _categories[i];
              final isAll = cat == 'All';
              final selected = isAll ? _category == null : _category == cat;
              return CategoryChip(
                label: cat,
                selected: selected,
                onTap: () {
                  setState(() => _category = isAll ? null : cat);
                  _load();
                },
              );
            },
          ),
        ),

        // Class list
        Expanded(
          child: _loading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : _classes.isEmpty
              ? const EmptyState(
                  icon: Icons.calendar_today,
                  title: 'No upcoming classes',
                  subtitle: 'Check back later for new classes.',
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  color: AppColors.primary,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(20),
                    itemCount: _classes.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (ctx, i) => _ClassCard(
                      gymClass: _classes[i],
                      onBooked: _load,
                    ),
                  ),
                ),
        ),
      ]),
    );
  }
}

// ── Class Card ─────────────────────────────────────────────────────────────
class _ClassCard extends StatefulWidget {
  final GymClass gymClass;
  final VoidCallback onBooked;
  const _ClassCard({required this.gymClass, required this.onBooked});
  @override
  State<_ClassCard> createState() => _ClassCardState();
}

class _ClassCardState extends State<_ClassCard> {
  bool _booking = false;

  Future<void> _book() async {
    setState(() => _booking = true);
    try {
      final result = await api.bookClass(widget.gymClass.id);
      final type   = result['type'] as String;
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(type == 'waitlist'
          ? '📋 Added to waitlist at position #${result['position']}'
          : '✅ Class booked! See you there 💪'),
        backgroundColor: type == 'waitlist' ? AppColors.amber : AppColors.green,
      ));
      widget.onBooked();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(e.toString().contains('409') ? 'Already booked' : 'Booking failed'),
        backgroundColor: AppColors.red,
      ));
    } finally { setState(() => _booking = false); }
  }

  @override
  Widget build(BuildContext context) {
    final c  = widget.gymClass;
    final dt = c.startTime;

    final categoryIcons = {
      'yoga':     Icons.self_improvement,
      'hiit':     Icons.flash_on,
      'pilates':  Icons.accessibility_new,
      'spinning': Icons.directions_bike,
      'boxing':   Icons.sports_mma,
      'crossfit': Icons.fitness_center,
      'cardio':   Icons.directions_run,
    };
    final icon = categoryIcons[c.category] ?? Icons.sports;

    return GymCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: AppColors.purpleDim, borderRadius: AppRadius.md,
            ),
            child: Icon(icon, color: AppColors.purple, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(c.name, style: AppText.body.copyWith(fontWeight: FontWeight.w600)),
            Text(
              DateFormat('EEE, MMM d · HH:mm').format(dt) +
              ' · ${c.durationMinutes}min',
              style: AppText.small,
            ),
          ])),
          StatusBadge.classStatus(c.status),
        ]),

        if (c.location != null) ...[
          const SizedBox(height: 8),
          Row(children: [
            const Icon(Icons.location_on_outlined, size: 14, color: AppColors.textMuted),
            const SizedBox(width: 4),
            Text(c.location!, style: AppText.small),
          ]),
        ],

        const SizedBox(height: 12),
        Row(children: [
          // Capacity indicator
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              c.isFull ? 'Full — join waitlist' : '${c.spotsRemaining} of ${c.maxCapacity} spots left',
              style: AppText.small.copyWith(
                color: c.isFull ? AppColors.amber
                     : c.spotsRemaining <= 3 ? AppColors.amber
                     : AppColors.textMuted,
              ),
            ),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: AppRadius.full,
              child: LinearProgressIndicator(
                value: c.confirmedBookingsCount / c.maxCapacity,
                backgroundColor: AppColors.border,
                valueColor: AlwaysStoppedAnimation(
                  c.isFull ? AppColors.red
                  : c.spotsRemaining <= 3 ? AppColors.amber
                  : AppColors.green,
                ),
                minHeight: 3,
              ),
            ),
          ])),
          const SizedBox(width: 12),
          // Book button
          if (c.isBookable)
            ElevatedButton(
              onPressed: _booking ? null : _book,
              style: ElevatedButton.styleFrom(
                backgroundColor: c.isFull ? AppColors.amber : AppColors.primary,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                minimumSize: Size.zero,
              ),
              child: _booking
                ? const SizedBox(width: 16, height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : Text(c.isFull ? 'Waitlist' : 'Book',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            ),
        ]),
      ]),
    );
  }
}
