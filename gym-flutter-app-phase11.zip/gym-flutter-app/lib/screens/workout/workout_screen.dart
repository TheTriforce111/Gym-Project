// lib/screens/workout/workout_screen.dart
//
// Workout tracking screen with:
// - Tab 1: My Plans — assigned workout plans
// - Tab 2: Log Session — log a completed workout
// - Tab 3: Progress — personal bests + streak stats

import 'package:flutter/material.dart';
import '../../models/models.dart';
import '../../services/api_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import 'package:intl/intl.dart';

class WorkoutScreen extends StatefulWidget {
  const WorkoutScreen({super.key});
  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Workouts'),
        bottom: TabBar(
          controller: _tabCtrl,
          labelStyle: AppText.small.copyWith(fontWeight: FontWeight.w600),
          unselectedLabelStyle: AppText.small,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textMuted,
          indicatorColor: AppColors.primary,
          tabs: const [
            Tab(text: 'My Plans'),
            Tab(text: 'Log Session'),
            Tab(text: 'Progress'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: const [
          _MyPlansTab(),
          _LogSessionTab(),
          _ProgressTab(),
        ],
      ),
    );
  }
}

// ── TAB 1: My Plans ────────────────────────────────────────────────────────
class _MyPlansTab extends StatefulWidget {
  const _MyPlansTab();
  @override
  State<_MyPlansTab> createState() => _MyPlansTabState();
}

class _MyPlansTabState extends State<_MyPlansTab> {
  List<WorkoutPlan> _plans   = [];
  bool              _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      _plans = await api.getMyPlans();
    } catch (_) { }
    finally { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_plans.isEmpty) return const EmptyState(
      icon: Icons.fitness_center,
      title: 'No workout plans yet',
      subtitle: 'Your trainer will assign plans here.',
    );

    return ListView.separated(
      padding: const EdgeInsets.all(20),
      itemCount: _plans.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (ctx, i) => _PlanCard(plan: _plans[i]),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final WorkoutPlan plan;
  const _PlanCard({required this.plan});

  @override
  Widget build(BuildContext context) {
    final diffColors = {
      'beginner':     AppColors.green,
      'intermediate': AppColors.amber,
      'advanced':     AppColors.red,
    };
    final color = diffColors[plan.difficulty] ?? AppColors.primary;

    return GymCard(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => _PlanDetailScreen(planId: plan.id)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(plan.name, style: AppText.h3)),
          StatusBadge(label: plan.difficulty, color: color),
        ]),
        if (plan.goal != null) ...[
          const SizedBox(height: 4),
          Text('🎯 ${plan.goal}', style: AppText.small),
        ],
        const SizedBox(height: 12),
        Row(children: [
          Icon(Icons.fitness_center, size: 14, color: AppColors.textMuted),
          const SizedBox(width: 4),
          Text('${plan.totalExercises} exercises', style: AppText.small),
          const SizedBox(width: 16),
          Icon(Icons.circle, size: 6, color: AppColors.textSubtle),
          const SizedBox(width: 8),
          Text(
            plan.status.toUpperCase(),
            style: AppText.label.copyWith(
              color: plan.status == 'active' ? AppColors.green : AppColors.textMuted,
            ),
          ),
        ]),
      ]),
    );
  }
}

// ── Plan Detail Screen ─────────────────────────────────────────────────────
class _PlanDetailScreen extends StatefulWidget {
  final int planId;
  const _PlanDetailScreen({required this.planId});
  @override
  State<_PlanDetailScreen> createState() => _PlanDetailScreenState();
}

class _PlanDetailScreenState extends State<_PlanDetailScreen> {
  WorkoutPlan? _plan;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    api.getPlan(widget.planId).then((p) {
      setState(() { _plan = p; _loading = false; });
    }).catchError((_) { setState(() => _loading = false); });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_plan?.name ?? 'Workout Plan')),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
        : _plan == null
          ? const EmptyState(icon: Icons.error_outline, title: 'Could not load plan')
          : ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: _plan!.entries.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (ctx, i) {
                final entry = _plan!.entries[i];
                return GymCard(
                  child: Row(children: [
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: AppColors.primaryDim, borderRadius: AppRadius.md,
                      ),
                      child: Center(child: Text(
                        '${i + 1}',
                        style: AppText.body.copyWith(color: AppColors.primary, fontWeight: FontWeight.w700),
                      )),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(entry.exercise.name,
                        style: AppText.body.copyWith(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 2),
                      Text(
                        [
                          '${entry.sets} sets',
                          if (entry.reps != null) '× ${entry.reps} reps',
                          if (entry.weightKg != null) '@ ${entry.weightKg}kg',
                        ].join(' '),
                        style: AppText.small,
                      ),
                      if (entry.notes != null) ...[
                        const SizedBox(height: 2),
                        Text(entry.notes!, style: AppText.small.copyWith(
                          color: AppColors.textSubtle, fontStyle: FontStyle.italic,
                        )),
                      ],
                    ])),
                    if (entry.restSeconds != null)
                      Text('${entry.restSeconds}s\nrest',
                        style: AppText.label.copyWith(color: AppColors.textSubtle),
                        textAlign: TextAlign.center),
                  ]),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => _LogSessionTab(initialPlanId: _plan?.id)),
        ),
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.play_arrow_rounded),
        label: const Text('Start Workout'),
      ),
    );
  }
}

// ── TAB 2: Log Session ─────────────────────────────────────────────────────
class _LogSessionTab extends StatefulWidget {
  final int? initialPlanId;
  const _LogSessionTab({this.initialPlanId});
  @override
  State<_LogSessionTab> createState() => _LogSessionTabState();
}

class _LogSessionTabState extends State<_LogSessionTab> {
  int?   _feeling;
  int?   _duration;
  String _notes    = '';
  bool   _logging  = false;
  bool   _success  = false;
  final _notesCtrl = TextEditingController();
  final _durCtrl   = TextEditingController();

  @override
  void dispose() { _notesCtrl.dispose(); _durCtrl.dispose(); super.dispose(); }

  Future<void> _log() async {
    setState(() => _logging = true);
    try {
      await api.logWorkout(
        planId: widget.initialPlanId,
        durationMinutes: _duration,
        overallFeeling:  _feeling,
        notes:           _notes.isEmpty ? null : _notes,
        exercises: [], // Add exercise logging UI for a full implementation
      );
      setState(() => _success = true);
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not save workout. Try again.')),
      );
    } finally { setState(() => _logging = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (_success) return Center(child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.check_circle_outline, color: AppColors.green, size: 64),
        const SizedBox(height: 16),
        Text('Workout Logged!', style: AppText.h2),
        const SizedBox(height: 8),
        Text('Keep up the great work 💪', style: AppText.bodyMuted),
        const SizedBox(height: 32),
        TextButton(onPressed: () => setState(() => _success = false),
          child: const Text('Log Another')),
      ],
    ));

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // Duration
        Text('Session Duration (minutes)', style: AppText.label),
        const SizedBox(height: 8),
        TextField(
          controller: _durCtrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(hintText: 'e.g. 60'),
          onChanged: (v) => _duration = int.tryParse(v),
        ),
        const SizedBox(height: 20),

        // How did it feel
        Text('How did you feel?', style: AppText.label),
        const SizedBox(height: 8),
        FeelingSelectorWidget(
          selected: _feeling,
          onSelect: (v) => setState(() => _feeling = v),
        ),
        const SizedBox(height: 20),

        // Notes
        Text('Session notes (optional)', style: AppText.label),
        const SizedBox(height: 8),
        TextField(
          controller: _notesCtrl,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'e.g. Increased bench press PR, shoulder felt tight...'),
          onChanged: (v) => _notes = v,
        ),
        const SizedBox(height: 32),

        PrimaryButton(
          label: 'Save Workout',
          icon: Icons.save_outlined,
          onPressed: _log,
          loading: _logging,
        ),
      ]),
    );
  }
}

// ── TAB 3: Progress ─────────────────────────────────────────────────────────
class _ProgressTab extends StatefulWidget {
  const _ProgressTab();
  @override
  State<_ProgressTab> createState() => _ProgressTabState();
}

class _ProgressTabState extends State<_ProgressTab> {
  Map<String, dynamic>? _stats;
  List<Map<String, dynamic>> _pbs = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([
        api.getWorkoutStats(),
        api.getPersonalBests(),
      ]);
      setState(() {
        _stats = results[0] as Map<String, dynamic>;
        _pbs   = results[1] as List<Map<String, dynamic>>;
      });
    } catch (_) { }
    finally { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        // Stats summary
        if (_stats != null) ...[
          Row(children: [
            Expanded(child: KPICard(
              label: 'Total Sessions',
              value: '${_stats!['total_sessions'] ?? 0}',
              icon: Icons.fitness_center,
              iconColor: AppColors.primary,
            )),
            const SizedBox(width: 12),
            Expanded(child: KPICard(
              label: 'This Week',
              value: '${_stats!['sessions_this_week'] ?? 0}',
              icon: Icons.calendar_week,
              iconColor: AppColors.green,
            )),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: KPICard(
              label: 'Current Streak',
              value: '${_stats!['current_streak_days'] ?? 0}d',
              icon: Icons.local_fire_department_outlined,
              iconColor: AppColors.amber,
            )),
            const SizedBox(width: 12),
            Expanded(child: KPICard(
              label: 'Avg Duration',
              value: _stats!['average_duration_min'] != null
                ? '${(_stats!['average_duration_min'] as num).toInt()}m' : '—',
              icon: Icons.timer_outlined,
              iconColor: AppColors.purple,
            )),
          ]),
          const SizedBox(height: 24),
        ],

        // Personal bests
        const SectionHeader(title: '🏆 Personal Bests'),
        const SizedBox(height: 12),

        if (_pbs.isEmpty)
          const EmptyState(
            icon: Icons.emoji_events_outlined,
            title: 'No personal bests yet',
            subtitle: 'Log workouts with weight and reps to track your PRs.',
          )
        else
          ..._pbs.map((pb) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: GymCard(
              child: Row(children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.amberDim, borderRadius: AppRadius.md,
                  ),
                  child: const Icon(Icons.emoji_events_outlined, color: AppColors.amber, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(pb['exercise_name'] as String,
                    style: AppText.body.copyWith(fontWeight: FontWeight.w600)),
                  Text(
                    '${pb['best_weight_kg']}kg × ${pb['best_reps']} reps',
                    style: AppText.small,
                  ),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(
                    '${pb['best_volume']?.toStringAsFixed(0)} vol',
                    style: AppText.number.copyWith(color: AppColors.amber),
                  ),
                  Text(
                    DateFormat('MMM d').format(DateTime.parse(pb['achieved_on'] as String)),
                    style: AppText.label,
                  ),
                ]),
              ]),
            ),
          )).toList(),

        const SizedBox(height: 32),
      ],
    );
  }
}
