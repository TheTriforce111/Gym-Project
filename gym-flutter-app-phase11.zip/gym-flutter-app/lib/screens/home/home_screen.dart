// lib/screens/home/home_screen.dart
//
// Home screen — member dashboard overview.
// Shows: greeting, membership status card, quick stats,
// upcoming classes, and recent activity shortcuts.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../models/models.dart';
import '../../services/api_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import 'package:intl/intl.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  User?        _user;
  Membership?  _membership;
  MemberStats? _stats;
  List<GymClass> _upcomingClasses = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([
        api.getMe(),
        api.getMyMembership().catchError((_) => null),
        api.getMyAttendanceStats().catchError((_) => MemberStats.fromJson({
          'total_visits': 0, 'visits_this_month': 0, 'visits_this_week': 0,
          'average_per_week': 0.0, 'current_streak': 0, 'longest_streak': 0,
        })),
        api.getClasses().catchError((_) => <GymClass>[]),
      ]);
      setState(() {
        _user       = results[0] as User;
        _membership = results[1] as Membership?;
        _stats      = results[2] as MemberStats;
        _upcomingClasses = (results[3] as List<GymClass>).take(3).toList();
      });
    } catch (_) { /* handled gracefully */ }
    finally { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _load,
        color: AppColors.primary,
        backgroundColor: AppColors.surface,
        child: CustomScrollView(
          slivers: [
            // ── Header / greeting ──────────────────────────────────────────
            SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 56, 20, 24),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(
                        _greeting(),
                        style: AppText.small.copyWith(color: AppColors.textMuted),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _user?.fullName.split(' ').first ?? '...',
                        style: AppText.h1,
                      ),
                    ]),
                  ),
                  // Avatar
                  if (_user != null)
                    GestureDetector(
                      onTap: () => context.push('/profile'),
                      child: UserAvatar(initials: _user!.initials, size: 44),
                    ),
                ]),
              ),
            ),

            if (_loading)
              SliverFillRemaining(
                child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
              )
            else ...[

              // ── Membership Card ────────────────────────────────────────
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _MembershipCard(membership: _membership),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 24)),

              // ── Quick Stats Row ────────────────────────────────────────
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SectionHeader(title: 'Your Stats'),
                      const SizedBox(height: 12),
                      Row(children: [
                        Expanded(child: KPICard(
                          label: 'Visits',
                          value: '${_stats?.visitsThisMonth ?? 0}',
                          sublabel: 'this month',
                          icon: Icons.check_circle_outline,
                          iconColor: AppColors.green,
                        )),
                        const SizedBox(width: 12),
                        Expanded(child: KPICard(
                          label: 'Streak',
                          value: '${_stats?.currentStreak ?? 0}d',
                          sublabel: 'current',
                          icon: Icons.local_fire_department_outlined,
                          iconColor: AppColors.amber,
                        )),
                        const SizedBox(width: 12),
                        Expanded(child: KPICard(
                          label: 'Total',
                          value: '${_stats?.totalVisits ?? 0}',
                          sublabel: 'all time',
                          icon: Icons.emoji_events_outlined,
                          iconColor: AppColors.purple,
                        )),
                      ]),
                    ],
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 24)),

              // ── Quick Actions ──────────────────────────────────────────
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SectionHeader(title: 'Quick Actions'),
                      const SizedBox(height: 12),
                      Row(children: [
                        _QuickAction(icon: Icons.qr_code_2, label: 'My QR\nCode', color: AppColors.primary,
                          onTap: () => context.go('/attendance')),
                        const SizedBox(width: 12),
                        _QuickAction(icon: Icons.fitness_center, label: 'Log\nWorkout', color: AppColors.green,
                          onTap: () => context.go('/workout')),
                        const SizedBox(width: 12),
                        _QuickAction(icon: Icons.calendar_today, label: 'Book\nClass', color: AppColors.purple,
                          onTap: () => context.go('/classes')),
                        const SizedBox(width: 12),
                        _QuickAction(icon: Icons.bar_chart, label: 'My\nProgress', color: AppColors.amber,
                          onTap: () => context.go('/workout')),
                      ]),
                    ],
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 24)),

              // ── Upcoming Classes ───────────────────────────────────────
              if (_upcomingClasses.isNotEmpty)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SectionHeader(
                          title: 'Upcoming Classes',
                          action: 'See all',
                          onAction: () => context.go('/classes'),
                        ),
                        const SizedBox(height: 12),
                        ..._upcomingClasses.map((c) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _UpcomingClassTile(gymClass: c),
                        )),
                      ],
                    ),
                  ),
                ),

              const SliverToBoxAdapter(child: SizedBox(height: 32)),
            ],
          ],
        ),
      ),
    );
  }

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning 👋';
    if (h < 17) return 'Good afternoon 👋';
    return 'Good evening 👋';
  }
}

// ── Membership Status Card ─────────────────────────────────────────────────
class _MembershipCard extends StatelessWidget {
  final Membership? membership;
  const _MembershipCard({this.membership});

  @override
  Widget build(BuildContext context) {
    if (membership == null) {
      return GymCard(
        color: AppColors.redDim,
        child: Row(children: [
          const Icon(Icons.warning_amber_outlined, color: AppColors.amber),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('No Active Membership', style: AppText.h3),
            Text('Visit reception to purchase a plan.', style: AppText.small),
          ])),
        ]),
      );
    }

    final m          = membership!;
    final isExpiring = m.isExpiringSoon;
    final cardColor  = isExpiring ? AppColors.amberDim : AppColors.primaryDim;
    final statusColor = isExpiring ? AppColors.amber : AppColors.primary;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.surface, cardColor],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: AppRadius.lg,
        border: Border.all(color: statusColor.withOpacity(0.3)),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          StatusBadge.membership(m.status.name),
          const Spacer(),
          Text(
            m.plan.name.toUpperCase(),
            style: AppText.label.copyWith(color: statusColor),
          ),
        ]),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Days Remaining', style: AppText.small),
            const SizedBox(height: 4),
            Text('${m.daysRemaining}', style: AppText.display.copyWith(
              color: isExpiring ? AppColors.amber : AppColors.textPrimary,
            )),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('Expires', style: AppText.small),
            const SizedBox(height: 4),
            Text(
              DateFormat('MMM d, yyyy').format(m.endDate),
              style: AppText.body.copyWith(fontWeight: FontWeight.w600),
            ),
          ]),
        ]),
        // Progress bar
        const SizedBox(height: 16),
        ClipRRect(
          borderRadius: AppRadius.full,
          child: LinearProgressIndicator(
            value: m.daysRemaining / (m.plan == MembershipPlan.yearly ? 365 :
                   m.plan == MembershipPlan.quarterly ? 90 : 30),
            backgroundColor: AppColors.border,
            valueColor: AlwaysStoppedAnimation(statusColor),
            minHeight: 4,
          ),
        ),
        if (isExpiring) ...[
          const SizedBox(height: 12),
          Text(
            '⚠️ Expiring soon — renew at reception to avoid losing access.',
            style: AppText.small.copyWith(color: AppColors.amber),
          ),
        ],
      ]),
    );
  }
}

// ── Quick Action Button ────────────────────────────────────────────────────
class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _QuickAction({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: AppRadius.lg,
            border: Border.all(color: color.withOpacity(0.25)),
          ),
          child: Column(children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 6),
            Text(label, style: AppText.label.copyWith(
              color: color, fontSize: 10, letterSpacing: 0,
            ), textAlign: TextAlign.center),
          ]),
        ),
      ),
    );
  }
}

// ── Upcoming Class Tile ────────────────────────────────────────────────────
class _UpcomingClassTile extends StatelessWidget {
  final GymClass gymClass;
  const _UpcomingClassTile({required this.gymClass});

  @override
  Widget build(BuildContext context) {
    final timeStr = DateFormat('EEE, MMM d · HH:mm').format(gymClass.startTime);
    return GymCard(
      onTap: () => context.push('/classes/${gymClass.id}'),
      child: Row(children: [
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            color: AppColors.purpleDim,
            borderRadius: AppRadius.md,
          ),
          child: const Icon(Icons.self_improvement, color: AppColors.purple, size: 22),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(gymClass.name, style: AppText.body.copyWith(fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(timeStr, style: AppText.small),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('${gymClass.spotsRemaining} left', style: AppText.small.copyWith(
            color: gymClass.isFull ? AppColors.red : AppColors.green,
          )),
          const SizedBox(height: 4),
          StatusBadge.classStatus(gymClass.status),
        ]),
      ]),
    );
  }
}
