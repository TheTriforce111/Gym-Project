// lib/theme/app_theme.dart
//
// GymOS App Design System
//
// Design direction: dark gym aesthetic matching the admin dashboard.
// Electric blue primary, near-black surfaces, sharp typography.
// Consistent spacing scale: 4, 8, 12, 16, 20, 24, 32, 48dp.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ────────────────────────────────────────────────────────────────────────────
// COLOR PALETTE
// ────────────────────────────────────────────────────────────────────────────
class AppColors {
  // Brand
  static const primary    = Color(0xFF3B6BFF);  // Electric blue — CTAs, active
  static const primaryDim = Color(0x263B6BFF);  // 15% blue — tinted backgrounds

  // Backgrounds
  static const bg         = Color(0xFF0E0E16);  // App background
  static const surface    = Color(0xFF16161F);  // Card / bottom sheet
  static const surfaceAlt = Color(0xFF1E1E2A);  // Elevated surfaces
  static const border     = Color(0xFF2A2A3A);  // Dividers, card borders

  // Semantic colors
  static const green  = Color(0xFF00D97E);  // Success, active status
  static const red    = Color(0xFFFF3B5C);  // Error, danger, expired
  static const amber  = Color(0xFFFFB020);  // Warning, expiring soon
  static const purple = Color(0xFF9B59B6);  // Classes, workout

  // Text
  static const textPrimary = Color(0xFFF0F0F8);   // Main text
  static const textMuted   = Color(0xFF8888A8);   // Secondary text
  static const textSubtle  = Color(0xFF4A4A6A);   // Placeholder, disabled

  // Tinted semantic surfaces
  static const greenDim  = Color(0x1A00D97E);
  static const redDim    = Color(0x1AFF3B5C);
  static const amberDim  = Color(0x1AFFB020);
  static const purpleDim = Color(0x1A9B59B6);

  AppColors._();
}

// ────────────────────────────────────────────────────────────────────────────
// TEXT STYLES
// ────────────────────────────────────────────────────────────────────────────
class AppText {
  // Display — large KPI numbers
  static const display = TextStyle(
    fontSize: 36, fontWeight: FontWeight.w800,
    color: AppColors.textPrimary, letterSpacing: -1,
    fontFeatures: [FontFeature.tabularFigures()],
  );

  // Headings
  static const h1 = TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textPrimary, letterSpacing: -0.5);
  static const h2 = TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimary, letterSpacing: -0.3);
  static const h3 = TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textPrimary);

  // Body
  static const body      = TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: AppColors.textPrimary);
  static const bodyMuted = TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: AppColors.textMuted);
  static const small     = TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: AppColors.textMuted);
  static const label     = TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textMuted, letterSpacing: 0.8);

  // Numeric / mono
  static const number = TextStyle(
    fontSize: 14, fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
    fontFeatures: [FontFeature.tabularFigures()],
  );

  AppText._();
}

// ────────────────────────────────────────────────────────────────────────────
// THEME
// ────────────────────────────────────────────────────────────────────────────
class AppTheme {
  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    fontFamily: 'Inter',

    // Colors
    colorScheme: const ColorScheme.dark(
      primary:    AppColors.primary,
      surface:    AppColors.surface,
      background: AppColors.bg,
      error:      AppColors.red,
      onPrimary:  Colors.white,
      onSurface:  AppColors.textPrimary,
    ),
    scaffoldBackgroundColor: AppColors.bg,

    // App bar — transparent with no elevation
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: AppText.h3,
      iconTheme: IconThemeData(color: AppColors.textPrimary),
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
    ),

    // Cards
    cardTheme: CardTheme(
      color: AppColors.surface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: AppColors.border, width: 1),
      ),
      margin: EdgeInsets.zero,
    ),

    // Elevated button (primary CTA)
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
      ),
    ),

    // Text button
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: AppColors.primary,
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
      ),
    ),

    // Input fields
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.surfaceAlt,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.red),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: const TextStyle(color: AppColors.textSubtle, fontSize: 14),
      labelStyle: const TextStyle(color: AppColors.textMuted),
    ),

    // Bottom navigation
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.surface,
      indicatorColor: AppColors.primaryDim,
      labelTextStyle: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.primary);
        }
        return const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: AppColors.textMuted);
      }),
      iconTheme: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return const IconThemeData(color: AppColors.primary, size: 22);
        }
        return const IconThemeData(color: AppColors.textMuted, size: 22);
      }),
    ),

    // Divider
    dividerTheme: const DividerThemeData(color: AppColors.border, thickness: 1, space: 1),

    // Chip
    chipTheme: ChipThemeData(
      backgroundColor: AppColors.surfaceAlt,
      selectedColor: AppColors.primaryDim,
      labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      side: const BorderSide(color: AppColors.border),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    ),

    // Bottom sheet
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: AppColors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      dragHandleColor: AppColors.border,
    ),

    // Snackbar
    snackBarTheme: SnackBarThemeData(
      backgroundColor: AppColors.surfaceAlt,
      contentTextStyle: const TextStyle(color: AppColors.textPrimary),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      behavior: SnackBarBehavior.floating,
    ),
  );

  AppTheme._();
}

// ────────────────────────────────────────────────────────────────────────────
// SPACING CONSTANTS
// ────────────────────────────────────────────────────────────────────────────
class AppSpacing {
  static const xs  = 4.0;
  static const sm  = 8.0;
  static const md  = 16.0;
  static const lg  = 24.0;
  static const xl  = 32.0;
  static const xxl = 48.0;

  static const pagePadding = EdgeInsets.symmetric(horizontal: 20, vertical: 16);
  static const cardPadding = EdgeInsets.all(16);

  AppSpacing._();
}

// ────────────────────────────────────────────────────────────────────────────
// BORDER RADIUS
// ────────────────────────────────────────────────────────────────────────────
class AppRadius {
  static const sm  = BorderRadius.all(Radius.circular(8));
  static const md  = BorderRadius.all(Radius.circular(12));
  static const lg  = BorderRadius.all(Radius.circular(16));
  static const xl  = BorderRadius.all(Radius.circular(24));
  static const full = BorderRadius.all(Radius.circular(999));

  AppRadius._();
}
