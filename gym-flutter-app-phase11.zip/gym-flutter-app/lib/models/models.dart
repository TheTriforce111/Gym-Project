// lib/models/models.dart
//
// Data models matching the FastAPI backend Pydantic schemas.
// All fromJson constructors parse the API response format.
// All dates come from API as ISO 8601 strings — parsed to DateTime.

// ────────────────────────────────────────────────────────────────────────────
// AUTH
// ────────────────────────────────────────────────────────────────────────────

class AuthTokens {
  final String accessToken;
  final String refreshToken;

  const AuthTokens({required this.accessToken, required this.refreshToken});

  factory AuthTokens.fromJson(Map<String, dynamic> json) => AuthTokens(
    accessToken:  json['access_token']  as String,
    refreshToken: json['refresh_token'] as String,
  );
}

// ────────────────────────────────────────────────────────────────────────────
// USER
// ────────────────────────────────────────────────────────────────────────────

enum UserRole { admin, trainer, member }

class User {
  final int id;
  final String fullName;
  final String email;
  final String? phone;
  final UserRole role;
  final bool isActive;
  final bool isVerified;
  final DateTime createdAt;

  const User({
    required this.id,
    required this.fullName,
    required this.email,
    this.phone,
    required this.role,
    required this.isActive,
    required this.isVerified,
    required this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    id:         json['id']         as int,
    fullName:   json['full_name']  as String,
    email:      json['email']      as String,
    phone:      json['phone']      as String?,
    role:       UserRole.values.firstWhere((r) => r.name == json['role']),
    isActive:   json['is_active']  as bool,
    isVerified: json['is_verified'] as bool,
    createdAt:  DateTime.parse(json['created_at'] as String),
  );

  /// Initials for avatar display: "John Doe" → "JD"
  String get initials {
    final parts = fullName.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return fullName.isNotEmpty ? fullName[0].toUpperCase() : '?';
  }
}

// ────────────────────────────────────────────────────────────────────────────
// MEMBERSHIP
// ────────────────────────────────────────────────────────────────────────────

enum MembershipPlan   { monthly, quarterly, yearly, custom }
enum MembershipStatus { active, expired, frozen, cancelled }

class Membership {
  final int id;
  final int userId;
  final MembershipPlan plan;
  final MembershipStatus status;
  final DateTime startDate;
  final DateTime endDate;
  final double pricePaid;
  final String currency;
  final int daysRemaining;
  final bool isValid;
  final bool isExpiringSoon;
  final int totalFrozenDays;
  final String? notes;

  const Membership({
    required this.id,
    required this.userId,
    required this.plan,
    required this.status,
    required this.startDate,
    required this.endDate,
    required this.pricePaid,
    required this.currency,
    required this.daysRemaining,
    required this.isValid,
    required this.isExpiringSoon,
    required this.totalFrozenDays,
    this.notes,
  });

  factory Membership.fromJson(Map<String, dynamic> json) => Membership(
    id:              json['id']               as int,
    userId:          json['user_id']          as int,
    plan:            MembershipPlan.values.firstWhere((p) => p.name == json['plan']),
    status:          MembershipStatus.values.firstWhere((s) => s.name == json['status']),
    startDate:       DateTime.parse(json['start_date'] as String),
    endDate:         DateTime.parse(json['end_date']   as String),
    pricePaid:       (json['price_paid'] as num).toDouble(),
    currency:        json['currency']         as String,
    daysRemaining:   json['days_remaining']   as int,
    isValid:         json['is_valid']         as bool,
    isExpiringSoon:  json['is_expiring_soon'] as bool,
    totalFrozenDays: json['total_frozen_days'] as int,
    notes:           json['notes']            as String?,
  );
}

// ────────────────────────────────────────────────────────────────────────────
// WORKOUT
// ────────────────────────────────────────────────────────────────────────────

enum MuscleGroup { chest, back, shoulders, biceps, triceps, legs, glutes, core, cardio, full_body, other }
enum DifficultyLevel { beginner, intermediate, advanced }

class Exercise {
  final int id;
  final String name;
  final String? description;
  final String? instructions;
  final MuscleGroup muscleGroup;
  final String? equipment;
  final DifficultyLevel difficulty;
  final String? videoUrl;

  const Exercise({
    required this.id,
    required this.name,
    this.description,
    this.instructions,
    required this.muscleGroup,
    this.equipment,
    required this.difficulty,
    this.videoUrl,
  });

  factory Exercise.fromJson(Map<String, dynamic> json) => Exercise(
    id:           json['id']          as int,
    name:         json['name']        as String,
    description:  json['description'] as String?,
    instructions: json['instructions'] as String?,
    muscleGroup:  MuscleGroup.values.firstWhere(
      (m) => m.name == (json['muscle_group'] as String).replaceAll(' ', '_'),
      orElse: () => MuscleGroup.other,
    ),
    equipment:    json['equipment']   as String?,
    difficulty:   DifficultyLevel.values.firstWhere(
      (d) => d.name == json['difficulty'],
      orElse: () => DifficultyLevel.intermediate,
    ),
    videoUrl:     json['video_url']   as String?,
  );
}

class WorkoutEntry {
  final int id;
  final int exerciseId;
  final Exercise exercise;
  final int sets;
  final int? reps;
  final double? weightKg;
  final int? restSeconds;
  final String? notes;
  final int orderIndex;

  const WorkoutEntry({
    required this.id,
    required this.exerciseId,
    required this.exercise,
    required this.sets,
    this.reps,
    this.weightKg,
    this.restSeconds,
    this.notes,
    required this.orderIndex,
  });

  factory WorkoutEntry.fromJson(Map<String, dynamic> json) => WorkoutEntry(
    id:          json['id']           as int,
    exerciseId:  json['exercise_id']  as int,
    exercise:    Exercise.fromJson(json['exercise'] as Map<String, dynamic>),
    sets:        json['sets']         as int,
    reps:        json['reps']         as int?,
    weightKg:    (json['weight_kg'] as num?)?.toDouble(),
    restSeconds: json['rest_seconds'] as int?,
    notes:       json['notes']        as String?,
    orderIndex:  json['order_index']  as int,
  );
}

class WorkoutPlan {
  final int id;
  final String name;
  final int userId;
  final int createdBy;
  final String? description;
  final String difficulty;
  final String status;
  final String? goal;
  final int totalExercises;
  final List<WorkoutEntry> entries;

  const WorkoutPlan({
    required this.id,
    required this.name,
    required this.userId,
    required this.createdBy,
    this.description,
    required this.difficulty,
    required this.status,
    this.goal,
    required this.totalExercises,
    required this.entries,
  });

  factory WorkoutPlan.fromJson(Map<String, dynamic> json) => WorkoutPlan(
    id:             json['id']               as int,
    name:           json['name']             as String,
    userId:         json['user_id']          as int,
    createdBy:      json['created_by']       as int,
    description:    json['description']      as String?,
    difficulty:     json['difficulty']       as String,
    status:         json['status']           as String,
    goal:           json['goal']             as String?,
    totalExercises: json['total_exercises']  as int,
    entries:        (json['entries'] as List)
        .map((e) => WorkoutEntry.fromJson(e as Map<String, dynamic>))
        .toList(),
  );
}

class WorkoutLog {
  final int id;
  final int userId;
  final int? planId;
  final DateTime date;
  final int? durationMinutes;
  final int? overallFeeling;
  final double? bodyWeightKg;
  final String? notes;

  const WorkoutLog({
    required this.id,
    required this.userId,
    this.planId,
    required this.date,
    this.durationMinutes,
    this.overallFeeling,
    this.bodyWeightKg,
    this.notes,
  });

  factory WorkoutLog.fromJson(Map<String, dynamic> json) => WorkoutLog(
    id:              json['id']       as int,
    userId:          json['user_id']  as int,
    planId:          json['plan_id']  as int?,
    date:            DateTime.parse(json['date'] as String),
    durationMinutes: json['duration_minutes']  as int?,
    overallFeeling:  json['overall_feeling']   as int?,
    bodyWeightKg:    (json['body_weight_kg'] as num?)?.toDouble(),
    notes:           json['notes']    as String?,
  );
}

// ────────────────────────────────────────────────────────────────────────────
// GYM CLASS
// ────────────────────────────────────────────────────────────────────────────

class GymClass {
  final int id;
  final String name;
  final String category;
  final String difficulty;
  final String? description;
  final int? trainerId;
  final DateTime startTime;
  final DateTime endTime;
  final int durationMinutes;
  final String? location;
  final int maxCapacity;
  final int confirmedBookingsCount;
  final int spotsRemaining;
  final bool isFull;
  final bool isBookable;
  final String status;
  final String? whatToBring;

  const GymClass({
    required this.id,
    required this.name,
    required this.category,
    required this.difficulty,
    this.description,
    this.trainerId,
    required this.startTime,
    required this.endTime,
    required this.durationMinutes,
    this.location,
    required this.maxCapacity,
    required this.confirmedBookingsCount,
    required this.spotsRemaining,
    required this.isFull,
    required this.isBookable,
    required this.status,
    this.whatToBring,
  });

  factory GymClass.fromJson(Map<String, dynamic> json) => GymClass(
    id:                     json['id']                       as int,
    name:                   json['name']                     as String,
    category:               json['category']                 as String,
    difficulty:             json['difficulty']               as String,
    description:            json['description']              as String?,
    trainerId:              json['trainer_id']               as int?,
    startTime:              DateTime.parse(json['start_time'] as String),
    endTime:                DateTime.parse(json['end_time']   as String),
    durationMinutes:        json['duration_minutes']         as int,
    location:               json['location']                 as String?,
    maxCapacity:            json['max_capacity']             as int,
    confirmedBookingsCount: json['confirmed_bookings_count'] as int,
    spotsRemaining:         json['spots_remaining']          as int,
    isFull:                 json['is_full']                  as bool,
    isBookable:             json['is_bookable']              as bool,
    status:                 json['status']                   as String,
    whatToBring:            json['what_to_bring']            as String?,
  );
}

// ────────────────────────────────────────────────────────────────────────────
// ATTENDANCE
// ────────────────────────────────────────────────────────────────────────────

class AttendanceRecord {
  final int id;
  final int userId;
  final DateTime checkInTime;
  final DateTime? checkOutTime;
  final String method;
  final int? durationMinutes;

  const AttendanceRecord({
    required this.id,
    required this.userId,
    required this.checkInTime,
    this.checkOutTime,
    required this.method,
    this.durationMinutes,
  });

  factory AttendanceRecord.fromJson(Map<String, dynamic> json) => AttendanceRecord(
    id:              json['id']       as int,
    userId:          json['user_id']  as int,
    checkInTime:     DateTime.parse(json['check_in_time'] as String),
    checkOutTime:    json['check_out_time'] != null
        ? DateTime.parse(json['check_out_time'] as String)
        : null,
    method:          json['method']   as String,
    durationMinutes: json['duration_minutes'] as int?,
  );
}

class QRToken {
  final String token;
  final String qrImageBase64;
  final DateTime expiresAt;
  final int expiresInMinutes;

  const QRToken({
    required this.token,
    required this.qrImageBase64,
    required this.expiresAt,
    required this.expiresInMinutes,
  });

  factory QRToken.fromJson(Map<String, dynamic> json) => QRToken(
    token:            json['token']              as String,
    qrImageBase64:    json['qr_image_base64']    as String,
    expiresAt:        DateTime.parse(json['expires_at'] as String),
    expiresInMinutes: json['expires_in_minutes'] as int,
  );
}

// ────────────────────────────────────────────────────────────────────────────
// NOTIFICATION
// ────────────────────────────────────────────────────────────────────────────

class AppNotification {
  final int id;
  final String title;
  final String body;
  final String notificationType;
  final String channel;
  final String status;
  final bool isRead;
  final DateTime createdAt;

  const AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.notificationType,
    required this.channel,
    required this.status,
    required this.isRead,
    required this.createdAt,
  });

  factory AppNotification.fromJson(Map<String, dynamic> json) => AppNotification(
    id:                 json['id']                  as int,
    title:              json['title']               as String,
    body:               json['body']                as String,
    notificationType:   json['notification_type']   as String,
    channel:            json['channel']             as String,
    status:             json['status']              as String,
    isRead:             json['is_read']             as bool,
    createdAt:          DateTime.parse(json['created_at'] as String),
  );
}

// ────────────────────────────────────────────────────────────────────────────
// ANALYTICS (member-facing stats)
// ────────────────────────────────────────────────────────────────────────────

class MemberStats {
  final int totalVisits;
  final int visitsThisMonth;
  final int visitsThisWeek;
  final double averagePerWeek;
  final DateTime? lastVisit;
  final int currentStreak;
  final int longestStreak;

  const MemberStats({
    required this.totalVisits,
    required this.visitsThisMonth,
    required this.visitsThisWeek,
    required this.averagePerWeek,
    this.lastVisit,
    required this.currentStreak,
    required this.longestStreak,
  });

  factory MemberStats.fromJson(Map<String, dynamic> json) => MemberStats(
    totalVisits:     json['total_visits']     as int,
    visitsThisMonth: json['visits_this_month'] as int,
    visitsThisWeek:  json['visits_this_week']  as int,
    averagePerWeek:  (json['average_per_week'] as num).toDouble(),
    lastVisit:       json['last_visit'] != null
        ? DateTime.parse(json['last_visit'] as String) : null,
    currentStreak:   json['current_streak']   as int,
    longestStreak:   json['longest_streak']   as int,
  );
}
