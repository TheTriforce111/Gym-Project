// lib/router.dart
//
// GoRouter configuration — declarative routing with auth guards.
//
// Route structure:
//   /login          → LoginScreen
//   /register       → RegisterScreen
//   /               → Shell with bottom nav (Home, Workout, Classes, QR, Notifications)
//     /             → HomeScreen
//     /workout      → WorkoutScreen
//     /classes      → ClassesScreen
//     /attendance   → QRScreen
//     /notifications → NotificationsScreen
//     /profile       → ProfileScreen

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'screens/auth/login_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/workout/workout_screen.dart';
import 'screens/classes/classes_screen.dart';
import 'screens/attendance/qr_screen.dart';
import 'screens/notifications/notifications_screen.dart';
import 'services/api_service.dart';
import 'theme/app_theme.dart';

// ---------------------------------------------------------------------------
// Shell scaffold — bottom navigation bar
// ---------------------------------------------------------------------------
class _AppShell extends StatefulWidget {
  final Widget child;
  final GoRouterState state;
  const _AppShell({required this.child, required this.state});

  @override
  State<_AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<_AppShell> {
  static const _tabs = ['/', '/workout', '/classes', '/attendance', '/notifications'];

  int get _currentIndex {
    final path = widget.state.uri.path;
    final idx  = _tabs.indexWhere((t) => t == path);
    return idx < 0 ? 0 : idx;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: widget.child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => context.go(_tabs[i]),
        destinations: const [
          NavigationDestination(
            icon:         Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label:        'Home',
          ),
          NavigationDestination(
            icon:         Icon(Icons.fitness_center_outlined),
            selectedIcon: Icon(Icons.fitness_center_rounded),
            label:        'Workout',
          ),
          NavigationDestination(
            icon:         Icon(Icons.calendar_today_outlined),
            selectedIcon: Icon(Icons.calendar_today_rounded),
            label:        'Classes',
          ),
          NavigationDestination(
            icon:         Icon(Icons.qr_code_2_outlined),
            selectedIcon: Icon(Icons.qr_code_2_rounded),
            label:        'My QR',
          ),
          NavigationDestination(
            icon:         Icon(Icons.notifications_outlined),
            selectedIcon: Icon(Icons.notifications_rounded),
            label:        'Alerts',
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
GoRouter buildRouter() => GoRouter(
  initialLocation: '/',
  redirect: (context, state) async {
    final loggedIn    = await api.hasValidToken();
    final isAuthRoute = state.uri.path == '/login' || state.uri.path == '/register';

    if (!loggedIn && !isAuthRoute) return '/login';
    if (loggedIn  && isAuthRoute)  return '/';
    return null;
  },
  routes: [
    // ── Auth routes ──────────────────────────────────────────────────────
    GoRoute(path: '/login',    builder: (_, __) => const LoginScreen()),
    GoRoute(path: '/register', builder: (_, __) => const RegisterScreen()),

    // ── App shell with bottom navigation ─────────────────────────────────
    ShellRoute(
      builder: (context, state, child) => _AppShell(child: child, state: state),
      routes: [
        GoRoute(path: '/',              builder: (_, __) => const HomeScreen()),
        GoRoute(path: '/workout',       builder: (_, __) => const WorkoutScreen()),
        GoRoute(path: '/classes',       builder: (_, __) => const ClassesScreen()),
        GoRoute(path: '/attendance',    builder: (_, __) => const QRScreen()),
        GoRoute(path: '/notifications', builder: (_, __) => const NotificationsScreen()),
        GoRoute(path: '/profile',       builder: (_, __) => const ProfileScreen()),
      ],
    ),
  ],
);
