"""
routers/workouts.py — Workout Management API Endpoints (Phase 5)

────────────────────────────────────────────────────
EXERCISE LIBRARY
────────────────────────────────────────────────────
GET    /api/workouts/exercises                → Browse exercise library
POST   /api/workouts/exercises                → Add exercise (Trainer/Admin)
GET    /api/workouts/exercises/{id}           → Get exercise details
PATCH  /api/workouts/exercises/{id}           → Update exercise (Trainer/Admin)
DELETE /api/workouts/exercises/{id}           → Soft-delete exercise (Admin)

────────────────────────────────────────────────────
WORKOUT PLANS
────────────────────────────────────────────────────
POST   /api/workouts/plans                    → Create plan (Trainer/Admin)
GET    /api/workouts/plans/me                 → My active plans (Member)
GET    /api/workouts/plans/user/{user_id}     → Plans for a user (Trainer/Admin)
GET    /api/workouts/plans/{id}               → Get plan details
PATCH  /api/workouts/plans/{id}               → Update plan metadata
POST   /api/workouts/plans/{id}/entries       → Add exercise to existing plan
DELETE /api/workouts/plans/{id}/entries/{eid} → Remove exercise from plan

────────────────────────────────────────────────────
WORKOUT LOGS (Progress Tracking)
────────────────────────────────────────────────────
POST   /api/workouts/logs                     → Log a completed session
GET    /api/workouts/logs/me                  → My workout history
GET    /api/workouts/logs/{id}                → Get a specific session log

────────────────────────────────────────────────────
PROGRESS & ANALYTICS
────────────────────────────────────────────────────
GET    /api/workouts/progress/{exercise_id}   → Progress chart data
GET    /api/workouts/personal-bests           → All personal bests
GET    /api/workouts/stats                    → Frequency & consistency stats
"""

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin, require_trainer
from app.models.workout import DifficultyLevel, MuscleGroup, PlanStatus
from app.models.user import User
from app.schemas.workout import (
    ExerciseCreate, ExerciseResponse, ExerciseUpdate,
    ExerciseProgressResponse, WorkoutFrequencyStats,
    WorkoutLogCreate, WorkoutLogResponse, WorkoutLogSummary,
    WorkoutPlanCreate, WorkoutPlanResponse, WorkoutPlanSummary,
    WorkoutPlanUpdate, WorkoutEntryCreate, WorkoutEntryResponse,
)
from app.services.workout_service import WorkoutService

router = APIRouter()


# ====================================================================
# EXERCISE LIBRARY
# ====================================================================

@router.get(
    "/exercises",
    response_model=List[ExerciseResponse],
    summary="Browse the exercise library",
)
def list_exercises(
    muscle_group: Optional[MuscleGroup]    = Query(None, description="Filter by muscle group"),
    difficulty:   Optional[DifficultyLevel]= Query(None, description="Filter by difficulty"),
    equipment:    Optional[str]            = Query(None, description="Filter by equipment type"),
    search:       Optional[str]            = Query(None, description="Search by exercise name"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns all exercises in the gym's library.
    Supports filtering by muscle group, difficulty, equipment, and name search.

    Examples:
        /api/workouts/exercises                          → all exercises
        /api/workouts/exercises?muscle_group=chest       → chest exercises
        /api/workouts/exercises?search=squat             → exercises with "squat" in name
        /api/workouts/exercises?difficulty=beginner      → beginner-friendly exercises
        /api/workouts/exercises?equipment=Bodyweight     → no equipment needed
    """
    service = WorkoutService(db)
    return service.list_exercises(
        muscle_group=muscle_group,
        difficulty=difficulty,
        equipment=equipment,
        search=search,
    )


@router.post(
    "/exercises",
    response_model=ExerciseResponse,
    status_code=201,
    summary="Add a new exercise to the library (Trainer/Admin)",
)
def create_exercise(
    body: ExerciseCreate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Add a new exercise to the gym's exercise library.
    Trainer and Admin only.

    The exercise becomes available to all trainers to use in workout plans.
    """
    service = WorkoutService(db)
    return service.create_exercise(data=body, created_by_id=trainer.id)


@router.get(
    "/exercises/{exercise_id}",
    response_model=ExerciseResponse,
    summary="Get exercise details",
)
def get_exercise(
    exercise_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get full details for a single exercise including instructions and video link."""
    from fastapi import HTTPException
    e = db.query(__import__('app.models.workout', fromlist=['Exercise']).Exercise).filter_by(id=exercise_id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Exercise not found.")
    return e


@router.patch(
    "/exercises/{exercise_id}",
    response_model=ExerciseResponse,
    summary="Update an exercise (Trainer/Admin)",
)
def update_exercise(
    exercise_id: int,
    body: ExerciseUpdate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """Update an exercise's details (name, description, video link, etc.)."""
    service = WorkoutService(db)
    return service.update_exercise(exercise_id=exercise_id, data=body)


@router.delete(
    "/exercises/{exercise_id}",
    summary="Soft-delete an exercise (Admin)",
)
def delete_exercise(
    exercise_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Soft-delete an exercise (hides it from the library but keeps existing plan references).
    Admin only.
    """
    service = WorkoutService(db)
    service.delete_exercise(exercise_id)
    return {"message": f"Exercise #{exercise_id} has been removed from the library."}


# ====================================================================
# WORKOUT PLANS
# ====================================================================

@router.post(
    "/plans",
    response_model=WorkoutPlanResponse,
    status_code=201,
    summary="Create a workout plan for a member (Trainer/Admin)",
)
def create_plan(
    body: WorkoutPlanCreate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Create a new workout plan and assign it to a gym member.
    Trainers and admins only.

    You can include the full list of exercises in the request body,
    or create the plan first and add exercises later using the
    POST /plans/{id}/entries endpoint.

    Example body:
    ```json
    {
      "name": "Week 1 — Strength Foundation",
      "user_id": 42,
      "goal": "Build muscle mass",
      "difficulty": "intermediate",
      "sessions_per_week": 4,
      "entries": [
        {
          "exercise_id": 1,
          "sets": 4,
          "reps": 10,
          "weight_kg": 80,
          "rest_seconds": 90,
          "notes": "Control the descent"
        }
      ]
    }
    ```
    """
    service = WorkoutService(db)
    return service.create_plan(data=body, created_by=trainer)


@router.get(
    "/plans/me",
    response_model=List[WorkoutPlanSummary],
    summary="Get my assigned workout plans",
)
def get_my_plans(
    status_filter: Optional[PlanStatus] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns all workout plans assigned to the currently logged-in user.
    Members use this to see what their trainer has prescribed for them.
    """
    service = WorkoutService(db)
    return service.get_plans_for_user(
        user_id=current_user.id,
        status_filter=status_filter,
    )


@router.get(
    "/plans/user/{user_id}",
    response_model=List[WorkoutPlanSummary],
    summary="Get all plans for a specific member (Trainer/Admin)",
)
def get_plans_for_user(
    user_id: int,
    status_filter: Optional[PlanStatus] = Query(None),
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Get all workout plans for a specific member.
    Trainers use this to review what they've assigned to a member.
    """
    service = WorkoutService(db)
    return service.get_plans_for_user(
        user_id=user_id,
        status_filter=status_filter,
    )


@router.get(
    "/plans/{plan_id}",
    response_model=WorkoutPlanResponse,
    summary="Get full plan details with all exercises",
)
def get_plan(
    plan_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Get full workout plan details including all exercises with their
    sets, reps, weights, and instructions.

    Members can only view their own plans.
    Trainers and admins can view any plan.
    """
    service = WorkoutService(db)
    return service.get_plan_by_id(plan_id=plan_id, requesting_user=current_user)


@router.patch(
    "/plans/{plan_id}",
    response_model=WorkoutPlanResponse,
    summary="Update plan metadata (Trainer/Admin)",
)
def update_plan(
    plan_id: int,
    body: WorkoutPlanUpdate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Update a workout plan's name, description, goal, status, etc.
    Only the trainer who created the plan (or an admin) can edit it.
    """
    service = WorkoutService(db)
    return service.update_plan(
        plan_id=plan_id,
        data=body,
        requesting_user=trainer,
    )


@router.post(
    "/plans/{plan_id}/entries",
    response_model=WorkoutEntryResponse,
    status_code=201,
    summary="Add an exercise to an existing plan (Trainer/Admin)",
)
def add_exercise_to_plan(
    plan_id: int,
    body: WorkoutEntryCreate,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Add a new exercise to an existing workout plan.
    Use this when you want to modify a plan after it's been created.
    The exercise is appended to the end of the plan by default.
    """
    service = WorkoutService(db)
    return service.add_entry_to_plan(
        plan_id=plan_id,
        entry_data=body,
        requesting_user=trainer,
    )


@router.delete(
    "/plans/{plan_id}/entries/{entry_id}",
    summary="Remove an exercise from a plan (Trainer/Admin)",
)
def remove_exercise_from_plan(
    plan_id: int,
    entry_id: int,
    trainer: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """Remove a specific exercise from a workout plan."""
    service = WorkoutService(db)
    service.remove_entry_from_plan(
        plan_id=plan_id,
        entry_id=entry_id,
        requesting_user=trainer,
    )
    return {"message": f"Exercise entry #{entry_id} removed from plan #{plan_id}."}


# ====================================================================
# WORKOUT LOGS
# ====================================================================

@router.post(
    "/logs",
    response_model=WorkoutLogResponse,
    status_code=201,
    summary="Log a completed workout session",
)
def log_workout(
    body: WorkoutLogCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Record a completed workout session.

    Call this endpoint after finishing a workout.
    Include each exercise you performed with your actual sets, reps, and weight.

    The system will automatically detect personal bests (is_personal_best=true)
    when you beat your previous best weight × reps for any exercise.

    Example body:
    ```json
    {
      "plan_id": 5,
      "duration_minutes": 65,
      "overall_feeling": 4,
      "body_weight_kg": 82.5,
      "notes": "Great session, bench felt strong",
      "exercises": [
        {
          "exercise_id": 1,
          "workout_entry_id": 12,
          "sets_completed": 4,
          "reps_completed": 10,
          "weight_used_kg": 85,
          "rpe_actual": 8,
          "set_results": [
            {"set_number": 1, "reps": 10, "weight_kg": 85},
            {"set_number": 2, "reps": 10, "weight_kg": 85},
            {"set_number": 3, "reps":  9, "weight_kg": 85},
            {"set_number": 4, "reps":  9, "weight_kg": 85}
          ]
        }
      ]
    }
    ```
    """
    service = WorkoutService(db)
    return service.log_workout(data=body, user=current_user)


@router.get(
    "/logs/me",
    response_model=List[WorkoutLogSummary],
    summary="Get my workout history",
)
def get_my_workout_history(
    limit:   int            = Query(20, ge=1, le=100),
    plan_id: Optional[int]  = Query(None, description="Filter by specific plan"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the current user's workout history, most recent first.
    Shows a summary of each session (date, duration, feeling, exercise count).
    Use GET /logs/{id} to get full details of a specific session.
    """
    service = WorkoutService(db)
    logs = service.get_workout_history(
        user_id=current_user.id,
        limit=limit,
        plan_id=plan_id,
    )
    # Add exercise count to summary
    result = []
    for log in logs:
        result.append({
            "id":               log.id,
            "date":             log.date,
            "plan_id":          log.plan_id,
            "duration_minutes": log.duration_minutes,
            "overall_feeling":  log.overall_feeling,
            "exercise_count":   len(log.log_entries),
        })
    return result


@router.get(
    "/logs/{log_id}",
    response_model=WorkoutLogResponse,
    summary="Get full details of a specific workout session",
)
def get_workout_log(
    log_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Get full details of a single workout session including all exercises,
    sets/reps/weights logged, and any personal bests achieved.
    """
    from fastapi import HTTPException
    from app.models.workout import WorkoutLog
    log = db.query(WorkoutLog).filter(WorkoutLog.id == log_id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Workout log not found.")

    # Members can only see their own logs
    from app.models.user import UserRole
    if current_user.role == UserRole.MEMBER and log.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied.")

    return log


# ====================================================================
# PROGRESS & ANALYTICS
# ====================================================================

@router.get(
    "/progress/{exercise_id}",
    response_model=ExerciseProgressResponse,
    summary="Get progress chart data for a specific exercise",
)
def get_exercise_progress(
    exercise_id: int,
    days: int = Query(90, ge=7, le=365, description="Look-back window in days"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns a time-series of your performance for a specific exercise.
    Used by the mobile app to draw progress charts.

    Each data point includes:
    - Date of the session
    - Weight used (kg)
    - Reps completed
    - Volume (weight × reps) — the overall load metric
    - RPE (how hard it felt)

    Default window: last 90 days. Max: 365 days.
    """
    service = WorkoutService(db)
    return service.get_exercise_progress(
        user_id=current_user.id,
        exercise_id=exercise_id,
        days=days,
    )


@router.get(
    "/personal-bests",
    summary="Get all personal bests",
)
def get_personal_bests(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the user's personal best for every exercise they have tracked.
    Includes best weight, best reps, best volume, and when it was achieved.
    """
    service = WorkoutService(db)
    return service.get_personal_bests(user_id=current_user.id)


@router.get(
    "/stats",
    response_model=WorkoutFrequencyStats,
    summary="Get workout frequency and consistency stats",
)
def get_workout_stats(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns training frequency stats for the member's dashboard:
    - Total sessions ever
    - Sessions this week / this month
    - Average session duration
    - Most-trained muscle group
    - Current training streak (consecutive days)
    """
    service = WorkoutService(db)
    return service.get_frequency_stats(user_id=current_user.id)
