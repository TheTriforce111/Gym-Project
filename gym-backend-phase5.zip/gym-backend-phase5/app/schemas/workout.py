"""
schemas/workout.py — Workout System Request & Response Schemas (Phase 5)

Covers:
- Exercise CRUD schemas
- WorkoutPlan creation and response
- WorkoutLog submission (what the member actually did)
- Progress analytics response shapes
"""

import json
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, field_validator, model_validator

from app.models.workout import DifficultyLevel, MuscleGroup, PlanStatus


# ============================================================
# EXERCISE SCHEMAS
# ============================================================

class ExerciseCreate(BaseModel):
    """Body for POST /api/workouts/exercises (Trainer/Admin)"""
    name:              str
    description:       Optional[str] = None
    instructions:      Optional[str] = None
    muscle_group:      MuscleGroup   = MuscleGroup.OTHER
    secondary_muscles: Optional[str] = None
    equipment:         Optional[str] = None
    difficulty:        DifficultyLevel = DifficultyLevel.INTERMEDIATE
    video_url:         Optional[str] = None
    image_url:         Optional[str] = None

    @field_validator("name")
    @classmethod
    def name_not_empty(cls, v):
        if not v.strip():
            raise ValueError("Exercise name cannot be empty.")
        return v.strip().title()
        # .title() → "bench press" becomes "Bench Press" for consistency


class ExerciseUpdate(BaseModel):
    """Body for PATCH /api/workouts/exercises/{id} (Trainer/Admin)"""
    name:              Optional[str]            = None
    description:       Optional[str]            = None
    instructions:      Optional[str]            = None
    muscle_group:      Optional[MuscleGroup]    = None
    secondary_muscles: Optional[str]            = None
    equipment:         Optional[str]            = None
    difficulty:        Optional[DifficultyLevel]= None
    video_url:         Optional[str]            = None
    image_url:         Optional[str]            = None
    is_active:         Optional[bool]           = None


class ExerciseResponse(BaseModel):
    """Exercise details returned by the API."""
    id:                int
    name:              str
    description:       Optional[str]
    instructions:      Optional[str]
    muscle_group:      MuscleGroup
    secondary_muscles: Optional[str]
    equipment:         Optional[str]
    difficulty:        DifficultyLevel
    video_url:         Optional[str]
    image_url:         Optional[str]
    is_active:         bool
    created_at:        datetime

    class Config:
        from_attributes = True


# ============================================================
# WORKOUT PLAN SCHEMAS
# ============================================================

class WorkoutEntryCreate(BaseModel):
    """
    One exercise to add to a workout plan.
    Defines what the member should do: sets, reps, weight, rest.
    """
    exercise_id:      int
    sets:             int   = 3
    reps:             Optional[int]   = 10
    duration_seconds: Optional[int]   = None    # For time-based exercises
    weight_kg:        Optional[float] = None
    rest_seconds:     int   = 60
    tempo:            Optional[str]   = None
    rpe_target:       Optional[float] = None
    notes:            Optional[str]   = None
    order_index:      int   = 0

    @field_validator("sets")
    @classmethod
    def sets_positive(cls, v):
        if v < 1:
            raise ValueError("Sets must be at least 1.")
        return v

    @field_validator("rpe_target")
    @classmethod
    def rpe_range(cls, v):
        if v is not None and not (1 <= v <= 10):
            raise ValueError("RPE must be between 1 and 10.")
        return v


class WorkoutEntryResponse(BaseModel):
    """An exercise entry within a plan, with full exercise details."""
    id:               int
    exercise_id:      int
    sets:             int
    reps:             Optional[int]
    duration_seconds: Optional[int]
    weight_kg:        Optional[float]
    rest_seconds:     Optional[int]
    tempo:            Optional[str]
    rpe_target:       Optional[float]
    notes:            Optional[str]
    order_index:      int
    exercise:         ExerciseResponse

    class Config:
        from_attributes = True


class WorkoutPlanCreate(BaseModel):
    """Body for POST /api/workouts/plans (Trainer/Admin)"""
    name:              str
    user_id:           int               # Who to assign this plan to
    description:       Optional[str]   = None
    difficulty:        DifficultyLevel = DifficultyLevel.BEGINNER
    duration_weeks:    Optional[int]   = None
    sessions_per_week: Optional[int]   = None
    goal:              Optional[str]   = None
    notes:             Optional[str]   = None
    start_date:        Optional[datetime] = None
    end_date:          Optional[datetime] = None
    entries:           List[WorkoutEntryCreate] = []
    # entries can be empty — trainer can add exercises later

    @field_validator("name")
    @classmethod
    def name_not_empty(cls, v):
        if not v.strip():
            raise ValueError("Plan name cannot be empty.")
        return v.strip()


class WorkoutPlanUpdate(BaseModel):
    """Body for PATCH /api/workouts/plans/{id}"""
    name:              Optional[str]            = None
    description:       Optional[str]            = None
    difficulty:        Optional[DifficultyLevel]= None
    status:            Optional[PlanStatus]     = None
    duration_weeks:    Optional[int]            = None
    sessions_per_week: Optional[int]            = None
    goal:              Optional[str]            = None
    notes:             Optional[str]            = None
    end_date:          Optional[datetime]       = None


class WorkoutPlanResponse(BaseModel):
    """Full plan details including all exercises."""
    id:                int
    name:              str
    user_id:           int
    created_by:        int
    description:       Optional[str]
    difficulty:        DifficultyLevel
    status:            PlanStatus
    duration_weeks:    Optional[int]
    sessions_per_week: Optional[int]
    goal:              Optional[str]
    notes:             Optional[str]
    start_date:        Optional[datetime]
    end_date:          Optional[datetime]
    total_exercises:   int          # Computed property
    total_volume_kg:   float        # Computed property
    entries:           List[WorkoutEntryResponse] = []
    created_at:        datetime
    updated_at:        datetime

    class Config:
        from_attributes = True


class WorkoutPlanSummary(BaseModel):
    """Lightweight plan info for list views."""
    id:              int
    name:            str
    user_id:         int
    difficulty:      DifficultyLevel
    status:          PlanStatus
    goal:            Optional[str]
    total_exercises: int
    created_at:      datetime

    class Config:
        from_attributes = True


# ============================================================
# WORKOUT LOG SCHEMAS
# ============================================================

class SetResult(BaseModel):
    """
    Performance data for a single set.
    Stored as JSON inside WorkoutLogEntry.set_results.
    """
    set_number: int
    reps:       Optional[int]   = None
    weight_kg:  Optional[float] = None
    duration_s: Optional[int]   = None   # For time-based sets
    rpe:        Optional[float] = None   # How hard this specific set felt
    completed:  bool = True              # False = set was skipped/failed


class WorkoutLogEntryCreate(BaseModel):
    """
    Performance data for one exercise in a session.
    The member fills this in after completing each exercise.
    """
    exercise_id:      int
    workout_entry_id: Optional[int]   = None
    sets_completed:   Optional[int]   = None
    reps_completed:   Optional[int]   = None
    weight_used_kg:   Optional[float] = None
    duration_seconds: Optional[int]   = None
    rpe_actual:       Optional[float] = None
    set_results:      Optional[List[SetResult]] = None
    # Per-set breakdown — optional but gives the best data for progress tracking
    notes:            Optional[str]   = None

    @model_validator(mode="after")
    def serialize_set_results(self):
        """Convert set_results list to JSON string for DB storage."""
        # We store it as a string in the DB — convert here for consistency
        # The router/service handles the actual serialization
        return self


class WorkoutLogCreate(BaseModel):
    """
    Body for POST /api/workouts/logs
    Member submits this after completing a workout session.
    """
    plan_id:          Optional[int]   = None
    date:             Optional[datetime] = None
    # If not provided, defaults to now (today's session)

    duration_minutes: Optional[int]   = None
    overall_feeling:  Optional[int]   = None
    # 1 = terrible, 5 = amazing

    body_weight_kg:   Optional[float] = None
    notes:            Optional[str]   = None
    exercises:        List[WorkoutLogEntryCreate] = []
    # List of all exercises performed with their results

    @field_validator("overall_feeling")
    @classmethod
    def feeling_range(cls, v):
        if v is not None and not (1 <= v <= 5):
            raise ValueError("overall_feeling must be between 1 (bad) and 5 (great).")
        return v


class WorkoutLogEntryResponse(BaseModel):
    """One logged exercise in a session."""
    id:               int
    exercise_id:      int
    sets_completed:   Optional[int]
    reps_completed:   Optional[int]
    weight_used_kg:   Optional[float]
    duration_seconds: Optional[int]
    rpe_actual:       Optional[float]
    set_results:      Optional[str]   # JSON string
    notes:            Optional[str]
    is_personal_best: bool
    exercise:         ExerciseResponse

    class Config:
        from_attributes = True


class WorkoutLogResponse(BaseModel):
    """Full workout session log."""
    id:               int
    user_id:          int
    plan_id:          Optional[int]
    date:             datetime
    duration_minutes: Optional[int]
    overall_feeling:  Optional[int]
    body_weight_kg:   Optional[float]
    notes:            Optional[str]
    log_entries:      List[WorkoutLogEntryResponse] = []
    created_at:       datetime

    class Config:
        from_attributes = True


class WorkoutLogSummary(BaseModel):
    """Lightweight log info for history lists."""
    id:               int
    date:             datetime
    plan_id:          Optional[int]
    duration_minutes: Optional[int]
    overall_feeling:  Optional[int]
    exercise_count:   int = 0

    class Config:
        from_attributes = True


# ============================================================
# PROGRESS & ANALYTICS SCHEMAS
# ============================================================

class PersonalBestRecord(BaseModel):
    """A member's personal best for a specific exercise."""
    exercise_id:   int
    exercise_name: str
    best_weight_kg: Optional[float]
    best_reps:     Optional[int]
    best_volume:   Optional[float]   # weight × reps
    achieved_on:   datetime


class ExerciseProgressPoint(BaseModel):
    """
    One data point in a progress chart.
    Used to plot weight/reps over time for a specific exercise.
    """
    date:        datetime
    weight_kg:   Optional[float]
    reps:        Optional[int]
    volume:      Optional[float]   # weight_kg × reps (total load)
    rpe:         Optional[float]


class ExerciseProgressResponse(BaseModel):
    """Progress history for one exercise — used to draw a progress chart."""
    exercise_id:   int
    exercise_name: str
    data_points:   List[ExerciseProgressPoint]
    personal_best_kg:   Optional[float]
    personal_best_reps: Optional[int]


class WorkoutFrequencyStats(BaseModel):
    """How consistently the member has been training."""
    total_sessions:       int
    sessions_this_week:   int
    sessions_this_month:  int
    average_duration_min: Optional[float]
    most_trained_muscle:  Optional[str]
    current_streak_days:  int   # Consecutive days with at least one session
