"""
models/workout.py — Workout Management Database Models (Phase 5)

This file defines FOUR related tables that make up the workout system:

┌─────────────────────────────────────────────────────────────────┐
│  Exercise       → Library of all available exercises            │
│  WorkoutPlan    → A named plan assigned to a user               │
│  WorkoutEntry   → One exercise inside a plan (sets/reps/weight) │
│  WorkoutLog     → A completed workout session (progress record) │
│  WorkoutLogEntry→ Actual performance logged per exercise        │
└─────────────────────────────────────────────────────────────────┘

Relationship map:
  WorkoutPlan ──< WorkoutEntry >── Exercise
  WorkoutPlan ──< WorkoutLog   ──< WorkoutLogEntry

How it works end-to-end:
  1. Trainer creates an Exercise (e.g. "Bench Press")
  2. Trainer creates a WorkoutPlan for a member
  3. Trainer adds WorkoutEntries to the plan (e.g. "Bench Press — 4x10 @ 80kg")
  4. Member follows the plan and logs results as WorkoutLogEntries
  5. WorkoutLogs build the member's progress history
"""

import enum
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean, Column, DateTime, Enum,
    Float, ForeignKey, Integer, String, Text
)
from sqlalchemy.orm import relationship

from app.core.database import Base


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class MuscleGroup(str, enum.Enum):
    """
    Body part targeted by an exercise.
    Used for filtering the exercise library.
    """
    CHEST      = "chest"
    BACK       = "back"
    SHOULDERS  = "shoulders"
    BICEPS     = "biceps"
    TRICEPS    = "triceps"
    LEGS       = "legs"
    GLUTES     = "glutes"
    CORE       = "core"
    CARDIO     = "cardio"
    FULL_BODY  = "full_body"
    OTHER      = "other"


class DifficultyLevel(str, enum.Enum):
    """Difficulty rating for exercises and workout plans."""
    BEGINNER     = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED     = "advanced"


class PlanStatus(str, enum.Enum):
    """
    Lifecycle status of a workout plan.
    ACTIVE = member is currently following this plan
    COMPLETED = plan period ended
    ARCHIVED = trainer archived it (still visible but not active)
    """
    ACTIVE    = "active"
    COMPLETED = "completed"
    ARCHIVED  = "archived"


# ---------------------------------------------------------------------------
# Exercise Model — the global exercise library
# ---------------------------------------------------------------------------

class Exercise(Base):
    """
    A single exercise in the gym's exercise library.
    Shared across all workout plans — one bench press entry used everywhere.

    Maps to the 'exercises' table.
    """
    __tablename__ = "exercises"

    id           = Column(Integer, primary_key=True, index=True)
    name         = Column(String(150), unique=True, nullable=False, index=True)
    # index=True speeds up searches by name

    description  = Column(Text, nullable=True)
    # Instructions on how to perform the exercise correctly

    instructions = Column(Text, nullable=True)
    # Step-by-step form guide: "1. Lie flat on bench. 2. Grip bar shoulder-width..."

    muscle_group = Column(Enum(MuscleGroup), nullable=False, default=MuscleGroup.OTHER)
    # Primary muscle group this exercise targets

    secondary_muscles = Column(String(200), nullable=True)
    # Comma-separated secondary muscles: "triceps, shoulders"

    equipment    = Column(String(100), nullable=True)
    # e.g. "Barbell", "Dumbbells", "Cable Machine", "Bodyweight"

    difficulty   = Column(Enum(DifficultyLevel), default=DifficultyLevel.INTERMEDIATE)

    video_url    = Column(String(500), nullable=True)
    # Link to a demo video (YouTube, Vimeo, etc.)

    image_url    = Column(String(500), nullable=True)
    # Thumbnail image for the exercise card

    is_active    = Column(Boolean, default=True)
    # False = soft-deleted (hidden from library but existing plans keep it)

    created_by   = Column(Integer, ForeignKey("users.id"), nullable=True)
    # Which trainer/admin added this exercise

    created_at   = Column(DateTime, default=datetime.utcnow)
    updated_at   = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # --- Relationships ---
    creator      = relationship("User", foreign_keys=[created_by])
    plan_entries = relationship("WorkoutEntry", back_populates="exercise")

    def __repr__(self):
        return f"<Exercise name='{self.name}' muscle={self.muscle_group}>"


# ---------------------------------------------------------------------------
# WorkoutPlan Model — a plan assigned to a specific member
# ---------------------------------------------------------------------------

class WorkoutPlan(Base):
    """
    A named workout plan created by a trainer for a specific member.

    A plan contains multiple WorkoutEntries — one per exercise.
    The member follows this plan during their gym sessions.

    Maps to the 'workout_plans' table.
    """
    __tablename__ = "workout_plans"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(200), nullable=False)
    # e.g. "Week 1 — Strength Foundation", "Beginner Full Body Program"

    description = Column(Text, nullable=True)
    # Overview: "This 4-week program focuses on building foundational strength..."

    # --- Who this plan is for ---
    user_id     = Column(Integer, ForeignKey("users.id"), nullable=False)
    # The member this plan is assigned to

    # --- Who created it ---
    created_by  = Column(Integer, ForeignKey("users.id"), nullable=False)
    # The trainer or admin who built this plan

    # --- Plan properties ---
    difficulty   = Column(Enum(DifficultyLevel), default=DifficultyLevel.BEGINNER)
    status       = Column(Enum(PlanStatus),      default=PlanStatus.ACTIVE)

    duration_weeks = Column(Integer, nullable=True)
    # How many weeks this plan is designed for (e.g. 4, 8, 12 weeks)

    sessions_per_week = Column(Integer, nullable=True)
    # How many times per week the member should train (e.g. 3, 4, 5)

    goal        = Column(String(200), nullable=True)
    # e.g. "Build muscle mass", "Lose weight", "Improve endurance"

    notes       = Column(Text, nullable=True)
    # Trainer's notes for the member

    start_date  = Column(DateTime, nullable=True, default=datetime.utcnow)
    end_date    = Column(DateTime, nullable=True)
    # Optional dates — helps track if member is still on schedule

    created_at  = Column(DateTime, default=datetime.utcnow)
    updated_at  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # --- Relationships ---
    member      = relationship("User", foreign_keys=[user_id],    back_populates="workouts")
    trainer     = relationship("User", foreign_keys=[created_by])
    entries     = relationship(
        "WorkoutEntry", back_populates="plan",
        cascade="all, delete-orphan",
        # cascade: deleting a plan deletes all its entries automatically
        order_by="WorkoutEntry.order_index"
        # Entries are returned in the order the trainer set
    )
    logs        = relationship("WorkoutLog", back_populates="plan")

    @property
    def total_exercises(self) -> int:
        """Number of exercises in this plan."""
        return len(self.entries)

    @property
    def total_volume_kg(self) -> float:
        """
        Total planned volume in kg across all exercises.
        Volume = sets × reps × weight_kg
        Useful for comparing workout intensity.
        """
        return sum(
            (e.sets * e.reps * (e.weight_kg or 0))
            for e in self.entries
        )

    def __repr__(self):
        return (
            f"<WorkoutPlan id={self.id} "
            f"name='{self.name}' user_id={self.user_id}>"
        )


# ---------------------------------------------------------------------------
# WorkoutEntry Model — one exercise inside a plan
# ---------------------------------------------------------------------------

class WorkoutEntry(Base):
    """
    A single exercise prescribed within a workout plan.

    Example: "Bench Press — 4 sets × 10 reps @ 80 kg, 90s rest"

    Maps to the 'workout_entries' table.
    """
    __tablename__ = "workout_entries"

    id          = Column(Integer, primary_key=True, index=True)
    plan_id     = Column(Integer, ForeignKey("workout_plans.id"), nullable=False)
    exercise_id = Column(Integer, ForeignKey("exercises.id"),     nullable=False)

    # --- Prescription (what the trainer prescribes) ---
    sets         = Column(Integer, nullable=False, default=3)
    # Number of sets

    reps         = Column(Integer, nullable=True,  default=10)
    # Reps per set — nullable because some exercises use duration instead
    # e.g. "Plank — 3 sets × 60 seconds"

    duration_seconds = Column(Integer, nullable=True)
    # For time-based exercises: "Plank — 3 × 60 seconds"

    weight_kg    = Column(Float,   nullable=True)
    # Prescribed weight in kg. null = bodyweight or "choose appropriate weight"

    rest_seconds = Column(Integer, nullable=True, default=60)
    # Rest time between sets in seconds

    tempo        = Column(String(20), nullable=True)
    # Lift tempo: "3-1-2-0" = 3s down, 1s pause, 2s up, 0s pause
    # Advanced programming detail — optional

    rpe_target   = Column(Float, nullable=True)
    # Target RPE (Rate of Perceived Exertion) on a 1-10 scale
    # e.g. 8.0 = should feel like 8/10 difficulty

    notes        = Column(String(500), nullable=True)
    # Trainer tips: "Keep elbows tucked", "Full range of motion"

    order_index  = Column(Integer, nullable=False, default=0)
    # Position in the plan (0=first, 1=second, etc.)
    # Allows trainer to reorder exercises

    # --- Relationships ---
    plan         = relationship("WorkoutPlan", back_populates="entries")
    exercise     = relationship("Exercise",    back_populates="plan_entries")
    log_entries  = relationship("WorkoutLogEntry", back_populates="workout_entry")

    def __repr__(self):
        return (
            f"<WorkoutEntry plan_id={self.plan_id} "
            f"exercise_id={self.exercise_id} "
            f"{self.sets}x{self.reps}>"
        )


# ---------------------------------------------------------------------------
# WorkoutLog Model — a completed workout session
# ---------------------------------------------------------------------------

class WorkoutLog(Base):
    """
    Records a single gym session completed by a member.

    A WorkoutLog is the "session header" — it records when the member
    worked out and how long it took. The actual exercise performance
    is stored in WorkoutLogEntry records linked to this log.

    Maps to the 'workout_logs' table.
    """
    __tablename__ = "workout_logs"

    id          = Column(Integer, primary_key=True, index=True)
    user_id     = Column(Integer, ForeignKey("users.id"),          nullable=False)
    plan_id     = Column(Integer, ForeignKey("workout_plans.id"),  nullable=True)
    # plan_id is nullable — members can log free-form workouts not tied to a plan

    # --- Session info ---
    date             = Column(DateTime, default=datetime.utcnow, nullable=False)
    duration_minutes = Column(Integer, nullable=True)
    # How long the workout session lasted in minutes

    overall_feeling  = Column(Integer, nullable=True)
    # Self-rated session quality: 1 (terrible) to 5 (amazing)
    # Great for tracking fatigue and motivation trends

    body_weight_kg   = Column(Float, nullable=True)
    # Optional: member can record their body weight on training days
    # Builds a body weight history alongside workout history

    notes            = Column(Text, nullable=True)
    # Free-text notes: "Felt strong today", "Shoulder bothering me"

    created_at       = Column(DateTime, default=datetime.utcnow)

    # --- Relationships ---
    user        = relationship("User",        foreign_keys=[user_id])
    plan        = relationship("WorkoutPlan", back_populates="logs")
    log_entries = relationship(
        "WorkoutLogEntry", back_populates="workout_log",
        cascade="all, delete-orphan"
    )

    @property
    def total_sets_completed(self) -> int:
        """Total number of sets logged in this session."""
        return sum(len(e.set_results) for e in self.log_entries if e.set_results)

    def __repr__(self):
        return (
            f"<WorkoutLog id={self.id} "
            f"user_id={self.user_id} "
            f"date={self.date.date()}>"
        )


# ---------------------------------------------------------------------------
# WorkoutLogEntry Model — actual performance per exercise in a session
# ---------------------------------------------------------------------------

class WorkoutLogEntry(Base):
    """
    Records the actual performance for one exercise in a workout session.

    Links back to both the WorkoutLog (which session) and the WorkoutEntry
    (which prescribed exercise), then records what the member actually did.

    Example:
        Prescribed: Bench Press — 4 sets × 10 reps @ 80 kg
        Logged:     Set 1: 10 reps @ 80kg  ✅
                    Set 2: 10 reps @ 80kg  ✅
                    Set 3:  8 reps @ 80kg  (couldn't complete)
                    Set 4:  8 reps @ 80kg

    Maps to the 'workout_log_entries' table.
    """
    __tablename__ = "workout_log_entries"

    id               = Column(Integer, primary_key=True, index=True)
    workout_log_id   = Column(Integer, ForeignKey("workout_logs.id"),    nullable=False)
    workout_entry_id = Column(Integer, ForeignKey("workout_entries.id"), nullable=True)
    # nullable: allow logging exercises not in the plan (free-form additions)

    exercise_id      = Column(Integer, ForeignKey("exercises.id"), nullable=False)
    # Direct exercise link (redundant with workout_entry but needed for free-form)

    # --- Actual performance ---
    sets_completed   = Column(Integer, nullable=True)
    reps_completed   = Column(Integer, nullable=True)
    # The actual reps/sets the member managed (may differ from prescription)

    weight_used_kg   = Column(Float, nullable=True)
    # The actual weight used

    duration_seconds = Column(Integer, nullable=True)
    # For time-based exercises

    rpe_actual       = Column(Float, nullable=True)
    # How hard it actually felt (1-10)

    set_results      = Column(Text, nullable=True)
    # JSON string with per-set breakdown:
    # '[{"set":1,"reps":10,"kg":80},{"set":2,"reps":10,"kg":80},{"set":3,"reps":8,"kg":80}]'

    notes            = Column(String(500), nullable=True)
    # Per-exercise notes: "Left shoulder tight", "Personal best!"

    is_personal_best = Column(Boolean, default=False)
    # Flag set when this entry beats the user's previous best for this exercise

    # --- Relationships ---
    workout_log    = relationship("WorkoutLog",  back_populates="log_entries")
    workout_entry  = relationship("WorkoutEntry", back_populates="log_entries")
    exercise       = relationship("Exercise")

    def __repr__(self):
        return (
            f"<WorkoutLogEntry log_id={self.workout_log_id} "
            f"exercise_id={self.exercise_id} "
            f"{self.sets_completed}x{self.reps_completed}@{self.weight_used_kg}kg>"
        )
