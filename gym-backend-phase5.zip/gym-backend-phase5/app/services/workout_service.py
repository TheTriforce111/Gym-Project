"""
services/workout_service.py — Workout Business Logic (Phase 5)

This service handles:
1. Exercise library management (CRUD)
2. Workout plan creation and management
3. Logging completed workout sessions
4. Progress tracking and personal bests
5. Analytics (frequency, volume trends)

Design note:
  We separate the service from the router so that business rules
  (like personal best detection or access control checks) are
  tested independently from HTTP concerns.
"""

import json
import logging
from collections import defaultdict
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import HTTPException, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.workout import (
    DifficultyLevel, Exercise, MuscleGroup,
    PlanStatus, WorkoutEntry, WorkoutLog,
    WorkoutLogEntry, WorkoutPlan,
)
from app.models.user import User, UserRole
from app.schemas.workout import (
    ExerciseCreate, ExerciseUpdate,
    WorkoutLogCreate, WorkoutLogEntryCreate,
    WorkoutPlanCreate, WorkoutPlanUpdate,
)

logger = logging.getLogger(__name__)


class WorkoutService:
    """
    All workout-related business logic.
    Instantiate with a DB session: service = WorkoutService(db)
    """

    def __init__(self, db: Session):
        self.db = db

    # ===================================================================
    # EXERCISE LIBRARY
    # ===================================================================

    def list_exercises(
        self,
        muscle_group: Optional[MuscleGroup] = None,
        difficulty: Optional[DifficultyLevel] = None,
        equipment: Optional[str] = None,
        search: Optional[str] = None,
        active_only: bool = True,
    ) -> List[Exercise]:
        """
        Return exercises from the library with optional filters.
        Members, trainers, and admins can all browse the library.

        Filters:
          muscle_group → filter by body part
          difficulty   → beginner / intermediate / advanced
          equipment    → "Barbell", "Bodyweight", etc.
          search       → partial name match (case-insensitive)
          active_only  → hide soft-deleted exercises (default True)
        """
        query = self.db.query(Exercise)

        if active_only:
            query = query.filter(Exercise.is_active == True)
        if muscle_group:
            query = query.filter(Exercise.muscle_group == muscle_group)
        if difficulty:
            query = query.filter(Exercise.difficulty == difficulty)
        if equipment:
            query = query.filter(Exercise.equipment.ilike(f"%{equipment}%"))
        if search:
            query = query.filter(Exercise.name.ilike(f"%{search}%"))

        return query.order_by(Exercise.name).all()

    def create_exercise(
        self,
        data: ExerciseCreate,
        created_by_id: int,
    ) -> Exercise:
        """
        Add a new exercise to the library.
        Trainers and admins only. Rejects duplicate names.
        """
        # Check for duplicate name (case-insensitive)
        existing = self.db.query(Exercise).filter(
            func.lower(Exercise.name) == data.name.lower()
        ).first()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Exercise '{data.name}' already exists in the library.",
            )

        exercise = Exercise(**data.model_dump(), created_by=created_by_id)
        self.db.add(exercise)
        self.db.commit()
        self.db.refresh(exercise)

        logger.info(f"Exercise created: '{exercise.name}' by user #{created_by_id}")
        return exercise

    def update_exercise(
        self,
        exercise_id: int,
        data: ExerciseUpdate,
    ) -> Exercise:
        """Update an exercise's details. Trainers and admins only."""
        exercise = self._get_exercise_or_404(exercise_id)

        # Only update fields that were actually provided
        for field, value in data.model_dump(exclude_none=True).items():
            setattr(exercise, field, value)

        self.db.commit()
        self.db.refresh(exercise)
        return exercise

    def delete_exercise(self, exercise_id: int) -> None:
        """
        Soft-delete an exercise (set is_active=False).
        We never hard-delete exercises because existing workout plans
        and logs still reference them.
        """
        exercise = self._get_exercise_or_404(exercise_id)
        exercise.is_active = False
        self.db.commit()
        logger.info(f"Exercise #{exercise_id} soft-deleted")

    # ===================================================================
    # WORKOUT PLANS
    # ===================================================================

    def create_plan(
        self,
        data: WorkoutPlanCreate,
        created_by: User,
    ) -> WorkoutPlan:
        """
        Create a new workout plan and assign it to a member.
        Trainers and admins can create plans.

        Steps:
        1. Verify the target member exists
        2. Create the plan record
        3. Validate and add each exercise entry
        4. Set order_index if not provided
        """
        # Verify the target member exists
        member = self.db.query(User).filter(User.id == data.user_id).first()
        if not member:
            raise HTTPException(
                status_code=404,
                detail=f"User #{data.user_id} not found.",
            )

        # Create the plan
        plan_data = data.model_dump(exclude={"entries"})
        plan = WorkoutPlan(**plan_data, created_by=created_by.id)
        self.db.add(plan)
        self.db.flush()  # Get plan.id before inserting entries

        # Add each exercise entry
        for idx, entry_data in enumerate(data.entries):
            exercise = self._get_exercise_or_404(entry_data.exercise_id)

            # Auto-assign order if not provided
            if entry_data.order_index == 0 and idx > 0:
                entry_data.order_index = idx

            entry = WorkoutEntry(
                plan_id=plan.id,
                **entry_data.model_dump()
            )
            self.db.add(entry)

        self.db.commit()
        self.db.refresh(plan)

        logger.info(
            f"Plan '{plan.name}' created for user #{data.user_id} "
            f"by trainer #{created_by.id} "
            f"with {len(data.entries)} exercises"
        )
        return plan

    def update_plan(
        self,
        plan_id: int,
        data: WorkoutPlanUpdate,
        requesting_user: User,
    ) -> WorkoutPlan:
        """
        Update a workout plan's metadata.
        Only the creator or an admin can update a plan.
        """
        plan = self._get_plan_or_404(plan_id)
        self._check_plan_edit_permission(plan, requesting_user)

        for field, value in data.model_dump(exclude_none=True).items():
            setattr(plan, field, value)

        self.db.commit()
        self.db.refresh(plan)
        return plan

    def add_entry_to_plan(
        self,
        plan_id: int,
        entry_data: "WorkoutEntryCreate",
        requesting_user: User,
    ) -> WorkoutEntry:
        """
        Add a new exercise to an existing workout plan.
        Used when the trainer wants to modify a plan after creation.
        """
        plan = self._get_plan_or_404(plan_id)
        self._check_plan_edit_permission(plan, requesting_user)
        self._get_exercise_or_404(entry_data.exercise_id)

        # Append at end if order not specified
        if entry_data.order_index == 0:
            max_order = max((e.order_index for e in plan.entries), default=-1)
            entry_data.order_index = max_order + 1

        entry = WorkoutEntry(plan_id=plan_id, **entry_data.model_dump())
        self.db.add(entry)
        self.db.commit()
        self.db.refresh(entry)
        return entry

    def remove_entry_from_plan(
        self,
        plan_id: int,
        entry_id: int,
        requesting_user: User,
    ) -> None:
        """Remove an exercise from a workout plan."""
        plan = self._get_plan_or_404(plan_id)
        self._check_plan_edit_permission(plan, requesting_user)

        entry = self.db.query(WorkoutEntry).filter(
            WorkoutEntry.id == entry_id,
            WorkoutEntry.plan_id == plan_id,
        ).first()
        if not entry:
            raise HTTPException(
                status_code=404,
                detail=f"Entry #{entry_id} not found in plan #{plan_id}.",
            )

        self.db.delete(entry)
        self.db.commit()

    def get_plans_for_user(
        self,
        user_id: int,
        status_filter: Optional[PlanStatus] = None,
    ) -> List[WorkoutPlan]:
        """Get all workout plans assigned to a specific user."""
        query = self.db.query(WorkoutPlan).filter(
            WorkoutPlan.user_id == user_id
        )
        if status_filter:
            query = query.filter(WorkoutPlan.status == status_filter)
        return query.order_by(WorkoutPlan.created_at.desc()).all()

    def get_plan_by_id(
        self,
        plan_id: int,
        requesting_user: User,
    ) -> WorkoutPlan:
        """
        Get a specific plan.
        Members can only view their own plans.
        Trainers/admins can view any plan.
        """
        plan = self._get_plan_or_404(plan_id)

        if requesting_user.role == UserRole.MEMBER:
            if plan.user_id != requesting_user.id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You can only view your own workout plans.",
                )

        return plan

    # ===================================================================
    # WORKOUT LOGGING
    # ===================================================================

    def log_workout(
        self,
        data: WorkoutLogCreate,
        user: User,
    ) -> WorkoutLog:
        """
        Record a completed workout session.
        Called by the member after finishing a workout.

        Steps:
        1. Create the WorkoutLog (session header)
        2. Create WorkoutLogEntry for each exercise performed
        3. Check for personal bests on each exercise
        4. Return the full log

        Personal Best Detection:
          We compare the weight_used_kg × reps_completed (volume) against
          all previous logs for the same exercise by the same user.
          If this session beats the previous best, we flag it.
        """
        # Create the session log
        log = WorkoutLog(
            user_id=user.id,
            plan_id=data.plan_id,
            date=data.date or datetime.utcnow(),
            duration_minutes=data.duration_minutes,
            overall_feeling=data.overall_feeling,
            body_weight_kg=data.body_weight_kg,
            notes=data.notes,
        )
        self.db.add(log)
        self.db.flush()  # Need log.id before adding entries

        # Add each exercise's performance
        for exercise_data in data.exercises:
            entry = self._create_log_entry(
                log_id=log.id,
                data=exercise_data,
                user_id=user.id,
            )
            self.db.add(entry)

        self.db.commit()
        self.db.refresh(log)

        logger.info(
            f"Workout logged: user #{user.id}, "
            f"session #{log.id}, "
            f"{len(data.exercises)} exercises"
        )
        return log

    def _create_log_entry(
        self,
        log_id: int,
        data: WorkoutLogEntryCreate,
        user_id: int,
    ) -> WorkoutLogEntry:
        """
        Create one exercise log entry and detect personal bests.
        """
        # Serialize set_results list to JSON string for storage
        set_results_json = None
        if data.set_results:
            set_results_json = json.dumps(
                [s.model_dump() for s in data.set_results]
            )

        # Check if this is a personal best for this user + exercise
        is_pb = self._is_personal_best(
            user_id=user_id,
            exercise_id=data.exercise_id,
            weight_kg=data.weight_used_kg,
            reps=data.reps_completed,
        )

        entry = WorkoutLogEntry(
            workout_log_id=log_id,
            workout_entry_id=data.workout_entry_id,
            exercise_id=data.exercise_id,
            sets_completed=data.sets_completed,
            reps_completed=data.reps_completed,
            weight_used_kg=data.weight_used_kg,
            duration_seconds=data.duration_seconds,
            rpe_actual=data.rpe_actual,
            set_results=set_results_json,
            notes=data.notes,
            is_personal_best=is_pb,
        )

        if is_pb:
            logger.info(
                f"Personal best! user #{user_id}, "
                f"exercise #{data.exercise_id}, "
                f"{data.weight_used_kg}kg × {data.reps_completed} reps"
            )

        return entry

    def _is_personal_best(
        self,
        user_id: int,
        exercise_id: int,
        weight_kg: Optional[float],
        reps: Optional[int],
    ) -> bool:
        """
        Check if this performance beats the user's previous best.
        We use volume (weight × reps) as the comparison metric.
        Returns True if this is a new personal best.
        """
        if not weight_kg or not reps:
            return False  # Can't determine PB without weight and reps

        new_volume = weight_kg * reps

        # Find the best previous volume for this user + exercise
        best = (
            self.db.query(
                func.max(
                    WorkoutLogEntry.weight_used_kg * WorkoutLogEntry.reps_completed
                )
            )
            .join(WorkoutLog, WorkoutLogEntry.workout_log_id == WorkoutLog.id)
            .filter(
                WorkoutLog.user_id == user_id,
                WorkoutLogEntry.exercise_id == exercise_id,
                WorkoutLogEntry.weight_used_kg.isnot(None),
                WorkoutLogEntry.reps_completed.isnot(None),
            )
            .scalar()
        )

        return best is None or new_volume > best

    def get_workout_history(
        self,
        user_id: int,
        limit: int = 20,
        plan_id: Optional[int] = None,
    ) -> List[WorkoutLog]:
        """
        Get a user's workout history, most recent first.
        Optionally filter by plan.
        """
        query = self.db.query(WorkoutLog).filter(
            WorkoutLog.user_id == user_id
        )
        if plan_id:
            query = query.filter(WorkoutLog.plan_id == plan_id)

        return query.order_by(WorkoutLog.date.desc()).limit(limit).all()

    # ===================================================================
    # PROGRESS TRACKING
    # ===================================================================

    def get_exercise_progress(
        self,
        user_id: int,
        exercise_id: int,
        days: int = 90,
    ) -> dict:
        """
        Get progress history for a specific exercise over the last N days.
        Returns data points suitable for plotting a progress chart.

        Each data point = one logged session with weight/reps for that exercise.
        """
        exercise = self._get_exercise_or_404(exercise_id)
        cutoff   = datetime.utcnow() - timedelta(days=days)

        entries = (
            self.db.query(WorkoutLogEntry)
            .join(WorkoutLog, WorkoutLogEntry.workout_log_id == WorkoutLog.id)
            .filter(
                WorkoutLog.user_id  == user_id,
                WorkoutLogEntry.exercise_id == exercise_id,
                WorkoutLog.date >= cutoff,
            )
            .order_by(WorkoutLog.date.asc())
            .all()
        )

        data_points = []
        best_weight = None
        best_reps   = None

        for entry in entries:
            volume = None
            if entry.weight_used_kg and entry.reps_completed:
                volume = round(entry.weight_used_kg * entry.reps_completed, 2)

            data_points.append({
                "date":      entry.workout_log.date,
                "weight_kg": entry.weight_used_kg,
                "reps":      entry.reps_completed,
                "volume":    volume,
                "rpe":       entry.rpe_actual,
            })

            # Track personal bests
            if entry.weight_used_kg:
                if best_weight is None or entry.weight_used_kg > best_weight:
                    best_weight = entry.weight_used_kg
            if entry.reps_completed:
                if best_reps is None or entry.reps_completed > best_reps:
                    best_reps = entry.reps_completed

        return {
            "exercise_id":        exercise_id,
            "exercise_name":      exercise.name,
            "data_points":        data_points,
            "personal_best_kg":   best_weight,
            "personal_best_reps": best_reps,
        }

    def get_personal_bests(self, user_id: int) -> List[dict]:
        """
        Get the user's personal best for every exercise they've tracked.
        Returns a record per exercise with their best weight and reps.
        """
        # Get all log entries for this user, grouped by exercise
        entries = (
            self.db.query(WorkoutLogEntry)
            .join(WorkoutLog, WorkoutLogEntry.workout_log_id == WorkoutLog.id)
            .filter(
                WorkoutLog.user_id == user_id,
                WorkoutLogEntry.weight_used_kg.isnot(None),
                WorkoutLogEntry.reps_completed.isnot(None),
            )
            .all()
        )

        # Group by exercise and find the best performance
        bests = {}  # exercise_id → best entry
        for entry in entries:
            eid    = entry.exercise_id
            volume = entry.weight_used_kg * entry.reps_completed

            if eid not in bests or volume > (bests[eid]["volume"] or 0):
                bests[eid] = {
                    "exercise_id":    eid,
                    "exercise_name":  entry.exercise.name,
                    "best_weight_kg": entry.weight_used_kg,
                    "best_reps":      entry.reps_completed,
                    "best_volume":    round(volume, 2),
                    "achieved_on":    entry.workout_log.date,
                }

        return list(bests.values())

    def get_frequency_stats(self, user_id: int) -> dict:
        """
        Calculate workout frequency stats for the member's dashboard.
        Shows how consistently they've been training.
        """
        now        = datetime.utcnow()
        week_start = now - timedelta(days=7)
        month_start= now - timedelta(days=30)

        all_logs   = self.db.query(WorkoutLog).filter(
            WorkoutLog.user_id == user_id
        ).order_by(WorkoutLog.date.desc()).all()

        this_week  = [l for l in all_logs if l.date >= week_start]
        this_month = [l for l in all_logs if l.date >= month_start]

        # Average duration
        durations  = [l.duration_minutes for l in all_logs if l.duration_minutes]
        avg_dur    = round(sum(durations) / len(durations), 1) if durations else None

        # Most trained muscle group
        muscle_counts = defaultdict(int)
        for log in all_logs:
            for entry in log.log_entries:
                if entry.exercise and entry.exercise.muscle_group:
                    muscle_counts[entry.exercise.muscle_group.value] += 1

        most_trained = max(muscle_counts, key=muscle_counts.get) if muscle_counts else None

        # Consecutive training streak
        streak = self._calculate_streak(all_logs)

        return {
            "total_sessions":       len(all_logs),
            "sessions_this_week":   len(this_week),
            "sessions_this_month":  len(this_month),
            "average_duration_min": avg_dur,
            "most_trained_muscle":  most_trained,
            "current_streak_days":  streak,
        }

    def _calculate_streak(self, logs: List[WorkoutLog]) -> int:
        """
        Calculate the current consecutive training streak in days.
        A streak counts if the member trained at least once each day.
        """
        if not logs:
            return 0

        # Get unique training dates (normalize to date only)
        trained_dates = sorted(
            {l.date.date() for l in logs},
            reverse=True
        )

        today  = datetime.utcnow().date()
        streak = 0

        for i, d in enumerate(trained_dates):
            expected = today - timedelta(days=i)
            if d == expected:
                streak += 1
            else:
                break  # Gap found — streak ends

        return streak

    # ===================================================================
    # PRIVATE HELPERS
    # ===================================================================

    def _get_exercise_or_404(self, exercise_id: int) -> Exercise:
        e = self.db.query(Exercise).filter(Exercise.id == exercise_id).first()
        if not e:
            raise HTTPException(
                status_code=404,
                detail=f"Exercise #{exercise_id} not found.",
            )
        return e

    def _get_plan_or_404(self, plan_id: int) -> WorkoutPlan:
        p = self.db.query(WorkoutPlan).filter(WorkoutPlan.id == plan_id).first()
        if not p:
            raise HTTPException(
                status_code=404,
                detail=f"Workout plan #{plan_id} not found.",
            )
        return p

    def _check_plan_edit_permission(
        self, plan: WorkoutPlan, user: User
    ) -> None:
        """
        Only the plan's creator or an admin can edit it.
        Raises HTTP 403 if the user doesn't have permission.
        """
        if user.role == UserRole.ADMIN:
            return  # Admins can edit anything
        if plan.created_by != user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only edit plans you created.",
            )
