# 🏋️ Phase 5 — Workout Management System

A complete workout tracking system: exercise library, trainer-assigned plans, member logging, personal bests, and progress analytics.

---

## 📁 New Files in Phase 5

```
app/
├── models/
│   └── workout.py              ← 5 models: Exercise, WorkoutPlan, WorkoutEntry,
│                                           WorkoutLog, WorkoutLogEntry
├── schemas/
│   └── workout.py              ← Full schemas + progress analytics shapes
├── routers/
│   └── workouts.py             ← 18 endpoints covering the full system
└── services/
    └── workout_service.py      ← All business logic incl. PB detection & analytics

tests/
└── test_workouts.py            ← Full test suite (exercises, plans, logs, progress)
```

---

## 📋 Endpoints

### Exercise Library
| Method | Endpoint                        | Auth          | Description                   |
|--------|---------------------------------|---------------|-------------------------------|
| GET    | `/api/workouts/exercises`       | Any           | Browse library (filterable)   |
| POST   | `/api/workouts/exercises`       | Trainer/Admin | Add new exercise              |
| GET    | `/api/workouts/exercises/{id}`  | Any           | Get exercise details          |
| PATCH  | `/api/workouts/exercises/{id}`  | Trainer/Admin | Update exercise               |
| DELETE | `/api/workouts/exercises/{id}`  | Admin         | Soft-delete exercise          |

### Workout Plans
| Method | Endpoint                              | Auth          | Description                  |
|--------|---------------------------------------|---------------|------------------------------|
| POST   | `/api/workouts/plans`                 | Trainer/Admin | Create plan for member        |
| GET    | `/api/workouts/plans/me`              | Any           | My assigned plans             |
| GET    | `/api/workouts/plans/user/{id}`       | Trainer/Admin | Plans for a member            |
| GET    | `/api/workouts/plans/{id}`            | Any           | Full plan with exercises      |
| PATCH  | `/api/workouts/plans/{id}`            | Trainer/Admin | Update plan metadata          |
| POST   | `/api/workouts/plans/{id}/entries`    | Trainer/Admin | Add exercise to plan          |
| DELETE | `/api/workouts/plans/{id}/entries/{eid}` | Trainer/Admin | Remove exercise from plan   |

### Workout Logs
| Method | Endpoint                    | Auth | Description                     |
|--------|-----------------------------|------|---------------------------------|
| POST   | `/api/workouts/logs`        | Any  | Log a completed session         |
| GET    | `/api/workouts/logs/me`     | Any  | My workout history              |
| GET    | `/api/workouts/logs/{id}`   | Any  | Full session details            |

### Progress & Analytics
| Method | Endpoint                            | Auth | Description                   |
|--------|-------------------------------------|------|-------------------------------|
| GET    | `/api/workouts/progress/{exercise}` | Any  | Progress chart data           |
| GET    | `/api/workouts/personal-bests`      | Any  | All personal bests            |
| GET    | `/api/workouts/stats`               | Any  | Frequency & consistency stats |

---

## 🗃️ Data Model

```
Exercise (library)
    ↕ used in
WorkoutEntry ──── belongs to ──── WorkoutPlan (assigned to a User by a Trainer)
    ↕ referenced by
WorkoutLogEntry ── belongs to ── WorkoutLog (a completed session by a User)
```

---

## 🏆 Personal Best Detection

Every time a member logs an exercise, the system checks whether they beat their previous best using **volume** (weight × reps) as the comparison metric:

```python
new_volume = weight_used_kg × reps_completed

if new_volume > all_previous_volumes:
    is_personal_best = True  # 🎉
```

This is flagged in the log entry and shown in the mobile app.

---

## 📊 Progress Charts

The `/progress/{exercise_id}` endpoint returns time-series data ready for charting:

```json
{
  "exercise_name": "Bench Press",
  "personal_best_kg": 90.0,
  "data_points": [
    {"date": "2025-01-05", "weight_kg": 70, "reps": 10, "volume": 700},
    {"date": "2025-01-12", "weight_kg": 75, "reps": 10, "volume": 750},
    {"date": "2025-01-19", "weight_kg": 80, "reps": 10, "volume": 800},
    {"date": "2025-01-26", "weight_kg": 85, "reps": 10, "volume": 850}
  ]
}
```

Use this in the Flutter app with fl_chart or charts_flutter to draw the progress line.

---

## 📱 Mobile App Usage (Flutter)

```dart
// Log a workout after the session
await api.post('/api/workouts/logs', body: {
  'plan_id': currentPlan.id,
  'duration_minutes': 65,
  'overall_feeling': 4,
  'exercises': completedExercises.map((e) => e.toJson()).toList(),
});

// Check for personal bests in the response
for (var entry in response['log_entries']) {
  if (entry['is_personal_best']) {
    showCelebrationAnimation(entry['exercise']['name']);
  }
}
```

---

## ➡️ Next: Phase 6 — Class Scheduling System

Adds gym class management: creating classes, assigning trainers, booking by members, capacity enforcement, and cancellation.
