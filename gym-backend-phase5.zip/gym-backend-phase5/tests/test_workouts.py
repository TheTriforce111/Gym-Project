"""
tests/test_workouts.py — Workout System Tests (Phase 5)

Run with:
    pytest tests/test_workouts.py -v

Tests cover:
- Exercise library CRUD
- Workout plan creation and management
- Access control (members can't create plans, etc.)
- Logging workouts with set-by-set data
- Personal best detection
- Progress tracking data
- Workout frequency stats
"""

import pytest
from datetime import datetime, timedelta
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.core.security import hash_password
from app.models.user import User, UserRole
from app.models.workout import Exercise, MuscleGroup, DifficultyLevel, WorkoutPlan

SQLALCHEMY_DATABASE_URL = "sqlite:///./test_workouts.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
Base.metadata.create_all(bind=engine)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield


@pytest.fixture
def db():
    s = TestingSessionLocal()
    yield s
    s.close()


def _create_user(db, email, role):
    u = User(
        full_name=f"Test {role}",
        email=email,
        hashed_password=hash_password("Test1234"),
        role=role,
        is_active=True,
    )
    db.add(u)
    db.commit()
    resp = client.post("/api/auth/login", json={"email": email, "password": "Test1234"})
    return {"user": u, "token": resp.json()["access_token"]}


@pytest.fixture
def admin(db):   return _create_user(db, "admin@gym.com",   UserRole.ADMIN)

@pytest.fixture
def trainer(db): return _create_user(db, "trainer@gym.com", UserRole.TRAINER)

@pytest.fixture
def member(db):  return _create_user(db, "member@gym.com",  UserRole.MEMBER)


@pytest.fixture
def bench_press(db, trainer):
    """Create a sample exercise in the library."""
    resp = client.post(
        "/api/workouts/exercises",
        headers={"Authorization": f"Bearer {trainer['token']}"},
        json={
            "name": "Bench Press",
            "muscle_group": "chest",
            "equipment": "Barbell",
            "difficulty": "intermediate",
        }
    )
    assert resp.status_code == 201
    return resp.json()


@pytest.fixture
def squat(db, trainer):
    resp = client.post(
        "/api/workouts/exercises",
        headers={"Authorization": f"Bearer {trainer['token']}"},
        json={"name": "Squat", "muscle_group": "legs", "equipment": "Barbell"}
    )
    return resp.json()


# ---------------------------------------------------------------------------
# Exercise Library Tests
# ---------------------------------------------------------------------------

class TestExerciseLibrary:

    def test_trainer_can_create_exercise(self, trainer):
        """Trainers can add exercises to the library."""
        resp = client.post(
            "/api/workouts/exercises",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={
                "name": "Pull-up",
                "muscle_group": "back",
                "equipment": "Bodyweight",
                "difficulty": "intermediate",
            }
        )
        assert resp.status_code == 201
        assert resp.json()["name"] == "Pull-Up"   # Title-cased

    def test_member_cannot_create_exercise(self, member):
        """Regular members cannot add exercises."""
        resp = client.post(
            "/api/workouts/exercises",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={"name": "Push-up", "muscle_group": "chest"}
        )
        assert resp.status_code == 403

    def test_duplicate_exercise_rejected(self, trainer, bench_press):
        """Cannot add an exercise with a name that already exists."""
        resp = client.post(
            "/api/workouts/exercises",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={"name": "Bench Press", "muscle_group": "chest"}
        )
        assert resp.status_code == 409   # Conflict

    def test_filter_by_muscle_group(self, trainer, bench_press, squat):
        """Filtering exercises by muscle group works correctly."""
        resp = client.get(
            "/api/workouts/exercises?muscle_group=chest",
            headers={"Authorization": f"Bearer {trainer['token']}"}
        )
        assert resp.status_code == 200
        names = [e["name"] for e in resp.json()]
        assert "Bench Press" in names
        assert "Squat" not in names

    def test_search_by_name(self, trainer, bench_press, squat):
        """Partial name search finds the right exercises."""
        resp = client.get(
            "/api/workouts/exercises?search=bench",
            headers={"Authorization": f"Bearer {trainer['token']}"}
        )
        assert resp.status_code == 200
        assert len(resp.json()) == 1
        assert resp.json()[0]["name"] == "Bench Press"

    def test_update_exercise(self, trainer, bench_press):
        """Trainers can update exercise details."""
        resp = client.patch(
            f"/api/workouts/exercises/{bench_press['id']}",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={"video_url": "https://youtube.com/bench-press-tutorial"}
        )
        assert resp.status_code == 200
        assert resp.json()["video_url"] == "https://youtube.com/bench-press-tutorial"


# ---------------------------------------------------------------------------
# Workout Plan Tests
# ---------------------------------------------------------------------------

class TestWorkoutPlans:

    def test_trainer_creates_plan_with_exercises(self, trainer, member, bench_press, squat):
        """Trainer can create a full workout plan with exercises."""
        resp = client.post(
            "/api/workouts/plans",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={
                "name": "Week 1 Strength",
                "user_id": member["user"].id,
                "goal": "Build strength",
                "difficulty": "intermediate",
                "sessions_per_week": 3,
                "entries": [
                    {
                        "exercise_id": bench_press["id"],
                        "sets": 4,
                        "reps": 8,
                        "weight_kg": 80,
                        "rest_seconds": 120,
                        "order_index": 0,
                    },
                    {
                        "exercise_id": squat["id"],
                        "sets": 4,
                        "reps": 8,
                        "weight_kg": 100,
                        "rest_seconds": 120,
                        "order_index": 1,
                    },
                ]
            }
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "Week 1 Strength"
        assert data["total_exercises"] == 2
        assert len(data["entries"]) == 2
        assert data["entries"][0]["exercise"]["name"] == "Bench Press"

    def test_member_cannot_create_plan(self, member):
        """Regular members cannot create workout plans."""
        resp = client.post(
            "/api/workouts/plans",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={"name": "My Plan", "user_id": member["user"].id}
        )
        assert resp.status_code == 403

    def test_member_sees_own_plans(self, trainer, member, bench_press):
        """Members can list their own assigned plans."""
        # Trainer creates plan for member
        client.post(
            "/api/workouts/plans",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={
                "name": "Member Plan",
                "user_id": member["user"].id,
                "entries": []
            }
        )
        resp = client.get(
            "/api/workouts/plans/me",
            headers={"Authorization": f"Bearer {member['token']}"}
        )
        assert resp.status_code == 200
        assert len(resp.json()) == 1
        assert resp.json()[0]["name"] == "Member Plan"

    def test_member_cannot_view_other_members_plan(self, trainer, member, admin, db):
        """A member cannot view another member's workout plan."""
        # Create a second member
        other = _create_user(db, "other@gym.com", UserRole.MEMBER)

        # Trainer creates plan for the other member
        resp = client.post(
            "/api/workouts/plans",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={"name": "Other's Plan", "user_id": other["user"].id}
        )
        plan_id = resp.json()["id"]

        # First member tries to view it — should be denied
        resp = client.get(
            f"/api/workouts/plans/{plan_id}",
            headers={"Authorization": f"Bearer {member['token']}"}
        )
        assert resp.status_code == 403

    def test_add_exercise_to_existing_plan(self, trainer, member, bench_press, squat):
        """Trainer can add an exercise to a plan after creation."""
        plan_resp = client.post(
            "/api/workouts/plans",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={"name": "Test Plan", "user_id": member["user"].id, "entries": []}
        )
        plan_id = plan_resp.json()["id"]

        add_resp = client.post(
            f"/api/workouts/plans/{plan_id}/entries",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={"exercise_id": bench_press["id"], "sets": 3, "reps": 12}
        )
        assert add_resp.status_code == 201
        assert add_resp.json()["exercise"]["name"] == "Bench Press"


# ---------------------------------------------------------------------------
# Workout Logging Tests
# ---------------------------------------------------------------------------

class TestWorkoutLogging:

    def test_member_logs_workout(self, trainer, member, bench_press):
        """Member can log a completed workout session."""
        resp = client.post(
            "/api/workouts/logs",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={
                "duration_minutes": 60,
                "overall_feeling": 4,
                "body_weight_kg": 82.5,
                "notes": "Great session!",
                "exercises": [
                    {
                        "exercise_id": bench_press["id"],
                        "sets_completed": 4,
                        "reps_completed": 10,
                        "weight_used_kg": 80.0,
                        "rpe_actual": 7.5,
                        "set_results": [
                            {"set_number": 1, "reps": 10, "weight_kg": 80},
                            {"set_number": 2, "reps": 10, "weight_kg": 80},
                            {"set_number": 3, "reps": 10, "weight_kg": 80},
                            {"set_number": 4, "reps": 10, "weight_kg": 80},
                        ]
                    }
                ]
            }
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["duration_minutes"] == 60
        assert data["overall_feeling"] == 4
        assert len(data["log_entries"]) == 1

    def test_personal_best_detected(self, member, bench_press):
        """System flags a personal best when user beats their previous record."""
        # First session — 70kg × 10 reps
        client.post(
            "/api/workouts/logs",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={
                "exercises": [{
                    "exercise_id": bench_press["id"],
                    "sets_completed": 3,
                    "reps_completed": 10,
                    "weight_used_kg": 70.0,
                }]
            }
        )

        # Second session — 80kg × 10 reps (heavier = personal best)
        resp = client.post(
            "/api/workouts/logs",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={
                "exercises": [{
                    "exercise_id": bench_press["id"],
                    "sets_completed": 3,
                    "reps_completed": 10,
                    "weight_used_kg": 80.0,
                }]
            }
        )
        assert resp.status_code == 201
        entry = resp.json()["log_entries"][0]
        assert entry["is_personal_best"] is True

    def test_no_personal_best_on_lower_weight(self, member, bench_press):
        """Does NOT flag personal best when performance is lower than before."""
        # First session — 80kg × 10 reps
        client.post(
            "/api/workouts/logs",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={"exercises": [{"exercise_id": bench_press["id"],
                                 "sets_completed": 3, "reps_completed": 10,
                                 "weight_used_kg": 80.0}]}
        )

        # Second session — 70kg × 10 reps (lighter = NOT a PB)
        resp = client.post(
            "/api/workouts/logs",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={"exercises": [{"exercise_id": bench_press["id"],
                                 "sets_completed": 3, "reps_completed": 10,
                                 "weight_used_kg": 70.0}]}
        )
        entry = resp.json()["log_entries"][0]
        assert entry["is_personal_best"] is False

    def test_workout_history(self, member, bench_press):
        """Member can retrieve their workout history."""
        # Log 3 sessions
        for _ in range(3):
            client.post(
                "/api/workouts/logs",
                headers={"Authorization": f"Bearer {member['token']}"},
                json={"exercises": [{"exercise_id": bench_press["id"],
                                     "sets_completed": 3, "reps_completed": 10,
                                     "weight_used_kg": 75.0}]}
            )

        resp = client.get(
            "/api/workouts/logs/me",
            headers={"Authorization": f"Bearer {member['token']}"}
        )
        assert resp.status_code == 200
        assert len(resp.json()) == 3


# ---------------------------------------------------------------------------
# Progress Tests
# ---------------------------------------------------------------------------

class TestProgress:

    def test_exercise_progress(self, member, bench_press):
        """Progress endpoint returns time-series data for chart rendering."""
        # Log two sessions with increasing weight
        for weight in [70, 75, 80]:
            client.post(
                "/api/workouts/logs",
                headers={"Authorization": f"Bearer {member['token']}"},
                json={"exercises": [{"exercise_id": bench_press["id"],
                                     "sets_completed": 3, "reps_completed": 10,
                                     "weight_used_kg": float(weight)}]}
            )

        resp = client.get(
            f"/api/workouts/progress/{bench_press['id']}",
            headers={"Authorization": f"Bearer {member['token']}"}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["exercise_name"] == "Bench Press"
        assert len(data["data_points"]) == 3
        assert data["personal_best_kg"] == 80.0

    def test_personal_bests_summary(self, member, bench_press, squat):
        """Personal bests endpoint returns best for each tracked exercise."""
        client.post("/api/workouts/logs",
                    headers={"Authorization": f"Bearer {member['token']}"},
                    json={"exercises": [
                        {"exercise_id": bench_press["id"],
                         "sets_completed": 3, "reps_completed": 10, "weight_used_kg": 85.0},
                        {"exercise_id": squat["id"],
                         "sets_completed": 3, "reps_completed": 5,  "weight_used_kg": 120.0},
                    ]})

        resp = client.get("/api/workouts/personal-bests",
                          headers={"Authorization": f"Bearer {member['token']}"})
        assert resp.status_code == 200
        bests = {pb["exercise_name"]: pb for pb in resp.json()}
        assert bests["Bench Press"]["best_weight_kg"] == 85.0
        assert bests["Squat"]["best_weight_kg"] == 120.0

    def test_workout_stats(self, member, bench_press):
        """Stats endpoint returns session counts and streak."""
        # Log a session today
        client.post("/api/workouts/logs",
                    headers={"Authorization": f"Bearer {member['token']}"},
                    json={"exercises": [{"exercise_id": bench_press["id"],
                                         "sets_completed": 3, "reps_completed": 10,
                                         "weight_used_kg": 70.0}]})

        resp = client.get("/api/workouts/stats",
                          headers={"Authorization": f"Bearer {member['token']}"})
        assert resp.status_code == 200
        stats = resp.json()
        assert stats["total_sessions"] == 1
        assert stats["sessions_this_week"] == 1
        assert stats["current_streak_days"] == 1
