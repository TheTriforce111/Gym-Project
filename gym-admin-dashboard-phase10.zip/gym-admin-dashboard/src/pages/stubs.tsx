/**
 * pages/stubs.tsx — Placeholder pages for sections not yet fully built
 *
 * Each of these can be expanded into a full page following the same
 * pattern as Members.tsx, Payments.tsx, etc.
 */

import Header from '../components/layout/Header'
import { EmptyState } from '../components/ui'
import { Calendar, QrCode, Dumbbell, Bell } from 'lucide-react'

export function Classes() {
  return (
    <>
      <Header title="Classes" subtitle="Gym class scheduling and bookings" />
      <div className="p-6">
        <div className="card">
          <EmptyState
            icon={<Calendar size={32} />}
            title="Class Schedule"
            description="This page shows all scheduled classes, trainer assignments, bookings, and attendance. Connect to GET /api/classes/ to populate."
          />
          <div className="mt-6 p-4 bg-surface-hover rounded-lg">
            <p className="text-xs text-[var(--muted)] font-mono">
              GET /api/classes/?upcoming_only=true<br />
              GET /api/classes/schedule/weekly<br />
              POST /api/classes/&#123;id&#125;/cancel-class<br />
              POST /api/classes/&#123;id&#125;/mark-attendance
            </p>
          </div>
        </div>
      </div>
    </>
  )
}

export function Attendance() {
  return (
    <>
      <Header title="Attendance" subtitle="QR check-in management" />
      <div className="p-6">
        <div className="card">
          <EmptyState
            icon={<QrCode size={32} />}
            title="QR Attendance System"
            description="Live check-in feed, member QR management, daily/weekly/monthly reports. Connect to the attendance endpoints."
          />
          <div className="mt-6 p-4 bg-surface-hover rounded-lg">
            <p className="text-xs text-[var(--muted)] font-mono">
              GET /api/attendance/today<br />
              GET /api/attendance/report/daily<br />
              GET /api/attendance/report/weekly<br />
              POST /api/attendance/invalidate-qr/&#123;user_id&#125;
            </p>
          </div>
        </div>
      </div>
    </>
  )
}

export function Workouts() {
  return (
    <>
      <Header title="Workouts" subtitle="Exercise library and workout plans" />
      <div className="p-6">
        <div className="card">
          <EmptyState
            icon={<Dumbbell size={32} />}
            title="Workout Management"
            description="Browse the exercise library, manage workout plans assigned to members, and view training logs. Connect to the workouts endpoints."
          />
          <div className="mt-6 p-4 bg-surface-hover rounded-lg">
            <p className="text-xs text-[var(--muted)] font-mono">
              GET /api/workouts/exercises<br />
              GET /api/workouts/plans/user/&#123;id&#125;<br />
              GET /api/workouts/personal-bests<br />
              GET /api/workouts/stats
            </p>
          </div>
        </div>
      </div>
    </>
  )
}

export function Notifications() {
  return (
    <>
      <Header title="Notifications" subtitle="Push and email notification management" />
      <div className="p-6">
        <div className="card">
          <EmptyState
            icon={<Bell size={32} />}
            title="Notification Center"
            description="Send announcements, view failed notifications, and retry delivery. Connect to the notifications endpoints."
          />
          <div className="mt-6 p-4 bg-surface-hover rounded-lg">
            <p className="text-xs text-[var(--muted)] font-mono">
              POST /api/notifications/announce<br />
              GET  /api/notifications/failed<br />
              POST /api/notifications/&#123;id&#125;/retry
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
