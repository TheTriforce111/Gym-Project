/**
 * pages/Members.tsx — Member Management Page
 *
 * Full CRUD table: search, filter by role/status, deactivate.
 * Click a member to see details in a slide-over.
 */

import { useState, useEffect } from 'react'
import { Search, UserX, RefreshCw, UserPlus } from 'lucide-react'
import { usersService, membershipService } from '../services/api'
import type { User, Membership } from '../types'
import Header from '../components/layout/Header'
import { Badge, MembershipStatusBadge, PageLoader, EmptyState, ConfirmDialog } from '../components/ui'
import { format } from 'date-fns'

export default function Members() {
  const [users,    setUsers]    = useState<User[]>([])
  const [search,   setSearch]   = useState('')
  const [loading,  setLoading]  = useState(true)
  const [selected, setSelected] = useState<User | null>(null)
  const [membership, setMembership] = useState<Membership | null>(null)
  const [confirmDeactivate, setConfirmDeactivate] = useState<User | null>(null)

  const load = async () => {
    setLoading(true)
    try {
      const data = await usersService.list(0, 200)
      setUsers(data.filter(u => u.role === 'member'))
    } catch { /* handle silently */ }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleSelect = async (user: User) => {
    setSelected(user)
    setMembership(null)
    try {
      // Fetch the user's membership from the all memberships endpoint
      const all = await membershipService.getAll()
      const m   = all.find(m => m.user_id === user.id)
      setMembership(m ?? null)
    } catch { /* no membership */ }
  }

  const handleDeactivate = async (user: User) => {
    await usersService.deactivate(user.id)
    setUsers(prev => prev.filter(u => u.id !== user.id))
    setSelected(null)
  }

  const filtered = users.filter(u =>
    u.full_name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <>
      <Header
        title="Members"
        subtitle={`${users.length} total members`}
        onRefresh={load}
      />

      <div className="p-6 flex gap-5 h-[calc(100vh-64px)] overflow-hidden">

        {/* ── Left: Member table ─────────────────────────── */}
        <div className="flex-1 overflow-hidden flex flex-col gap-4">
          {/* Search bar */}
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
              <input
                className="input pl-9"
                placeholder="Search by name or email…"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>

          {/* Table */}
          <div className="card flex-1 overflow-auto p-0">
            {loading ? (
              <div className="p-6"><PageLoader /></div>
            ) : filtered.length === 0 ? (
              <EmptyState icon="👥" title="No members found" description="Try a different search." />
            ) : (
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Status</th>
                    <th>Joined</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(user => (
                    <tr
                      key={user.id}
                      className={`cursor-pointer ${selected?.id === user.id ? 'bg-brand-500/10' : ''}`}
                      onClick={() => handleSelect(user)}
                    >
                      <td>
                        <div className="flex items-center gap-3">
                          {/* Avatar */}
                          <div className="w-7 h-7 rounded-full bg-brand-500/20 flex items-center
                                          justify-center text-brand-500 text-xs font-bold shrink-0">
                            {user.full_name.split(' ').map(n => n[0]).join('').slice(0,2)}
                          </div>
                          <div>
                            <div className="text-xs font-medium text-white">{user.full_name}</div>
                            <div className="text-[10px] text-[var(--muted)]">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <Badge variant={user.is_active ? 'green' : 'red'}>
                          {user.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </td>
                      <td className="text-xs text-[var(--muted)]">
                        {format(new Date(user.created_at), 'MMM d, yyyy')}
                      </td>
                      <td>
                        <button
                          onClick={e => { e.stopPropagation(); setConfirmDeactivate(user) }}
                          className="btn-ghost p-1 hover:text-accent-red"
                          title="Deactivate member"
                        >
                          <UserX size={13} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* ── Right: Member detail panel ─────────────────── */}
        {selected && (
          <div className="w-72 shrink-0 card overflow-y-auto space-y-5">
            {/* Avatar + name */}
            <div className="text-center pt-2">
              <div className="w-14 h-14 rounded-full bg-brand-500/20 flex items-center
                              justify-center text-brand-500 text-xl font-bold mx-auto mb-3">
                {selected.full_name.split(' ').map(n => n[0]).join('').slice(0,2)}
              </div>
              <h3 className="text-sm font-semibold text-white">{selected.full_name}</h3>
              <p className="text-xs text-[var(--muted)]">{selected.email}</p>
            </div>

            <hr className="border-surface-border" />

            {/* Details */}
            <div className="space-y-2.5">
              <Row label="Phone"   value={selected.phone || '—'} />
              <Row label="Role"    value={selected.role} />
              <Row label="Account" value={selected.is_active ? 'Active' : 'Inactive'} />
              <Row label="Verified" value={selected.is_verified ? 'Yes' : 'No'} />
              <Row label="Joined"  value={format(new Date(selected.created_at), 'MMM d, yyyy')} />
            </div>

            {/* Membership */}
            {membership && (
              <>
                <hr className="border-surface-border" />
                <div>
                  <p className="text-xs font-semibold text-[var(--muted)] uppercase tracking-wider mb-3">
                    Membership
                  </p>
                  <div className="space-y-2.5">
                    <Row label="Plan"    value={<span className="capitalize">{membership.plan}</span>} />
                    <Row label="Status"  value={<MembershipStatusBadge status={membership.status} />} />
                    <Row label="Expires" value={format(new Date(membership.end_date), 'MMM d, yyyy')} />
                    <Row label="Days left" value={`${membership.days_remaining}d`} />
                  </div>
                </div>
              </>
            )}

            {/* Actions */}
            <hr className="border-surface-border" />
            <button
              onClick={() => setConfirmDeactivate(selected)}
              className="btn-danger w-full justify-center text-xs py-2"
            >
              <UserX size={13} />
              Deactivate Account
            </button>
          </div>
        )}
      </div>

      {/* Confirm deactivate dialog */}
      <ConfirmDialog
        open={!!confirmDeactivate}
        onClose={() => setConfirmDeactivate(null)}
        onConfirm={() => confirmDeactivate && handleDeactivate(confirmDeactivate)}
        title="Deactivate member?"
        message={`${confirmDeactivate?.full_name} will no longer be able to log in. Their data is preserved.`}
        danger
      />
    </>
  )
}

function Row({ label, value }: { label: string; value: any }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs text-[var(--muted)]">{label}</span>
      <span className="text-xs font-medium text-white">{value}</span>
    </div>
  )
}
