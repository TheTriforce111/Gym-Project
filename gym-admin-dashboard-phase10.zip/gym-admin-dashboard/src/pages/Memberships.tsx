/**
 * pages/Memberships.tsx — Membership Management Page
 */

import { useState, useEffect } from 'react'
import { Search, Snowflake, XCircle, RefreshCw } from 'lucide-react'
import { membershipService } from '../services/api'
import type { Membership } from '../types'
import Header from '../components/layout/Header'
import { MembershipStatusBadge, PageLoader, EmptyState, ConfirmDialog, SectionCard } from '../components/ui'
import { format, differenceInDays } from 'date-fns'

export default function Memberships() {
  const [memberships, setMemberships] = useState<Membership[]>([])
  const [loading, setLoading] = useState(true)
  const [search,  setSearch]  = useState('')
  const [filter,  setFilter]  = useState('all')
  const [action,  setAction]  = useState<{ type: string; m: Membership } | null>(null)

  const load = async () => {
    setLoading(true)
    try {
      const data = await membershipService.getAll()
      setMemberships(data)
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const filtered = memberships.filter(m => {
    if (filter !== 'all' && m.status !== filter) return false
    return true
  })

  const doAction = async () => {
    if (!action) return
    const { type, m } = action
    if (type === 'freeze')    await membershipService.freeze(m.id)
    if (type === 'unfreeze')  await membershipService.unfreeze(m.id)
    if (type === 'cancel')    await membershipService.cancel(m.id)
    if (type === 'renew')     await membershipService.renew(m.id)
    setAction(null)
    load()
  }

  return (
    <>
      <Header title="Memberships" subtitle={`${memberships.length} total`} onRefresh={load} />
      <div className="p-6 space-y-4">
        {/* Filter tabs */}
        <div className="flex gap-2">
          {['all','active','expiring','frozen','expired','cancelled'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`btn text-xs py-1.5 px-3 ${filter === f ? 'btn-primary' : 'btn-ghost'}`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        <SectionCard>
          {loading ? <PageLoader /> : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>User ID</th><th>Plan</th><th>Status</th>
                  <th>Start</th><th>Expires</th><th>Days Left</th>
                  <th>Paid</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(m => (
                  <tr key={m.id}>
                    <td className="text-[var(--muted)] text-xs">#{m.user_id}</td>
                    <td className="capitalize text-xs">{m.plan}</td>
                    <td><MembershipStatusBadge status={m.status} /></td>
                    <td className="text-xs text-[var(--muted)]">{format(new Date(m.start_date),'MMM d')}</td>
                    <td className="text-xs text-[var(--muted)]">{format(new Date(m.end_date),'MMM d, yyyy')}</td>
                    <td>
                      <span className={`text-xs font-semibold ${m.days_remaining <= 7 ? 'text-accent-amber' : 'text-white'}`}>
                        {m.days_remaining}d
                      </span>
                    </td>
                    <td className="text-xs">${m.price_paid}</td>
                    <td>
                      <div className="flex gap-1">
                        {m.status === 'active' && (
                          <button onClick={() => setAction({ type:'freeze', m })}
                            className="btn-ghost p-1 text-[10px]" title="Freeze">
                            <Snowflake size={12} />
                          </button>
                        )}
                        {m.status === 'frozen' && (
                          <button onClick={() => setAction({ type:'unfreeze', m })}
                            className="btn-ghost p-1 text-[10px]" title="Unfreeze">
                            <RefreshCw size={12} />
                          </button>
                        )}
                        <button onClick={() => setAction({ type:'renew', m })}
                          className="btn-ghost p-1 text-[10px]" title="Renew">
                          <RefreshCw size={12} className="text-accent-green" />
                        </button>
                        {m.status !== 'cancelled' && (
                          <button onClick={() => setAction({ type:'cancel', m })}
                            className="btn-ghost p-1" title="Cancel">
                            <XCircle size={12} className="text-accent-red" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </SectionCard>
      </div>

      <ConfirmDialog
        open={!!action}
        onClose={() => setAction(null)}
        onConfirm={doAction}
        title={`${action?.type?.charAt(0).toUpperCase()}${action?.type?.slice(1)} membership?`}
        message={`This will ${action?.type} membership #${action?.m?.id}. Continue?`}
        danger={action?.type === 'cancel'}
      />
    </>
  )
}
