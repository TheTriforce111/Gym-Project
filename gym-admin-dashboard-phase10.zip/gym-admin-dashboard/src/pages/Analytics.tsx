/**
 * pages/Analytics.tsx — Deep analytics view with CSV exports
 */

import { useState, useEffect } from 'react'
import { Download } from 'lucide-react'
import { analyticsService } from '../services/api'
import type { RevenueAnalytics, MemberDemographics, AttendanceAnalytics, ClassAnalytics, TopMembersReport } from '../types'
import Header from '../components/layout/Header'
import { SectionCard, PageLoader, StatRow } from '../components/ui'
import {
  RevenueTrendChart, AttendanceTrendChart,
  MemberGrowthChart, PlanDistributionChart,
  ClassPopularityChart, AttendanceHeatmapChart,
} from '../components/charts'

type Period = 7 | 30 | 90 | 365

export default function Analytics() {
  const [period, setPeriod]     = useState<Period>(30)
  const [revenue,   setRevenue]   = useState<RevenueAnalytics | null>(null)
  const [members,   setMembers]   = useState<MemberDemographics | null>(null)
  const [attendance, setAttendance] = useState<AttendanceAnalytics | null>(null)
  const [classes,   setClasses]   = useState<ClassAnalytics | null>(null)
  const [topMembers, setTopMembers] = useState<TopMembersReport | null>(null)
  const [loading, setLoading] = useState(true)

  const load = async () => {
    setLoading(true)
    try {
      const [r, m, a, c, t] = await Promise.all([
        analyticsService.getRevenue(period),
        analyticsService.getMembers(12),
        analyticsService.getAttendance(period),
        analyticsService.getClasses(period),
        analyticsService.getTopMembers(10),
      ])
      setRevenue(r); setMembers(m); setAttendance(a)
      setClasses(c); setTopMembers(t)
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [period])

  if (loading) return (
    <>
      <Header title="Analytics" />
      <div className="p-6"><PageLoader /></div>
    </>
  )

  return (
    <>
      <Header title="Analytics" subtitle="Deep-dive reports" onRefresh={load} />
      <div className="p-6 space-y-5">

        {/* Period selector + exports */}
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            {([7, 30, 90, 365] as Period[]).map(d => (
              <button key={d}
                onClick={() => setPeriod(d)}
                className={`btn text-xs py-1.5 px-3 ${period === d ? 'btn-primary' : 'btn-ghost'}`}>
                {d === 365 ? '1 Year' : `${d}d`}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            {['revenue','attendance','members','classes'].map(t => (
              <a key={t}
                href={analyticsService.getCSVExportUrl(t, period)}
                className="btn-ghost text-xs py-1.5 px-2.5" download>
                <Download size={12} /> {t}
              </a>
            ))}
          </div>
        </div>

        {/* Revenue section */}
        {revenue && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2">
              <SectionCard title={`Revenue — Last ${period} days`}
                actions={<span className="text-xs text-[var(--muted)]">
                  Peak: ${revenue.highest_revenue_amount?.toFixed(0)} on {revenue.highest_revenue_day}
                </span>}>
                <RevenueTrendChart data={revenue.trend.data_points} />
              </SectionCard>
            </div>
            <SectionCard title="Revenue Summary">
              <StatRow label="Total Revenue"    value={`$${revenue.total_revenue.toLocaleString()}`} highlight />
              <StatRow label="Net Revenue"      value={`$${revenue.net_revenue.toLocaleString()}`} />
              <StatRow label="Total Refunded"   value={`$${revenue.total_refunded.toLocaleString()}`} />
              <StatRow label="Refund Rate"      value={`${revenue.refund_rate_pct}%`} />
              <StatRow label="Avg/Member"       value={`$${revenue.avg_revenue_per_member.toFixed(0)}`} />
              {revenue.by_plan.map(p => (
                <StatRow key={p.plan}
                  label={`${p.plan} plan`}
                  value={`$${p.revenue.toLocaleString()} (${p.percentage}%)`} />
              ))}
            </SectionCard>
          </div>
        )}

        {/* Member analytics */}
        {members && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <SectionCard title="Member Growth (12 months)">
              <MemberGrowthChart data={members.growth_trend} />
            </SectionCard>
            <SectionCard title="Plan Distribution">
              <PlanDistributionChart data={members.plan_distribution} />
            </SectionCard>
          </div>
        )}

        {/* Retention */}
        {members && (
          <SectionCard title="Retention Report">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-accent-green">{members.retention_report.avg_retention_pct}%</div>
                <div className="text-xs text-[var(--muted)] mt-1">Retention Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent-red">{members.retention_report.avg_churn_pct}%</div>
                <div className="text-xs text-[var(--muted)] mt-1">Churn Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white">{members.retention_report.renewals_this_month}</div>
                <div className="text-xs text-[var(--muted)] mt-1">Renewals This Month</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent-amber">{members.retention_report.expirations_this_month}</div>
                <div className="text-xs text-[var(--muted)] mt-1">Expirations This Month</div>
              </div>
            </div>
          </SectionCard>
        )}

        {/* Attendance */}
        {attendance && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <SectionCard title={`Attendance Trend — ${period} days`}
              actions={<span className="text-xs text-[var(--muted)]">avg {attendance.daily_trend.average.toFixed(1)}/day</span>}>
              <AttendanceTrendChart data={attendance.daily_trend.data_points} />
            </SectionCard>
            <SectionCard title="Peak Hours Heatmap"
              actions={<span className="text-xs text-[var(--muted)]">
                Busiest: {attendance.heatmap.peak_day} {attendance.heatmap.peak_hour}:00
              </span>}>
              <AttendanceHeatmapChart cells={attendance.heatmap.cells} peakAvg={attendance.heatmap.peak_avg} />
            </SectionCard>
          </div>
        )}

        {/* Classes */}
        {classes && (
          <SectionCard title="Class Popularity"
            actions={<span className="text-xs text-[var(--muted)]">Overall fill {classes.overall_fill_rate}%</span>}>
            <ClassPopularityChart data={classes.popularity} />
          </SectionCard>
        )}

        {/* Top Members */}
        {topMembers && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {[
              { title: 'Most Visits',  data: topMembers.by_visits  },
              { title: 'Highest Spend', data: topMembers.by_revenue },
              { title: 'Longest Streak', data: topMembers.by_streak },
              { title: 'Most Classes',   data: topMembers.by_classes },
            ].map(({ title, data }) => (
              <SectionCard key={title} title={title}>
                <div className="space-y-2">
                  {data.slice(0, 5).map(m => (
                    <div key={m.user_id} className="flex items-center gap-3">
                      <span className="text-[10px] text-[var(--muted)] w-4 text-right">{m.rank}</span>
                      <div className="w-6 h-6 rounded-full bg-brand-500/20 flex items-center
                                      justify-center text-brand-500 text-[9px] font-bold shrink-0">
                        {m.full_name.split(' ').map((n:string) => n[0]).join('').slice(0,2)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-white truncate">{m.full_name}</p>
                      </div>
                      <span className="text-xs font-semibold text-accent-green">{m.value_label}</span>
                    </div>
                  ))}
                </div>
              </SectionCard>
            ))}
          </div>
        )}

      </div>
    </>
  )
}
