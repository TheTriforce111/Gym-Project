/**
 * pages/Dashboard.tsx — Main Admin Dashboard
 *
 * The home screen. Shows:
 * - KPI row (8 key numbers)
 * - Revenue + Attendance trend charts
 * - Member growth + Plan distribution
 * - Attendance heatmap
 * - Activity feed + Top members
 * - Class popularity
 */

import { useState, useEffect, useCallback } from 'react'
import { Users, DollarSign, QrCode, Calendar, TrendingUp, Zap, AlertTriangle, Activity } from 'lucide-react'
import { analyticsService } from '../services/api'
import type { DashboardOverview } from '../types'
import Header from '../components/layout/Header'
import { KPICard, SectionCard, PageLoader, EmptyState } from '../components/ui'
import {
  RevenueTrendChart, AttendanceTrendChart,
  MemberGrowthChart, PlanDistributionChart,
  ClassPopularityChart, AttendanceHeatmapChart,
} from '../components/charts'
import { format, formatDistanceToNow } from 'date-fns'

export default function Dashboard() {
  const [data,       setData]       = useState<DashboardOverview | null>(null)
  const [loading,    setLoading]    = useState(true)
  const [error,      setError]      = useState('')
  const [refreshing, setRefreshing] = useState(false)

  const load = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true)
    else setLoading(true)
    try {
      const overview = await analyticsService.getDashboard()
      setData(overview)
      setError('')
    } catch {
      setError('Failed to load dashboard data. Is the backend running?')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  // Auto-refresh KPIs every 60 seconds
  useEffect(() => {
    const timer = setInterval(() => load(true), 60_000)
    return () => clearInterval(timer)
  }, [load])

  if (loading) return (
    <>
      <Header title="Dashboard" subtitle="Loading..." />
      <div className="p-6"><PageLoader /></div>
    </>
  )

  if (error) return (
    <>
      <Header title="Dashboard" />
      <div className="p-6">
        <EmptyState icon="⚠️" title={error} description="Check that the FastAPI backend is running on port 8000." />
      </div>
    </>
  )

  const { kpis, revenue, members, attendance, classes, top_members, recent_activity } = data!
  const fmt = (n: number) => new Intl.NumberFormat().format(n)
  const money = (n: number) => `$${n.toLocaleString('en', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`

  return (
    <>
      <Header
        title="Dashboard"
        subtitle={`Last updated ${format(new Date(data!.generated_at), 'HH:mm:ss')}`}
        onRefresh={() => load(true)}
        refreshing={refreshing}
      />

      <div className="p-6 space-y-6">

        {/* ── KPI Row ─────────────────────────────────────── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <KPICard
            label="Total Members"
            value={fmt(kpis.total_members)}
            sublabel={`${kpis.active_members} active`}
            trend={kpis.new_members_this_month > 0 ? (kpis.new_members_this_month / (kpis.total_members || 1)) * 100 : null}
            icon={<Users size={16} />}
            iconColor="text-brand-500"
          />
          <KPICard
            label="Revenue This Month"
            value={money(kpis.revenue_this_month)}
            sublabel={`${money(kpis.revenue_this_year)} this year`}
            trend={revenue.trend.trend_pct}
            icon={<DollarSign size={16} />}
            iconColor="text-accent-green"
          />
          <KPICard
            label="Check-ins Today"
            value={fmt(kpis.checkins_today)}
            sublabel={`${kpis.currently_in_gym} currently inside`}
            icon={<QrCode size={16} />}
            iconColor="text-accent-amber"
          />
          <KPICard
            label="Classes Today"
            value={fmt(kpis.classes_today)}
            sublabel={`${kpis.total_bookings_today} bookings · ${kpis.class_fill_rate.toFixed(0)}% fill`}
            icon={<Calendar size={16} />}
            iconColor="text-accent-purple"
          />
        </div>

        {/* ── Second KPI row ──────────────────────────────── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <KPICard
            label="New Members"
            value={`+${kpis.new_members_this_month}`}
            sublabel="this month"
            icon={<TrendingUp size={16} />}
            iconColor="text-brand-500"
          />
          <KPICard
            label="Expiring Soon"
            value={kpis.expiring_soon_count}
            sublabel="within 7 days"
            icon={<AlertTriangle size={16} />}
            iconColor="text-accent-amber"
          />
          <KPICard
            label="Active Members"
            value={fmt(kpis.active_members)}
            sublabel={`${kpis.frozen_count} frozen`}
            icon={<Zap size={16} />}
            iconColor="text-accent-green"
          />
          <KPICard
            label="Personal Bests Today"
            value={kpis.personal_bests_today}
            sublabel={`${kpis.workouts_logged_today} sessions logged`}
            icon={<Activity size={16} />}
            iconColor="text-brand-500"
          />
        </div>

        {/* ── Revenue + Attendance charts ─────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <SectionCard
            title="Revenue Trend (30 days)"
            actions={
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold text-white">{money(revenue.total_revenue)}</span>
                {revenue.trend.trend_pct !== null && (
                  <span className={revenue.trend.trend_pct >= 0 ? 'trend-up' : 'trend-down'}>
                    {revenue.trend.trend_pct >= 0 ? '+' : ''}{revenue.trend.trend_pct}%
                  </span>
                )}
              </div>
            }
          >
            <RevenueTrendChart data={revenue.trend.data_points} />
          </SectionCard>

          <SectionCard
            title="Daily Check-ins (30 days)"
            actions={
              <span className="text-xs text-[var(--muted)]">
                avg {attendance.daily_trend.average.toFixed(1)}/day
              </span>
            }
          >
            <AttendanceTrendChart data={attendance.daily_trend.data_points} />
          </SectionCard>
        </div>

        {/* ── Member growth + Plan distribution ───────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <SectionCard title="Member Growth (12 months)">
            <MemberGrowthChart data={members.growth_trend} />
          </SectionCard>

          <SectionCard title="Plan Distribution">
            <PlanDistributionChart data={members.plan_distribution} />
            {/* Percentages below chart */}
            <div className="mt-3 space-y-1">
              {members.plan_distribution.map((p, i) => (
                <div key={p.plan} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{
                      background: ['#3b6bff','#00d97e','#ffb020','#9b59b6'][i]
                    }} />
                    <span className="capitalize text-[var(--muted)]">{p.plan}</span>
                  </div>
                  <span className="font-semibold text-white">{p.count} ({p.percentage}%)</span>
                </div>
              ))}
            </div>
          </SectionCard>
        </div>

        {/* ── Attendance Heatmap ───────────────────────────── */}
        <SectionCard
          title="Peak Hours Heatmap"
          actions={
            <span className="text-xs text-[var(--muted)]">
              Busiest: {attendance.heatmap.peak_day} {attendance.heatmap.peak_hour}:00
            </span>
          }
        >
          <AttendanceHeatmapChart
            cells={attendance.heatmap.cells}
            peakAvg={attendance.heatmap.peak_avg}
          />
        </SectionCard>

        {/* ── Class Popularity + Activity Feed ─────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <SectionCard
            title="Class Fill Rates"
            actions={<span className="text-xs text-[var(--muted)]">Overall {classes.overall_fill_rate}%</span>}
          >
            <ClassPopularityChart data={classes.popularity} />
          </SectionCard>

          {/* Activity Feed */}
          <SectionCard title="Live Activity Feed">
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {recent_activity.length === 0 && (
                <p className="text-xs text-[var(--muted)] py-4 text-center">No recent activity</p>
              )}
              {recent_activity.map((item, i) => (
                <div key={`${item.event_type}-${i}`}
                     className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-surface-hover transition-colors">
                  <span className="text-lg leading-none mt-0.5">{item.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-white truncate">{item.description}</p>
                    <p className="text-[10px] text-[var(--muted)] mt-0.5">
                      {formatDistanceToNow(new Date(item.timestamp), { addSuffix: true })}
                    </p>
                  </div>
                  {item.amount !== null && (
                    <span className="text-xs font-semibold text-accent-green shrink-0">
                      ${item.amount.toFixed(2)}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </SectionCard>
        </div>

        {/* ── Top Members ──────────────────────────────────── */}
        <SectionCard title="Top Members This Month">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Member</th>
                  <th>Plan</th>
                  <th>Visits</th>
                  <th>Revenue</th>
                  <th>Streak</th>
                </tr>
              </thead>
              <tbody>
                {top_members.by_visits.slice(0, 8).map((member) => {
                  const rev   = top_members.by_revenue.find(r => r.user_id === member.user_id)
                  const streak = top_members.by_streak.find(s  => s.user_id === member.user_id)
                  return (
                    <tr key={member.user_id}>
                      <td className="text-[var(--muted)] w-8">{member.rank}</td>
                      <td>
                        <div className="font-medium text-white text-xs">{member.full_name}</div>
                        <div className="text-[10px] text-[var(--muted)]">{member.email}</div>
                      </td>
                      <td><span className="capitalize text-xs text-[var(--muted)]">{member.membership_plan}</span></td>
                      <td><span className="font-semibold text-accent-green">{member.value_label}</span></td>
                      <td><span className="text-xs">{rev ? `$${rev.value.toFixed(0)}` : '—'}</span></td>
                      <td><span className="text-xs text-[var(--muted)]">{streak ? `${streak.value}d` : '—'}</span></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </SectionCard>

      </div>
    </>
  )
}
