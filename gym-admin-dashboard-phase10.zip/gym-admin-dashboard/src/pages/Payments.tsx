/**
 * pages/Payments.tsx — Payment History & Management
 */

import { useState, useEffect } from 'react'
import { RefreshCw, Download } from 'lucide-react'
import { paymentService, analyticsService } from '../services/api'
import type { Payment } from '../types'
import Header from '../components/layout/Header'
import { PaymentStatusBadge, PageLoader, SectionCard, KPICard } from '../components/ui'
import { format } from 'date-fns'
import { DollarSign, TrendingUp, AlertCircle, Clock } from 'lucide-react'

export default function Payments() {
  const [payments, setPayments] = useState<Payment[]>([])
  const [stats,    setStats]    = useState<any>(null)
  const [loading,  setLoading]  = useState(true)
  const [filter,   setFilter]   = useState('all')

  const load = async () => {
    setLoading(true)
    try {
      const [pmts, revenue] = await Promise.all([
        paymentService.getAll({ limit: 100 }),
        paymentService.getRevenueStats(),
      ])
      setPayments(pmts)
      setStats(revenue)
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const filtered = payments.filter(p =>
    filter === 'all' || p.status === filter
  )

  const handleRefund = async (payment: Payment) => {
    if (!window.confirm(`Refund $${payment.amount} for payment #${payment.id}?`)) return
    await paymentService.refund(payment.id)
    load()
  }

  return (
    <>
      <Header title="Payments" subtitle="Transaction history" onRefresh={load} />
      <div className="p-6 space-y-5">

        {/* Stats row */}
        {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard label="Total Revenue" value={`$${stats.total_revenue.toLocaleString()}`}
              icon={<DollarSign size={16} />} iconColor="text-accent-green" />
            <KPICard label="Net Revenue"   value={`$${stats.net_revenue.toLocaleString()}`}
              icon={<TrendingUp size={16} />} iconColor="text-brand-500" />
            <KPICard label="Failed"        value={stats.failed_count}
              icon={<AlertCircle size={16} />} iconColor="text-accent-red" />
            <KPICard label="Pending"       value={stats.pending_count}
              icon={<Clock size={16} />} iconColor="text-accent-amber" />
          </div>
        )}

        {/* Filter + Export */}
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            {['all','success','failed','pending','refunded'].map(f => (
              <button key={f}
                onClick={() => setFilter(f)}
                className={`btn text-xs py-1.5 px-3 ${filter === f ? 'btn-primary' : 'btn-ghost'}`}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
          <a
            href={analyticsService.getCSVExportUrl('revenue', 30)}
            className="btn-ghost text-xs"
            download
          >
            <Download size={13} /> Export CSV
          </a>
        </div>

        {/* Table */}
        <SectionCard>
          {loading ? <PageLoader /> : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>ID</th><th>User</th><th>Amount</th><th>Status</th>
                  <th>Type</th><th>Date</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => (
                  <tr key={p.id}>
                    <td className="text-[var(--muted)] text-xs font-mono">#{p.id}</td>
                    <td className="text-xs">User #{p.user_id}</td>
                    <td className="font-semibold text-sm">${p.amount.toFixed(2)}</td>
                    <td><PaymentStatusBadge status={p.status} /></td>
                    <td className="text-xs text-[var(--muted)] capitalize">
                      {p.payment_type.replace('_', ' ')}
                    </td>
                    <td className="text-xs text-[var(--muted)]">
                      {format(new Date(p.created_at), 'MMM d, HH:mm')}
                    </td>
                    <td>
                      {p.status === 'success' && p.amount_refunded < p.amount && (
                        <button
                          onClick={() => handleRefund(p)}
                          className="text-xs text-accent-red hover:underline"
                        >
                          Refund
                        </button>
                      )}
                      {p.failure_reason && (
                        <span className="text-[10px] text-[var(--muted)]" title={p.failure_reason}>
                          ℹ️
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </SectionCard>
      </div>
    </>
  )
}
