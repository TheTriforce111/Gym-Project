/**
 * types/index.ts — TypeScript type definitions
 *
 * These match the Pydantic schemas from the FastAPI backend.
 * Keep in sync with the backend schemas when making changes.
 */

// ============================================================
// AUTH
// ============================================================
export interface LoginCredentials {
  email: string
  password: string
}

export interface TokenResponse {
  access_token:  string
  refresh_token: string
  token_type:    string
}

// ============================================================
// USER
// ============================================================
export type UserRole = 'admin' | 'trainer' | 'member'

export interface User {
  id:          number
  full_name:   string
  email:       string
  phone:       string | null
  role:        UserRole
  is_active:   boolean
  is_verified: boolean
  created_at:  string
}

// ============================================================
// MEMBERSHIP
// ============================================================
export type MembershipPlan   = 'monthly' | 'quarterly' | 'yearly' | 'custom'
export type MembershipStatus = 'active' | 'expired' | 'frozen' | 'cancelled'

export interface Membership {
  id:                number
  user_id:           number
  plan:              MembershipPlan
  status:            MembershipStatus
  start_date:        string
  end_date:          string
  price_paid:        number
  currency:          string
  days_remaining:    number
  is_valid:          boolean
  is_expiring_soon:  boolean
  total_frozen_days: number
  notes:             string | null
  created_at:        string
  updated_at:        string
}

// ============================================================
// PAYMENT
// ============================================================
export type PaymentStatus = 'pending' | 'success' | 'failed' | 'refunded' | 'cancelled'
export type PaymentType   = 'new_membership' | 'renewal' | 'upgrade' | 'refund'

export interface Payment {
  id:                      number
  user_id:                 number
  membership_id:           number | null
  payment_type:            PaymentType
  amount:                  number
  currency:                string
  amount_refunded:         number
  net_amount:              number
  status:                  PaymentStatus
  description:             string | null
  failure_reason:          string | null
  stripe_payment_intent_id: string | null
  stripe_charge_id:        string | null
  is_test:                 boolean
  created_at:              string
  completed_at:            string | null
}

// ============================================================
// GYM CLASS
// ============================================================
export type ClassCategory   = 'yoga' | 'hiit' | 'pilates' | 'spinning' | 'zumba' | 'boxing' | 'crossfit' | 'stretching' | 'strength' | 'cardio' | 'other'
export type ClassStatus     = 'scheduled' | 'ongoing' | 'completed' | 'cancelled'
export type BookingStatus   = 'confirmed' | 'attended' | 'cancelled' | 'no_show'

export interface GymClass {
  id:                       number
  name:                     string
  category:                 ClassCategory
  difficulty:               string
  description:              string | null
  trainer_id:               number | null
  start_time:               string
  end_time:                 string
  duration_minutes:         number
  location:                 string | null
  max_capacity:             number
  confirmed_bookings_count: number
  spots_remaining:          number
  is_full:                  boolean
  is_bookable:              boolean
  status:                   ClassStatus
}

// ============================================================
// ANALYTICS
// ============================================================
export interface KPISummary {
  total_members:           number
  active_members:          number
  new_members_today:       number
  new_members_this_week:   number
  new_members_this_month:  number
  expiring_soon_count:     number
  frozen_count:            number
  expired_count:           number
  revenue_today:           number
  revenue_this_week:       number
  revenue_this_month:      number
  revenue_this_year:       number
  total_revenue_all_time:  number
  pending_payments:        number
  checkins_today:          number
  checkins_this_week:      number
  checkins_this_month:     number
  currently_in_gym:        number
  classes_today:           number
  classes_this_week:       number
  total_bookings_today:    number
  class_fill_rate:         number
  workouts_logged_today:   number
  personal_bests_today:    number
}

export interface DataPoint {
  date:  string
  value: number
  label?: string
}

export interface TimeSeriesResponse {
  metric:      string
  period:      string
  data_points: DataPoint[]
  total:       number
  average:     number
  peak_value:  number
  peak_date:   string | null
  trend_pct:   number | null
}

export interface RevenueByPlan {
  plan:              string
  revenue:           number
  transaction_count: number
  percentage:        number
}

export interface RevenueAnalytics {
  total_revenue:          number
  net_revenue:            number
  total_refunded:         number
  refund_rate_pct:        number
  by_plan:                RevenueByPlan[]
  trend:                  TimeSeriesResponse
  monthly_comparison:     DataPoint[]
  avg_revenue_per_member: number
  highest_revenue_day:    string | null
  highest_revenue_amount: number | null
}

export interface PlanDistribution {
  plan:          string
  count:         number
  percentage:    number
  revenue_share: number
}

export interface MemberGrowthPoint {
  month:         string
  new_members:   number
  total_members: number
  churned:       number
}

export interface RetentionReport {
  period_months:            number
  avg_retention_pct:        number
  avg_churn_pct:            number
  renewals_this_month:      number
  expirations_this_month:   number
  new_joins_this_month:     number
  monthly_retention:        DataPoint[]
}

export interface MemberDemographics {
  plan_distribution: PlanDistribution[]
  status_breakdown:  Record<string, number>
  growth_trend:      MemberGrowthPoint[]
  retention_report:  RetentionReport
}

export interface HeatmapCell {
  day_of_week:  number
  hour:         number
  avg_checkins: number
  day_name:     string
  hour_label:   string
}

export interface AttendanceHeatmap {
  cells:    HeatmapCell[]
  peak_hour: number
  peak_day:  string
  peak_avg:  number
}

export interface AttendanceAnalytics {
  heatmap:                 AttendanceHeatmap
  daily_trend:             TimeSeriesResponse
  weekly_avg:              number
  busiest_month:           string | null
  avg_session_duration_min: number | null
}

export interface ClassPopularity {
  category:              string
  total_classes:         number
  total_bookings:        number
  total_capacity:        number
  fill_rate_pct:         number
  avg_attendance:        number
  no_show_rate_pct:      number
  cancellation_rate_pct: number
}

export interface TrainerPerformance {
  trainer_id:    number
  trainer_name:  string
  classes_taught: number
  total_students: number
  avg_fill_rate:  number
}

export interface ClassAnalytics {
  popularity:          ClassPopularity[]
  trainer_performance: TrainerPerformance[]
  most_popular_class:  string | null
  least_popular_class: string | null
  overall_fill_rate:   number
  total_classes_run:   number
  total_bookings:      number
  cancellation_trend:  TimeSeriesResponse
}

export interface TopMemberEntry {
  rank:            number
  user_id:         number
  full_name:       string
  email:           string
  membership_plan: string
  value:           number
  value_label:     string
}

export interface TopMembersReport {
  by_visits:  TopMemberEntry[]
  by_revenue: TopMemberEntry[]
  by_streak:  TopMemberEntry[]
  by_classes: TopMemberEntry[]
}

export interface ActivityFeedItem {
  id:          number
  timestamp:   string
  event_type:  string
  description: string
  user_id:     number | null
  user_name:   string | null
  icon:        string
  amount:      number | null
}

export interface DashboardOverview {
  generated_at:    string
  kpis:            KPISummary
  revenue:         RevenueAnalytics
  members:         MemberDemographics
  attendance:      AttendanceAnalytics
  classes:         ClassAnalytics
  top_members:     TopMembersReport
  recent_activity: ActivityFeedItem[]
}
