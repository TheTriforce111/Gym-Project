/**
 * services/api.ts — Centralized API Service
 *
 * Single axios instance with:
 * - JWT token injection on every request
 * - Auto-refresh when access token expires (401 response)
 * - Type-safe response wrappers for every endpoint
 */

import axios, { AxiosInstance, AxiosResponse, InternalAxiosRequestConfig } from 'axios'
import type {
  AttendanceAnalytics, ClassAnalytics, DashboardOverview,
  GymClass, KPISummary, LoginCredentials, Membership,
  MemberDemographics, Payment, RevenueAnalytics,
  TokenResponse, TopMembersReport, User, ActivityFeedItem,
} from '../types'

// ---------------------------------------------------------------------------
// Axios instance
// ---------------------------------------------------------------------------
const api: AxiosInstance = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 15_000,
})

// ---------------------------------------------------------------------------
// Request interceptor — attach JWT access token
// ---------------------------------------------------------------------------
api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// ---------------------------------------------------------------------------
// Response interceptor — auto-refresh access token on 401
// ---------------------------------------------------------------------------
let isRefreshing = false
let pendingRequests: Array<(token: string) => void> = []

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config

    // If 401 and not the login/refresh endpoint itself
    if (
      error.response?.status === 401 &&
      !originalRequest._retry &&
      !originalRequest.url?.includes('/auth/')
    ) {
      originalRequest._retry = true

      if (isRefreshing) {
        // Queue while refresh is in progress
        return new Promise((resolve) => {
          pendingRequests.push((token) => {
            originalRequest.headers.Authorization = `Bearer ${token}`
            resolve(api(originalRequest))
          })
        })
      }

      isRefreshing = true
      const refreshToken = localStorage.getItem('refresh_token')

      if (!refreshToken) {
        // No refresh token — send to login
        authService.logout()
        return Promise.reject(error)
      }

      try {
        const { data } = await axios.post<TokenResponse>('/api/auth/refresh', {
          refresh_token: refreshToken,
        })
        localStorage.setItem('access_token',  data.access_token)
        localStorage.setItem('refresh_token', data.refresh_token)

        // Retry all pending requests with new token
        pendingRequests.forEach((cb) => cb(data.access_token))
        pendingRequests = []

        originalRequest.headers.Authorization = `Bearer ${data.access_token}`
        return api(originalRequest)
      } catch {
        authService.logout()
        return Promise.reject(error)
      } finally {
        isRefreshing = false
      }
    }

    return Promise.reject(error)
  }
)

// ---------------------------------------------------------------------------
// Auth Service
// ---------------------------------------------------------------------------
export const authService = {
  async login(credentials: LoginCredentials): Promise<TokenResponse> {
    const { data } = await api.post<TokenResponse>('/auth/login', credentials)
    localStorage.setItem('access_token',  data.access_token)
    localStorage.setItem('refresh_token', data.refresh_token)
    return data
  },

  logout() {
    localStorage.removeItem('access_token')
    localStorage.removeItem('refresh_token')
    window.location.href = '/login'
  },

  isAuthenticated(): boolean {
    return !!localStorage.getItem('access_token')
  },

  async getMe(): Promise<User> {
    const { data } = await api.get<User>('/auth/me')
    return data
  },
}

// ---------------------------------------------------------------------------
// Users Service
// ---------------------------------------------------------------------------
export const usersService = {
  async list(skip = 0, limit = 50): Promise<User[]> {
    const { data } = await api.get<User[]>('/users/', { params: { skip, limit } })
    return data
  },

  async get(id: number): Promise<User> {
    const { data } = await api.get<User>(`/users/${id}`)
    return data
  },

  async deactivate(id: number): Promise<void> {
    await api.delete(`/users/${id}`)
  },

  async update(id: number, payload: Partial<User>): Promise<User> {
    const { data } = await api.put<User>(`/users/${id}`, payload)
    return data
  },
}

// ---------------------------------------------------------------------------
// Membership Service
// ---------------------------------------------------------------------------
export const membershipService = {
  async getAll(statusFilter?: string): Promise<Membership[]> {
    const params = statusFilter ? { status_filter: statusFilter } : {}
    const { data } = await api.get<Membership[]>('/memberships/all', { params })
    return data
  },

  async getById(id: number): Promise<Membership> {
    const { data } = await api.get<Membership>(`/memberships/${id}`)
    return data
  },

  async create(payload: {
    user_id: number; plan: string; price_paid?: number; notes?: string
  }): Promise<Membership> {
    const { data } = await api.post<Membership>('/memberships/', payload)
    return data
  },

  async renew(id: number, plan?: string): Promise<Membership> {
    const { data } = await api.post<Membership>(`/memberships/${id}/renew`, { plan })
    return data
  },

  async freeze(id: number, reason?: string): Promise<Membership> {
    const { data } = await api.post<Membership>(`/memberships/${id}/freeze`, { reason })
    return data
  },

  async unfreeze(id: number): Promise<Membership> {
    const { data } = await api.post<Membership>(`/memberships/${id}/unfreeze`, {})
    return data
  },

  async cancel(id: number, reason?: string): Promise<Membership> {
    const { data } = await api.post<Membership>(`/memberships/${id}/cancel`, { reason })
    return data
  },

  async getExpiringSoon(days = 7): Promise<Membership[]> {
    const { data } = await api.get<Membership[]>('/memberships/expiring-soon', {
      params: { days },
    })
    return data
  },
}

// ---------------------------------------------------------------------------
// Payment Service
// ---------------------------------------------------------------------------
export const paymentService = {
  async getAll(params?: { status_filter?: string; user_id?: number; skip?: number; limit?: number }): Promise<Payment[]> {
    const { data } = await api.get<Payment[]>('/payments/all', { params })
    return data
  },

  async getById(id: number): Promise<Payment> {
    const { data } = await api.get<Payment>(`/payments/${id}`)
    return data
  },

  async refund(id: number, amount?: number, reason?: string): Promise<Payment> {
    const { data } = await api.post<Payment>(`/payments/${id}/refund`, { amount, reason })
    return data
  },

  async getRevenueStats(): Promise<{
    total_revenue: number; net_revenue: number; payment_count: number;
    failed_count: number; pending_count: number;
  }> {
    const { data } = await api.get('/payments/revenue-stats')
    return data
  },
}

// ---------------------------------------------------------------------------
// Analytics Service
// ---------------------------------------------------------------------------
export const analyticsService = {
  async getDashboard(): Promise<DashboardOverview> {
    const { data } = await api.get<DashboardOverview>('/analytics/dashboard')
    return data
  },

  async getKPIs(): Promise<KPISummary> {
    const { data } = await api.get<KPISummary>('/analytics/kpis')
    return data
  },

  async getRevenue(days = 30): Promise<RevenueAnalytics> {
    const { data } = await api.get<RevenueAnalytics>('/analytics/revenue', { params: { days } })
    return data
  },

  async getMembers(months = 12): Promise<MemberDemographics> {
    const { data } = await api.get<MemberDemographics>('/analytics/members', { params: { months } })
    return data
  },

  async getAttendance(days = 30): Promise<AttendanceAnalytics> {
    const { data } = await api.get<AttendanceAnalytics>('/analytics/attendance', { params: { days } })
    return data
  },

  async getClasses(days = 30): Promise<ClassAnalytics> {
    const { data } = await api.get<ClassAnalytics>('/analytics/classes', { params: { days } })
    return data
  },

  async getTopMembers(limit = 10): Promise<TopMembersReport> {
    const { data } = await api.get<TopMembersReport>('/analytics/top-members', { params: { limit } })
    return data
  },

  async getActivityFeed(limit = 20): Promise<ActivityFeedItem[]> {
    const { data } = await api.get<ActivityFeedItem[]>('/analytics/activity-feed', { params: { limit } })
    return data
  },

  getCSVExportUrl(reportType: string, days = 30): string {
    return `/api/analytics/export/csv?report_type=${reportType}&days=${days}`
  },
}

// ---------------------------------------------------------------------------
// Classes Service
// ---------------------------------------------------------------------------
export const classesService = {
  async getAll(params?: { category?: string; upcoming_only?: boolean }): Promise<GymClass[]> {
    const { data } = await api.get<GymClass[]>('/classes/', { params })
    return data
  },

  async cancel(id: number, reason?: string): Promise<void> {
    await api.post(`/classes/${id}/cancel-class`, null, { params: { reason } })
  },
}

export default api
