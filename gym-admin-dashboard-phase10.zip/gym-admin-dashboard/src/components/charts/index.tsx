/**
 * components/charts/index.tsx — Reusable chart components
 *
 * All charts use Recharts with a consistent dark theme.
 * Color palette matches the GymOS design system.
 */

import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from 'recharts'
import type { DataPoint, MemberGrowthPoint, ClassPopularity } from '../../types'

// ── Design tokens shared across all charts ─────────────────
const COLORS = {
  blue:   '#3b6bff',
  green:  '#00d97e',
  red:    '#ff3b5c',
  amber:  '#ffb020',
  purple: '#9b59b6',
  muted:  '#8888a8',
  border: '#2a2a3a',
  card:   '#16161f',
}

const CHART_COLORS = [COLORS.blue, COLORS.green, COLORS.amber, COLORS.purple, COLORS.red]

// Shared axis / grid props
const axisStyle   = { fill: COLORS.muted, fontSize: 11 }
const gridStyle   = { stroke: COLORS.border, strokeDasharray: '3 3' }
const tooltipStyle = {
  contentStyle: { background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 8, color: '#f0f0f8' },
  labelStyle:   { color: COLORS.muted, fontSize: 11 },
}

// ============================================================
// REVENUE LINE CHART
// ============================================================
export function RevenueTrendChart({ data }: { data: DataPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <AreaChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor={COLORS.blue} stopOpacity={0.3} />
            <stop offset="95%" stopColor={COLORS.blue} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid {...gridStyle} vertical={false} />
        <XAxis dataKey="date" tick={axisStyle} tickLine={false} axisLine={false}
               tickFormatter={(v: string) => v.slice(5)} interval="preserveStartEnd" />
        <YAxis tick={axisStyle} tickLine={false} axisLine={false}
               tickFormatter={(v: number) => `$${v >= 1000 ? `${(v/1000).toFixed(1)}k` : v}`} />
        <Tooltip {...tooltipStyle} formatter={(v: number) => [`$${v.toFixed(2)}`, 'Revenue']} />
        <Area type="monotone" dataKey="value" stroke={COLORS.blue} strokeWidth={2}
              fill="url(#revenueGrad)" dot={false} activeDot={{ r: 4, fill: COLORS.blue }} />
      </AreaChart>
    </ResponsiveContainer>
  )
}

// ============================================================
// ATTENDANCE LINE CHART
// ============================================================
export function AttendanceTrendChart({ data }: { data: DataPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <AreaChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id="attendGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor={COLORS.green} stopOpacity={0.25} />
            <stop offset="95%" stopColor={COLORS.green} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid {...gridStyle} vertical={false} />
        <XAxis dataKey="date" tick={axisStyle} tickLine={false} axisLine={false}
               tickFormatter={(v: string) => v.slice(5)} interval="preserveStartEnd" />
        <YAxis tick={axisStyle} tickLine={false} axisLine={false} />
        <Tooltip {...tooltipStyle} formatter={(v: number) => [v, 'Check-ins']} />
        <Area type="monotone" dataKey="value" stroke={COLORS.green} strokeWidth={2}
              fill="url(#attendGrad)" dot={false} activeDot={{ r: 4, fill: COLORS.green }} />
      </AreaChart>
    </ResponsiveContainer>
  )
}

// ============================================================
// MEMBER GROWTH BAR CHART
// ============================================================
export function MemberGrowthChart({ data }: { data: MemberGrowthPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: 0 }} barSize={12}>
        <CartesianGrid {...gridStyle} vertical={false} />
        <XAxis dataKey="month" tick={axisStyle} tickLine={false} axisLine={false}
               tickFormatter={(v: string) => v.split(' ')[0]} />
        <YAxis tick={axisStyle} tickLine={false} axisLine={false} />
        <Tooltip {...tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 11, color: COLORS.muted }} />
        <Bar dataKey="new_members" name="New"    fill={COLORS.blue}  radius={[3,3,0,0]} />
        <Bar dataKey="churned"     name="Churned" fill={COLORS.red}  radius={[3,3,0,0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}

// ============================================================
// PLAN DISTRIBUTION PIE CHART
// ============================================================
export function PlanDistributionChart({ data }: {
  data: Array<{ plan: string; count: number; percentage: number }>
}) {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <PieChart>
        <Pie
          data={data}
          cx="50%" cy="50%"
          innerRadius={55} outerRadius={80}
          dataKey="count"
          nameKey="plan"
          paddingAngle={3}
        >
          {data.map((_, i) => (
            <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
          ))}
        </Pie>
        <Tooltip
          {...tooltipStyle}
          formatter={(v: number, _: string, entry: any) => [
            `${v} members (${entry.payload.percentage}%)`, entry.payload.plan
          ]}
        />
        <Legend
          formatter={(value) => <span style={{ color: COLORS.muted, fontSize: 11 }}>{value}</span>}
        />
      </PieChart>
    </ResponsiveContainer>
  )
}

// ============================================================
// CLASS POPULARITY BAR CHART
// ============================================================
export function ClassPopularityChart({ data }: { data: ClassPopularity[] }) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart
        data={data}
        layout="vertical"
        margin={{ top: 0, right: 20, bottom: 0, left: 60 }}
        barSize={10}
      >
        <CartesianGrid {...gridStyle} horizontal={false} />
        <XAxis type="number" tick={axisStyle} tickLine={false} axisLine={false}
               tickFormatter={(v: number) => `${v}%`} domain={[0, 100]} />
        <YAxis type="category" dataKey="category" tick={axisStyle} tickLine={false}
               axisLine={false} width={60}
               tickFormatter={(v: string) => v.charAt(0).toUpperCase() + v.slice(1)} />
        <Tooltip
          {...tooltipStyle}
          formatter={(v: number) => [`${v}%`, 'Fill Rate']}
        />
        <Bar dataKey="fill_rate_pct" name="Fill Rate" radius={[0, 3, 3, 0]}>
          {data.map((entry, i) => (
            <Cell
              key={i}
              fill={entry.fill_rate_pct > 75 ? COLORS.green :
                    entry.fill_rate_pct > 50 ? COLORS.blue  : COLORS.amber}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}

// ============================================================
// ATTENDANCE HEATMAP
// ============================================================
interface HeatmapCell {
  day_of_week: number
  hour: number
  avg_checkins: number
  day_name: string
  hour_label: string
}

export function AttendanceHeatmapChart({ cells, peakAvg }: {
  cells: HeatmapCell[]; peakAvg: number
}) {
  const DAYS  = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
  // Show business hours 5am–11pm (hours 5–22)
  const HOURS = Array.from({ length: 18 }, (_, i) => i + 5)

  // Build lookup map
  const map: Record<string, number> = {}
  cells.forEach(c => { map[`${c.day_of_week}-${c.hour}`] = c.avg_checkins })

  const getColor = (val: number) => {
    if (val === 0) return 'bg-surface-hover'
    const pct = val / (peakAvg || 1)
    if (pct > 0.75) return 'bg-brand-500'
    if (pct > 0.5)  return 'bg-brand-500/60'
    if (pct > 0.25) return 'bg-brand-500/30'
    return 'bg-brand-500/15'
  }

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[640px]">
        {/* Hour labels */}
        <div className="flex mb-1 ml-8">
          {HOURS.map(h => (
            <div key={h} className="flex-1 text-center text-[9px] text-[var(--muted)]">
              {h === 12 ? '12p' : h < 12 ? `${h}a` : `${h-12}p`}
            </div>
          ))}
        </div>
        {/* Grid */}
        {DAYS.map((day, dayIdx) => (
          <div key={day} className="flex items-center mb-1">
            <div className="w-8 text-[10px] text-[var(--muted)] shrink-0">{day}</div>
            {HOURS.map(h => {
              const val = map[`${dayIdx}-${h}`] ?? 0
              return (
                <div key={h} className="flex-1 px-0.5">
                  <div
                    className={`h-5 rounded-sm transition-colors ${getColor(val)}`}
                    title={`${day} ${h}:00 — avg ${val.toFixed(1)} check-ins`}
                  />
                </div>
              )
            })}
          </div>
        ))}
        {/* Legend */}
        <div className="flex items-center gap-2 mt-3 ml-8">
          <span className="text-[9px] text-[var(--muted)]">Low</span>
          {['bg-brand-500/15','bg-brand-500/30','bg-brand-500/60','bg-brand-500'].map((c, i) => (
            <div key={i} className={`w-5 h-3 rounded-sm ${c}`} />
          ))}
          <span className="text-[9px] text-[var(--muted)]">High</span>
        </div>
      </div>
    </div>
  )
}
