/**
 * components/layout/Header.tsx — Top header bar
 *
 * Shows page title, search, and a live clock.
 * Sits to the right of the sidebar (ml-56).
 */

import { useState, useEffect } from 'react'
import { Search, RefreshCw } from 'lucide-react'
import { format } from 'date-fns'

interface HeaderProps {
  title:    string
  subtitle?: string
  onRefresh?: () => void
  refreshing?: boolean
}

export default function Header({ title, subtitle, onRefresh, refreshing }: HeaderProps) {
  const [now, setNow] = useState(new Date())

  // Live clock — ticks every second
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  return (
    <header className="h-16 flex items-center justify-between px-6
                       border-b border-surface-border bg-surface/80 backdrop-blur-sm
                       sticky top-0 z-20">
      {/* Title */}
      <div>
        <h1 className="text-base font-semibold text-white leading-tight">{title}</h1>
        {subtitle && <p className="text-xs text-[var(--muted)]">{subtitle}</p>}
      </div>

      {/* Right side: clock + refresh */}
      <div className="flex items-center gap-3">
        {/* Live clock */}
        <div className="text-right hidden sm:block">
          <div className="text-xs font-mono text-white">{format(now, 'HH:mm:ss')}</div>
          <div className="text-[10px] text-[var(--muted)]">{format(now, 'EEE, MMM d yyyy')}</div>
        </div>

        {onRefresh && (
          <button
            onClick={onRefresh}
            className="btn-ghost p-2 rounded-lg"
            title="Refresh data"
          >
            <RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} />
          </button>
        )}
      </div>
    </header>
  )
}
