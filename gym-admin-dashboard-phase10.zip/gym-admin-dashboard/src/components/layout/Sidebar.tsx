/**
 * components/layout/Sidebar.tsx — Left navigation sidebar
 *
 * Fixed sidebar with logo, navigation links, and user info at bottom.
 * Active link highlighted with brand blue.
 */

import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, Users, CreditCard, Calendar,
  BarChart3, Dumbbell, QrCode, Bell, LogOut, Zap,
} from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import clsx from 'clsx'

const NAV_ITEMS = [
  { to: '/',           icon: LayoutDashboard, label: 'Dashboard'    },
  { to: '/users',      icon: Users,           label: 'Members'      },
  { to: '/memberships', icon: Zap,            label: 'Memberships'  },
  { to: '/payments',   icon: CreditCard,      label: 'Payments'     },
  { to: '/classes',    icon: Calendar,        label: 'Classes'      },
  { to: '/attendance', icon: QrCode,          label: 'Attendance'   },
  { to: '/workouts',   icon: Dumbbell,        label: 'Workouts'     },
  { to: '/analytics',  icon: BarChart3,       label: 'Analytics'    },
  { to: '/notifications', icon: Bell,         label: 'Notifications'},
]

export default function Sidebar() {
  const { user, logout } = useAuth()

  return (
    <aside className="fixed left-0 top-0 h-screen w-56 flex flex-col
                      bg-surface-card border-r border-surface-border z-30">

      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 h-16 border-b border-surface-border">
        <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center">
          <Dumbbell size={15} className="text-white" />
        </div>
        <span className="font-bold text-white text-base tracking-tight">GymOS</span>
        <span className="text-[10px] font-semibold text-brand-500 bg-brand-500/10
                         px-1.5 py-0.5 rounded ml-auto">ADMIN</span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
        {NAV_ITEMS.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              clsx('sidebar-link', isActive && 'active')
            }
          >
            <Icon size={16} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* User info + logout */}
      <div className="px-3 py-4 border-t border-surface-border">
        <div className="flex items-center gap-3 px-3 py-2 mb-1">
          {/* Avatar — initials */}
          <div className="w-7 h-7 rounded-full bg-brand-500/20 flex items-center
                          justify-center text-brand-500 text-xs font-bold shrink-0">
            {user?.full_name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-white truncate">{user?.full_name}</p>
            <p className="text-[10px] text-[var(--muted)] truncate">{user?.email}</p>
          </div>
        </div>
        <button onClick={logout} className="sidebar-link w-full text-accent-red/80
                                            hover:text-accent-red hover:bg-accent-red/10">
          <LogOut size={15} />
          Sign out
        </button>
      </div>
    </aside>
  )
}
