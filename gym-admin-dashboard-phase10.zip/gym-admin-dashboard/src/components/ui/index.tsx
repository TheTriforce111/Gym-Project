/**
 * components/ui/index.tsx — Reusable UI components
 *
 * Small, composable building blocks used throughout the dashboard.
 */

import React, { ReactNode } from 'react'
import { TrendingUp, TrendingDown, Minus, Loader2 } from 'lucide-react'
import clsx from 'clsx'

// ============================================================
// KPI CARD
// ============================================================
interface KPICardProps {
  label:      string
  value:      string | number
  trend?:     number | null   // percentage change vs previous period
  icon?:      ReactNode
  iconColor?: string
  sublabel?:  string
  loading?:   boolean
}

export function KPICard({ label, value, trend, icon, iconColor = 'text-brand-500', sublabel, loading }: KPICardProps) {
  const isUp   = (trend ?? 0) > 0
  const isDown = (trend ?? 0) < 0

  return (
    <div className="card flex flex-col gap-3">
      <div className="flex items-start justify-between">
        <span className="text-xs font-medium text-[var(--muted)] uppercase tracking-wider">
          {label}
        </span>
        {icon && (
          <span className={clsx('opacity-80', iconColor)}>{icon}</span>
        )}
      </div>

      {loading ? (
        <div className="h-8 bg-surface-hover animate-pulse rounded-md w-24" />
      ) : (
        <div className="kpi-value">{value}</div>
      )}

      <div className="flex items-center gap-2 mt-auto">
        {trend !== undefined && trend !== null && (
          <span className={clsx(
            'flex items-center gap-0.5 text-xs font-semibold',
            isUp ? 'text-accent-green' : isDown ? 'text-accent-red' : 'text-[var(--muted)]'
          )}>
            {isUp ? <TrendingUp size={11} /> : isDown ? <TrendingDown size={11} /> : <Minus size={11} />}
            {Math.abs(trend).toFixed(1)}%
          </span>
        )}
        {sublabel && <span className="text-xs text-[var(--muted)]">{sublabel}</span>}
      </div>
    </div>
  )
}

// ============================================================
// STAT ROW — compact inline stat
// ============================================================
export function StatRow({ label, value, highlight }: {
  label: string; value: string | number; highlight?: boolean
}) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-surface-border/50 last:border-0">
      <span className="text-xs text-[var(--muted)]">{label}</span>
      <span className={clsx('text-sm font-semibold', highlight ? 'text-accent-green' : 'text-white')}>
        {value}
      </span>
    </div>
  )
}

// ============================================================
// BADGE
// ============================================================
type BadgeVariant = 'green' | 'red' | 'amber' | 'blue' | 'subtle' | 'purple'

export function Badge({ children, variant = 'subtle' }: { children: ReactNode; variant?: BadgeVariant }) {
  return (
    <span className={clsx('badge', `badge-${variant}`)}>
      {children}
    </span>
  )
}

export function MembershipStatusBadge({ status }: { status: string }) {
  const map: Record<string, BadgeVariant> = {
    active: 'green', expired: 'red', frozen: 'blue', cancelled: 'subtle',
  }
  return <Badge variant={map[status] ?? 'subtle'}>{status}</Badge>
}

export function PaymentStatusBadge({ status }: { status: string }) {
  const map: Record<string, BadgeVariant> = {
    success: 'green', failed: 'red', pending: 'amber', refunded: 'blue', cancelled: 'subtle',
  }
  return <Badge variant={map[status] ?? 'subtle'}>{status}</Badge>
}

// ============================================================
// LOADING SPINNER
// ============================================================
export function Spinner({ size = 20, className }: { size?: number; className?: string }) {
  return <Loader2 size={size} className={clsx('animate-spin text-brand-500', className)} />
}

// ============================================================
// EMPTY STATE
// ============================================================
export function EmptyState({ icon, title, description }: {
  icon?: ReactNode; title: string; description?: string
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      {icon && <div className="text-4xl mb-4 opacity-30">{icon}</div>}
      <p className="text-sm font-medium text-[var(--muted)]">{title}</p>
      {description && <p className="text-xs text-[var(--subtle)] mt-1">{description}</p>}
    </div>
  )
}

// ============================================================
// PAGE LOADER
// ============================================================
export function PageLoader() {
  return (
    <div className="flex items-center justify-center h-64">
      <Spinner size={28} />
    </div>
  )
}

// ============================================================
// SECTION CARD wrapper
// ============================================================
export function SectionCard({ title, children, actions }: {
  title?: string; children: ReactNode; actions?: ReactNode
}) {
  return (
    <div className="card">
      {(title || actions) && (
        <div className="flex items-center justify-between mb-5">
          {title && <h3 className="section-title mb-0">{title}</h3>}
          {actions && <div className="flex items-center gap-2">{actions}</div>}
        </div>
      )}
      {children}
    </div>
  )
}

// ============================================================
// MODAL (simple overlay)
// ============================================================
export function Modal({ open, onClose, title, children }: {
  open: boolean; onClose: () => void; title: string; children: ReactNode
}) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-surface-card border border-surface-border rounded-2xl
                      w-full max-w-md p-6 shadow-2xl">
        <h2 className="text-base font-semibold text-white mb-4">{title}</h2>
        {children}
      </div>
    </div>
  )
}

// ============================================================
// CONFIRM DIALOG
// ============================================================
export function ConfirmDialog({ open, onClose, onConfirm, title, message, danger }: {
  open: boolean; onClose: () => void; onConfirm: () => void;
  title: string; message: string; danger?: boolean
}) {
  return (
    <Modal open={open} onClose={onClose} title={title}>
      <p className="text-sm text-[var(--muted)] mb-6">{message}</p>
      <div className="flex gap-3 justify-end">
        <button className="btn-ghost" onClick={onClose}>Cancel</button>
        <button
          className={danger ? 'btn-danger' : 'btn-primary'}
          onClick={() => { onConfirm(); onClose() }}
        >
          Confirm
        </button>
      </div>
    </Modal>
  )
}
