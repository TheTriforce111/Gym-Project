/**
 * hooks/useAuth.tsx — Authentication Context + Hook
 *
 * Provides the current user, login, and logout to all components.
 * Wrap the app in <AuthProvider> then use useAuth() anywhere.
 */

import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { authService } from '../services/api'
import type { User } from '../types'

interface AuthContextValue {
  user:          User | null
  loading:       boolean
  login:         (email: string, password: string) => Promise<void>
  logout:        () => void
  isAuthenticated: boolean
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user,    setUser]    = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // On mount: check if we have a stored token and fetch user info
  useEffect(() => {
    if (authService.isAuthenticated()) {
      authService.getMe()
        .then(setUser)
        .catch(() => {
          // Token invalid — clear and redirect
          localStorage.removeItem('access_token')
          localStorage.removeItem('refresh_token')
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  const login = async (email: string, password: string) => {
    await authService.login({ email, password })
    const me = await authService.getMe()
    // Only admins can access this dashboard
    if (me.role !== 'admin') {
      authService.logout()
      throw new Error('Access denied. Admin account required.')
    }
    setUser(me)
  }

  const logout = () => {
    setUser(null)
    authService.logout()
  }

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      login,
      logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within <AuthProvider>')
  return ctx
}
