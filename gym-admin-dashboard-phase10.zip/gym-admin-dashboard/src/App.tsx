/**
 * App.tsx — Root application component
 *
 * Sets up:
 * - AuthProvider (JWT context)
 * - React Router (all page routes)
 * - Protected route wrapper (redirects to /login if not authenticated)
 * - Layout: Sidebar (fixed left) + main content area (ml-56)
 */

import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom'
import { AuthProvider, useAuth } from './hooks/useAuth'
import Sidebar from './components/layout/Sidebar'
import { Spinner } from './components/ui'

// Pages
import Login         from './pages/Login'
import Dashboard     from './pages/Dashboard'
import Members       from './pages/Members'
import Memberships   from './pages/Memberships'
import Payments      from './pages/Payments'
import Analytics     from './pages/Analytics'
import { Classes, Attendance, Workouts, Notifications } from './pages/stubs'

// ---------------------------------------------------------------------------
// Protected Route Wrapper
// Shows a loading spinner while auth is resolving.
// Redirects to /login if not authenticated.
// ---------------------------------------------------------------------------
function ProtectedLayout() {
  const { isAuthenticated, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size={28} />
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  return (
    <div className="flex min-h-screen">
      {/* Fixed left sidebar */}
      <Sidebar />

      {/* Main content — offset by sidebar width */}
      <main className="ml-56 flex-1 flex flex-col min-h-screen overflow-hidden">
        <Outlet />
      </main>
    </div>
  )
}

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------
export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public route */}
          <Route path="/login" element={<LoginGuard />} />

          {/* Protected routes — all share the sidebar layout */}
          <Route element={<ProtectedLayout />}>
            <Route path="/"             element={<Dashboard />} />
            <Route path="/users"        element={<Members />} />
            <Route path="/memberships"  element={<Memberships />} />
            <Route path="/payments"     element={<Payments />} />
            <Route path="/classes"      element={<Classes />} />
            <Route path="/attendance"   element={<Attendance />} />
            <Route path="/workouts"     element={<Workouts />} />
            <Route path="/analytics"    element={<Analytics />} />
            <Route path="/notifications" element={<Notifications />} />
          </Route>

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}

// Redirect already-logged-in users away from the login page
function LoginGuard() {
  const { isAuthenticated, loading } = useAuth()
  if (loading) return <div className="min-h-screen flex items-center justify-center"><Spinner /></div>
  if (isAuthenticated) return <Navigate to="/" replace />
  return <Login />
}
