/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Brand palette — dark gym aesthetic with electric accent
        brand: {
          50:  '#f0f4ff',
          100: '#e0e9ff',
          500: '#3b6bff',   // Electric blue — CTAs, active states
          600: '#2952e3',
          700: '#1e3db8',
          900: '#0f1e5a',
        },
        surface: {
          DEFAULT: '#0e0e16',  // Near-black background
          card:    '#16161f',  // Card background
          hover:   '#1e1e2a',  // Hover state
          border:  '#2a2a3a',  // Subtle borders
        },
        accent: {
          red:    '#ff3b5c',   // Danger / revenue drop
          green:  '#00d97e',   // Success / revenue up
          amber:  '#ffb020',   // Warning / expiring soon
          purple: '#9b59b6',   // Classes / workout
        },
      },
      fontFamily: {
        sans:  ['Inter', 'system-ui', 'sans-serif'],
        mono:  ['JetBrains Mono', 'monospace'],
        display: ['Inter', 'sans-serif'],
      },
      borderRadius: {
        'xl': '12px',
        '2xl': '16px',
      },
    },
  },
  plugins: [],
}
