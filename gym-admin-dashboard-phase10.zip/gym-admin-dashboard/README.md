# 🖥️ Phase 10 — React Admin Dashboard (GymOS)

A full TypeScript + React admin dashboard with dark gym aesthetic, live charts, and JWT auth. Connects to all Phase 1–9 backend endpoints.

---

## 📁 Project Structure

```
gym-admin-dashboard/
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Sidebar.tsx      ← Fixed left nav with all routes
│   │   │   └── Header.tsx       ← Top bar with live clock + refresh
│   │   ├── charts/
│   │   │   └── index.tsx        ← Revenue, Attendance, Growth, Heatmap charts
│   │   └── ui/
│   │       └── index.tsx        ← KPICard, Badge, Modal, Table, Spinner, etc.
│   ├── hooks/
│   │   └── useAuth.tsx          ← JWT auth context + login/logout
│   ├── pages/
│   │   ├── Login.tsx            ← Dark login form (admin only)
│   │   ├── Dashboard.tsx        ← Main overview with all charts + KPIs
│   │   ├── Members.tsx          ← Member table + detail panel
│   │   ├── Memberships.tsx      ← Membership table with freeze/cancel actions
│   │   ├── Payments.tsx         ← Payment history + refund + CSV export
│   │   ├── Analytics.tsx        ← Deep analytics with period selector
│   │   └── stubs.tsx            ← Classes, Attendance, Workouts, Notifications
│   ├── services/
│   │   └── api.ts               ← Axios instance with auto-refresh + all API calls
│   ├── types/
│   │   └── index.ts             ← TypeScript interfaces for all API responses
│   ├── App.tsx                  ← Router + layout + protected routes
│   ├── main.tsx                 ← React entry point
│   └── index.css                ← Tailwind + custom design tokens
├── package.json
├── vite.config.ts               ← Dev proxy to FastAPI on :8000
├── tailwind.config.js           ← Dark theme color palette
└── tsconfig.json
```

---

## 🚀 Quick Start

```bash
# 1. Navigate to the project
cd gym-admin-dashboard

# 2. Install dependencies
npm install

# 3. Start the dev server (FastAPI must be running on :8000)
npm run dev

# Opens: http://localhost:3000
# Login with your admin account credentials
```

---

## 🎨 Design System

**Palette:**
- Background: `#0e0e16` (near-black)
- Card: `#16161f`
- Brand Blue: `#3b6bff` (CTAs, active nav, charts)
- Success Green: `#00d97e`
- Danger Red: `#ff3b5c`
- Warning Amber: `#ffb020`

**Typography:** Inter (300–800 weights) — tabular numbers for KPI displays

**Signature element:** The attendance heatmap — a 7×24 grid that shows gym peak hours at a glance, color-coded from faint blue (quiet) to solid blue (peak).

---

## 📄 Pages

| Page | Route | What it shows |
|------|-------|---------------|
| Login | `/login` | Dark login form, admin-only |
| Dashboard | `/` | KPIs, all charts, activity feed, top members |
| Members | `/users` | Searchable member table + detail panel |
| Memberships | `/memberships` | All memberships with freeze/cancel/renew actions |
| Payments | `/payments` | Transaction history, stats, refund, CSV export |
| Analytics | `/analytics` | Deep-dive with period selector (7/30/90/365d) |
| Classes | `/classes` | Stub — connects to class scheduling endpoints |
| Attendance | `/attendance` | Stub — connects to QR attendance endpoints |
| Workouts | `/workouts` | Stub — connects to workout endpoints |
| Notifications | `/notifications` | Stub — connects to notification endpoints |

---

## 🔌 API Connection

All requests go through `src/services/api.ts`:

```typescript
// JWT is automatically attached to every request
const api = axios.create({ baseURL: '/api' })

// Token auto-refresh on 401 (transparent to the UI)
api.interceptors.response.use(null, async (error) => {
  if (error.response?.status === 401) {
    const newToken = await refreshAccessToken()
    return api(originalRequest)  // retry automatically
  }
})
```

The Vite dev server proxies `/api` to `http://localhost:8000` — no CORS issues during development.

---

## 📦 Building for Production

```bash
npm run build
# Output in: dist/

# Serve with nginx, serve, or any static file server
# Configure nginx to proxy /api to your FastAPI backend
```

nginx example:
```nginx
location /api/ {
    proxy_pass http://localhost:8000;
}
location / {
    root /var/www/gym-admin;
    try_files $uri /index.html;  # SPA routing
}
```

---

## ➡️ Next: Phase 11 — Flutter Mobile App

The member-facing mobile app:
- Login / Register
- QR Code check-in screen
- Workout tracking with personal bests
- Class booking with waitlist
- Membership status and expiry
- Push notifications (Firebase)
