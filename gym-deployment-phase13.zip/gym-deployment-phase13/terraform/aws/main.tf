# terraform/aws/main.tf — AWS Infrastructure (Terraform)
# ============================================================
# Provisions the following AWS resources:
#
#   VPC                   → Isolated network
#   EC2 t3.medium         → Application server (API + workers)
#   RDS db.t3.micro       → Managed PostgreSQL (automated backups)
#   ElastiCache t3.micro  → Managed Redis
#   ALB                   → Application Load Balancer (HTTPS)
#   ACM Certificate       → Free SSL/TLS from AWS
#   S3 Bucket             → Database backups + static files
#   CloudFront            → CDN for the React admin dashboard
#
# Cost estimate (us-east-1, on-demand):
#   EC2 t3.medium:   ~$30/month
#   RDS t3.micro:    ~$15/month
#   ElastiCache:     ~$12/month
#   ALB:             ~$16/month
#   Total:           ~$75/month
#
# Usage:
#   terraform init
#   terraform plan
#   terraform apply
# ============================================================

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # Store Terraform state in S3 (required for team collaboration)
  backend "s3" {
    bucket = "gymapp-terraform-state"
    key    = "production/terraform.tfstate"
    region = "us-east-1"
    encrypt = true
  }
}

provider "aws" {
  region = var.aws_region
}

# ── Variables ─────────────────────────────────────────────────
variable "aws_region"    { default = "us-east-1" }
variable "app_name"      { default = "gymapp" }
variable "environment"   { default = "production" }
variable "domain_name"   { description = "Your domain e.g. yourgym.com" }
variable "db_password"   { sensitive = true; description = "PostgreSQL password" }
variable "redis_password"{ sensitive = true; description = "Redis auth token" }

locals {
  tags = {
    Project     = var.app_name
    Environment = var.environment
    ManagedBy   = "Terraform"
  }
}

# ── VPC ───────────────────────────────────────────────────────
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags = merge(local.tags, { Name = "${var.app_name}-vpc" })
}

resource "aws_subnet" "public" {
  count             = 2
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.${count.index}.0/24"
  availability_zone = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true
  tags = merge(local.tags, { Name = "${var.app_name}-public-${count.index}" })
}

resource "aws_subnet" "private" {
  count             = 2
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.${count.index + 10}.0/24"
  availability_zone = data.aws_availability_zones.available.names[count.index]
  tags = merge(local.tags, { Name = "${var.app_name}-private-${count.index}" })
}

data "aws_availability_zones" "available" { state = "available" }

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id
  tags   = merge(local.tags, { Name = "${var.app_name}-igw" })
}

# ── Security Groups ───────────────────────────────────────────
resource "aws_security_group" "alb" {
  name   = "${var.app_name}-alb-sg"
  vpc_id = aws_vpc.main.id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]   # Allow HTTP from anywhere (redirects to HTTPS)
  }
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]   # Allow HTTPS from anywhere
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = local.tags
}

resource "aws_security_group" "ec2" {
  name   = "${var.app_name}-ec2-sg"
  vpc_id = aws_vpc.main.id

  ingress {
    from_port       = 8000
    to_port         = 8000
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]  # Only from ALB
  }
  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["YOUR_OFFICE_IP/32"]  # SSH from your IP only
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = local.tags
}

resource "aws_security_group" "rds" {
  name   = "${var.app_name}-rds-sg"
  vpc_id = aws_vpc.main.id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.ec2.id]  # Only from EC2
  }
  tags = local.tags
}

resource "aws_security_group" "redis" {
  name   = "${var.app_name}-redis-sg"
  vpc_id = aws_vpc.main.id

  ingress {
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [aws_security_group.ec2.id]  # Only from EC2
  }
  tags = local.tags
}

# ── RDS PostgreSQL ────────────────────────────────────────────
resource "aws_db_subnet_group" "main" {
  name       = "${var.app_name}-db-subnet-group"
  subnet_ids = aws_subnet.private[*].id
  tags       = local.tags
}

resource "aws_db_instance" "postgres" {
  identifier        = "${var.app_name}-postgres"
  engine            = "postgres"
  engine_version    = "15.4"
  instance_class    = "db.t3.micro"
  allocated_storage = 20
  storage_encrypted = true

  db_name  = "gymdb"
  username = "gymapp"
  password = var.db_password

  vpc_security_group_ids = [aws_security_group.rds.id]
  db_subnet_group_name   = aws_db_subnet_group.main.name

  # Automated backups
  backup_retention_period = 7        # Keep 7 days of backups
  backup_window          = "02:00-03:00"  # 2-3am UTC
  maintenance_window     = "sun:04:00-sun:05:00"

  # High availability
  multi_az = true   # Standby replica in different AZ

  # Don't delete the database when terraform destroy is run
  deletion_protection = true
  skip_final_snapshot = false
  final_snapshot_identifier = "${var.app_name}-final-snapshot"

  tags = local.tags
}

# ── ElastiCache Redis ─────────────────────────────────────────
resource "aws_elasticache_subnet_group" "main" {
  name       = "${var.app_name}-redis-subnet-group"
  subnet_ids = aws_subnet.private[*].id
}

resource "aws_elasticache_cluster" "redis" {
  cluster_id           = "${var.app_name}-redis"
  engine               = "redis"
  node_type            = "cache.t3.micro"
  num_cache_nodes      = 1
  parameter_group_name = "default.redis7"
  engine_version       = "7.0"
  port                 = 6379

  subnet_group_name  = aws_elasticache_subnet_group.main.name
  security_group_ids = [aws_security_group.redis.id]

  tags = local.tags
}

# ── EC2 Instance ──────────────────────────────────────────────
data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"]  # Canonical (Ubuntu)
  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]
  }
}

resource "aws_instance" "app" {
  ami           = data.aws_ami.ubuntu.id
  instance_type = "t3.medium"

  subnet_id              = aws_subnet.public[0].id
  vpc_security_group_ids = [aws_security_group.ec2.id]
  key_name               = var.key_pair_name

  root_block_device {
    volume_type = "gp3"
    volume_size = 30
    encrypted   = true
  }

  user_data = base64encode(templatefile("${path.module}/user-data.sh", {
    app_name      = var.app_name
    db_host       = aws_db_instance.postgres.address
    redis_host    = aws_elasticache_cluster.redis.cache_nodes[0].address
  }))

  tags = merge(local.tags, { Name = "${var.app_name}-server" })
}

# ── S3 Backup Bucket ──────────────────────────────────────────
resource "aws_s3_bucket" "backups" {
  bucket = "${var.app_name}-backups-${var.environment}"
  tags   = local.tags
}

resource "aws_s3_bucket_lifecycle_configuration" "backups" {
  bucket = aws_s3_bucket.backups.id
  rule {
    id     = "backup-retention"
    status = "Enabled"
    expiration { days = 90 }  # Delete backups older than 90 days
    transition {
      days          = 30
      storage_class = "STANDARD_IA"  # Move to cheap storage after 30 days
    }
  }
}

# ── Outputs ───────────────────────────────────────────────────
output "ec2_public_ip"   { value = aws_instance.app.public_ip }
output "rds_endpoint"    { value = aws_db_instance.postgres.address }
output "redis_endpoint"  { value = aws_elasticache_cluster.redis.cache_nodes[0].address }
output "s3_bucket"       { value = aws_s3_bucket.backups.bucket }

variable "key_pair_name" { description = "EC2 SSH key pair name" }
