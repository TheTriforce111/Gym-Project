#!/usr/bin/env bash
# scripts/deploy.sh — Zero-Downtime Deployment Script
# ============================================================
# Usage:
#   ./scripts/deploy.sh              # Deploy latest main branch
#   ./scripts/deploy.sh --skip-tests # Skip tests (emergency deploy)
#   ./scripts/deploy.sh --rollback   # Roll back to previous version
#
# What this script does:
#   1. Pull latest code from Git
#   2. Run tests (optional)
#   3. Build new Docker image
#   4. Run database migrations (Alembic)
#   5. Rolling restart of API instances (no downtime)
#   6. Verify the new version is healthy
#   7. Roll back automatically if health check fails
#
# Requirements:
#   - Docker + Docker Compose v2
#   - Git access to the repository
#   - .env.prod file present
#   - Server user in the docker group
# ============================================================

set -euo pipefail
# -e: exit on error
# -u: exit on unset variable
# -o pipefail: exit if any command in a pipe fails

# ── Configuration ────────────────────────────────────────────
COMPOSE_FILE="docker-compose.prod.yml"
APP_DIR="/opt/gymapp"        # Where the repo is cloned on the server
LOG_FILE="/var/log/gymapp/deploy.log"
HEALTH_CHECK_URL="http://localhost/health"
HEALTH_CHECK_RETRIES=10
HEALTH_CHECK_INTERVAL=5      # Seconds between health check attempts

# Colors for output
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

# ── Helpers ──────────────────────────────────────────────────
log() { echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $*" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[$(date '+%H:%M:%S')] WARN:${NC} $*" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[$(date '+%H:%M:%S')] ERROR:${NC} $*" | tee -a "$LOG_FILE"; }

# ── Parse arguments ───────────────────────────────────────────
SKIP_TESTS=false
ROLLBACK=false
for arg in "$@"; do
    case $arg in
        --skip-tests) SKIP_TESTS=true  ;;
        --rollback)   ROLLBACK=true    ;;
    esac
done

# ── Rollback function ─────────────────────────────────────────
rollback() {
    warn "Rolling back to previous version..."
    cd "$APP_DIR"
    git checkout HEAD~1
    docker compose -f "$COMPOSE_FILE" up -d --no-deps api
    log "Rollback complete."
    exit 1
}

# ── Trap errors → auto rollback ───────────────────────────────
trap 'error "Deployment failed! Initiating rollback..."; rollback' ERR

# ── Handle rollback flag ──────────────────────────────────────
if [ "$ROLLBACK" = true ]; then
    rollback
fi

# ── Main deployment ───────────────────────────────────────────
mkdir -p "$(dirname "$LOG_FILE")"
log "=========================================="
log "Starting GymOS deployment"
log "Timestamp: $(date)"
log "=========================================="

# Step 1: Pull latest code
log "Step 1/7: Pulling latest code..."
cd "$APP_DIR"
git fetch origin main
git reset --hard origin/main
COMMIT_HASH=$(git rev-parse --short HEAD)
COMMIT_MSG=$(git log -1 --pretty=format:"%s")
log "  Commit: $COMMIT_HASH — $COMMIT_MSG"

# Step 2: Run tests
if [ "$SKIP_TESTS" = false ]; then
    log "Step 2/7: Running tests..."
    docker compose -f "$COMPOSE_FILE" run --rm \
        -e DATABASE_URL=sqlite:///./test.db \
        api pytest tests/ -q --tb=short
    log "  ✅ All tests passed"
else
    warn "Step 2/7: Tests SKIPPED (--skip-tests flag)"
fi

# Step 3: Build new image
log "Step 3/7: Building new Docker image..."
docker compose -f "$COMPOSE_FILE" build \
    --no-cache \
    --build-arg BUILD_DATE="$(date -u +'%Y-%m-%dT%H:%M:%SZ')" \
    --build-arg GIT_COMMIT="$COMMIT_HASH" \
    api worker beat
log "  ✅ Images built: $COMMIT_HASH"

# Step 4: Run database migrations
log "Step 4/7: Running database migrations..."
docker compose -f "$COMPOSE_FILE" run --rm api \
    alembic upgrade head
log "  ✅ Migrations applied"

# Step 5: Rolling restart of API
log "Step 5/7: Rolling restart of API instances..."
# Scale down to 1, bring up new, then scale back to 2
# This ensures at least one instance is always serving traffic
docker compose -f "$COMPOSE_FILE" up -d --no-deps --scale api=1 api
sleep 5
docker compose -f "$COMPOSE_FILE" up -d --no-deps --scale api=2 api

# Step 6: Restart workers (they can have downtime — async processing)
log "Step 6/7: Restarting workers..."
docker compose -f "$COMPOSE_FILE" up -d --no-deps worker beat
log "  ✅ Workers restarted"

# Step 7: Health check
log "Step 7/7: Verifying deployment health..."
for i in $(seq 1 $HEALTH_CHECK_RETRIES); do
    if curl -sf "$HEALTH_CHECK_URL" > /dev/null 2>&1; then
        log "  ✅ Health check passed (attempt $i/$HEALTH_CHECK_RETRIES)"
        break
    fi
    if [ "$i" -eq "$HEALTH_CHECK_RETRIES" ]; then
        error "Health check failed after $HEALTH_CHECK_RETRIES attempts!"
        exit 1   # Triggers the ERR trap → rollback
    fi
    warn "  Health check attempt $i/$HEALTH_CHECK_RETRIES failed, retrying in ${HEALTH_CHECK_INTERVAL}s..."
    sleep "$HEALTH_CHECK_INTERVAL"
done

# Remove dangling images (old layers that are no longer referenced)
docker image prune -f

log "=========================================="
log "✅ Deployment successful!"
log "   Version:   $COMMIT_HASH"
log "   Message:   $COMMIT_MSG"
log "   Timestamp: $(date)"
log "=========================================="
