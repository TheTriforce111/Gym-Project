-- scripts/db-init.sql
-- ============================================================
-- Runs ONCE when the PostgreSQL container is first created.
-- Sets up extensions and performance-related configuration.
-- ============================================================

-- Enable UUID generation (for idempotency keys, etc.)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable pg_trgm for fast text search (LIKE/ILIKE on large tables)
-- Used for member name search in the admin dashboard
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Enable btree_gist for range exclusion constraints
-- Used for preventing overlapping time periods (if needed)
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- Enable pgcrypto for password hashing at DB level (backup layer)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── Performance indexes ──────────────────────────────────────────────────
-- These are in addition to the indexes SQLAlchemy creates from the models.
-- Created here so they exist even before migrations run.

-- Trigram index for fast case-insensitive member name search
-- Enables: WHERE full_name ILIKE '%john%' to use an index
-- Without this, searches on large member tables do full scans.
CREATE INDEX IF NOT EXISTS idx_users_full_name_trgm
    ON users USING GIN (full_name gin_trgm_ops);

CREATE INDEX IF NOT EXISTS idx_users_email_trgm
    ON users USING GIN (email gin_trgm_ops);

-- Compound index for attendance queries (most common query pattern)
-- "Did user X check in on date Y?" — used by QR check-in validation
CREATE INDEX IF NOT EXISTS idx_attendance_user_date
    ON attendances (user_id, check_in_date DESC);

-- Index for membership expiry queries (used by daily scheduled task)
CREATE INDEX IF NOT EXISTS idx_memberships_status_enddate
    ON memberships (status, end_date)
    WHERE status = 'active';

-- Index for payment analytics queries (date-ranged aggregations)
CREATE INDEX IF NOT EXISTS idx_payments_status_created
    ON payments (status, created_at DESC)
    WHERE status = 'success';

-- Index for class schedule queries (upcoming classes)
CREATE INDEX IF NOT EXISTS idx_gym_classes_start_status
    ON gym_classes (start_time ASC, status)
    WHERE status = 'scheduled';

-- Index for notifications inbox queries
CREATE INDEX IF NOT EXISTS idx_notifications_user_status
    ON notifications (user_id, created_at DESC)
    WHERE status != 'read';

-- ── Database configuration ───────────────────────────────────────────────
-- Set timezone to UTC — all timestamps stored and compared in UTC
ALTER DATABASE gymdb SET timezone TO 'UTC';

-- Enable statement statistics (for pg_stat_statements monitoring)
-- ALTER SYSTEM SET shared_preload_libraries = 'pg_stat_statements';

-- Log slow queries (queries taking more than 1 second)
ALTER DATABASE gymdb SET log_min_duration_statement TO 1000;

-- ── Verify setup ─────────────────────────────────────────────────────────
DO $$
BEGIN
    RAISE NOTICE 'GymOS database initialized successfully.';
    RAISE NOTICE 'Extensions: uuid-ossp, pg_trgm, btree_gist, pgcrypto';
    RAISE NOTICE 'Performance indexes: created for common query patterns';
END
$$;
