#!/usr/bin/env bash
# scripts/backup.sh — Automated Database Backup
# ============================================================
# Usage:
#   ./scripts/backup.sh              # One-time backup
#   Add to crontab for scheduled backups:
#   0 2 * * * /opt/gymapp/scripts/backup.sh
#   (runs at 2am every night)
#
# Backups are:
#   - Compressed with gzip
#   - Named with timestamp
#   - Rotated: keep last 30 daily, 12 monthly backups
#   - Optionally uploaded to S3 / GCS
# ============================================================

set -euo pipefail

# ── Configuration ────────────────────────────────────────────
BACKUP_DIR="/var/backups/gymapp"
RETENTION_DAYS=30
RETENTION_MONTHS=12
S3_BUCKET="${S3_BACKUP_BUCKET:-}"     # Optional: set in .env.prod
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="gymapp_backup_${TIMESTAMP}.sql.gz"

# ── Create backup directory ───────────────────────────────────
mkdir -p "$BACKUP_DIR"

echo "[$(date '+%H:%M:%S')] Starting backup: $BACKUP_FILE"

# ── Dump PostgreSQL → compress ────────────────────────────────
docker exec gym_db pg_dump \
    -U "${DB_USER}" \
    "${DB_NAME}" \
    --no-password \
    --format=plain \
    --no-owner \
    --no-acl \
    | gzip -9 > "$BACKUP_DIR/$BACKUP_FILE"

SIZE=$(du -sh "$BACKUP_DIR/$BACKUP_FILE" | cut -f1)
echo "[$(date '+%H:%M:%S')] Backup created: $BACKUP_FILE ($SIZE)"

# ── Upload to S3 (if configured) ─────────────────────────────
if [ -n "$S3_BUCKET" ]; then
    aws s3 cp "$BACKUP_DIR/$BACKUP_FILE" "s3://$S3_BUCKET/backups/$BACKUP_FILE" \
        --storage-class STANDARD_IA
    # STANDARD_IA: Infrequent Access — cheaper for backups
    echo "[$(date '+%H:%M:%S')] Uploaded to s3://$S3_BUCKET/backups/$BACKUP_FILE"
fi

# ── Rotate old backups ────────────────────────────────────────
# Delete daily backups older than RETENTION_DAYS
find "$BACKUP_DIR" -name "gymapp_backup_*.sql.gz" \
    -mtime +"$RETENTION_DAYS" -delete

echo "[$(date '+%H:%M:%S')] Old backups cleaned up (kept last $RETENTION_DAYS days)"

# ── Verify backup integrity ───────────────────────────────────
if gzip -t "$BACKUP_DIR/$BACKUP_FILE" 2>/dev/null; then
    echo "[$(date '+%H:%M:%S')] ✅ Backup integrity verified"
else
    echo "[$(date '+%H:%M:%S')] ❌ ERROR: Backup file is corrupted!" >&2
    exit 1
fi

echo "[$(date '+%H:%M:%S')] Backup complete: $BACKUP_FILE"


# ============================================================
# scripts/restore.sh — Database Restore from Backup
# ============================================================
# Usage:
#   ./scripts/restore.sh gymapp_backup_20250210_020000.sql.gz
#
# WARNING: This REPLACES all current data with the backup.
#          Take a fresh backup first if you have recent data!
# ============================================================
restore_database() {
    BACKUP_TO_RESTORE="$1"

    if [ -z "$BACKUP_TO_RESTORE" ]; then
        echo "Usage: $0 <backup_file.sql.gz>"
        echo "Available backups:"
        ls -la "$BACKUP_DIR"/*.sql.gz 2>/dev/null || echo "  No backups found"
        exit 1
    fi

    if [ ! -f "$BACKUP_DIR/$BACKUP_TO_RESTORE" ]; then
        echo "ERROR: Backup file not found: $BACKUP_DIR/$BACKUP_TO_RESTORE"
        exit 1
    fi

    echo "⚠️  WARNING: This will REPLACE all current database data!"
    echo "   Backup to restore: $BACKUP_TO_RESTORE"
    read -r -p "Type 'yes' to confirm: " confirm
    if [ "$confirm" != "yes" ]; then
        echo "Restore cancelled."
        exit 0
    fi

    echo "[$(date '+%H:%M:%S')] Stopping API to prevent writes during restore..."
    docker compose -f /opt/gymapp/docker-compose.prod.yml stop api worker beat

    echo "[$(date '+%H:%M:%S')] Dropping and recreating database..."
    docker exec gym_db psql -U "${DB_USER}" -c "DROP DATABASE IF EXISTS ${DB_NAME};"
    docker exec gym_db psql -U "${DB_USER}" -c "CREATE DATABASE ${DB_NAME};"

    echo "[$(date '+%H:%M:%S')] Restoring from backup..."
    gunzip -c "$BACKUP_DIR/$BACKUP_TO_RESTORE" | \
        docker exec -i gym_db psql -U "${DB_USER}" "${DB_NAME}"

    echo "[$(date '+%H:%M:%S')] Running migrations to latest schema..."
    docker compose -f /opt/gymapp/docker-compose.prod.yml run --rm api alembic upgrade head

    echo "[$(date '+%H:%M:%S')] Restarting services..."
    docker compose -f /opt/gymapp/docker-compose.prod.yml up -d api worker beat

    echo "[$(date '+%H:%M:%S')] ✅ Restore complete from $BACKUP_TO_RESTORE"
}

# Run restore if this script is called as restore.sh
if [[ "${BASH_SOURCE[0]}" == *"restore.sh"* ]]; then
    restore_database "${1:-}"
fi
