#!/usr/bin/env bash
# scripts/server-setup.sh — Fresh Server Setup
# ============================================================
# Run ONCE on a new Ubuntu 22.04 server to install all
# dependencies and prepare for the GymOS deployment.
#
# Usage:
#   ssh user@your-server
#   curl -fsSL https://your-repo.com/scripts/server-setup.sh | bash
#
# What it installs:
#   - Docker Engine + Docker Compose v2
#   - Nginx (managed by Docker, but certbot needs host nginx)
#   - Certbot (Let's Encrypt SSL certificates)
#   - Git
#   - Basic security hardening (UFW firewall, fail2ban)
# ============================================================

set -euo pipefail

echo "🚀 Setting up GymOS server..."

# ── Update system ─────────────────────────────────────────────
apt-get update && apt-get upgrade -y

# ── Install Docker ────────────────────────────────────────────
echo "Installing Docker..."
curl -fsSL https://get.docker.com | bash

# Add current user to docker group (no sudo needed for docker commands)
usermod -aG docker "$USER"

# Install Docker Compose plugin
apt-get install -y docker-compose-plugin
docker compose version   # Verify

# ── Install utilities ─────────────────────────────────────────
apt-get install -y \
    git \
    curl \
    wget \
    htop \
    unzip \
    certbot \
    fail2ban \
    ufw \
    logrotate

# ── Configure UFW firewall ────────────────────────────────────
echo "Configuring firewall..."
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp     # SSH
ufw allow 80/tcp     # HTTP (→ HTTPS redirect)
ufw allow 443/tcp    # HTTPS
ufw --force enable
echo "Firewall configured: 22, 80, 443 open"

# ── Configure fail2ban (blocks brute force SSH attempts) ──────
echo "Configuring fail2ban..."
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime  = 3600    # 1 hour ban
findtime = 600     # 10 minute window
maxretry = 5       # 5 failed attempts before ban

[sshd]
enabled = true
port    = ssh
EOF
systemctl enable fail2ban
systemctl restart fail2ban

# ── Create application directory ──────────────────────────────
echo "Creating application directory..."
mkdir -p /opt/gymapp
mkdir -p /var/log/gymapp
mkdir -p /var/backups/gymapp

# ── Clone repository ──────────────────────────────────────────
echo "Cloning repository..."
# Replace with your actual repository URL
git clone https://github.com/your-org/gym-backend.git /opt/gymapp
cd /opt/gymapp

# ── Setup environment file ────────────────────────────────────
echo "Setting up environment..."
cp .env.prod.example .env.prod
chmod 600 .env.prod  # Only readable by owner
echo ""
echo "⚠️  IMPORTANT: Edit /opt/gymapp/.env.prod with your real credentials!"
echo "   nano /opt/gymapp/.env.prod"

# ── Obtain SSL certificate ────────────────────────────────────
echo ""
echo "🔐 SSL Certificate Setup"
echo "Before running certbot, make sure:"
echo "  1. Your domain points to this server's IP"
echo "  2. Port 80 is open (for ACME challenge)"
echo ""
echo "Run this command after updating DNS:"
echo "  certbot certonly --standalone -d api.yourgym.com -d admin.yourgym.com"
echo "  # Then update nginx/sites/api.conf with your domain"

# ── Setup automatic certificate renewal ───────────────────────
cat > /etc/cron.d/certbot-renewal << 'EOF'
0 0,12 * * * root certbot renew --quiet --deploy-hook "docker exec gym_nginx nginx -s reload"
EOF
# Run twice daily — certbot only actually renews when cert is <30 days from expiry

# ── Setup log rotation ────────────────────────────────────────
cat > /etc/logrotate.d/gymapp << 'EOF'
/var/log/gymapp/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    copytruncate
}
EOF

# ── Setup daily database backup ───────────────────────────────
cat > /etc/cron.d/gymapp-backup << 'EOF'
0 2 * * * root /opt/gymapp/scripts/backup.sh >> /var/log/gymapp/backup.log 2>&1
EOF
# Backup at 2am every day

# ── System optimization ───────────────────────────────────────
# Increase file descriptor limits (important for high-concurrency)
cat >> /etc/security/limits.conf << 'EOF'
*    soft nofile 65536
*    hard nofile 65536
root soft nofile 65536
root hard nofile 65536
EOF

# Kernel parameter tuning for network performance
cat >> /etc/sysctl.conf << 'EOF'
# TCP performance
net.core.somaxconn = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_keepalive_time = 300
# Memory
vm.swappiness = 10
EOF
sysctl -p

echo ""
echo "=========================================="
echo "✅ Server setup complete!"
echo ""
echo "Next steps:"
echo "  1. Edit /opt/gymapp/.env.prod with real credentials"
echo "  2. Get SSL cert: certbot certonly --standalone -d yourdomain.com"
echo "  3. Update nginx/sites/api.conf with your domain"
echo "  4. Start services: cd /opt/gymapp && docker compose -f docker-compose.prod.yml up -d"
echo "  5. Check health: curl https://api.yourgym.com/health"
echo "=========================================="
