"""
schemas/analytics.py — Admin Analytics Response Schemas (Phase 9)

Every schema here represents one "widget" or "chart" on the admin dashboard.

Dashboard layout (what each schema powers):
┌──────────────────────────────────────────────────────────────────┐
│  KPI Row: Total Members | Active | Revenue | Check-ins Today     │
├────────────────────┬─────────────────┬───────────────────────────┤
│  Revenue Chart     │  Member Growth  │  Class Popularity         │
│  (line, 30/90 day) │  (bar, monthly) │  (bar, by category)       │
├────────────────────┴─────────────────┴───────────────────────────┤
│  Attendance Heatmap (hour × weekday grid)                        │
├────────────────────┬─────────────────────────────────────────────┤
│  Retention Report  │  Top Members Table                          │
│  (churn + renewal) │  (most visits, highest revenue)             │
├────────────────────┴─────────────────────────────────────────────┤
│  Recent Activity Feed  │  Plan Distribution Pie Chart            │
└────────────────────────┴─────────────────────────────────────────┘

All schemas use simple Python types (float, int, str, list) so they
serialize cleanly to JSON for React / chart libraries (Recharts, Chart.js).
"""

from datetime import date, datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel


# ============================================================
# KPI SUMMARY (top of dashboard — the "at a glance" numbers)
# ============================================================

class KPISummary(BaseModel):
    """
    The most important numbers shown at the top of the admin dashboard.
    Updated in real-time (no caching — always fresh).
    """
    # --- Members ---
    total_members:        int    # All users with role=MEMBER ever registered
    active_members:       int    # Members with an ACTIVE membership right now
    new_members_today:    int    # Registered today
    new_members_this_week:  int
    new_members_this_month: int

    # --- Memberships ---
    expiring_soon_count:  int    # Active memberships expiring in <= 7 days
    frozen_count:         int    # Currently frozen memberships
    expired_count:        int    # Total expired (not yet renewed)

    # --- Revenue ---
    revenue_today:        float  # Sum of successful payments today
    revenue_this_week:    float
    revenue_this_month:   float
    revenue_this_year:    float
    total_revenue_all_time: float
    pending_payments:     int    # Payments awaiting confirmation

    # --- Attendance ---
    checkins_today:       int
    checkins_this_week:   int
    checkins_this_month:  int
    currently_in_gym:     int    # Members checked in but not checked out

    # --- Classes ---
    classes_today:        int    # Classes scheduled for today
    classes_this_week:    int
    total_bookings_today: int
    class_fill_rate:      float  # % of class spots that are booked (0-100)

    # --- Workouts ---
    workouts_logged_today: int
    personal_bests_today:  int


# ============================================================
# TIME-SERIES DATA (for line and bar charts)
# ============================================================

class DataPoint(BaseModel):
    """
    A single point on a time-series chart.
    Generic enough to work for revenue, attendance, member growth, etc.
    """
    date:    str    # "2025-02-10" — string so React can use it directly as chart label
    value:   float  # The metric value on this date
    label:   Optional[str] = None  # Optional human-friendly label: "$1,234"


class TimeSeriesResponse(BaseModel):
    """
    A complete time-series dataset for a line or bar chart.
    Used for: revenue trend, attendance trend, member growth.
    """
    metric:       str             # What is being measured: "revenue", "checkins", "new_members"
    period:       str             # "daily", "weekly", "monthly"
    data_points:  List[DataPoint]
    total:        float           # Sum of all data points
    average:      float           # Average per period
    peak_value:   float           # Highest single value
    peak_date:    Optional[str]   # When the peak occurred
    trend_pct:    Optional[float] # % change vs previous period (positive = growth)


# ============================================================
# REVENUE ANALYTICS
# ============================================================

class RevenueByPlan(BaseModel):
    """Revenue breakdown by membership plan type."""
    plan:          str    # "monthly", "quarterly", "yearly"
    revenue:       float
    transaction_count: int
    percentage:    float  # % of total revenue this plan represents


class RevenueAnalytics(BaseModel):
    """Complete revenue picture for the finance section of the dashboard."""
    total_revenue:     float
    net_revenue:       float   # After refunds
    total_refunded:    float
    refund_rate_pct:   float   # refunded / total * 100

    by_plan:           List[RevenueByPlan]
    # e.g. [{"plan":"monthly","revenue":4500,"percentage":45}, ...]

    trend:             TimeSeriesResponse   # Daily revenue for last 30 days
    monthly_comparison: List[DataPoint]     # This month vs last month, day by day

    avg_revenue_per_member: float
    highest_revenue_day:    Optional[str]
    highest_revenue_amount: Optional[float]


# ============================================================
# MEMBER ANALYTICS
# ============================================================

class MemberGrowthPoint(BaseModel):
    """Monthly member count for growth chart."""
    month:        str    # "Jan 2025"
    new_members:  int
    total_members: int   # Cumulative total at end of this month
    churned:      int    # Members whose membership expired this month


class MemberRetentionReport(BaseModel):
    """
    Retention / churn analysis.
    Shows how well the gym keeps its members month over month.
    """
    period_months:    int     # How many months this covers (e.g. last 12)
    avg_retention_pct: float  # % of members who renew (industry avg ~60-70%)
    avg_churn_pct:    float   # % of members who don't renew (100 - retention)

    renewals_this_month:   int   # Members who renewed this calendar month
    expirations_this_month: int  # Members whose membership expired this month
    new_joins_this_month:  int

    monthly_retention:     List[DataPoint]  # Monthly retention % over time


class PlanDistribution(BaseModel):
    """How members are distributed across membership plan types."""
    plan:          str
    count:         int
    percentage:    float
    revenue_share: float   # % of total revenue this plan contributes


class MemberDemographics(BaseModel):
    """Breakdown of the member base."""
    plan_distribution: List[PlanDistribution]
    # e.g. 45% monthly, 30% quarterly, 25% yearly

    status_breakdown: Dict[str, int]
    # {"active": 312, "expired": 89, "frozen": 14, "cancelled": 23}

    growth_trend:     List[MemberGrowthPoint]   # Last 12 months
    retention_report: MemberRetentionReport


# ============================================================
# ATTENDANCE ANALYTICS
# ============================================================

class HourlyHeatmapCell(BaseModel):
    """
    One cell in the attendance heatmap grid.
    The heatmap shows average check-ins for each hour × weekday combination.
    """
    day_of_week: int    # 0=Monday, 6=Sunday
    hour:        int    # 0-23 (0=midnight, 6=6am, 18=6pm)
    avg_checkins: float # Average check-ins in this slot across all weeks
    day_name:    str    # "Monday"
    hour_label:  str    # "6:00 AM"


class AttendanceHeatmap(BaseModel):
    """
    7×24 grid of average check-ins per hour per weekday.
    Used to find peak gym hours and staff accordingly.
    """
    cells:        List[HourlyHeatmapCell]   # 168 cells (7 days × 24 hours)
    peak_hour:    int                        # Busiest hour overall (0-23)
    peak_day:     str                        # Busiest day of week ("Monday")
    peak_avg:     float                      # Highest average in any cell


class AttendanceAnalytics(BaseModel):
    """Full attendance analytics package."""
    heatmap:          AttendanceHeatmap
    daily_trend:      TimeSeriesResponse    # Last 30 days
    weekly_avg:       float                 # Average daily check-ins (last 4 weeks)
    busiest_month:    Optional[str]
    avg_session_duration_min: Optional[float]  # Average time spent in gym


# ============================================================
# CLASS ANALYTICS
# ============================================================

class ClassPopularityEntry(BaseModel):
    """Stats for one class category (e.g. Yoga, HIIT)."""
    category:        str
    total_classes:   int    # How many classes of this type ran
    total_bookings:  int    # Total booking slots filled
    total_capacity:  int    # Total slots available
    fill_rate_pct:   float  # bookings / capacity * 100
    avg_attendance:  float  # Average actual attendees per class
    no_show_rate_pct: float # % of confirmed bookings that were no-shows
    cancellation_rate_pct: float  # % of bookings cancelled by members


class TrainerPerformance(BaseModel):
    """Performance metrics for a single trainer."""
    trainer_id:    int
    trainer_name:  str
    classes_taught: int
    total_students: int    # Unique members who attended their classes
    avg_fill_rate:  float
    avg_rating:     Optional[float]  # If you add a class rating feature later


class ClassAnalytics(BaseModel):
    """Class system analytics."""
    popularity:         List[ClassPopularityEntry]   # By category, sorted by fill rate
    trainer_performance: List[TrainerPerformance]
    most_popular_class:  Optional[str]               # e.g. "Morning Yoga"
    least_popular_class: Optional[str]
    overall_fill_rate:   float
    total_classes_run:   int
    total_bookings:      int
    cancellation_trend:  TimeSeriesResponse          # Daily cancellations last 30 days


# ============================================================
# TOP MEMBERS TABLE
# ============================================================

class TopMemberEntry(BaseModel):
    """One row in the "Top Members" leaderboard table."""
    rank:          int
    user_id:       int
    full_name:     str
    email:         str
    membership_plan: str
    value:         float  # The metric being ranked (visits, revenue, streak)
    value_label:   str    # Human-friendly: "47 visits", "$449.99", "23-day streak"


class TopMembersReport(BaseModel):
    """Top members by different metrics."""
    by_visits:     List[TopMemberEntry]    # Most gym visits this month
    by_revenue:    List[TopMemberEntry]    # Highest total spend
    by_streak:     List[TopMemberEntry]    # Longest current training streak
    by_classes:    List[TopMemberEntry]    # Most classes attended


# ============================================================
# RECENT ACTIVITY FEED
# ============================================================

class ActivityFeedItem(BaseModel):
    """
    One item in the live activity feed on the admin dashboard.
    Shows real-time events: new signups, payments, check-ins, etc.
    """
    id:          int
    timestamp:   datetime
    event_type:  str         # "member_joined", "payment", "checkin", "class_booked"
    description: str         # "John Doe joined with a monthly plan"
    user_id:     Optional[int]
    user_name:   Optional[str]
    icon:        str         # Emoji for the event type: "👋", "💳", "✅", "📅"
    amount:      Optional[float]  # For payment events


# ============================================================
# FULL DASHBOARD RESPONSE
# ============================================================

class DashboardOverview(BaseModel):
    """
    The complete dataset for the admin dashboard home page.
    One API call returns everything the dashboard needs.
    Reduces the number of round-trips from the React frontend.
    """
    generated_at:  datetime
    kpis:          KPISummary
    revenue:       RevenueAnalytics
    members:       MemberDemographics
    attendance:    AttendanceAnalytics
    classes:       ClassAnalytics
    top_members:   TopMembersReport
    recent_activity: List[ActivityFeedItem]
