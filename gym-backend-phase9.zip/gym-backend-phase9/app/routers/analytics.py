"""
routers/analytics.py — Admin Analytics API Endpoints (Phase 9)

All endpoints are Admin only — this data is never exposed to members.

────────────────────────────────────────────
DASHBOARD
────────────────────────────────────────────
GET /api/analytics/dashboard         → Full dashboard (all sections in one call)
GET /api/analytics/kpis              → KPI numbers only (fast refresh)

────────────────────────────────────────────
REVENUE
────────────────────────────────────────────
GET /api/analytics/revenue           → Revenue analytics + trend chart
GET /api/analytics/revenue/trend     → Daily revenue for last N days

────────────────────────────────────────────
MEMBERS
────────────────────────────────────────────
GET /api/analytics/members           → Member demographics + growth + retention
GET /api/analytics/members/growth    → Monthly growth trend only
GET /api/analytics/members/retention → Retention/churn report only

────────────────────────────────────────────
ATTENDANCE
────────────────────────────────────────────
GET /api/analytics/attendance        → Full attendance analytics
GET /api/analytics/attendance/heatmap → Hour×weekday heatmap only
GET /api/analytics/attendance/trend  → Daily trend only

────────────────────────────────────────────
CLASSES
────────────────────────────────────────────
GET /api/analytics/classes           → Class analytics + popularity + trainers
GET /api/analytics/classes/popularity → Category popularity only

────────────────────────────────────────────
LEADERBOARDS & FEED
────────────────────────────────────────────
GET /api/analytics/top-members       → Top members by visits/revenue/streak/classes
GET /api/analytics/activity-feed     → Live activity feed (last N events)
GET /api/analytics/export/csv        → Export key metrics as CSV
"""

import csv
import io
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import require_admin
from app.models.user import User
from app.schemas.analytics import (
    AttendanceAnalytics, AttendanceHeatmap,
    ClassAnalytics, DashboardOverview,
    KPISummary, MemberDemographics,
    RevenueAnalytics, TimeSeriesResponse,
    TopMembersReport,
)
from app.services.analytics_service import AnalyticsService

router = APIRouter()


# ====================================================================
# FULL DASHBOARD
# ====================================================================

@router.get(
    "/dashboard",
    response_model=DashboardOverview,
    summary="Full admin dashboard — all metrics in one call (Admin)",
)
def get_dashboard(
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns the complete admin dashboard dataset in a single API call.

    Includes:
    - KPI summary (members, revenue, attendance, classes)
    - Revenue analytics with 30-day trend chart
    - Member demographics (plan distribution, growth, retention)
    - Attendance heatmap + daily trend
    - Class popularity + trainer performance
    - Top members leaderboard
    - Live activity feed (last 20 events)

    The React dashboard calls this once on page load, then refreshes
    individual sections as needed using the focused endpoints below.

    ⚠️ This is a heavy query — consider caching the result for 5 minutes
    in production using Redis (see Phase 8 for Redis setup).
    """
    service = AnalyticsService(db)
    return service.get_dashboard_overview()


@router.get(
    "/kpis",
    response_model=KPISummary,
    summary="KPI numbers only — fast refresh (Admin)",
)
def get_kpis(
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns only the top-level KPI numbers.
    Lighter than the full dashboard — refresh every 60 seconds
    to keep the live counters updated without re-fetching everything.

    React usage:
    ```js
    // Poll every 60 seconds for live numbers
    useEffect(() => {
      const interval = setInterval(() => fetchKPIs(), 60_000);
      return () => clearInterval(interval);
    }, []);
    ```
    """
    service = AnalyticsService(db)
    return service.get_kpi_summary()


# ====================================================================
# REVENUE
# ====================================================================

@router.get(
    "/revenue",
    response_model=RevenueAnalytics,
    summary="Full revenue analytics (Admin)",
)
def get_revenue_analytics(
    days: int = Query(30, ge=7, le=365, description="Look-back window in days"),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Complete revenue picture:
    - Total, net, and refunded amounts
    - Breakdown by membership plan (monthly/quarterly/yearly)
    - Daily revenue trend for the past N days
    - Month-over-month daily comparison
    - Average revenue per member

    Use the `days` parameter to zoom the charts:
    - days=7   → last week (detail view)
    - days=30  → last month (default)
    - days=90  → last quarter
    - days=365 → full year
    """
    service = AnalyticsService(db)
    return service.get_revenue_analytics(days=days)


@router.get(
    "/revenue/trend",
    response_model=TimeSeriesResponse,
    summary="Daily revenue trend chart data (Admin)",
)
def get_revenue_trend(
    days: int = Query(30, ge=7, le=365),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns just the daily revenue time-series — lighter than the full revenue endpoint.
    Use this to update only the revenue chart without re-fetching everything.
    """
    service = AnalyticsService(db)
    full    = service.get_revenue_analytics(days=days)
    return full["trend"]


# ====================================================================
# MEMBERS
# ====================================================================

@router.get(
    "/members",
    response_model=MemberDemographics,
    summary="Member demographics, growth, and retention (Admin)",
)
def get_member_demographics(
    months: int = Query(12, ge=1, le=24, description="Number of months for growth trend"),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Member base analytics:
    - Plan distribution (monthly/quarterly/yearly %)
    - Status breakdown (active/expired/frozen/cancelled)
    - Monthly growth trend (new members per month, cumulative total)
    - Retention and churn rates

    Used to populate:
    - Pie chart: plan distribution
    - Bar chart: monthly new members
    - Line chart: cumulative member count
    - KPI cards: retention %, churn %
    """
    service = AnalyticsService(db)
    return service.get_member_demographics(months=months)


@router.get(
    "/members/growth",
    summary="Monthly member growth trend (Admin)",
)
def get_member_growth(
    months: int = Query(12, ge=1, le=24),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Monthly new member counts for growth bar chart."""
    service = AnalyticsService(db)
    data    = service.get_member_demographics(months=months)
    return data["growth_trend"]


@router.get(
    "/members/retention",
    summary="Retention and churn report (Admin)",
)
def get_retention_report(
    months: int = Query(12, ge=1, le=24),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Retention rate, churn rate, and monthly trend."""
    service = AnalyticsService(db)
    data    = service.get_member_demographics(months=months)
    return data["retention_report"]


# ====================================================================
# ATTENDANCE
# ====================================================================

@router.get(
    "/attendance",
    response_model=AttendanceAnalytics,
    summary="Full attendance analytics (Admin)",
)
def get_attendance_analytics(
    days: int = Query(30, ge=7, le=365),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Attendance analytics:
    - Heatmap (average check-ins by hour × day of week)
    - Daily trend line chart
    - Weekly average and session duration stats

    The heatmap is the most unique feature here — it shows WHEN the gym
    is busiest during the week so the admin can schedule staff and classes
    at peak times.
    """
    service = AnalyticsService(db)
    return service.get_attendance_analytics(days=days)


@router.get(
    "/attendance/heatmap",
    response_model=AttendanceHeatmap,
    summary="Check-in heatmap (hour × weekday) (Admin)",
)
def get_attendance_heatmap(
    days: int = Query(30, ge=7, le=365),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns 168 data cells (7 days × 24 hours) with average check-ins.
    Use this to render the peak hours heatmap grid in the dashboard.

    React Recharts example:
    ```jsx
    // Each cell: { day_of_week: 0, hour: 8, avg_checkins: 12.5, day_name: "Monday" }
    // Color intensity based on avg_checkins relative to peak
    ```
    """
    service = AnalyticsService(db)
    data    = service.get_attendance_analytics(days=days)
    return data["heatmap"]


@router.get(
    "/attendance/trend",
    response_model=TimeSeriesResponse,
    summary="Daily attendance trend (Admin)",
)
def get_attendance_trend(
    days: int = Query(30, ge=7, le=365),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Daily check-in counts for trend chart."""
    service = AnalyticsService(db)
    data    = service.get_attendance_analytics(days=days)
    return data["daily_trend"]


# ====================================================================
# CLASSES
# ====================================================================

@router.get(
    "/classes",
    response_model=ClassAnalytics,
    summary="Class analytics — popularity, trainers, fill rates (Admin)",
)
def get_class_analytics(
    days: int = Query(30, ge=7, le=365),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Class system analytics:
    - Popularity by category (fill rate, attendance, no-show rate)
    - Trainer performance (classes taught, unique students, fill rate)
    - Overall fill rate and cancellation trend

    Used to decide which class types to expand or cut,
    and which trainers attract the most members.
    """
    service = AnalyticsService(db)
    return service.get_class_analytics(days=days)


@router.get(
    "/classes/popularity",
    summary="Class popularity ranked by fill rate (Admin)",
)
def get_class_popularity(
    days: int = Query(30, ge=7, le=365),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Class categories sorted by fill rate — for the popularity bar chart."""
    service = AnalyticsService(db)
    data    = service.get_class_analytics(days=days)
    return data["popularity"]


# ====================================================================
# TOP MEMBERS & ACTIVITY FEED
# ====================================================================

@router.get(
    "/top-members",
    response_model=TopMembersReport,
    summary="Top members leaderboard by visits, revenue, streak, classes (Admin)",
)
def get_top_members(
    limit: int = Query(10, ge=3, le=50, description="Number of members per category"),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns top members by four different metrics:
    - Most gym visits this month
    - Highest total membership spend
    - Longest current training streak
    - Most class sessions attended

    Used as a leaderboard table on the admin dashboard.
    Can also power a "Star Member" feature displayed on the gym's TV screen.
    """
    service = AnalyticsService(db)
    return service.get_top_members(limit=limit)


@router.get(
    "/activity-feed",
    summary="Live admin activity feed (Admin)",
)
def get_activity_feed(
    limit: int = Query(20, ge=5, le=100),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns the most recent events across the system:
    - New member registrations
    - Successful payments
    - Gym check-ins
    - Class bookings

    Shown as a live event feed on the admin dashboard.
    Poll every 30 seconds to keep it fresh.

    React usage:
    ```js
    const events = data.map(event => (
      <div key={event.id}>
        <span>{event.icon}</span>
        <span>{event.description}</span>
        <span>{formatTime(event.timestamp)}</span>
      </div>
    ));
    ```
    """
    service = AnalyticsService(db)
    return service.get_recent_activity(limit=limit)


# ====================================================================
# CSV EXPORT
# ====================================================================

@router.get(
    "/export/csv",
    summary="Export key metrics as CSV (Admin)",
    response_class=StreamingResponse,
)
def export_metrics_csv(
    report_type: str = Query(
        "revenue",
        description="What to export: 'revenue', 'members', 'attendance', 'classes'"
    ),
    days: int = Query(30, ge=7, le=365),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Export analytics data as a downloadable CSV file.

    Supported reports:
    - revenue:    Daily revenue for the last N days
    - members:    Monthly member growth for the last 12 months
    - attendance: Daily check-in counts for the last N days
    - classes:    Class popularity by category

    Usage from React:
    ```js
    const url = `/api/analytics/export/csv?report_type=revenue&days=90`;
    window.open(url);   // Triggers browser download
    ```
    """
    service = AnalyticsService(db)
    output  = io.StringIO()
    writer  = csv.writer(output)

    filename = f"gym_{report_type}_{datetime.utcnow().strftime('%Y%m%d')}.csv"

    if report_type == "revenue":
        data = service.get_revenue_analytics(days=days)
        writer.writerow(["Date", "Revenue (USD)"])
        for point in data["trend"]["data_points"]:
            writer.writerow([point["date"], point["value"]])

    elif report_type == "members":
        data = service.get_member_demographics(months=12)
        writer.writerow(["Month", "New Members", "Total Members", "Churned"])
        for point in data["growth_trend"]:
            writer.writerow([
                point["month"], point["new_members"],
                point["total_members"], point["churned"],
            ])

    elif report_type == "attendance":
        data = service.get_attendance_analytics(days=days)
        writer.writerow(["Date", "Check-ins"])
        for point in data["daily_trend"]["data_points"]:
            writer.writerow([point["date"], int(point["value"])])

    elif report_type == "classes":
        data = service.get_class_analytics(days=days)
        writer.writerow([
            "Category", "Total Classes", "Total Bookings",
            "Fill Rate %", "No-Show Rate %",
        ])
        for cat in data["popularity"]:
            writer.writerow([
                cat["category"], cat["total_classes"], cat["total_bookings"],
                cat["fill_rate_pct"], cat["no_show_rate_pct"],
            ])
    else:
        writer.writerow(["Error"])
        writer.writerow([f"Unknown report_type: {report_type}"])

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
