"""
services/analytics_service.py — Admin Analytics Business Logic (Phase 9)

This service computes every metric shown on the admin dashboard.

Query strategy:
  - All queries use SQLAlchemy aggregations (func.count, func.sum, func.avg)
    rather than fetching all rows and counting in Python.
  - This keeps data processing in the database (where it belongs) and
    avoids loading thousands of records into memory.

Performance notes:
  - The full dashboard overview query touches many tables.
  - In production, cache the result for 5-10 minutes using Redis:
      result = redis.get("dashboard_overview")
      if not result:
          result = compute_dashboard()
          redis.setex("dashboard_overview", 300, json.dumps(result))
  - Individual chart endpoints are cheaper and can be called on demand.

All methods return plain dicts that match the Pydantic schemas in analytics.py.
"""

import logging
from collections import defaultdict
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import func, case, distinct, and_, extract
from sqlalchemy.orm import Session

from app.models.attendance import Attendance
from app.models.gym_class import ClassBooking, BookingStatus, GymClass, ClassStatus
from app.models.membership import Membership, MembershipPlan, MembershipStatus
from app.models.payment import Payment, PaymentStatus, PaymentType
from app.models.user import User, UserRole
from app.models.workout import WorkoutLog, WorkoutLogEntry

logger = logging.getLogger(__name__)


class AnalyticsService:
    """
    Computes all analytics metrics for the admin dashboard.
    Instantiate with a DB session: service = AnalyticsService(db)
    """

    def __init__(self, db: Session):
        self.db = db

    # ===================================================================
    # KPI SUMMARY
    # ===================================================================

    def get_kpi_summary(self) -> dict:
        """
        Compute all top-level KPI numbers.
        These are the "at a glance" numbers at the top of the dashboard.
        """
        now   = datetime.utcnow()
        today = now.date()
        week_start  = today - timedelta(days=today.weekday())
        month_start = today.replace(day=1)
        year_start  = today.replace(month=1, day=1)

        # ---------------------------------------------------------------
        # Members
        # ---------------------------------------------------------------
        total_members = self.db.query(func.count(User.id)).filter(
            User.role == UserRole.MEMBER
        ).scalar() or 0

        active_members = self.db.query(func.count(Membership.id)).filter(
            Membership.status == MembershipStatus.ACTIVE,
            Membership.end_date > now,
        ).scalar() or 0

        new_today = self.db.query(func.count(User.id)).filter(
            User.role == UserRole.MEMBER,
            func.date(User.created_at) == today,
        ).scalar() or 0

        new_this_week = self.db.query(func.count(User.id)).filter(
            User.role == UserRole.MEMBER,
            func.date(User.created_at) >= week_start,
        ).scalar() or 0

        new_this_month = self.db.query(func.count(User.id)).filter(
            User.role == UserRole.MEMBER,
            func.date(User.created_at) >= month_start,
        ).scalar() or 0

        # ---------------------------------------------------------------
        # Membership statuses
        # ---------------------------------------------------------------
        expiring_soon = self.db.query(func.count(Membership.id)).filter(
            Membership.status == MembershipStatus.ACTIVE,
            Membership.end_date <= now + timedelta(days=7),
            Membership.end_date > now,
        ).scalar() or 0

        frozen_count = self.db.query(func.count(Membership.id)).filter(
            Membership.status == MembershipStatus.FROZEN
        ).scalar() or 0

        expired_count = self.db.query(func.count(Membership.id)).filter(
            Membership.status == MembershipStatus.EXPIRED
        ).scalar() or 0

        # ---------------------------------------------------------------
        # Revenue
        # ---------------------------------------------------------------
        def revenue_since(since_date):
            result = self.db.query(func.sum(Payment.amount)).filter(
                Payment.status == PaymentStatus.SUCCESS,
                func.date(Payment.created_at) >= since_date,
            ).scalar()
            return round(result or 0, 2)

        revenue_today      = revenue_since(today)
        revenue_this_week  = revenue_since(week_start)
        revenue_this_month = revenue_since(month_start)
        revenue_this_year  = revenue_since(year_start)
        total_revenue      = round(
            self.db.query(func.sum(Payment.amount)).filter(
                Payment.status == PaymentStatus.SUCCESS
            ).scalar() or 0, 2
        )
        pending_payments = self.db.query(func.count(Payment.id)).filter(
            Payment.status == PaymentStatus.PENDING
        ).scalar() or 0

        # ---------------------------------------------------------------
        # Attendance
        # ---------------------------------------------------------------
        checkins_today = self.db.query(func.count(Attendance.id)).filter(
            Attendance.check_in_date == today
        ).scalar() or 0

        checkins_this_week = self.db.query(func.count(Attendance.id)).filter(
            Attendance.check_in_date >= week_start
        ).scalar() or 0

        checkins_this_month = self.db.query(func.count(Attendance.id)).filter(
            Attendance.check_in_date >= month_start
        ).scalar() or 0

        # Members currently in the gym (checked in today, no check-out)
        currently_in = self.db.query(func.count(Attendance.id)).filter(
            Attendance.check_in_date  == today,
            Attendance.check_out_time == None,
        ).scalar() or 0

        # ---------------------------------------------------------------
        # Classes
        # ---------------------------------------------------------------
        classes_today = self.db.query(func.count(GymClass.id)).filter(
            func.date(GymClass.start_time) == today,
            GymClass.status != ClassStatus.CANCELLED,
        ).scalar() or 0

        classes_this_week = self.db.query(func.count(GymClass.id)).filter(
            func.date(GymClass.start_time) >= week_start,
            GymClass.status != ClassStatus.CANCELLED,
        ).scalar() or 0

        bookings_today = self.db.query(func.count(ClassBooking.id)).filter(
            ClassBooking.status == BookingStatus.CONFIRMED,
            func.date(ClassBooking.booked_at) == today,
        ).scalar() or 0

        # Fill rate: confirmed bookings / total capacity for upcoming classes
        fill_rate = self._compute_class_fill_rate()

        # ---------------------------------------------------------------
        # Workouts
        # ---------------------------------------------------------------
        workouts_today = self.db.query(func.count(WorkoutLog.id)).filter(
            func.date(WorkoutLog.date) == today
        ).scalar() or 0

        pbs_today = self.db.query(func.count(WorkoutLogEntry.id)).filter(
            WorkoutLogEntry.is_personal_best == True,
            func.date(WorkoutLogEntry.workout_log.has(
                func.date(WorkoutLog.date) == today
            )),
        ).scalar() or 0

        return {
            "total_members":           total_members,
            "active_members":          active_members,
            "new_members_today":       new_today,
            "new_members_this_week":   new_this_week,
            "new_members_this_month":  new_this_month,
            "expiring_soon_count":     expiring_soon,
            "frozen_count":            frozen_count,
            "expired_count":           expired_count,
            "revenue_today":           revenue_today,
            "revenue_this_week":       revenue_this_week,
            "revenue_this_month":      revenue_this_month,
            "revenue_this_year":       revenue_this_year,
            "total_revenue_all_time":  total_revenue,
            "pending_payments":        pending_payments,
            "checkins_today":          checkins_today,
            "checkins_this_week":      checkins_this_week,
            "checkins_this_month":     checkins_this_month,
            "currently_in_gym":        currently_in,
            "classes_today":           classes_today,
            "classes_this_week":       classes_this_week,
            "total_bookings_today":    bookings_today,
            "class_fill_rate":         fill_rate,
            "workouts_logged_today":   workouts_today,
            "personal_bests_today":    pbs_today,
        }

    # ===================================================================
    # REVENUE ANALYTICS
    # ===================================================================

    def get_revenue_analytics(self, days: int = 30) -> dict:
        """
        Full revenue breakdown: by plan, daily trend, MoM comparison.
        """
        now        = datetime.utcnow()
        today      = now.date()
        start_date = today - timedelta(days=days - 1)

        # ---------------------------------------------------------------
        # Totals
        # ---------------------------------------------------------------
        all_payments = self.db.query(Payment).filter(
            Payment.status == PaymentStatus.SUCCESS
        ).all()

        total_revenue  = sum(p.amount for p in all_payments)
        total_refunded = sum(p.amount_refunded for p in all_payments)
        net_revenue    = total_revenue - total_refunded
        refund_rate    = round((total_refunded / total_revenue * 100) if total_revenue else 0, 1)

        # ---------------------------------------------------------------
        # Revenue by plan
        # ---------------------------------------------------------------
        plan_totals: dict[str, dict] = {}
        for payment in all_payments:
            if payment.membership and payment.membership.plan:
                plan = payment.membership.plan.value
            else:
                plan = "unknown"
            if plan not in plan_totals:
                plan_totals[plan] = {"revenue": 0, "count": 0}
            plan_totals[plan]["revenue"] += payment.amount
            plan_totals[plan]["count"]   += 1

        by_plan = [
            {
                "plan":              plan,
                "revenue":           round(data["revenue"], 2),
                "transaction_count": data["count"],
                "percentage":        round(data["revenue"] / total_revenue * 100, 1)
                                     if total_revenue else 0,
            }
            for plan, data in sorted(
                plan_totals.items(), key=lambda x: x[1]["revenue"], reverse=True
            )
        ]

        # ---------------------------------------------------------------
        # Daily revenue trend
        # ---------------------------------------------------------------
        daily_revenue: dict[date, float] = defaultdict(float)
        for payment in all_payments:
            d = payment.created_at.date()
            if d >= start_date:
                daily_revenue[d] += payment.amount

        data_points = []
        peak_value = 0.0
        peak_date  = None
        for i in range(days):
            d     = start_date + timedelta(days=i)
            value = round(daily_revenue.get(d, 0), 2)
            data_points.append({
                "date":  d.isoformat(),
                "value": value,
                "label": f"${value:,.2f}",
            })
            if value > peak_value:
                peak_value = value
                peak_date  = d.isoformat()

        total_period = sum(p["value"] for p in data_points)
        avg_period   = round(total_period / days, 2)

        # Trend: compare this period vs previous period
        prev_start = start_date - timedelta(days=days)
        prev_total = sum(
            p.amount for p in all_payments
            if prev_start <= p.created_at.date() < start_date
        )
        trend_pct = round(
            ((total_period - prev_total) / prev_total * 100) if prev_total else 0, 1
        )

        trend = {
            "metric":      "revenue",
            "period":      "daily",
            "data_points": data_points,
            "total":       round(total_period, 2),
            "average":     avg_period,
            "peak_value":  peak_value,
            "peak_date":   peak_date,
            "trend_pct":   trend_pct,
        }

        # ---------------------------------------------------------------
        # Month-over-month comparison
        # ---------------------------------------------------------------
        now_dt = datetime.utcnow()
        this_month_start = now_dt.replace(day=1, hour=0, minute=0, second=0)
        days_this_month  = now_dt.day
        monthly_compare  = []

        for i in range(days_this_month):
            d         = (this_month_start + timedelta(days=i)).date()
            this_val  = round(daily_revenue.get(d, 0), 2)
            monthly_compare.append({
                "date":  d.isoformat(),
                "value": this_val,
                "label": f"${this_val:,.2f}",
            })

        # Per-member average revenue
        total_members = self.db.query(func.count(User.id)).filter(
            User.role == UserRole.MEMBER
        ).scalar() or 1
        avg_per_member = round(total_revenue / total_members, 2)

        return {
            "total_revenue":           round(total_revenue, 2),
            "net_revenue":             round(net_revenue, 2),
            "total_refunded":          round(total_refunded, 2),
            "refund_rate_pct":         refund_rate,
            "by_plan":                 by_plan,
            "trend":                   trend,
            "monthly_comparison":      monthly_compare,
            "avg_revenue_per_member":  avg_per_member,
            "highest_revenue_day":     peak_date,
            "highest_revenue_amount":  peak_value,
        }

    # ===================================================================
    # MEMBER ANALYTICS
    # ===================================================================

    def get_member_demographics(self, months: int = 12) -> dict:
        """
        Member growth, plan distribution, and retention over the last N months.
        """
        now = datetime.utcnow()

        # ---------------------------------------------------------------
        # Plan distribution
        # ---------------------------------------------------------------
        memberships = self.db.query(Membership).all()
        plan_counts: dict[str, int] = defaultdict(int)
        for m in memberships:
            plan_counts[m.plan.value] += 1

        total_memberships = len(memberships) or 1
        plan_dist = [
            {
                "plan":          plan,
                "count":         count,
                "percentage":    round(count / total_memberships * 100, 1),
                "revenue_share": 0.0,  # Computed below
            }
            for plan, count in sorted(
                plan_counts.items(), key=lambda x: x[1], reverse=True
            )
        ]

        # ---------------------------------------------------------------
        # Status breakdown
        # ---------------------------------------------------------------
        status_counts = {}
        for status in MembershipStatus:
            count = self.db.query(func.count(Membership.id)).filter(
                Membership.status == status
            ).scalar() or 0
            status_counts[status.value] = count

        # ---------------------------------------------------------------
        # Monthly growth trend (last N months)
        # ---------------------------------------------------------------
        growth_trend = []
        all_users    = self.db.query(User).filter(
            User.role == UserRole.MEMBER
        ).order_by(User.created_at).all()

        for i in range(months - 1, -1, -1):
            month_start = (now.replace(day=1) - timedelta(days=i * 30)).replace(
                day=1, hour=0, minute=0, second=0, microsecond=0
            )
            month_end = (month_start + timedelta(days=32)).replace(day=1)

            new_this_month = sum(
                1 for u in all_users
                if month_start <= u.created_at < month_end
            )
            total_by_month = sum(1 for u in all_users if u.created_at < month_end)

            # Churn: memberships that expired this month
            churned = self.db.query(func.count(Membership.id)).filter(
                Membership.status == MembershipStatus.EXPIRED,
                Membership.end_date >= month_start,
                Membership.end_date <  month_end,
            ).scalar() or 0

            growth_trend.append({
                "month":         month_start.strftime("%b %Y"),
                "new_members":   new_this_month,
                "total_members": total_by_month,
                "churned":       churned,
            })

        # ---------------------------------------------------------------
        # Retention report
        # ---------------------------------------------------------------
        this_month_start = now.replace(day=1)
        renewals  = self.db.query(func.count(Membership.id)).filter(
            Membership.status == MembershipStatus.ACTIVE,
            Membership.start_date >= this_month_start,
        ).scalar() or 0

        expirations = self.db.query(func.count(Membership.id)).filter(
            Membership.status == MembershipStatus.EXPIRED,
            Membership.end_date >= this_month_start,
        ).scalar() or 0

        total_this_month = renewals + expirations
        avg_retention = round(
            (renewals / total_this_month * 100) if total_this_month else 0, 1
        )

        monthly_retention = [
            {
                "date":  g["month"],
                "value": round(
                    (g["new_members"] / (g["total_members"] or 1)) * 100, 1
                ),
                "label": f"{round((g['new_members'] / (g['total_members'] or 1)) * 100, 1)}%",
            }
            for g in growth_trend
        ]

        retention_report = {
            "period_months":          months,
            "avg_retention_pct":      avg_retention,
            "avg_churn_pct":          round(100 - avg_retention, 1),
            "renewals_this_month":    renewals,
            "expirations_this_month": expirations,
            "new_joins_this_month":   growth_trend[-1]["new_members"] if growth_trend else 0,
            "monthly_retention":      monthly_retention,
        }

        return {
            "plan_distribution": plan_dist,
            "status_breakdown":  status_counts,
            "growth_trend":      growth_trend,
            "retention_report":  retention_report,
        }

    # ===================================================================
    # ATTENDANCE ANALYTICS
    # ===================================================================

    def get_attendance_analytics(self, days: int = 30) -> dict:
        """
        Heatmap, daily trend, and session stats.
        """
        now        = datetime.utcnow()
        today      = now.date()
        start_date = today - timedelta(days=days - 1)

        all_records = self.db.query(Attendance).filter(
            Attendance.check_in_date >= start_date
        ).all()

        # ---------------------------------------------------------------
        # Heatmap: avg check-ins per hour per day-of-week
        # ---------------------------------------------------------------
        # Count occurrences of each (weekday, hour) combination
        slot_counts:  dict[Tuple[int, int], int] = defaultdict(int)
        slot_totals:  dict[Tuple[int, int], int] = defaultdict(int)

        for record in all_records:
            weekday = record.check_in_time.weekday()  # 0=Mon, 6=Sun
            hour    = record.check_in_time.hour
            slot_totals[(weekday, hour)] += 1

        # Count how many of each weekday appeared in the period
        weekday_counts: dict[int, int] = defaultdict(int)
        for i in range(days):
            d = start_date + timedelta(days=i)
            weekday_counts[d.weekday()] += 1

        day_names  = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        cells      = []
        peak_avg   = 0.0
        peak_hour  = 0
        peak_day   = "Monday"

        for weekday in range(7):
            for hour in range(24):
                count      = slot_totals.get((weekday, hour), 0)
                num_weeks  = weekday_counts.get(weekday, 1)
                avg        = round(count / num_weeks, 2)
                hour_label = datetime.strptime(str(hour), "%H").strftime("%-I:00 %p")

                cells.append({
                    "day_of_week":  weekday,
                    "hour":         hour,
                    "avg_checkins": avg,
                    "day_name":     day_names[weekday],
                    "hour_label":   hour_label,
                })

                if avg > peak_avg:
                    peak_avg  = avg
                    peak_hour = hour
                    peak_day  = day_names[weekday]

        heatmap = {
            "cells":     cells,
            "peak_hour": peak_hour,
            "peak_day":  peak_day,
            "peak_avg":  peak_avg,
        }

        # ---------------------------------------------------------------
        # Daily trend
        # ---------------------------------------------------------------
        daily_counts: dict[date, int] = defaultdict(int)
        for record in all_records:
            daily_counts[record.check_in_date] += 1

        trend_points = []
        peak_value   = 0.0
        peak_date    = None
        for i in range(days):
            d     = start_date + timedelta(days=i)
            value = float(daily_counts.get(d, 0))
            trend_points.append({
                "date":  d.isoformat(),
                "value": value,
                "label": str(int(value)),
            })
            if value > peak_value:
                peak_value = value
                peak_date  = d.isoformat()

        total_checkins = sum(p["value"] for p in trend_points)
        avg_daily      = round(total_checkins / days, 1)

        # Trend vs previous period
        prev_start = start_date - timedelta(days=days)
        prev_records = self.db.query(func.count(Attendance.id)).filter(
            Attendance.check_in_date >= prev_start,
            Attendance.check_in_date <  start_date,
        ).scalar() or 0
        trend_pct = round(
            ((total_checkins - prev_records) / prev_records * 100)
            if prev_records else 0, 1
        )

        daily_trend = {
            "metric":      "checkins",
            "period":      "daily",
            "data_points": trend_points,
            "total":       total_checkins,
            "average":     avg_daily,
            "peak_value":  peak_value,
            "peak_date":   peak_date,
            "trend_pct":   trend_pct,
        }

        # Average session duration
        durations = [r.duration_minutes for r in all_records if r.duration_minutes]
        avg_dur   = round(sum(durations) / len(durations), 1) if durations else None

        # Weekly average (last 4 weeks)
        four_weeks_ago  = today - timedelta(weeks=4)
        four_week_count = self.db.query(func.count(Attendance.id)).filter(
            Attendance.check_in_date >= four_weeks_ago
        ).scalar() or 0
        weekly_avg = round(four_week_count / 4, 1)

        return {
            "heatmap":                   heatmap,
            "daily_trend":               daily_trend,
            "weekly_avg":                weekly_avg,
            "busiest_month":             None,  # Could compute if needed
            "avg_session_duration_min":  avg_dur,
        }

    # ===================================================================
    # CLASS ANALYTICS
    # ===================================================================

    def get_class_analytics(self, days: int = 30) -> dict:
        """
        Class popularity by category, trainer performance, fill rates.
        """
        now        = datetime.utcnow()
        start_date = now - timedelta(days=days)

        classes = self.db.query(GymClass).filter(
            GymClass.start_time >= start_date,
            GymClass.status     != ClassStatus.CANCELLED,
        ).all()

        # ---------------------------------------------------------------
        # Popularity by category
        # ---------------------------------------------------------------
        category_stats: dict[str, dict] = defaultdict(
            lambda: {
                "total_classes":    0,
                "total_bookings":   0,
                "total_capacity":   0,
                "attended":         0,
                "no_shows":         0,
                "cancellations":    0,
            }
        )

        for cls in classes:
            cat = cls.category.value
            category_stats[cat]["total_classes"]  += 1
            category_stats[cat]["total_capacity"] += cls.max_capacity

            for booking in cls.bookings:
                if booking.status == BookingStatus.CONFIRMED:
                    category_stats[cat]["total_bookings"] += 1
                elif booking.status == BookingStatus.ATTENDED:
                    category_stats[cat]["attended"]       += 1
                    category_stats[cat]["total_bookings"] += 1
                elif booking.status == BookingStatus.NO_SHOW:
                    category_stats[cat]["no_shows"]       += 1
                    category_stats[cat]["total_bookings"] += 1
                elif booking.status == BookingStatus.CANCELLED:
                    category_stats[cat]["cancellations"]  += 1

        popularity = []
        for cat, stats in sorted(
            category_stats.items(),
            key=lambda x: x[1]["total_bookings"],
            reverse=True,
        ):
            n_classes  = stats["total_classes"]
            n_bookings = stats["total_bookings"]
            capacity   = stats["total_capacity"]
            no_shows   = stats["no_shows"]
            cancels    = stats["cancellations"]

            fill_rate    = round(n_bookings / capacity * 100, 1) if capacity else 0
            avg_att      = round(n_bookings / n_classes, 1) if n_classes else 0
            no_show_rate = round(no_shows / n_bookings * 100, 1) if n_bookings else 0
            cancel_rate  = round(cancels / (n_bookings + cancels) * 100, 1) if (n_bookings + cancels) else 0

            popularity.append({
                "category":              cat,
                "total_classes":         n_classes,
                "total_bookings":        n_bookings,
                "total_capacity":        capacity,
                "fill_rate_pct":         fill_rate,
                "avg_attendance":        avg_att,
                "no_show_rate_pct":      no_show_rate,
                "cancellation_rate_pct": cancel_rate,
            })

        # ---------------------------------------------------------------
        # Trainer performance
        # ---------------------------------------------------------------
        trainer_stats: dict[int, dict] = defaultdict(
            lambda: {"classes": 0, "students": set(), "fill_rates": []}
        )
        for cls in classes:
            if not cls.trainer_id:
                continue
            tid = cls.trainer_id
            trainer_stats[tid]["classes"] += 1
            for booking in cls.bookings:
                if booking.status in [BookingStatus.CONFIRMED, BookingStatus.ATTENDED]:
                    trainer_stats[tid]["students"].add(booking.user_id)
            if cls.max_capacity:
                confirmed = sum(1 for b in cls.bookings
                                if b.status in [BookingStatus.CONFIRMED, BookingStatus.ATTENDED])
                trainer_stats[tid]["fill_rates"].append(
                    confirmed / cls.max_capacity * 100
                )

        trainer_perf = []
        for tid, stats in trainer_stats.items():
            trainer = self.db.query(User).filter(User.id == tid).first()
            if not trainer:
                continue
            fill_rates = stats["fill_rates"]
            avg_fill   = round(sum(fill_rates) / len(fill_rates), 1) if fill_rates else 0
            trainer_perf.append({
                "trainer_id":    tid,
                "trainer_name":  trainer.full_name,
                "classes_taught": stats["classes"],
                "total_students": len(stats["students"]),
                "avg_fill_rate":  avg_fill,
                "avg_rating":     None,
            })
        trainer_perf.sort(key=lambda x: x["avg_fill_rate"], reverse=True)

        # Overall stats
        total_classes  = sum(s["total_classes"]  for s in category_stats.values())
        total_bookings = sum(s["total_bookings"]  for s in category_stats.values())
        total_capacity = sum(s["total_capacity"]  for s in category_stats.values())
        overall_fill   = round(total_bookings / total_capacity * 100, 1) if total_capacity else 0

        most_popular  = popularity[0]["category"]  if popularity else None
        least_popular = popularity[-1]["category"] if popularity else None

        # Cancellation trend (daily count)
        cancel_points = self._daily_cancellation_trend(days)

        return {
            "popularity":          popularity,
            "trainer_performance": trainer_perf,
            "most_popular_class":  most_popular,
            "least_popular_class": least_popular,
            "overall_fill_rate":   overall_fill,
            "total_classes_run":   total_classes,
            "total_bookings":      total_bookings,
            "cancellation_trend":  cancel_points,
        }

    # ===================================================================
    # TOP MEMBERS
    # ===================================================================

    def get_top_members(self, limit: int = 10) -> dict:
        """Top members by visits, revenue, streak, and class attendance."""
        today      = datetime.utcnow().date()
        month_start = today.replace(day=1)

        # --- By visits this month ---
        visits_q = (
            self.db.query(
                Attendance.user_id,
                func.count(Attendance.id).label("visits"),
            )
            .filter(Attendance.check_in_date >= month_start)
            .group_by(Attendance.user_id)
            .order_by(func.count(Attendance.id).desc())
            .limit(limit)
            .all()
        )
        by_visits = self._enrich_top_members(
            [(row.user_id, float(row.visits)) for row in visits_q],
            value_fmt=lambda v: f"{int(v)} visit{'s' if v != 1 else ''}",
        )

        # --- By total revenue ---
        revenue_q = (
            self.db.query(
                Payment.user_id,
                func.sum(Payment.amount).label("total"),
            )
            .filter(Payment.status == PaymentStatus.SUCCESS)
            .group_by(Payment.user_id)
            .order_by(func.sum(Payment.amount).desc())
            .limit(limit)
            .all()
        )
        by_revenue = self._enrich_top_members(
            [(row.user_id, round(float(row.total), 2)) for row in revenue_q],
            value_fmt=lambda v: f"${v:,.2f}",
        )

        # --- By class attendance ---
        class_q = (
            self.db.query(
                ClassBooking.user_id,
                func.count(ClassBooking.id).label("classes"),
            )
            .filter(ClassBooking.status == BookingStatus.ATTENDED)
            .group_by(ClassBooking.user_id)
            .order_by(func.count(ClassBooking.id).desc())
            .limit(limit)
            .all()
        )
        by_classes = self._enrich_top_members(
            [(row.user_id, float(row.classes)) for row in class_q],
            value_fmt=lambda v: f"{int(v)} class{'es' if v != 1 else ''}",
        )

        # --- By streak (compute in Python — complex SQL) ---
        streak_data = self._compute_all_streaks(limit)
        by_streak   = self._enrich_top_members(
            streak_data,
            value_fmt=lambda v: f"{int(v)}-day streak",
        )

        return {
            "by_visits":  by_visits,
            "by_revenue": by_revenue,
            "by_streak":  by_streak,
            "by_classes": by_classes,
        }

    # ===================================================================
    # RECENT ACTIVITY FEED
    # ===================================================================

    def get_recent_activity(self, limit: int = 20) -> List[dict]:
        """
        Latest events across the system for the admin live feed.
        Combines recent: registrations, payments, check-ins, bookings.
        """
        events = []

        # Recent registrations
        new_users = (
            self.db.query(User)
            .filter(User.role == UserRole.MEMBER)
            .order_by(User.created_at.desc())
            .limit(5)
            .all()
        )
        for u in new_users:
            events.append({
                "id":          u.id,
                "timestamp":   u.created_at,
                "event_type":  "member_joined",
                "description": f"{u.full_name} joined as a new member",
                "user_id":     u.id,
                "user_name":   u.full_name,
                "icon":        "👋",
                "amount":      None,
            })

        # Recent payments
        recent_payments = (
            self.db.query(Payment)
            .filter(Payment.status == PaymentStatus.SUCCESS)
            .order_by(Payment.created_at.desc())
            .limit(5)
            .all()
        )
        for p in recent_payments:
            user = self.db.query(User).filter(User.id == p.user_id).first()
            events.append({
                "id":          p.id,
                "timestamp":   p.created_at,
                "event_type":  "payment",
                "description": f"{user.full_name if user else 'Unknown'} paid ${p.amount:.2f}",
                "user_id":     p.user_id,
                "user_name":   user.full_name if user else None,
                "icon":        "💳",
                "amount":      p.amount,
            })

        # Recent check-ins
        recent_checkins = (
            self.db.query(Attendance)
            .order_by(Attendance.check_in_time.desc())
            .limit(5)
            .all()
        )
        for a in recent_checkins:
            user = self.db.query(User).filter(User.id == a.user_id).first()
            events.append({
                "id":          a.id,
                "timestamp":   a.check_in_time,
                "event_type":  "checkin",
                "description": f"{user.full_name if user else 'Unknown'} checked in",
                "user_id":     a.user_id,
                "user_name":   user.full_name if user else None,
                "icon":        "✅",
                "amount":      None,
            })

        # Sort all events by timestamp, newest first
        events.sort(key=lambda x: x["timestamp"], reverse=True)
        return events[:limit]

    # ===================================================================
    # FULL DASHBOARD
    # ===================================================================

    def get_dashboard_overview(self) -> dict:
        """
        Compute the complete dashboard dataset in one call.
        All sections computed together to minimize DB round-trips.
        """
        logger.info("Computing full dashboard overview...")
        return {
            "generated_at":    datetime.utcnow(),
            "kpis":            self.get_kpi_summary(),
            "revenue":         self.get_revenue_analytics(days=30),
            "members":         self.get_member_demographics(months=12),
            "attendance":      self.get_attendance_analytics(days=30),
            "classes":         self.get_class_analytics(days=30),
            "top_members":     self.get_top_members(limit=10),
            "recent_activity": self.get_recent_activity(limit=20),
        }

    # ===================================================================
    # PRIVATE HELPERS
    # ===================================================================

    def _compute_class_fill_rate(self) -> float:
        """Average fill rate across all upcoming scheduled classes."""
        upcoming = self.db.query(GymClass).filter(
            GymClass.status     == ClassStatus.SCHEDULED,
            GymClass.start_time >  datetime.utcnow(),
        ).all()
        if not upcoming:
            return 0.0
        rates = []
        for cls in upcoming:
            if cls.max_capacity > 0:
                confirmed = sum(
                    1 for b in cls.bookings
                    if b.status == BookingStatus.CONFIRMED
                )
                rates.append(confirmed / cls.max_capacity * 100)
        return round(sum(rates) / len(rates), 1) if rates else 0.0

    def _daily_cancellation_trend(self, days: int) -> dict:
        """Daily booking cancellation counts for last N days."""
        today      = datetime.utcnow().date()
        start_date = today - timedelta(days=days - 1)

        cancelled = self.db.query(ClassBooking).filter(
            ClassBooking.status      == BookingStatus.CANCELLED,
            ClassBooking.cancelled_at != None,
            func.date(ClassBooking.cancelled_at) >= start_date,
        ).all()

        daily: dict[date, int] = defaultdict(int)
        for b in cancelled:
            daily[b.cancelled_at.date()] += 1

        points = []
        for i in range(days):
            d     = start_date + timedelta(days=i)
            value = float(daily.get(d, 0))
            points.append({"date": d.isoformat(), "value": value, "label": str(int(value))})

        total = sum(p["value"] for p in points)
        return {
            "metric": "cancellations", "period": "daily",
            "data_points": points, "total": total,
            "average": round(total / days, 1),
            "peak_value": max((p["value"] for p in points), default=0),
            "peak_date": None, "trend_pct": None,
        }

    def _enrich_top_members(
        self,
        rows: List[Tuple[int, float]],
        value_fmt,
    ) -> List[dict]:
        """Add user details to top-member query results."""
        result = []
        for rank, (user_id, value) in enumerate(rows, start=1):
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                continue
            membership = self.db.query(Membership).filter(
                Membership.user_id == user_id,
                Membership.status  == MembershipStatus.ACTIVE,
            ).first()
            result.append({
                "rank":            rank,
                "user_id":         user_id,
                "full_name":       user.full_name,
                "email":           user.email,
                "membership_plan": membership.plan.value if membership else "none",
                "value":           value,
                "value_label":     value_fmt(value),
            })
        return result

    def _compute_all_streaks(self, limit: int) -> List[Tuple[int, float]]:
        """Compute current training streaks for all members, return top N."""
        today = datetime.utcnow().date()

        all_attendance = self.db.query(
            Attendance.user_id,
            Attendance.check_in_date,
        ).order_by(
            Attendance.user_id,
            Attendance.check_in_date.desc(),
        ).all()

        # Group by user
        user_dates: dict[int, list] = defaultdict(list)
        for row in all_attendance:
            user_dates[row.user_id].append(row.check_in_date)

        streaks = []
        for user_id, dates in user_dates.items():
            unique  = sorted(set(dates), reverse=True)
            streak  = 0
            expected = today
            for d in unique:
                if d == expected:
                    streak  += 1
                    expected = expected - timedelta(days=1)
                else:
                    break
            if streak > 0:
                streaks.append((user_id, float(streak)))

        streaks.sort(key=lambda x: x[1], reverse=True)
        return streaks[:limit]
