# 📊 Phase 9 — Admin Analytics Dashboard

A comprehensive analytics system powering every chart, table, and KPI on the admin dashboard.

---

## 📁 New Files in Phase 9

```
app/
├── schemas/
│   └── analytics.py             ← 20+ response schemas (KPIs, charts, heatmap, leaderboard)
├── routers/
│   └── analytics.py             ← 15 endpoints + CSV export
└── services/
    └── analytics_service.py     ← All metrics computed with SQLAlchemy aggregations

tests/
└── test_analytics.py            ← Full test suite (50+ assertions)
```

---

## 📋 Endpoints

| Method | Endpoint                            | Description                               |
|--------|-------------------------------------|-------------------------------------------|
| GET    | `/api/analytics/dashboard`          | Full dashboard — all sections in one call |
| GET    | `/api/analytics/kpis`               | KPI numbers only (fast, poll every 60s)  |
| GET    | `/api/analytics/revenue`            | Revenue totals, by-plan, trend chart      |
| GET    | `/api/analytics/revenue/trend`      | Daily revenue time-series only            |
| GET    | `/api/analytics/members`            | Demographics, growth, retention           |
| GET    | `/api/analytics/members/growth`     | Monthly growth trend only                 |
| GET    | `/api/analytics/members/retention`  | Retention/churn report                    |
| GET    | `/api/analytics/attendance`         | Heatmap + daily trend + session stats     |
| GET    | `/api/analytics/attendance/heatmap` | 7×24 peak hours grid                      |
| GET    | `/api/analytics/attendance/trend`   | Daily check-in time-series                |
| GET    | `/api/analytics/classes`            | Popularity, trainer perf, fill rates      |
| GET    | `/api/analytics/classes/popularity` | Category fill rate ranking                |
| GET    | `/api/analytics/top-members`        | Leaderboard (visits/revenue/streak/class) |
| GET    | `/api/analytics/activity-feed`      | Live event feed (registrations, payments) |
| GET    | `/api/analytics/export/csv`         | Download metrics as CSV                   |

---

## 📐 Dashboard Layout → API Mapping

```
┌─────────────────────────────────────────────────────┐
│  KPI Row                                            │
│  total_members │ revenue_this_month │ checkins_today│ ← GET /kpis
├──────────────────────────────────────────────────────┤
│  Revenue Chart  │  Member Growth    │  Plan Pie     │
│  (line 30d)     │  (bar, monthly)   │  (donut)      │ ← GET /revenue
│                 │                   │               │ ← GET /members
├──────────────────────────────────────────────────────┤
│  Attendance Heatmap (hour × weekday, 7×24 grid)     │ ← GET /attendance/heatmap
├──────────────────────────────────────────────────────┤
│  Class Popularity Bar  │  Trainer Performance Table │ ← GET /classes
├──────────────────────────────────────────────────────┤
│  Top Members Leaderboard (4 tabs)                   │ ← GET /top-members
├──────────────────────────────────────────────────────┤
│  Live Activity Feed    │  Retention Line Chart      │
│  (poll every 30s)      │                            │ ← GET /activity-feed
└─────────────────────────────────────────────────────┘
```

---

## 🔥 Attendance Heatmap

The heatmap is 168 cells (7 weekdays × 24 hours). Each cell shows the average number of check-ins at that hour on that day, computed over the lookback window.

```json
{
  "day_of_week": 0,          // 0 = Monday
  "hour": 18,                // 6 PM
  "avg_checkins": 24.3,      // Average members checking in at 6pm Mon
  "day_name": "Monday",
  "hour_label": "6:00 PM"
}
```

React Recharts usage:
```jsx
// Color cells from white (0) to red (peak)
const intensity = cell.avg_checkins / heatmap.peak_avg;
const color = `rgba(233, 69, 96, ${intensity})`;
```

---

## 📈 React Chart Integration (Recharts)

```jsx
// Revenue line chart
import { LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';

<LineChart data={revenue.trend.data_points}>
  <XAxis dataKey="date" />
  <YAxis />
  <Tooltip formatter={(v) => `$${v.toFixed(2)}`} />
  <Line type="monotone" dataKey="value" stroke="#e94560" />
</LineChart>

// Member growth bar chart
<BarChart data={members.growth_trend}>
  <Bar dataKey="new_members" fill="#1a1a2e" />
  <Bar dataKey="churned"     fill="#e94560" />
</BarChart>

// Plan distribution donut
import { PieChart, Pie, Cell } from 'recharts';
<PieChart>
  <Pie data={members.plan_distribution} dataKey="count" innerRadius={60}>
    {members.plan_distribution.map((entry, i) => (
      <Cell key={i} fill={COLORS[i]} />
    ))}
  </Pie>
</PieChart>
```

---

## ⚡ Performance Tips for Production

The full dashboard query touches 7 tables. Cache the result:

```python
# In the router
import json
from app.core.redis_client import redis_client

@router.get("/dashboard")
def get_dashboard(admin=Depends(require_admin), db=Depends(get_db)):
    cached = redis_client.get("dashboard_cache")
    if cached:
        return json.loads(cached)

    service = AnalyticsService(db)
    result  = service.get_dashboard_overview()

    # Cache for 5 minutes
    redis_client.setex("dashboard_cache", 300, json.dumps(result, default=str))
    return result
```

Individual endpoints (kpis, trend, heatmap) are cheap — poll those directly.

---

## 📥 CSV Export

```
GET /api/analytics/export/csv?report_type=revenue&days=90
→ Downloads: gym_revenue_20250210.csv

Columns: Date, Revenue (USD)
2025-01-15, 1234.56
2025-01-16, 987.00
...
```

Supported report_type values: `revenue`, `members`, `attendance`, `classes`

---

## ➡️ Next: Phase 10 — React Admin Dashboard

The React frontend that consumes all these analytics endpoints:
- Login with JWT
- Dashboard overview page (all the charts above)
- User management table
- Membership management
- Payment history
- Analytics charts (Recharts)
- Built with Tailwind CSS
