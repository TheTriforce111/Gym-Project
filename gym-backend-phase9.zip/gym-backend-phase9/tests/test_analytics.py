"""
tests/test_analytics.py — Admin Analytics Tests (Phase 9)

Run with:
    pytest tests/test_analytics.py -v

Tests cover:
- KPI summary accuracy
- Revenue analytics (totals, plan breakdown, trend)
- Member demographics (growth, plan distribution, retention)
- Attendance analytics (heatmap, trend, session duration)
- Class analytics (fill rate, popularity ranking)
- Top members leaderboard (all 4 categories)
- Activity feed
- CSV export
- Access control (members cannot access analytics)
"""

import pytest
from datetime import datetime, timedelta, date
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.core.security import hash_password
from app.models.user import User, UserRole
from app.models.membership import Membership, MembershipPlan, MembershipStatus
from app.models.payment import Payment, PaymentStatus, PaymentType
from app.models.attendance import Attendance
from app.models.gym_class import GymClass, ClassBooking, ClassStatus, BookingStatus, ClassCategory, DifficultyLevel

SQLALCHEMY_DATABASE_URL = "sqlite:///./test_analytics.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
Base.metadata.create_all(bind=engine)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield


@pytest.fixture
def db():
    s = TestingSessionLocal()
    yield s
    s.close()


def _make_user(db, email, role=UserRole.MEMBER):
    u = User(
        full_name=f"Test {role}",
        email=email,
        hashed_password=hash_password("Pass1234"),
        role=role,
        is_active=True,
    )
    db.add(u)
    db.commit()
    resp = client.post("/api/auth/login", json={"email": email, "password": "Pass1234"})
    return {"user": u, "token": resp.json()["access_token"]}


def _give_membership(db, user_id, plan=MembershipPlan.MONTHLY, status=MembershipStatus.ACTIVE):
    m = Membership(
        user_id=user_id,
        plan=plan,
        status=status,
        start_date=datetime.utcnow(),
        end_date=datetime.utcnow() + timedelta(days=30),
        price_paid=49.99,
    )
    db.add(m)
    db.commit()
    return m


def _add_payment(db, user_id, amount, membership_id=None):
    p = Payment(
        user_id=user_id,
        membership_id=membership_id,
        amount=amount,
        currency="usd",
        status=PaymentStatus.SUCCESS,
        payment_type=PaymentType.NEW_MEMBERSHIP,
        idempotency_key=f"test_{user_id}_{amount}_{datetime.utcnow().timestamp()}",
    )
    db.add(p)
    db.commit()
    return p


def _add_checkin(db, user_id, days_ago=0):
    check_date = (datetime.utcnow() - timedelta(days=days_ago)).date()
    a = Attendance(
        user_id=user_id,
        check_in_time=datetime.utcnow() - timedelta(days=days_ago),
        check_in_date=check_date,
        method="qr_scan",
    )
    db.add(a)
    db.commit()
    return a


@pytest.fixture
def admin(db):
    return _make_user(db, "admin@gym.com", UserRole.ADMIN)


@pytest.fixture
def populated_db(db):
    """Create a realistic dataset for analytics tests."""
    # 3 members with different plans
    m1 = _make_user(db, "m1@gym.com", UserRole.MEMBER)
    m2 = _make_user(db, "m2@gym.com", UserRole.MEMBER)
    m3 = _make_user(db, "m3@gym.com", UserRole.MEMBER)

    mem1 = _give_membership(db, m1["user"].id, MembershipPlan.MONTHLY)
    mem2 = _give_membership(db, m2["user"].id, MembershipPlan.YEARLY)
    mem3 = _give_membership(db, m3["user"].id, MembershipPlan.MONTHLY)

    # Payments
    _add_payment(db, m1["user"].id, 49.99,  mem1.id)
    _add_payment(db, m2["user"].id, 449.99, mem2.id)
    _add_payment(db, m3["user"].id, 49.99,  mem3.id)

    # Check-ins (m1 visits 5 times, m2 visits 3 times, m3 visits 1 time)
    for i in range(5):
        _add_checkin(db, m1["user"].id, days_ago=i)
    for i in range(3):
        _add_checkin(db, m2["user"].id, days_ago=i)
    _add_checkin(db, m3["user"].id, days_ago=0)

    # A gym class with bookings
    now = datetime.utcnow()
    cls = GymClass(
        name="Morning Yoga",
        category=ClassCategory.YOGA,
        difficulty=DifficultyLevel.ALL_LEVELS,
        start_time=now + timedelta(hours=2),
        end_time=now + timedelta(hours=3),
        max_capacity=20,
        status=ClassStatus.SCHEDULED,
    )
    db.add(cls)
    db.commit()

    booking = ClassBooking(
        user_id=m1["user"].id,
        gym_class_id=cls.id,
        status=BookingStatus.CONFIRMED,
    )
    db.add(booking)
    db.commit()

    return {
        "members": [m1, m2, m3],
        "memberships": [mem1, mem2, mem3],
        "gym_class": cls,
    }


# ---------------------------------------------------------------------------
# Access Control Tests
# ---------------------------------------------------------------------------

class TestAccessControl:

    def test_member_cannot_access_analytics(self, db):
        """Regular members get 403 on all analytics endpoints."""
        member = _make_user(db, "member@gym.com", UserRole.MEMBER)
        resp = client.get("/api/analytics/kpis",
                          headers={"Authorization": f"Bearer {member['token']}"})
        assert resp.status_code == 403

    def test_admin_can_access_analytics(self, admin):
        """Admin can access all analytics endpoints."""
        resp = client.get("/api/analytics/kpis",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# KPI Tests
# ---------------------------------------------------------------------------

class TestKPIs:

    def test_kpi_counts_members_correctly(self, admin, populated_db):
        """KPI total_members counts only MEMBER role users."""
        resp = client.get("/api/analytics/kpis",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_members"]  == 3
        assert data["active_members"] == 3

    def test_kpi_revenue_sums_correctly(self, admin, populated_db):
        """KPI revenue_this_month sums successful payments."""
        resp = client.get("/api/analytics/kpis",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        # 49.99 + 449.99 + 49.99 = 549.97
        assert data["revenue_this_month"] == pytest.approx(549.97, rel=1e-2)

    def test_kpi_checkins_today(self, admin, populated_db):
        """KPI checkins_today counts today's check-ins."""
        resp = client.get("/api/analytics/kpis",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        # m1, m2, m3 all checked in today
        assert data["checkins_today"] >= 3

    def test_kpi_has_all_required_fields(self, admin, populated_db):
        """KPI response includes all required fields."""
        resp = client.get("/api/analytics/kpis",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        required = [
            "total_members", "active_members", "revenue_today",
            "revenue_this_month", "checkins_today", "classes_today",
            "expiring_soon_count", "currently_in_gym",
        ]
        for field in required:
            assert field in data, f"Missing field: {field}"


# ---------------------------------------------------------------------------
# Revenue Tests
# ---------------------------------------------------------------------------

class TestRevenue:

    def test_revenue_totals(self, admin, populated_db):
        """Revenue endpoint returns correct totals."""
        resp = client.get("/api/analytics/revenue",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_revenue"]  == pytest.approx(549.97, rel=1e-2)
        assert data["total_refunded"] == 0.0
        assert data["net_revenue"]    == pytest.approx(549.97, rel=1e-2)

    def test_revenue_by_plan(self, admin, populated_db):
        """Revenue is correctly split by membership plan."""
        resp = client.get("/api/analytics/revenue",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data  = resp.json()
        plans = {p["plan"]: p for p in data["by_plan"]}
        assert "monthly" in plans
        assert "yearly"  in plans
        # Yearly member paid 449.99 → largest single payment
        assert plans["yearly"]["revenue"] == pytest.approx(449.99, rel=1e-2)

    def test_revenue_trend_has_correct_length(self, admin, populated_db):
        """Revenue trend has exactly `days` data points."""
        resp = client.get("/api/analytics/revenue?days=14",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        assert len(data["trend"]["data_points"]) == 14

    def test_revenue_trend_endpoint(self, admin, populated_db):
        """Focused revenue/trend endpoint works independently."""
        resp = client.get("/api/analytics/revenue/trend?days=7",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        assert len(resp.json()["data_points"]) == 7


# ---------------------------------------------------------------------------
# Member Analytics Tests
# ---------------------------------------------------------------------------

class TestMemberAnalytics:

    def test_member_demographics(self, admin, populated_db):
        """Member demographics shows correct plan distribution."""
        resp = client.get("/api/analytics/members",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        plans = {p["plan"]: p for p in data["plan_distribution"]}
        assert "monthly" in plans
        assert "yearly"  in plans
        assert plans["monthly"]["count"] == 2
        assert plans["yearly"]["count"]  == 1

    def test_growth_trend_length(self, admin, populated_db):
        """Growth trend returns correct number of months."""
        resp = client.get("/api/analytics/members?months=6",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        assert len(data["growth_trend"]) == 6

    def test_status_breakdown(self, admin, populated_db):
        """Status breakdown counts active memberships correctly."""
        resp = client.get("/api/analytics/members",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        assert data["status_breakdown"]["active"] == 3

    def test_retention_report(self, admin, populated_db):
        """Retention report has required fields."""
        resp = client.get("/api/analytics/members/retention",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        assert "avg_retention_pct" in data
        assert "avg_churn_pct"     in data
        assert data["avg_retention_pct"] + data["avg_churn_pct"] == pytest.approx(100.0, rel=1e-1)


# ---------------------------------------------------------------------------
# Attendance Analytics Tests
# ---------------------------------------------------------------------------

class TestAttendanceAnalytics:

    def test_attendance_analytics(self, admin, populated_db):
        """Attendance analytics returns heatmap, trend, and stats."""
        resp = client.get("/api/analytics/attendance",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        assert "heatmap"     in data
        assert "daily_trend" in data
        assert "weekly_avg"  in data

    def test_heatmap_has_168_cells(self, admin, populated_db):
        """Heatmap always has exactly 168 cells (7 days × 24 hours)."""
        resp = client.get("/api/analytics/attendance/heatmap",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        assert len(resp.json()["cells"]) == 168

    def test_heatmap_cell_structure(self, admin, populated_db):
        """Each heatmap cell has required fields."""
        resp = client.get("/api/analytics/attendance/heatmap",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        cell = resp.json()["cells"][0]
        assert "day_of_week"  in cell
        assert "hour"         in cell
        assert "avg_checkins" in cell
        assert "day_name"     in cell
        assert "hour_label"   in cell

    def test_attendance_trend_length(self, admin, populated_db):
        """Trend has exactly `days` data points."""
        resp = client.get("/api/analytics/attendance/trend?days=14",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert len(resp.json()["data_points"]) == 14


# ---------------------------------------------------------------------------
# Class Analytics Tests
# ---------------------------------------------------------------------------

class TestClassAnalytics:

    def test_class_popularity(self, admin, populated_db):
        """Class popularity shows yoga category."""
        resp = client.get("/api/analytics/classes",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        categories = [p["category"] for p in data["popularity"]]
        assert "yoga" in categories

    def test_fill_rate_is_computed(self, admin, populated_db):
        """Fill rate is correctly computed from bookings/capacity."""
        resp = client.get("/api/analytics/classes",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        yoga = next((p for p in data["popularity"] if p["category"] == "yoga"), None)
        assert yoga is not None
        # 1 booking out of 20 capacity = 5%
        assert yoga["fill_rate_pct"] == pytest.approx(5.0, rel=1e-1)

    def test_class_popularity_endpoint(self, admin, populated_db):
        """Focused popularity endpoint returns list."""
        resp = client.get("/api/analytics/classes/popularity",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


# ---------------------------------------------------------------------------
# Top Members Tests
# ---------------------------------------------------------------------------

class TestTopMembers:

    def test_top_members_by_visits(self, admin, populated_db):
        """Top member by visits is the one who visited most."""
        resp = client.get("/api/analytics/top-members",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        by_visits = data["by_visits"]
        assert len(by_visits) > 0
        # m1 visited 5 times — should be rank 1
        assert by_visits[0]["rank"] == 1
        assert by_visits[0]["value"] == 5.0

    def test_top_members_has_all_categories(self, admin, populated_db):
        """Top members response has all four leaderboard categories."""
        resp = client.get("/api/analytics/top-members",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        assert "by_visits"  in data
        assert "by_revenue" in data
        assert "by_streak"  in data
        assert "by_classes" in data

    def test_top_members_revenue(self, admin, populated_db):
        """Top member by revenue is the yearly plan member."""
        resp = client.get("/api/analytics/top-members",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        data = resp.json()
        top_by_revenue = data["by_revenue"][0]
        # m2 paid 449.99 (yearly plan)
        assert top_by_revenue["value"] == pytest.approx(449.99, rel=1e-2)


# ---------------------------------------------------------------------------
# Activity Feed Tests
# ---------------------------------------------------------------------------

class TestActivityFeed:

    def test_activity_feed_returns_events(self, admin, populated_db):
        """Activity feed returns events from multiple categories."""
        resp = client.get("/api/analytics/activity-feed",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        events = resp.json()
        assert len(events) > 0

        event_types = {e["event_type"] for e in events}
        # Should have at least registrations and payments
        assert "member_joined" in event_types or "payment" in event_types

    def test_activity_feed_event_structure(self, admin, populated_db):
        """Each event has required fields."""
        resp = client.get("/api/analytics/activity-feed",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        event = resp.json()[0]
        for field in ["id", "timestamp", "event_type", "description", "icon"]:
            assert field in event, f"Missing field: {field}"


# ---------------------------------------------------------------------------
# CSV Export Tests
# ---------------------------------------------------------------------------

class TestCSVExport:

    def test_revenue_csv_export(self, admin, populated_db):
        """CSV export for revenue returns downloadable CSV."""
        resp = client.get(
            "/api/analytics/export/csv?report_type=revenue&days=7",
            headers={"Authorization": f"Bearer {admin['token']}"}
        )
        assert resp.status_code == 200
        assert "text/csv" in resp.headers["content-type"]
        assert "attachment" in resp.headers["content-disposition"]
        # CSV should have header + data rows
        lines = resp.text.strip().split("\n")
        assert lines[0] == "Date,Revenue (USD)"
        assert len(lines) == 8  # header + 7 days

    def test_members_csv_export(self, admin, populated_db):
        """Members CSV export has correct headers."""
        resp = client.get(
            "/api/analytics/export/csv?report_type=members",
            headers={"Authorization": f"Bearer {admin['token']}"}
        )
        assert resp.status_code == 200
        lines = resp.text.strip().split("\n")
        assert "Month" in lines[0]
        assert "New Members" in lines[0]

    def test_attendance_csv_export(self, admin, populated_db):
        """Attendance CSV export works."""
        resp = client.get(
            "/api/analytics/export/csv?report_type=attendance&days=7",
            headers={"Authorization": f"Bearer {admin['token']}"}
        )
        assert resp.status_code == 200
        lines = resp.text.strip().split("\n")
        assert lines[0] == "Date,Check-ins"
        assert len(lines) == 8

    def test_classes_csv_export(self, admin, populated_db):
        """Classes CSV export includes all columns."""
        resp = client.get(
            "/api/analytics/export/csv?report_type=classes",
            headers={"Authorization": f"Bearer {admin['token']}"}
        )
        assert resp.status_code == 200
        assert "Category" in resp.text
        assert "Fill Rate" in resp.text


# ---------------------------------------------------------------------------
# Full Dashboard Test
# ---------------------------------------------------------------------------

class TestFullDashboard:

    def test_dashboard_overview(self, admin, populated_db):
        """Full dashboard returns all required sections."""
        resp = client.get("/api/analytics/dashboard",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        data = resp.json()
        required_sections = [
            "generated_at", "kpis", "revenue", "members",
            "attendance", "classes", "top_members", "recent_activity",
        ]
        for section in required_sections:
            assert section in data, f"Missing section: {section}"

    def test_dashboard_generated_at_is_recent(self, admin, populated_db):
        """Dashboard generated_at timestamp is current."""
        resp = client.get("/api/analytics/dashboard",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        generated_at = datetime.fromisoformat(
            resp.json()["generated_at"].replace("Z", "+00:00")
        )
        diff = (datetime.utcnow() - generated_at.replace(tzinfo=None)).total_seconds()
        assert diff < 60, "Dashboard generated_at should be within the last 60 seconds"
