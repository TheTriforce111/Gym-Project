"""
tests/test_notifications.py — Notification System Tests (Phase 8)

Run with:
    pytest tests/test_notifications.py -v

Tests cover:
- Device token registration (upsert, deactivation)
- Notification inbox (list, unread count, mark read)
- Service layer (all notification type templates)
- Admin announcement broadcast
- Failed notification retry
- Celery task behavior (mocked)
"""

import pytest
from unittest.mock import MagicMock, patch
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.core.security import hash_password
from app.models.user import User, UserRole
from app.models.membership import Membership, MembershipPlan, MembershipStatus
from app.models.notification import (
    DeviceToken, Notification,
    NotificationChannel, NotificationStatus, NotificationType,
)

from datetime import datetime, timedelta

SQLALCHEMY_DATABASE_URL = "sqlite:///./test_notifications.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
Base.metadata.create_all(bind=engine)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield


@pytest.fixture
def db():
    s = TestingSessionLocal()
    yield s
    s.close()


def _make_user(db, email, role):
    u = User(
        full_name=f"{role} User",
        email=email,
        hashed_password=hash_password("Pass1234"),
        role=role,
        is_active=True,
    )
    db.add(u)
    db.commit()
    resp = client.post("/api/auth/login", json={"email": email, "password": "Pass1234"})
    return {"user": u, "token": resp.json()["access_token"]}


def _give_membership(db, user_id):
    m = Membership(
        user_id=user_id,
        plan=MembershipPlan.MONTHLY,
        status=MembershipStatus.ACTIVE,
        start_date=datetime.utcnow(),
        end_date=datetime.utcnow() + timedelta(days=30),
        price_paid=49.99,
    )
    db.add(m)
    db.commit()
    return m


@pytest.fixture
def admin(db):   return _make_user(db, "admin@gym.com",   UserRole.ADMIN)
@pytest.fixture
def member(db):
    data = _make_user(db, "member@gym.com", UserRole.MEMBER)
    _give_membership(db, data["user"].id)
    return data


# ---------------------------------------------------------------------------
# Device Token Tests
# ---------------------------------------------------------------------------

class TestDeviceTokens:

    def test_register_device_token(self, member):
        """Member can register an FCM device token."""
        resp = client.post(
            "/api/notifications/device-token",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={
                "token":       "fcm_test_token_abc123",
                "device_type": "android",
                "device_name": "Pixel 8",
                "app_version": "2.1.0",
            }
        )
        assert resp.status_code == 201
        assert "token_id" in resp.json()

    def test_register_same_token_is_upsert(self, member):
        """Registering the same token twice updates, doesn't duplicate."""
        payload = {"token": "fcm_same_token_xyz"}
        client.post("/api/notifications/device-token",
                    headers={"Authorization": f"Bearer {member['token']}"},
                    json=payload)
        client.post("/api/notifications/device-token",
                    headers={"Authorization": f"Bearer {member['token']}"},
                    json=payload)

        # Only 1 token record should exist
        db = TestingSessionLocal()
        count = db.query(DeviceToken).filter(
            DeviceToken.token == "fcm_same_token_xyz"
        ).count()
        db.close()
        assert count == 1

    def test_remove_device_token(self, member, db):
        """Member can deactivate their device token on logout."""
        token_record = DeviceToken(
            user_id=member["user"].id,
            token="fcm_to_remove",
            is_active=True,
        )
        db.add(token_record)
        db.commit()

        resp = client.delete(
            f"/api/notifications/device-token/{token_record.id}",
            headers={"Authorization": f"Bearer {member['token']}"}
        )
        assert resp.status_code == 200

        db.refresh(token_record)
        assert token_record.is_active is False


# ---------------------------------------------------------------------------
# Inbox Tests
# ---------------------------------------------------------------------------

class TestInbox:

    def _create_notification(self, db, user_id, status=NotificationStatus.SENT):
        """Helper to insert a notification directly into DB."""
        n = Notification(
            user_id=user_id,
            title="Test Notification",
            body="This is a test.",
            notification_type=NotificationType.GENERAL_ANNOUNCEMENT,
            channel=NotificationChannel.PUSH,
            status=status,
        )
        db.add(n)
        db.commit()
        db.refresh(n)
        return n

    def test_empty_inbox(self, member):
        """New member has empty inbox."""
        resp = client.get("/api/notifications/",
                          headers={"Authorization": f"Bearer {member['token']}"})
        assert resp.status_code == 200
        assert resp.json() == []

    def test_notifications_appear_in_inbox(self, member, db):
        """Notifications created for user appear in their inbox."""
        self._create_notification(db, member["user"].id)
        self._create_notification(db, member["user"].id)

        resp = client.get("/api/notifications/",
                          headers={"Authorization": f"Bearer {member['token']}"})
        assert resp.status_code == 200
        assert len(resp.json()) == 2

    def test_unread_count(self, member, db):
        """Unread count reflects pending/sent notifications."""
        self._create_notification(db, member["user"].id, NotificationStatus.SENT)
        self._create_notification(db, member["user"].id, NotificationStatus.SENT)
        # One that's already read
        self._create_notification(db, member["user"].id, NotificationStatus.READ)

        resp = client.get("/api/notifications/unread-count",
                          headers={"Authorization": f"Bearer {member['token']}"})
        assert resp.json()["unread_count"] == 2

    def test_mark_all_as_read(self, member, db):
        """Mark-all-as-read sets all notifications to READ."""
        for _ in range(3):
            self._create_notification(db, member["user"].id, NotificationStatus.SENT)

        resp = client.post(
            "/api/notifications/mark-read",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={}   # No IDs = mark all
        )
        assert resp.status_code == 200
        assert resp.json()["marked_read"] == 3

        # Unread count should now be 0
        resp2 = client.get("/api/notifications/unread-count",
                           headers={"Authorization": f"Bearer {member['token']}"})
        assert resp2.json()["unread_count"] == 0

    def test_mark_specific_notification_as_read(self, member, db):
        """Mark a specific notification as read."""
        n1 = self._create_notification(db, member["user"].id)
        n2 = self._create_notification(db, member["user"].id)

        client.post(
            "/api/notifications/mark-read",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={"notification_ids": [n1.id]}
        )

        db.refresh(n1)
        db.refresh(n2)
        assert n1.status == NotificationStatus.READ
        assert n2.status != NotificationStatus.READ  # n2 still unread

    def test_delete_notification(self, member, db):
        """Member can delete a notification from their inbox."""
        n = self._create_notification(db, member["user"].id)

        resp = client.delete(
            f"/api/notifications/{n.id}",
            headers={"Authorization": f"Bearer {member['token']}"}
        )
        assert resp.status_code == 200

        # Should be gone from DB
        exists = db.query(Notification).filter(Notification.id == n.id).first()
        assert exists is None


# ---------------------------------------------------------------------------
# Notification Service Tests (unit-level, no HTTP)
# ---------------------------------------------------------------------------

class TestNotificationService:

    @patch("app.workers.notification_tasks.deliver_notification.delay")
    def test_send_creates_db_record_and_queues_task(self, mock_delay, member, db):
        """Calling service.send() creates a DB record and queues a Celery task."""
        from app.services.notification_service import NotificationService
        service = NotificationService(db)

        notif = service.send(
            user_id=member["user"].id,
            notification_type=NotificationType.GENERAL_ANNOUNCEMENT,
            title="Test Title",
            body="Test body.",
            channel=NotificationChannel.PUSH,
        )

        # DB record created
        assert notif.id is not None
        assert notif.status == NotificationStatus.PENDING
        assert notif.title == "Test Title"

        # Celery task queued
        mock_delay.assert_called_once_with(notif.id)

    @patch("app.workers.notification_tasks.deliver_notification.delay")
    def test_membership_created_notification(self, mock_delay, member, db):
        """notify_membership_created sends correct title/body."""
        from app.services.notification_service import NotificationService
        service = NotificationService(db)

        notif = service.notify_membership_created(
            user_id=member["user"].id,
            plan="monthly",
            end_date="February 28, 2025",
        )

        assert notif.notification_type == NotificationType.MEMBERSHIP_CREATED
        assert "monthly" in notif.body.lower()
        assert "February 28" in notif.body
        mock_delay.assert_called_once()

    @patch("app.workers.notification_tasks.deliver_notification.delay")
    def test_payment_success_notification(self, mock_delay, member, db):
        """notify_payment_success sends both push and email."""
        from app.services.notification_service import NotificationService
        service = NotificationService(db)

        notif = service.notify_payment_success(
            user_id=member["user"].id,
            amount=49.99,
            plan="monthly",
        )

        assert notif.notification_type == NotificationType.PAYMENT_SUCCESS
        assert notif.channel == NotificationChannel.BOTH
        assert "$49.99" in notif.body

    @patch("app.workers.notification_tasks.deliver_notification.delay")
    def test_attendance_milestone_at_10_visits(self, mock_delay, member, db):
        """Milestone notification fires at exactly 10 visits."""
        from app.services.notification_service import NotificationService
        service = NotificationService(db)

        # 10 visits → should trigger
        notif = service.notify_attendance_milestone(member["user"].id, 10)
        assert notif is not None
        assert "10" in notif.body

        # 11 visits → should NOT trigger (not a milestone)
        notif2 = service.notify_attendance_milestone(member["user"].id, 11)
        assert notif2 is None

    @patch("app.workers.notification_tasks.deliver_notification.delay")
    def test_announcement_broadcast(self, mock_delay, db):
        """Broadcast creates one notification per user."""
        from app.services.notification_service import NotificationService

        # Create 3 members
        user_ids = []
        for i in range(3):
            u = User(
                full_name=f"Member {i}",
                email=f"m{i}@gym.com",
                hashed_password=hash_password("Pass1234"),
                role=UserRole.MEMBER,
                is_active=True,
            )
            db.add(u)
            db.commit()
            user_ids.append(u.id)

        service = NotificationService(db)
        notifications = service.send_announcement(
            user_ids=user_ids,
            title="Gym Announcement",
            message="We're open on holidays!",
        )

        assert len(notifications) == 3
        assert mock_delay.call_count == 3


# ---------------------------------------------------------------------------
# Admin Tests
# ---------------------------------------------------------------------------

class TestAdminNotifications:

    def test_admin_announce_endpoint(self, admin, member):
        """Admin can broadcast an announcement to all members."""
        resp = client.post(
            "/api/notifications/announce",
            headers={"Authorization": f"Bearer {admin['token']}"},
            json={
                "title":   "Holiday Hours",
                "message": "We'll be open 8am-2pm on Dec 25.",
                "user_ids": [member["user"].id],
            }
        )
        assert resp.status_code == 200
        assert resp.json()["recipients"] == 1

    def test_member_cannot_announce(self, member):
        """Regular members cannot send announcements."""
        resp = client.post(
            "/api/notifications/announce",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={"title": "Fake", "message": "Not allowed"},
        )
        assert resp.status_code == 403

    @patch("app.workers.notification_tasks.deliver_notification.delay")
    def test_retry_failed_notification(self, mock_delay, admin, member, db):
        """Admin can manually retry a failed notification."""
        # Create a failed notification
        n = Notification(
            user_id=member["user"].id,
            title="Failed Notification",
            body="This failed to deliver.",
            notification_type=NotificationType.GENERAL_ANNOUNCEMENT,
            channel=NotificationChannel.PUSH,
            status=NotificationStatus.FAILED,
            retry_count=3,
            failure_reason="FCM timeout",
        )
        db.add(n)
        db.commit()

        resp = client.post(
            f"/api/notifications/{n.id}/retry",
            headers={"Authorization": f"Bearer {admin['token']}"}
        )
        assert resp.status_code == 200

        db.refresh(n)
        assert n.status == NotificationStatus.PENDING
        assert n.retry_count == 0
        mock_delay.assert_called_once_with(n.id)

    def test_list_failed_notifications(self, admin, member, db):
        """Admin can view all failed notifications."""
        for i in range(3):
            n = Notification(
                user_id=member["user"].id,
                title=f"Failed #{i}",
                body="Failed to send.",
                notification_type=NotificationType.GENERAL_ANNOUNCEMENT,
                channel=NotificationChannel.PUSH,
                status=NotificationStatus.FAILED,
            )
            db.add(n)
        db.commit()

        resp = client.get(
            "/api/notifications/failed",
            headers={"Authorization": f"Bearer {admin['token']}"}
        )
        assert resp.status_code == 200
        assert len(resp.json()) == 3
