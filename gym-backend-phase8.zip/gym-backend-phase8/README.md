# 🔔 Phase 8 — Notification System

A full push + email notification system with Celery background workers, automatic scheduling, retry logic, and a member notification inbox.

---

## 📁 New Files in Phase 8

```
app/
├── models/
│   └── notification.py          ← Notification + DeviceToken models
├── schemas/
│   └── notification.py          ← Request/response schemas
├── routers/
│   └── notifications.py         ← 10 endpoints (inbox, device tokens, admin)
├── services/
│   ├── notification_service.py  ← Central dispatcher + all event templates
│   ├── push_service.py          ← Firebase FCM integration
│   └── email_service.py         ← SMTP email with HTML templates
└── workers/
    ├── celery_app.py            ← Celery setup + beat schedule
    ├── notification_tasks.py    ← Delivery task with exponential backoff
    └── scheduled_tasks.py       ← 5 periodic tasks (expiry, reminders, etc.)

tests/
└── test_notifications.py        ← Full test suite (service + API + admin)
```

---

## 📋 Endpoints

| Method | Endpoint                              | Auth   | Description                       |
|--------|---------------------------------------|--------|-----------------------------------|
| POST   | `/api/notifications/device-token`     | Member | Register FCM token                |
| DELETE | `/api/notifications/device-token/{id}`| Member | Remove token on logout            |
| GET    | `/api/notifications/`                 | Member | Notification inbox                |
| GET    | `/api/notifications/unread-count`     | Member | Badge count for app icon          |
| POST   | `/api/notifications/mark-read`        | Member | Mark notifications as read        |
| DELETE | `/api/notifications/{id}`             | Member | Delete from inbox                 |
| POST   | `/api/notifications/announce`         | Admin  | Broadcast to all members          |
| GET    | `/api/notifications/failed`           | Admin  | List failed notifications         |
| POST   | `/api/notifications/{id}/retry`       | Admin  | Manually retry failed delivery    |

---

## 🏗️ Architecture

```
Any Service (membership, payment, class, attendance)
      │
      │  service.notify_xxx(user_id, ...)
      ▼
NotificationService.send()
  1. Save Notification to DB (status=PENDING)
  2. deliver_notification.delay(id)  ← Celery task queued
      │
      ▼ (async, in background)
Redis (message broker)
      │
      ▼
Celery Worker process
  1. Load notification from DB
  2. Send via Firebase (push) and/or SMTP (email)
  3. Update DB → SENT or FAILED
  4. If failed → retry with exponential backoff
```

---

## ⏰ Scheduled Tasks (Celery Beat)

| Task | Schedule | What it does |
|------|----------|--------------|
| `check_expiring_memberships` | Daily 9am | Warn members 7, 3, 1 day before expiry |
| `auto_expire_memberships` | Daily midnight | Mark overdue memberships as EXPIRED |
| `send_class_reminders` | Every 15 min | Push reminder 1h before class |
| `retry_failed_notifications` | Every 30 min | Re-queue failed notifications |
| `send_weekly_summaries` | Monday 8am | Weekly visit recap email |

---

## 🔁 Retry Logic

```
Attempt 1: Immediate
  ↓ fails
Attempt 2: 60 seconds later
  ↓ fails
Attempt 3: 300 seconds (5 min) later
  ↓ fails
Attempt 4: 900 seconds (15 min) later
  ↓ fails
Status → PERMANENTLY FAILED (admin can retry manually)
```

---

## 🚀 Running the System

```bash
# Start Redis (required as broker)
docker-compose up -d redis

# Start the API server
uvicorn app.main:app --reload

# Start the Celery worker (in a separate terminal)
celery -A app.workers.celery_app worker --loglevel=info

# Start Celery Beat scheduler (in a third terminal)
celery -A app.workers.celery_app beat --loglevel=info

# Monitor tasks with Flower (optional, great for debugging)
celery -A app.workers.celery_app flower --port=5555
# Open http://localhost:5555
```

---

## 📱 Flutter Integration

```dart
// 1. Setup Firebase in main.dart
await Firebase.initializeApp();

// 2. Get FCM token and register with backend
final token = await FirebaseMessaging.instance.getToken();
await api.post('/api/notifications/device-token', body: {'token': token, 'device_type': 'android'});

// 3. Handle foreground notifications
FirebaseMessaging.onMessage.listen((RemoteMessage message) {
  // Show in-app notification banner
  showSnackBar(message.notification?.title ?? '');
});

// 4. Handle notification taps (background)
FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
  final screen = message.data['screen'];
  Navigator.pushNamed(context, '/$screen');  // Deep-link
});

// 5. Refresh token when Firebase rotates it
FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
  api.post('/api/notifications/device-token', body: {'token': newToken});
});

// 6. Poll unread count for badge
final resp = await api.get('/api/notifications/unread-count');
FlutterAppBadger.updateBadgeCount(resp['unread_count']);
```

---

## 📧 Notification Types

| Type | Channel | Template |
|---|---|---|
| membership_created | Both | Welcome + plan details |
| membership_expiring | Both | Days remaining warning |
| membership_expired | Both | Renewal prompt |
| payment_success | Both | Receipt with amount |
| payment_failed | Both | Retry prompt |
| class_booking_confirmed | Push | + scheduled reminder |
| class_cancelled | Both | Apology + details |
| class_waitlist_promoted | Both | 🎉 Spot opened! |
| checkin_success | Push | Welcome + visit count |
| attendance_milestone | Both | 🏆 Achievement |
| personal_best | Push | 🏆 New record |
| general_announcement | Both | Admin broadcast |

---

## ➡️ Next: Phase 9 — Admin Analytics Dashboard

Adds comprehensive analytics endpoints: revenue trends, member growth, class popularity, peak hours, retention rates, and KPI summaries — all ready for the React admin dashboard.
