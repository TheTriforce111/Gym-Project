"""
models/notification.py — Notification Database Models (Phase 8)

Two tables:
┌──────────────────────────────────────────────────────────────────┐
│  Notification  → Every notification sent to a user              │
│  DeviceToken   → FCM push token registered per device           │
└──────────────────────────────────────────────────────────────────┘

Notification lifecycle:
  PENDING → SENT     (successfully delivered to FCM/SMTP)
  PENDING → FAILED   (delivery failed after MAX_RETRIES attempts)
  SENT    → READ     (member opened/acknowledged the notification)

DeviceToken:
  One user can have multiple tokens (phone + tablet).
  Tokens are invalidated when Firebase reports them as stale.
  Always send to ALL active tokens for a user.
"""

import enum
from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.core.database import Base


class NotificationType(str, enum.Enum):
    """Category of notification — determines the template and delivery channel."""
    # Membership
    MEMBERSHIP_CREATED    = "membership_created"
    MEMBERSHIP_EXPIRING   = "membership_expiring"     # 7-day warning
    MEMBERSHIP_EXPIRED    = "membership_expired"
    MEMBERSHIP_RENEWED    = "membership_renewed"
    MEMBERSHIP_FROZEN     = "membership_frozen"
    MEMBERSHIP_UNFROZEN   = "membership_unfrozen"
    # Payments
    PAYMENT_SUCCESS       = "payment_success"
    PAYMENT_FAILED        = "payment_failed"
    PAYMENT_REFUNDED      = "payment_refunded"
    # Classes
    CLASS_BOOKING_CONFIRMED = "class_booking_confirmed"
    CLASS_BOOKING_CANCELLED = "class_booking_cancelled"
    CLASS_CANCELLED         = "class_cancelled"
    CLASS_REMINDER          = "class_reminder"          # 1h before
    CLASS_WAITLIST_PROMOTED = "class_waitlist_promoted"
    # Attendance
    CHECKIN_SUCCESS       = "checkin_success"
    ATTENDANCE_MILESTONE  = "attendance_milestone"     # 10th, 50th visit
    # Workouts
    WORKOUT_PLAN_ASSIGNED = "workout_plan_assigned"
    PERSONAL_BEST         = "personal_best"
    # System
    GENERAL_ANNOUNCEMENT  = "general_announcement"
    ACCOUNT_WELCOME       = "account_welcome"
    PASSWORD_CHANGED      = "password_changed"


class NotificationChannel(str, enum.Enum):
    """Which delivery channel was used."""
    PUSH  = "push"
    EMAIL = "email"
    BOTH  = "both"


class NotificationStatus(str, enum.Enum):
    """Current delivery status."""
    PENDING = "pending"
    SENT    = "sent"
    FAILED  = "failed"
    READ    = "read"


class Notification(Base):
    """
    One notification record per message sent to a user.
    Supports push, email, or both channels.
    Retries on failure up to max_retries times.

    Maps to the 'notifications' table.
    """
    __tablename__ = "notifications"

    id      = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    # --- Content ---
    title   = Column(String(200), nullable=False)
    body    = Column(Text,        nullable=False)

    notification_type = Column(Enum(NotificationType), nullable=False)
    channel           = Column(Enum(NotificationChannel), nullable=False)

    # --- Status & Retry ---
    status         = Column(Enum(NotificationStatus), nullable=False,
                            default=NotificationStatus.PENDING)
    retry_count    = Column(Integer, default=0)
    max_retries    = Column(Integer, default=3)
    last_retry_at  = Column(DateTime, nullable=True)
    failure_reason = Column(String(500), nullable=True)

    # --- Delivery Results ---
    sent_at        = Column(DateTime, nullable=True)
    read_at        = Column(DateTime, nullable=True)
    fcm_message_id = Column(String(200), nullable=True)
    # Firebase message ID for delivery tracking

    # --- Extra Payload ---
    data = Column(Text, nullable=True)
    # JSON: {"screen": "membership", "id": 42}
    # Deep-links member to the right screen when they tap the notification

    # --- Timing ---
    created_at   = Column(DateTime, default=datetime.utcnow)
    scheduled_at = Column(DateTime, nullable=True)
    # Future send time for scheduled notifications (e.g. "1h before class")

    # --- Relationships ---
    user = relationship("User", foreign_keys=[user_id])

    @property
    def is_read(self) -> bool:
        return self.status == NotificationStatus.READ

    @property
    def can_retry(self) -> bool:
        return (
            self.status == NotificationStatus.FAILED
            and self.retry_count < self.max_retries
        )

    def __repr__(self):
        return (
            f"<Notification id={self.id} "
            f"user_id={self.user_id} "
            f"type={self.notification_type} "
            f"status={self.status}>"
        )


class DeviceToken(Base):
    """
    FCM device token for push notifications.
    One user can have multiple tokens (phone + tablet).
    Firebase notifies us when a token becomes stale — we set is_active=False.

    Maps to the 'device_tokens' table.
    """
    __tablename__ = "device_tokens"

    id          = Column(Integer, primary_key=True, index=True)
    user_id     = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    token       = Column(String(512), nullable=False, unique=True)
    # FCM registration token from Firebase SDK on the device

    device_type = Column(String(50), nullable=True)
    # "android", "ios", "web"

    device_name = Column(String(200), nullable=True)
    # e.g. "iPhone 15 Pro", "Samsung Galaxy S24"

    app_version = Column(String(50),  nullable=True)
    is_active   = Column(Boolean, default=True)
    last_used_at  = Column(DateTime, nullable=True)
    registered_at = Column(DateTime, default=datetime.utcnow)
    updated_at    = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", foreign_keys=[user_id])

    def __repr__(self):
        return (
            f"<DeviceToken user_id={self.user_id} "
            f"device={self.device_type} "
            f"active={self.is_active}>"
        )
