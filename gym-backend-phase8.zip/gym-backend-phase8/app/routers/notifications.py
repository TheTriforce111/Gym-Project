"""
routers/notifications.py — Notification API Endpoints (Phase 8)

────────────────────────────────────────────────
DEVICE TOKENS (FCM Registration)
────────────────────────────────────────────────
POST   /api/notifications/device-token      → Register FCM token (Member)
DELETE /api/notifications/device-token/{id} → Remove device token (Member)

────────────────────────────────────────────────
INBOX
────────────────────────────────────────────────
GET    /api/notifications/                  → My notification inbox
GET    /api/notifications/unread-count      → Badge count for app icon
POST   /api/notifications/mark-read        → Mark notifications as read
DELETE /api/notifications/{id}             → Delete a notification

────────────────────────────────────────────────
ADMIN
────────────────────────────────────────────────
POST   /api/notifications/announce          → Broadcast announcement (Admin)
GET    /api/notifications/failed            → List failed notifications (Admin)
POST   /api/notifications/{id}/retry        → Manually retry a failed notification (Admin)
"""

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.models.notification import DeviceToken, Notification, NotificationStatus
from app.models.user import User
from app.schemas.notification import (
    AnnouncementRequest,
    DeviceTokenRegister,
    MarkReadRequest,
    NotificationResponse,
    NotificationSummary,
    UnreadCountResponse,
)
from app.services.notification_service import NotificationService

router = APIRouter()


# ====================================================================
# DEVICE TOKEN MANAGEMENT
# ====================================================================

@router.post(
    "/device-token",
    status_code=201,
    summary="Register an FCM device token for push notifications (Member)",
)
def register_device_token(
    body: DeviceTokenRegister,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Register the device's FCM token so we can send push notifications.

    Call this on app startup and whenever Firebase SDK generates a new token
    (tokens are refreshed periodically by Firebase).

    Flutter integration:
    ```dart
    final token = await FirebaseMessaging.instance.getToken();
    await api.post('/api/notifications/device-token', body: {
      'token': token,
      'device_type': 'android',   // or 'ios'
      'device_name': 'Pixel 8',
      'app_version': '2.1.0',
    });

    // Also refresh when token changes:
    FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
      api.post('/api/notifications/device-token', body: {'token': newToken});
    });
    ```
    """
    # Upsert: if token already exists, update device info
    existing = db.query(DeviceToken).filter(
        DeviceToken.token == body.token
    ).first()

    if existing:
        existing.user_id     = current_user.id
        existing.device_type = body.device_type or existing.device_type
        existing.device_name = body.device_name or existing.device_name
        existing.app_version = body.app_version or existing.app_version
        existing.is_active   = True
        db.commit()
        return {"message": "Device token updated.", "token_id": existing.id}

    token_record = DeviceToken(
        user_id     = current_user.id,
        token       = body.token,
        device_type = body.device_type,
        device_name = body.device_name,
        app_version = body.app_version,
        is_active   = True,
    )
    db.add(token_record)
    db.commit()
    db.refresh(token_record)

    return {
        "message":  "Device token registered. You'll now receive push notifications.",
        "token_id": token_record.id,
    }


@router.delete(
    "/device-token/{token_id}",
    summary="Remove a device token (logout / uninstall)",
)
def remove_device_token(
    token_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Deactivate a device token when the user logs out or uninstalls the app.
    This prevents push notifications from being sent to the old device.
    """
    from fastapi import HTTPException
    token = db.query(DeviceToken).filter(
        DeviceToken.id      == token_id,
        DeviceToken.user_id == current_user.id,
    ).first()

    if not token:
        raise HTTPException(status_code=404, detail="Device token not found.")

    token.is_active = False
    db.commit()
    return {"message": "Device token removed. No further push notifications will be sent."}


# ====================================================================
# INBOX
# ====================================================================

@router.get(
    "/",
    response_model=List[NotificationSummary],
    summary="Get my notification inbox",
)
def get_my_notifications(
    unread_only: bool = Query(False, description="Only return unread notifications"),
    limit:       int  = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the current user's notification history, newest first.
    Use unread_only=true to show only unread notifications in the inbox tab.
    """
    service = NotificationService(db)
    return service.get_user_notifications(
        user_id=current_user.id,
        unread_only=unread_only,
        limit=limit,
    )


@router.get(
    "/unread-count",
    response_model=UnreadCountResponse,
    summary="Get unread notification count (for app badge)",
)
def get_unread_count(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the number of unread notifications.
    The mobile app polls this endpoint to update the red badge on the notifications icon.

    Flutter:
    ```dart
    final count = response['unread_count'];
    // Set badge: FlutterAppBadger.updateBadgeCount(count);
    ```
    """
    service = NotificationService(db)
    return {"unread_count": service.get_unread_count(user_id=current_user.id)}


@router.post(
    "/mark-read",
    summary="Mark notifications as read",
)
def mark_as_read(
    body: MarkReadRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Mark one or more notifications as read.

    If notification_ids is provided → mark only those notifications.
    If notification_ids is null/omitted → mark ALL notifications as read.

    Call this when:
    - User opens the notification inbox (mark all read)
    - User taps a specific notification (mark one read)
    """
    service = NotificationService(db)

    if body.notification_ids:
        # Mark specific notifications
        count = 0
        for nid in body.notification_ids:
            try:
                service.mark_as_read(notification_id=nid, user_id=current_user.id)
                count += 1
            except Exception:
                pass
        return {"marked_read": count}
    else:
        # Mark all as read
        count = service.mark_all_as_read(user_id=current_user.id)
        return {"marked_read": count, "message": "All notifications marked as read."}


@router.delete(
    "/{notification_id}",
    summary="Delete a notification from inbox",
)
def delete_notification(
    notification_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Delete a specific notification from the member's inbox."""
    from fastapi import HTTPException
    notif = db.query(Notification).filter(
        Notification.id      == notification_id,
        Notification.user_id == current_user.id,
    ).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found.")
    db.delete(notif)
    db.commit()
    return {"message": "Notification deleted."}


# ====================================================================
# ADMIN
# ====================================================================

@router.post(
    "/announce",
    summary="Broadcast an announcement to members (Admin)",
)
def send_announcement(
    body: AnnouncementRequest,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Send a push + email announcement to all active members or a specific list.

    Examples:
    - "Gym closed Saturday for maintenance"
    - "New yoga class added! Book now"
    - "Holiday hours next week"

    If user_ids is null → sends to ALL active members with a membership.
    If user_ids is provided → sends only to those members.
    """
    from app.models.membership import Membership, MembershipStatus

    service = NotificationService(db)

    # Resolve target user IDs
    if body.user_ids:
        target_ids = body.user_ids
    else:
        # All active members
        memberships = db.query(Membership).filter(
            Membership.status == MembershipStatus.ACTIVE
        ).all()
        target_ids = [m.user_id for m in memberships]

    notifications = service.send_announcement(
        user_ids=target_ids,
        title=body.title,
        message=body.message,
    )

    return {
        "message":    f"Announcement queued for {len(target_ids)} members.",
        "recipients": len(target_ids),
        "queued":     len(notifications),
    }


@router.get(
    "/failed",
    response_model=List[NotificationResponse],
    summary="List failed notifications (Admin)",
)
def list_failed_notifications(
    limit: int = Query(50, ge=1, le=200),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns all notifications that failed delivery (exhausted retries).
    Use this to investigate delivery issues and manually retry if needed.
    """
    return (
        db.query(Notification)
        .filter(Notification.status == NotificationStatus.FAILED)
        .order_by(Notification.created_at.desc())
        .limit(limit)
        .all()
    )


@router.post(
    "/{notification_id}/retry",
    summary="Manually retry a failed notification (Admin)",
)
def retry_notification(
    notification_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Manually re-queue a failed notification for delivery.
    Resets retry_count to 0 so all retries are available again.
    """
    from fastapi import HTTPException
    from app.workers.notification_tasks import deliver_notification

    notif = db.query(Notification).filter(
        Notification.id == notification_id
    ).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found.")
    if notif.status != NotificationStatus.FAILED:
        raise HTTPException(
            status_code=400,
            detail=f"Can only retry FAILED notifications. Current status: {notif.status}"
        )

    # Reset for retry
    notif.status         = NotificationStatus.PENDING
    notif.retry_count    = 0
    notif.failure_reason = None
    db.commit()

    deliver_notification.delay(notification_id)

    return {
        "message":         f"Notification #{notification_id} re-queued for delivery.",
        "notification_id": notification_id,
    }
