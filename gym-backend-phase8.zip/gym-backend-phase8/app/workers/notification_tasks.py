"""
workers/notification_tasks.py — Celery Notification Delivery Tasks (Phase 8)

These are the actual tasks that run in the background worker process.
When NotificationService.send() is called:
  1. A Notification record is created in DB (status=PENDING)
  2. deliver_notification.delay(notification_id) queues this task in Redis
  3. A Celery worker picks up the task and calls deliver_notification()
  4. deliver_notification() reads the DB record and calls Firebase/SMTP
  5. The DB record is updated with the result (SENT or FAILED)

Retry behavior:
  - If Firebase/SMTP fails → task is retried with exponential backoff
  - Max 3 retries: 1min, 5min, 15min delays between attempts
  - After 3 failures → status=FAILED, failure_reason stored in DB
  - Failed notifications can be re-queued by the retry_failed_notifications task

Exponential backoff:
  Attempt 1: immediate
  Attempt 2: 60 seconds later
  Attempt 3: 300 seconds (5 min) later
  Attempt 4 (final): 900 seconds (15 min) later
"""

import json
import logging
from datetime import datetime

from celery import Task

from app.workers.celery_app import celery_app

logger = logging.getLogger(__name__)

# Maximum number of retry attempts before marking as permanently failed
MAX_RETRIES = 3


class NotificationTask(Task):
    """
    Custom Celery Task base class with database session management.

    Why a custom base class?
    - Celery tasks run in a separate worker process with no shared state
    - We need to create a new SQLAlchemy DB session for each task
    - The _db property creates a session lazily and closes it when done
    """
    _db = None

    @property
    def db(self):
        """Lazily create a DB session for this task."""
        if self._db is None:
            from app.core.database import SessionLocal
            self._db = SessionLocal()
        return self._db

    def after_return(self, status, retval, task_id, args, kwargs, einfo):
        """
        Called after the task finishes (success or failure).
        Closes the DB session to release the connection back to the pool.
        """
        if self._db is not None:
            self._db.close()
            self._db = None


# ---------------------------------------------------------------------------
# MAIN DELIVERY TASK
# ---------------------------------------------------------------------------

@celery_app.task(
    bind=True,
    base=NotificationTask,
    max_retries=MAX_RETRIES,
    default_retry_delay=60,   # Initial retry delay in seconds
    name="app.workers.notification_tasks.deliver_notification",
)
def deliver_notification(self, notification_id: int) -> dict:
    """
    Main task: deliver one notification via push and/or email.

    Called with:
        deliver_notification.delay(notification_id)

    Steps:
    1. Load the notification from DB
    2. Determine which channel(s) to use
    3. Send via Firebase (push) and/or SMTP (email)
    4. Update DB record with result

    Retry on transient failures (network issues, Firebase down).
    Do NOT retry on permanent failures (invalid token, user not found).
    """
    from app.models.notification import Notification, NotificationChannel, NotificationStatus

    # Load the notification record
    notif = self.db.query(Notification).filter(
        Notification.id == notification_id
    ).first()

    if not notif:
        logger.error(f"Notification #{notification_id} not found in DB")
        return {"error": "not_found"}

    # Skip if already sent (idempotency — Celery may retry tasks that already completed)
    if notif.status == NotificationStatus.SENT:
        logger.info(f"Notification #{notification_id} already sent — skipping")
        return {"status": "already_sent"}

    # Update retry tracking
    notif.retry_count   += 1
    notif.last_retry_at  = datetime.utcnow()
    self.db.commit()

    success = True
    error_msg = None

    try:
        # --- Send via Push (Firebase) ---
        if notif.channel in [NotificationChannel.PUSH, NotificationChannel.BOTH]:
            from app.services.push_service import send_push_to_user
            push_result = send_push_to_user(
                db=self.db,
                user_id=notif.user_id,
                title=notif.title,
                body=notif.body,
                data=json.loads(notif.data) if notif.data else {},
                notification_id=notification_id,
            )
            if push_result["success_count"] == 0 and push_result["failure_count"] > 0:
                success = False
                error_msg = "Push delivery failed — no successful device deliveries"

        # --- Send via Email (SMTP) ---
        if notif.channel in [NotificationChannel.EMAIL, NotificationChannel.BOTH]:
            from app.services.email_service import send_notification_email
            # Get user email
            from app.models.user import User
            user = self.db.query(User).filter(User.id == notif.user_id).first()
            if user:
                email_sent = send_notification_email(
                    to_email=user.email,
                    full_name=user.full_name,
                    title=notif.title,
                    body=notif.body,
                )
                if not email_sent:
                    success = False
                    error_msg = "Email delivery failed"

        # --- Update status ---
        if success:
            notif.status  = NotificationStatus.SENT
            notif.sent_at = datetime.utcnow()
            self.db.commit()
            logger.info(f"Notification #{notification_id} sent successfully")
            return {"status": "sent", "notification_id": notification_id}
        else:
            raise Exception(error_msg or "Delivery failed")

    except Exception as exc:
        error_str = str(exc)
        logger.warning(
            f"Notification #{notification_id} delivery failed "
            f"(attempt {notif.retry_count}/{MAX_RETRIES}): {error_str}"
        )

        if notif.retry_count < MAX_RETRIES:
            # Retry with exponential backoff
            # Attempt 1 → 60s, Attempt 2 → 300s, Attempt 3 → 900s
            retry_delay = 60 * (5 ** (notif.retry_count - 1))
            logger.info(
                f"Retrying notification #{notification_id} "
                f"in {retry_delay}s"
            )
            raise self.retry(exc=exc, countdown=retry_delay)
        else:
            # Max retries exhausted — mark as permanently failed
            notif.status         = NotificationStatus.FAILED
            notif.failure_reason = error_str
            self.db.commit()
            logger.error(
                f"Notification #{notification_id} permanently failed "
                f"after {MAX_RETRIES} attempts: {error_str}"
            )
            return {"status": "failed", "error": error_str}
