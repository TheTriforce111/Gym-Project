"""
workers/celery_app.py — Celery Application Setup (Phase 8)

Celery is a distributed task queue.
We use it to run background jobs without blocking the API response.

Why background jobs?
  - Sending emails takes 1-3 seconds — users shouldn't wait for that
  - Push notifications to thousands of users must be done asynchronously
  - Scheduled tasks (e.g. "send expiry warning 7 days before") need a scheduler
  - Failed notifications need automatic retry with exponential backoff

Architecture:
  FastAPI (API server)
      │
      │  .delay() or .apply_async()
      ▼
  Redis (message broker) ← tasks are queued here as JSON messages
      │
      │  worker picks up tasks
      ▼
  Celery Worker (separate process)
      │
      │  executes the task
      ▼
  Firebase / SMTP (external services)

To run the worker:
    celery -A app.workers.celery_app worker --loglevel=info

To run the scheduler (for periodic tasks):
    celery -A app.workers.celery_app beat --loglevel=info

To monitor tasks with Flower (web UI):
    celery -A app.workers.celery_app flower --port=5555
    Open: http://localhost:5555
"""

from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

# ---------------------------------------------------------------------------
# Create the Celery application
# ---------------------------------------------------------------------------
celery_app = Celery(
    "gym_notifications",

    broker=settings.REDIS_URL,
    # Redis is the message broker — tasks are stored here as JSON messages
    # until a worker picks them up

    backend=settings.REDIS_URL,
    # Redis also stores task results (success/failure/return values)
    # so we can check if a task completed and what it returned

    include=[
        # Register task modules so Celery knows where to find task functions
        "app.workers.notification_tasks",
        "app.workers.scheduled_tasks",
    ],
)

# ---------------------------------------------------------------------------
# Celery Configuration
# ---------------------------------------------------------------------------
celery_app.conf.update(
    # Serialization: use JSON so tasks are human-readable in Redis
    task_serializer    = "json",
    result_serializer  = "json",
    accept_content     = ["json"],
    timezone           = "UTC",
    enable_utc         = True,

    # Retry settings for failed tasks
    task_acks_late     = True,
    # acks_late=True: acknowledge the task AFTER it completes (not before)
    # This ensures if the worker crashes mid-task, the task is re-queued

    worker_prefetch_multiplier = 1,
    # Only fetch 1 task at a time per worker thread
    # Prevents one slow task from blocking others

    task_track_started = True,
    # Track when a task moves from PENDING to STARTED

    # Result expiry: keep task results in Redis for 24 hours
    result_expires     = 86400,

    # Rate limiting: max 100 notification tasks per minute
    # Prevents overwhelming Firebase or the email server
    task_annotations   = {
        "app.workers.notification_tasks.send_push_notification": {
            "rate_limit": "100/m"
        },
        "app.workers.notification_tasks.send_email_notification": {
            "rate_limit": "50/m"
        },
    },
)

# ---------------------------------------------------------------------------
# Periodic Task Schedule (Celery Beat)
# ---------------------------------------------------------------------------
# These tasks run automatically on a schedule.
# Start celery beat to enable them:
#   celery -A app.workers.celery_app beat --loglevel=info
# ---------------------------------------------------------------------------
celery_app.conf.beat_schedule = {

    # Check for memberships expiring in 7 days — runs every morning at 9am UTC
    "check-expiring-memberships": {
        "task":     "app.workers.scheduled_tasks.check_expiring_memberships",
        "schedule": crontab(hour=9, minute=0),
        # crontab(hour=9, minute=0) = runs at 09:00 UTC every day
    },

    # Auto-expire overdue memberships — runs every night at midnight
    "auto-expire-memberships": {
        "task":     "app.workers.scheduled_tasks.auto_expire_memberships",
        "schedule": crontab(hour=0, minute=0),
    },

    # Send class reminders 1 hour before each class — runs every 15 minutes
    "send-class-reminders": {
        "task":     "app.workers.scheduled_tasks.send_class_reminders",
        "schedule": crontab(minute="*/15"),
        # "*/15" = every 15 minutes
    },

    # Retry failed notifications — runs every 30 minutes
    "retry-failed-notifications": {
        "task":     "app.workers.scheduled_tasks.retry_failed_notifications",
        "schedule": crontab(minute="*/30"),
    },

    # Weekly attendance summary for members — every Monday at 8am
    "weekly-attendance-summary": {
        "task":     "app.workers.scheduled_tasks.send_weekly_summaries",
        "schedule": crontab(day_of_week=1, hour=8, minute=0),
        # day_of_week=1 = Monday
    },
}
