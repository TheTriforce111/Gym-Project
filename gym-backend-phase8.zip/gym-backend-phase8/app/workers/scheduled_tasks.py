"""
workers/scheduled_tasks.py — Celery Periodic / Scheduled Tasks (Phase 8)

These tasks run automatically on a schedule defined in celery_app.py.
They don't need to be called manually — Celery Beat triggers them.

Tasks:
  check_expiring_memberships   → Daily 9am: warn members expiring in 7 days
  auto_expire_memberships      → Daily midnight: mark overdue as EXPIRED
  send_class_reminders         → Every 15 min: push reminder 1h before class
  retry_failed_notifications   → Every 30 min: retry failed notifications
  send_weekly_summaries        → Monday 8am: attendance recap email

Design notes:
  - Each task creates its own DB session (worker has no shared state)
  - Tasks are idempotent — safe to run multiple times without side effects
  - All DB sessions are closed in the finally block
  - Failures are logged but don't crash the worker
"""

import logging
from datetime import datetime, timedelta

from app.workers.celery_app import celery_app

logger = logging.getLogger(__name__)


@celery_app.task(name="app.workers.scheduled_tasks.check_expiring_memberships")
def check_expiring_memberships():
    """
    Scheduled: Daily at 9:00am UTC

    Finds all ACTIVE memberships expiring in exactly 7 days and sends
    a push + email reminder to each member.

    Why exactly 7 days?
    We also send reminders at 3 days and 1 day (different tasks).
    Checking "exactly N days" prevents sending duplicate reminders.
    We use a 24-hour window (e.g. expires between now+6 and now+7 days).
    """
    from app.core.database import SessionLocal
    from app.models.membership import Membership, MembershipStatus
    from app.services.notification_service import NotificationService

    db = SessionLocal()
    try:
        now = datetime.utcnow()

        # Find memberships expiring in 7 days (±12 hour window to catch timezone shifts)
        warning_days = [7, 3, 1]

        for days in warning_days:
            window_start = now + timedelta(days=days) - timedelta(hours=12)
            window_end   = now + timedelta(days=days) + timedelta(hours=12)

            expiring = db.query(Membership).filter(
                Membership.status   == MembershipStatus.ACTIVE,
                Membership.end_date >= window_start,
                Membership.end_date <= window_end,
            ).all()

            service = NotificationService(db)
            for membership in expiring:
                try:
                    service.notify_membership_expiring(
                        user_id=membership.user_id,
                        days_remaining=days,
                        end_date=membership.end_date.strftime("%B %d, %Y"),
                    )
                    logger.info(
                        f"Expiry reminder sent: user #{membership.user_id}, "
                        f"{days} days remaining"
                    )
                except Exception as e:
                    logger.error(
                        f"Failed to send expiry reminder to "
                        f"user #{membership.user_id}: {e}"
                    )

        return {"checked": True}

    finally:
        db.close()


@celery_app.task(name="app.workers.scheduled_tasks.auto_expire_memberships")
def auto_expire_memberships():
    """
    Scheduled: Daily at midnight UTC

    Marks all ACTIVE memberships whose end_date has passed as EXPIRED.
    Also sends the member an expiry notification.

    This replaces the manual admin action from Phase 3 with automation.
    """
    from app.core.database import SessionLocal
    from app.models.membership import Membership, MembershipStatus, MembershipHistory, MembershipChangeReason
    from app.services.notification_service import NotificationService

    db = SessionLocal()
    try:
        now = datetime.utcnow()

        overdue = db.query(Membership).filter(
            Membership.status   == MembershipStatus.ACTIVE,
            Membership.end_date <  now,
        ).all()

        service = NotificationService(db)
        expired_count = 0

        for membership in overdue:
            # Record the history entry
            history = MembershipHistory(
                membership_id=membership.id,
                previous_status=MembershipStatus.ACTIVE,
                new_status=MembershipStatus.EXPIRED,
                reason=MembershipChangeReason.EXPIRED,
                note="Auto-expired by scheduled task.",
            )
            db.add(history)

            membership.status = MembershipStatus.EXPIRED
            expired_count    += 1

            # Send expiry notification
            try:
                service.notify_membership_expired(user_id=membership.user_id)
            except Exception as e:
                logger.error(f"Failed to notify user #{membership.user_id} of expiry: {e}")

        db.commit()
        logger.info(f"Auto-expired {expired_count} memberships.")
        return {"expired_count": expired_count}

    finally:
        db.close()


@celery_app.task(name="app.workers.scheduled_tasks.send_class_reminders")
def send_class_reminders():
    """
    Scheduled: Every 15 minutes

    Finds all classes starting in 55–65 minutes (10-minute detection window)
    and sends a push reminder to all confirmed bookings.

    Why a window instead of exact time?
    The task runs every 15 minutes. A class at 10:00am might be detected
    at 8:55am check (65 min away) or 9:05am check (55 min away).
    The 10-minute window ensures every class is caught exactly once.
    """
    from app.core.database import SessionLocal
    from app.models.gym_class import GymClass, ClassBooking, ClassStatus, BookingStatus
    from app.services.notification_service import NotificationService

    db = SessionLocal()
    try:
        now          = datetime.utcnow()
        window_start = now + timedelta(minutes=55)
        window_end   = now + timedelta(minutes=65)

        # Find classes starting in the next 55-65 minutes
        upcoming = db.query(GymClass).filter(
            GymClass.status      == ClassStatus.SCHEDULED,
            GymClass.start_time  >= window_start,
            GymClass.start_time  <= window_end,
        ).all()

        service = NotificationService(db)
        reminder_count = 0

        for gym_class in upcoming:
            # Get all confirmed bookings
            bookings = db.query(ClassBooking).filter(
                ClassBooking.gym_class_id == gym_class.id,
                ClassBooking.status       == BookingStatus.CONFIRMED,
            ).all()

            for booking in bookings:
                try:
                    minutes_until = int(
                        (gym_class.start_time - now).total_seconds() / 60
                    )
                    service.send(
                        user_id=booking.user_id,
                        notification_type=__import__(
                            'app.models.notification',
                            fromlist=['NotificationType']
                        ).NotificationType.CLASS_REMINDER,
                        title=f"🔔 Class in {minutes_until} min",
                        body=(
                            f"{gym_class.name} starts in ~{minutes_until} minutes"
                            + (f" in {gym_class.location}" if gym_class.location else "")
                            + ". Time to get ready!"
                        ),
                        channel=__import__(
                            'app.models.notification',
                            fromlist=['NotificationChannel']
                        ).NotificationChannel.PUSH,
                        data={"screen": "classes", "class_id": str(gym_class.id)},
                    )
                    reminder_count += 1
                except Exception as e:
                    logger.error(
                        f"Failed to send class reminder to "
                        f"user #{booking.user_id}: {e}"
                    )

        logger.info(f"Class reminders sent: {reminder_count}")
        return {"reminder_count": reminder_count}

    finally:
        db.close()


@celery_app.task(name="app.workers.scheduled_tasks.retry_failed_notifications")
def retry_failed_notifications():
    """
    Scheduled: Every 30 minutes

    Finds notifications that failed delivery and retries them
    if they haven't exceeded max_retries.

    This handles transient failures like:
    - Firebase temporarily down
    - SMTP server timeout
    - Network blip
    """
    from app.core.database import SessionLocal
    from app.models.notification import Notification, NotificationStatus
    from app.workers.notification_tasks import deliver_notification

    db = SessionLocal()
    try:
        # Find failed notifications that can still be retried
        retryable = db.query(Notification).filter(
            Notification.status      == NotificationStatus.FAILED,
            Notification.retry_count <  Notification.max_retries,
        ).all()

        retry_count = 0
        for notif in retryable:
            try:
                # Reset status to pending so deliver_notification can process it
                notif.status = NotificationStatus.PENDING
                db.commit()

                deliver_notification.delay(notif.id)
                retry_count += 1
            except Exception as e:
                logger.error(f"Failed to re-queue notification #{notif.id}: {e}")

        logger.info(f"Re-queued {retry_count} failed notifications for retry.")
        return {"retried": retry_count}

    finally:
        db.close()


@celery_app.task(name="app.workers.scheduled_tasks.send_weekly_summaries")
def send_weekly_summaries():
    """
    Scheduled: Every Monday at 8:00am UTC

    Sends each active member a weekly attendance summary email.
    Includes visits this week, current streak, and a motivational message.
    """
    from app.core.database import SessionLocal
    from app.models.user import User, UserRole
    from app.models.membership import Membership, MembershipStatus
    from app.models.attendance import Attendance
    from app.services.email_service import send_weekly_summary_email

    db = SessionLocal()
    try:
        now        = datetime.utcnow()
        week_start = now - timedelta(days=7)

        # Get all active members
        active_memberships = db.query(Membership).filter(
            Membership.status == MembershipStatus.ACTIVE
        ).all()

        sent_count = 0
        for membership in active_memberships:
            user = db.query(User).filter(User.id == membership.user_id).first()
            if not user:
                continue

            # Count visits this week
            visits = db.query(Attendance).filter(
                Attendance.user_id       == user.id,
                Attendance.check_in_time >= week_start,
            ).count()

            try:
                send_weekly_summary_email(
                    to_email=user.email,
                    full_name=user.full_name,
                    visits_this_week=visits,
                    membership_expiry=membership.end_date.strftime("%B %d, %Y"),
                )
                sent_count += 1
            except Exception as e:
                logger.error(f"Failed to send weekly summary to {user.email}: {e}")

        logger.info(f"Weekly summaries sent to {sent_count} members.")
        return {"sent_count": sent_count}

    finally:
        db.close()
