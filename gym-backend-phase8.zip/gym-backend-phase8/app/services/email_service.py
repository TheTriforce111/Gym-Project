"""
services/email_service.py — Email Notification Service (Phase 8)

Sends styled HTML emails for all notification types.
Uses Python's built-in smtplib for SMTP delivery.

For production, consider switching to:
  - SendGrid (better deliverability, analytics)
  - Mailgun (similar features, good API)
  - AWS SES (cheapest at scale)

All email functions return bool (True=sent, False=failed).
Failures are logged but never crash the caller.

Templates use inline CSS for maximum email client compatibility.
(Many email clients strip <style> blocks, so we inline everything.)
"""

import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Base SMTP sender
# ---------------------------------------------------------------------------

def _send_email(to_email: str, subject: str, html_body: str) -> bool:
    """
    Send an HTML email via SMTP.
    Returns True on success, False on any failure.
    Errors are logged but not raised (non-critical operation).
    """
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = f"Gym Management <{settings.SMTP_USERNAME}>"
        msg["To"]      = to_email
        msg.attach(MIMEText(html_body, "html", "utf-8"))

        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=10) as server:
            server.ehlo()
            server.starttls()
            server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
            server.sendmail(settings.SMTP_USERNAME, to_email, msg.as_string())

        logger.info(f"Email sent → {to_email} | Subject: {subject}")
        return True

    except smtplib.SMTPAuthenticationError:
        logger.error("SMTP authentication failed — check SMTP_USERNAME and SMTP_PASSWORD in .env")
        return False
    except smtplib.SMTPException as e:
        logger.error(f"SMTP error sending to {to_email}: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error sending email to {to_email}: {e}")
        return False


# ---------------------------------------------------------------------------
# Shared email wrapper (used by Celery task for generic notifications)
# ---------------------------------------------------------------------------

def send_notification_email(
    to_email: str,
    full_name: str,
    title: str,
    body: str,
) -> bool:
    """
    Generic notification email — wraps any title/body in the standard template.
    Called by the Celery deliver_notification task.
    """
    html = _base_template(
        title=title,
        full_name=full_name,
        content=f"<p style='font-size:16px; color:#333; line-height:1.6;'>{body}</p>",
    )
    return _send_email(to_email, title, html)


# ---------------------------------------------------------------------------
# Specific email templates
# ---------------------------------------------------------------------------

def send_otp_email(to_email: str, otp: str, full_name: str = "Member") -> bool:
    """Password reset OTP email."""
    html = _base_template(
        title="🔐 Password Reset Code",
        full_name=full_name,
        content=f"""
            <p style="color:#555;">We received a request to reset your password.</p>
            <p style="color:#555;">Your one-time code is:</p>
            <div style="text-align:center; margin:30px 0;">
              <span style="font-size:42px; font-weight:bold; letter-spacing:12px;
                           color:#e94560; background:#fff5f7; padding:18px 28px;
                           border-radius:10px; border:2px dashed #e94560;">
                {otp}
              </span>
            </div>
            <p style="color:#888; font-size:13px;">⏰ Expires in <strong>10 minutes</strong>.</p>
            <p style="color:#888; font-size:13px;">🔒 Never share this code with anyone.</p>
        """,
    )
    return _send_email(to_email, "Your Password Reset Code", html)


def send_welcome_email(to_email: str, full_name: str) -> bool:
    """Welcome email sent after registration."""
    html = _base_template(
        title=f"Welcome, {full_name.split()[0]}! 💪",
        full_name=full_name,
        content="""
            <p style="color:#555;">Your account is ready. Here's what you can do:</p>
            <ul style="color:#555; line-height:2;">
              <li>📅 <strong>Book classes</strong> — Yoga, HIIT, Pilates and more</li>
              <li>🏋️ <strong>Track workouts</strong> — Log sets, reps, and weights</li>
              <li>📱 <strong>Check in with your QR code</strong> — No card needed</li>
              <li>📊 <strong>See your progress</strong> — Charts and personal bests</li>
            </ul>
            <p style="color:#555;">Visit reception to activate your membership and get started.</p>
            <div style="text-align:center; margin:30px 0;">
              <span style="background:#e94560; color:white; padding:14px 32px;
                           border-radius:8px; font-weight:bold; font-size:16px;">
                Let's Get Moving! 🚀
              </span>
            </div>
        """,
    )
    return _send_email(to_email, f"Welcome to the Gym, {full_name.split()[0]}!", html)


def send_membership_confirmation_email(
    to_email: str,
    full_name: str,
    plan: str,
    end_date: str,
    amount: float,
) -> bool:
    """Membership created/renewed confirmation."""
    html = _base_template(
        title="✅ Membership Confirmed",
        full_name=full_name,
        content=f"""
            <p style="color:#555;">Your membership is now active!</p>
            <table style="width:100%; border-collapse:collapse; margin:20px 0;">
              {_table_row("Plan", plan.title(), stripe=True)}
              {_table_row("Expires", end_date)}
              {_table_row("Amount Paid", f"${amount:.2f}", stripe=True)}
            </table>
            <p style="color:#555;">Thank you for being a valued member. Keep crushing your goals! 💪</p>
        """,
    )
    return _send_email(to_email, "✅ Membership Confirmed", html)


def send_payment_receipt_email(
    to_email: str,
    full_name: str,
    amount: float,
    plan: str,
    payment_date: str,
    stripe_payment_id: Optional[str] = None,
) -> bool:
    """Payment receipt email."""
    ref = f"<tr><td style='padding:10px; color:#888; font-size:12px;'>Reference</td><td style='padding:10px; color:#888; font-size:12px;'>{stripe_payment_id}</td></tr>" if stripe_payment_id else ""
    html = _base_template(
        title="💳 Payment Receipt",
        full_name=full_name,
        content=f"""
            <p style="color:#555;">Payment received successfully.</p>
            <table style="width:100%; border-collapse:collapse; margin:20px 0;">
              {_table_row("Date", payment_date, stripe=True)}
              {_table_row("Plan", plan.title())}
              {_table_row("Amount", f"${amount:.2f}", stripe=True)}
              {ref}
            </table>
            <p style="color:#888; font-size:12px;">Keep this email as your payment record.</p>
        """,
    )
    return _send_email(to_email, "💳 Payment Receipt", html)


def send_class_cancellation_email(
    to_email: str,
    full_name: str,
    class_name: str,
    class_time: str,
    reason: Optional[str] = None,
) -> bool:
    """Email sent when a class the member booked is cancelled."""
    reason_block = f"<p style='color:#555;'><strong>Reason:</strong> {reason}</p>" if reason else ""
    html = _base_template(
        title="⚠️ Class Cancelled",
        full_name=full_name,
        content=f"""
            <p style="color:#555;">We're sorry to let you know that the following class has been cancelled:</p>
            <div style="background:#fff5f7; border-left:4px solid #e94560;
                        padding:16px; margin:20px 0; border-radius:4px;">
              <strong style="font-size:18px;">{class_name}</strong><br>
              <span style="color:#888;">{class_time}</span>
            </div>
            {reason_block}
            <p style="color:#555;">Your booking has been automatically cancelled.
            Please browse our schedule to book an alternative class.</p>
        """,
    )
    return _send_email(to_email, f"⚠️ Class Cancelled: {class_name}", html)


def send_weekly_summary_email(
    to_email: str,
    full_name: str,
    visits_this_week: int,
    membership_expiry: str,
) -> bool:
    """Weekly attendance recap sent every Monday."""
    if visits_this_week == 0:
        motivation = "No visits this week — this is your week to get started! 💪"
        color = "#888"
    elif visits_this_week < 3:
        motivation = f"Good effort with {visits_this_week} visit{'s' if visits_this_week > 1 else ''}! Keep building that habit."
        color = "#f0a500"
    else:
        motivation = f"Amazing week! {visits_this_week} visits — you're crushing it! 🏆"
        color = "#27ae60"

    html = _base_template(
        title="📊 Your Weekly Gym Summary",
        full_name=full_name,
        content=f"""
            <p style="color:#555;">Here's your weekly recap:</p>
            <div style="text-align:center; margin:30px 0;">
              <div style="font-size:64px; font-weight:bold; color:{color};">{visits_this_week}</div>
              <div style="color:#888; font-size:18px;">visits this week</div>
            </div>
            <p style="color:#555; text-align:center; font-size:16px;">{motivation}</p>
            <hr style="border:none; border-top:1px solid #eee; margin:20px 0;">
            <p style="color:#888; font-size:13px; text-align:center;">
              Membership expires: <strong>{membership_expiry}</strong>
            </p>
        """,
    )
    return _send_email(to_email, "📊 Your Weekly Gym Summary", html)


# ---------------------------------------------------------------------------
# HTML Template Helpers
# ---------------------------------------------------------------------------

def _base_template(title: str, full_name: str, content: str) -> str:
    """
    Base HTML email template.
    All emails share this structure for brand consistency.
    Uses inline CSS for compatibility with all email clients.
    """
    first_name = full_name.split()[0] if full_name else "there"
    return f"""
    <!DOCTYPE html>
    <html>
    <body style="margin:0; padding:0; background:#f4f4f4; font-family: Arial, sans-serif;">
      <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4; padding:30px 0;">
        <tr>
          <td align="center">
            <table width="560" cellpadding="0" cellspacing="0"
                   style="background:white; border-radius:12px;
                          box-shadow:0 2px 12px rgba(0,0,0,0.1); overflow:hidden;">

              <!-- Header -->
              <tr>
                <td style="background:#1a1a2e; padding:24px 32px;">
                  <h1 style="margin:0; color:white; font-size:20px;">🏋️ Gym Management</h1>
                </td>
              </tr>

              <!-- Body -->
              <tr>
                <td style="padding:32px;">
                  <h2 style="color:#1a1a2e; margin-top:0;">{title}</h2>
                  <p style="color:#555;">Hi <strong>{first_name}</strong>,</p>
                  {content}
                </td>
              </tr>

              <!-- Footer -->
              <tr>
                <td style="background:#f8f8f8; padding:16px 32px;
                           border-top:1px solid #eee;">
                  <p style="margin:0; color:#aaa; font-size:12px; text-align:center;">
                    Gym Management System · This is an automated message, please do not reply.<br>
                    To unsubscribe from marketing emails, contact reception.
                  </p>
                </td>
              </tr>

            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>
    """


def _table_row(label: str, value: str, stripe: bool = False) -> str:
    """Helper to build a styled table row for email receipts."""
    bg = "background:#f8f8f8;" if stripe else ""
    return f"""
      <tr style="{bg}">
        <td style="padding:12px 16px; color:#888; font-size:14px;">{label}</td>
        <td style="padding:12px 16px; color:#333; font-weight:bold;">{value}</td>
      </tr>
    """
