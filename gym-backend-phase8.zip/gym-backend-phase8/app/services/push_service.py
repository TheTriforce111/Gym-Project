"""
services/push_service.py — Firebase Cloud Messaging (FCM) Push Notifications

This service sends push notifications to mobile devices using Firebase.

Setup required:
  1. Create a Firebase project at https://console.firebase.google.com
  2. Go to Project Settings → Service Accounts → Generate New Private Key
  3. Download the JSON file and save as 'firebase-credentials.json'
  4. Set FIREBASE_CREDENTIALS_PATH=firebase-credentials.json in .env

How FCM works:
  1. Mobile app starts → Firebase SDK gives it a unique registration token
  2. App sends token to our backend → we store it in DeviceToken table
  3. When we want to notify user → we send token + message to Firebase
  4. Firebase delivers the notification to the device
  5. Firebase tells us if delivery succeeded or if the token is stale

Token management:
  - Tokens expire when the app is uninstalled or not used for 270 days
  - Firebase returns specific error codes for stale tokens
  - We automatically deactivate stale tokens in our DB
"""

import json
import logging
from typing import List, Optional

from sqlalchemy.orm import Session

from app.models.notification import DeviceToken, Notification, NotificationStatus

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Firebase Admin SDK Initialization
# We initialize lazily (on first use) so the app starts even if Firebase
# credentials are not yet configured (e.g. during development).
# ---------------------------------------------------------------------------
_firebase_initialized = False


def _init_firebase():
    """
    Initialize Firebase Admin SDK.
    Called once before the first push notification is sent.
    """
    global _firebase_initialized
    if _firebase_initialized:
        return True

    try:
        import firebase_admin
        from firebase_admin import credentials
        from app.core.config import settings

        cred = credentials.Certificate(settings.FIREBASE_CREDENTIALS_PATH)
        firebase_admin.initialize_app(cred)
        _firebase_initialized = True
        logger.info("Firebase Admin SDK initialized successfully.")
        return True

    except FileNotFoundError:
        logger.warning(
            "Firebase credentials file not found. "
            "Push notifications will be simulated in development mode."
        )
        return False
    except Exception as e:
        logger.error(f"Firebase initialization failed: {e}")
        return False


# ---------------------------------------------------------------------------
# Send Push to One User (all their devices)
# ---------------------------------------------------------------------------

def send_push_to_user(
    db: Session,
    user_id: int,
    title: str,
    body: str,
    data: Optional[dict] = None,
    notification_id: Optional[int] = None,
) -> dict:
    """
    Send a push notification to all active devices belonging to a user.

    Why send to ALL devices?
    - A user might have the app on phone + tablet
    - We want them to see the notification on whichever device they pick up

    Returns:
        {
            "success_count": int,   # How many devices received it
            "failure_count": int,   # How many failed
            "stale_tokens":  list,  # Token IDs that were deactivated
        }

    Firebase Error Codes we handle:
        UNREGISTERED:     App uninstalled or token expired → deactivate token
        INVALID_ARGUMENT: Malformed token → deactivate token
        QUOTA_EXCEEDED:   Firebase rate limit → retry later
        INTERNAL:         Firebase server error → retry later
    """
    # Get all active FCM tokens for this user
    tokens = db.query(DeviceToken).filter(
        DeviceToken.user_id   == user_id,
        DeviceToken.is_active == True,
    ).all()

    if not tokens:
        logger.info(f"No active device tokens for user #{user_id}")
        return {"success_count": 0, "failure_count": 0, "stale_tokens": []}

    firebase_ready = _init_firebase()

    success_count = 0
    failure_count = 0
    stale_token_ids = []

    for device_token in tokens:
        result = _send_to_token(
            token=device_token.token,
            title=title,
            body=body,
            data=data or {},
            firebase_ready=firebase_ready,
        )

        if result["success"]:
            success_count += 1
            device_token.last_used_at = __import__('datetime').datetime.utcnow()

            # Update notification record with Firebase message ID
            if notification_id and result.get("message_id"):
                notif = db.query(Notification).filter(
                    Notification.id == notification_id
                ).first()
                if notif:
                    notif.fcm_message_id = result["message_id"]

        else:
            failure_count += 1
            error_code = result.get("error_code", "")

            # Deactivate stale tokens — Firebase told us this device is gone
            if error_code in ["UNREGISTERED", "INVALID_ARGUMENT"]:
                device_token.is_active = False
                stale_token_ids.append(device_token.id)
                logger.info(
                    f"Deactivated stale FCM token for user #{user_id}: "
                    f"{error_code}"
                )

    db.commit()

    logger.info(
        f"Push to user #{user_id}: "
        f"{success_count} success, {failure_count} failed, "
        f"{len(stale_token_ids)} tokens deactivated"
    )

    return {
        "success_count": success_count,
        "failure_count": failure_count,
        "stale_tokens":  stale_token_ids,
    }


def _send_to_token(
    token: str,
    title: str,
    body: str,
    data: dict,
    firebase_ready: bool,
) -> dict:
    """
    Send a push notification to a single FCM token.
    Returns {"success": bool, "message_id": str, "error_code": str}
    """
    if not firebase_ready:
        # Development mode — simulate a successful send
        logger.debug(f"[DEV] Push simulated to token: {token[:20]}...")
        return {"success": True, "message_id": "dev_message_id"}

    try:
        from firebase_admin import messaging

        # Build the FCM message
        message = messaging.Message(
            notification=messaging.Notification(
                title=title,
                body=body,
            ),
            data={str(k): str(v) for k, v in data.items()},
            # FCM data payload must be string: string dict
            # The mobile app reads this to deep-link to the right screen

            token=token,

            # Android-specific settings
            android=messaging.AndroidConfig(
                priority="high",
                # HIGH priority wakes the device screen immediately
                # (vs NORMAL which delivers silently when convenient)
                notification=messaging.AndroidNotification(
                    sound="default",
                    click_action="FLUTTER_NOTIFICATION_CLICK",
                    # Flutter apps need this action to handle taps
                ),
            ),

            # iOS-specific settings
            apns=messaging.APNSConfig(
                payload=messaging.APNSPayload(
                    aps=messaging.Aps(
                        sound="default",
                        badge=1,
                        # Increment the app badge count by 1
                    )
                )
            ),
        )

        # Send to Firebase
        message_id = messaging.send(message)
        return {"success": True, "message_id": message_id}

    except Exception as e:
        error_str = str(e)
        # Parse Firebase error code from exception message
        error_code = "UNKNOWN"
        for code in ["UNREGISTERED", "INVALID_ARGUMENT", "QUOTA_EXCEEDED", "INTERNAL"]:
            if code in error_str.upper():
                error_code = code
                break

        logger.error(f"FCM send failed: {error_str}")
        return {"success": False, "error_code": error_code, "error": error_str}


# ---------------------------------------------------------------------------
# Batch Push (send to multiple users at once)
# ---------------------------------------------------------------------------

def send_push_to_users(
    db: Session,
    user_ids: List[int],
    title: str,
    body: str,
    data: Optional[dict] = None,
) -> dict:
    """
    Send the same push notification to multiple users.
    Used for announcements and bulk notifications.

    Returns aggregate success/failure counts.
    """
    total_success = 0
    total_failure = 0

    for user_id in user_ids:
        result = send_push_to_user(
            db=db,
            user_id=user_id,
            title=title,
            body=body,
            data=data,
        )
        total_success += result["success_count"]
        total_failure += result["failure_count"]

    return {
        "users_notified": len(user_ids),
        "total_success":  total_success,
        "total_failure":  total_failure,
    }
