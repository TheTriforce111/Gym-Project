"""
services/notification_service.py — Notification Business Logic (Phase 8)

This service is the single entry point for ALL notifications in the system.
Every other service (membership, payments, classes, attendance) calls this
service to trigger notifications — they never send directly.

Architecture:
  ┌─────────────────────────────────────────────────────────────┐
  │  MembershipService  ──────────────────────────┐            │
  │  PaymentService     ─────────────────────────┐│            │
  │  ClassService       ────────────────────────┐││            │
  │  AttendanceService  ───────────────────────┐│││            │
  │                                            ▼▼▼▼            │
  │                              NotificationService           │
  │                                      │                     │
  │              ┌───────────────────────┼──────────────────┐  │
  │              ▼                       ▼                  ▼  │
  │         PushService            EmailService        DB log  │
  │         (Firebase)             (SMTP)                      │
  └─────────────────────────────────────────────────────────────┘

Design principles:
  1. Non-blocking: notifications are always queued to Celery, never sent inline
  2. Fault-tolerant: if Firebase/SMTP is down, jobs stay in queue and retry
  3. Templated: each notification type has a dedicated template function
  4. Logged: every notification is stored in the DB for history and retry
"""

import json
import logging
from datetime import datetime
from typing import List, Optional

from sqlalchemy.orm import Session

from app.models.notification import (
    DeviceToken,
    Notification,
    NotificationChannel,
    NotificationStatus,
    NotificationType,
)
from app.models.user import User

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Notification Templates
# Each function returns (title, body, data) for a specific event type.
# Keeping templates here makes it easy to update copy in one place.
# ---------------------------------------------------------------------------

def _membership_created_template(plan: str, end_date: str) -> tuple:
    return (
        "🎉 Welcome to the Gym!",
        f"Your {plan} membership is now active until {end_date}. Let's get moving!",
        {"screen": "membership"},
    )


def _membership_expiring_template(days: int, end_date: str) -> tuple:
    return (
        "⏰ Membership Expiring Soon",
        f"Your membership expires in {days} day{'s' if days > 1 else ''} ({end_date}). Renew now to keep your streak!",
        {"screen": "membership", "action": "renew"},
    )


def _membership_expired_template() -> tuple:
    return (
        "❌ Membership Expired",
        "Your gym membership has expired. Renew at reception or in the app to regain access.",
        {"screen": "membership", "action": "renew"},
    )


def _membership_frozen_template(reason: Optional[str]) -> tuple:
    note = f" Reason: {reason}" if reason else ""
    return (
        "❄️ Membership Frozen",
        f"Your membership has been temporarily frozen.{note} Contact reception for details.",
        {"screen": "membership"},
    )


def _membership_unfrozen_template(new_expiry: str) -> tuple:
    return (
        "✅ Membership Reactivated",
        f"Your membership is active again! New expiry date: {new_expiry}. See you at the gym!",
        {"screen": "membership"},
    )


def _payment_success_template(amount: float, plan: str) -> tuple:
    return (
        "✅ Payment Successful",
        f"Payment of ${amount:.2f} received for your {plan} membership. Thank you!",
        {"screen": "payments"},
    )


def _payment_failed_template(reason: Optional[str]) -> tuple:
    msg = f" Reason: {reason}" if reason else ""
    return (
        "❌ Payment Failed",
        f"Your payment could not be processed.{msg} Please update your payment method.",
        {"screen": "payments", "action": "retry"},
    )


def _payment_refunded_template(amount: float) -> tuple:
    return (
        "💰 Refund Processed",
        f"A refund of ${amount:.2f} has been processed. It may take 5-10 business days to appear.",
        {"screen": "payments"},
    )


def _class_booking_confirmed_template(class_name: str, start_time: str) -> tuple:
    return (
        "✅ Class Booked!",
        f"You're confirmed for {class_name} on {start_time}. See you there! 💪",
        {"screen": "classes"},
    )


def _class_booking_cancelled_template(class_name: str) -> tuple:
    return (
        "Booking Cancelled",
        f"Your booking for {class_name} has been cancelled.",
        {"screen": "classes"},
    )


def _class_cancelled_template(class_name: str, reason: Optional[str]) -> tuple:
    note = f" Reason: {reason}" if reason else ""
    return (
        "⚠️ Class Cancelled",
        f"{class_name} has been cancelled.{note} We apologize for the inconvenience.",
        {"screen": "classes"},
    )


def _class_reminder_template(class_name: str, minutes: int, location: Optional[str]) -> tuple:
    loc = f" in {location}" if location else ""
    return (
        f"🔔 Class Starting in {minutes} min",
        f"{class_name} starts in {minutes} minutes{loc}. Time to get ready!",
        {"screen": "classes"},
    )


def _waitlist_promoted_template(class_name: str, start_time: str) -> tuple:
    return (
        "🎉 You Got In!",
        f"A spot opened up in {class_name} on {start_time}. Your booking is confirmed!",
        {"screen": "classes"},
    )


def _check_in_template(member_name: str, visits_this_month: int) -> tuple:
    return (
        f"Welcome, {member_name.split()[0]}! 👋",
        f"Check-in successful! You've visited {visits_this_month} time{'s' if visits_this_month > 1 else ''} this month.",
        {"screen": "attendance"},
    )


def _attendance_milestone_template(visits: int) -> tuple:
    emojis = {10: "🥉", 25: "🥈", 50: "🥇", 100: "🏆"}
    emoji = emojis.get(visits, "🎯")
    return (
        f"{emoji} {visits} Visits Milestone!",
        f"Amazing! You've visited the gym {visits} times. Keep up the great work!",
        {"screen": "attendance"},
    )


def _workout_plan_assigned_template(plan_name: str, trainer_name: str) -> tuple:
    return (
        "💪 New Workout Plan!",
        f"{trainer_name} has assigned you a new plan: '{plan_name}'. Check it out!",
        {"screen": "workouts"},
    )


def _personal_best_template(exercise: str, weight: float, reps: int) -> tuple:
    return (
        "🏆 Personal Best!",
        f"You just set a new personal best on {exercise}: {weight}kg × {reps} reps. Incredible!",
        {"screen": "workouts"},
    )


def _welcome_template(name: str) -> tuple:
    return (
        f"Welcome, {name}! 🎉",
        "Your gym account is ready. Visit reception to activate your membership and get started!",
        {"screen": "home"},
    )


def _announcement_template(title: str, message: str) -> tuple:
    return (title, message, {"screen": "announcements"})


# ---------------------------------------------------------------------------
# NotificationService — the main dispatcher
# ---------------------------------------------------------------------------

class NotificationService:
    """
    Central notification dispatcher.
    Every service in the system calls methods here to send notifications.
    """

    def __init__(self, db: Session):
        self.db = db

    # ===================================================================
    # CORE DISPATCH METHOD
    # ===================================================================

    def send(
        self,
        user_id: int,
        notification_type: NotificationType,
        title: str,
        body: str,
        channel: NotificationChannel = NotificationChannel.BOTH,
        data: Optional[dict] = None,
        scheduled_at: Optional[datetime] = None,
    ) -> Notification:
        """
        Create a notification record and queue it for delivery.

        This is the ONLY method that saves to DB and dispatches.
        All other methods are convenience wrappers that call this.

        Args:
            user_id:           Recipient user
            notification_type: What kind of event triggered this
            title:             Short notification title
            body:              Full notification body text
            channel:           PUSH, EMAIL, or BOTH
            data:              Optional dict for deep-linking in the mobile app
            scheduled_at:      If set, send at this future time (Celery scheduled)

        Flow:
          1. Save notification to DB (status=PENDING)
          2. If scheduled_at → queue with eta in Celery
          3. If immediate → queue now with .delay()
          4. Celery worker picks up the task and sends via Firebase/SMTP
        """
        # Save to DB first so we have a record even if the queue fails
        notification = Notification(
            user_id=user_id,
            notification_type=notification_type,
            title=title,
            body=body,
            channel=channel,
            status=NotificationStatus.PENDING,
            data=json.dumps(data) if data else None,
            scheduled_at=scheduled_at,
        )
        self.db.add(notification)
        self.db.commit()
        self.db.refresh(notification)

        # Queue the actual delivery to Celery
        # Import here to avoid circular imports
        from app.workers.notification_tasks import deliver_notification

        if scheduled_at and scheduled_at > datetime.utcnow():
            # Scheduled delivery: Celery will execute at the specified time
            deliver_notification.apply_async(
                args=[notification.id],
                eta=scheduled_at,
            )
        else:
            # Immediate delivery: Celery picks up as soon as a worker is free
            deliver_notification.delay(notification.id)

        logger.info(
            f"Notification queued: type={notification_type} "
            f"user_id={user_id} "
            f"channel={channel} "
            f"id={notification.id}"
        )
        return notification

    # ===================================================================
    # MEMBERSHIP NOTIFICATIONS
    # ===================================================================

    def notify_membership_created(
        self, user_id: int, plan: str, end_date: str
    ) -> Notification:
        title, body, data = _membership_created_template(plan, end_date)
        return self.send(user_id, NotificationType.MEMBERSHIP_CREATED,
                         title, body, data=data)

    def notify_membership_expiring(
        self, user_id: int, days_remaining: int, end_date: str
    ) -> Notification:
        title, body, data = _membership_expiring_template(days_remaining, end_date)
        return self.send(user_id, NotificationType.MEMBERSHIP_EXPIRING,
                         title, body, data=data)

    def notify_membership_expired(self, user_id: int) -> Notification:
        title, body, data = _membership_expired_template()
        return self.send(user_id, NotificationType.MEMBERSHIP_EXPIRED,
                         title, body, data=data)

    def notify_membership_frozen(
        self, user_id: int, reason: Optional[str] = None
    ) -> Notification:
        title, body, data = _membership_frozen_template(reason)
        return self.send(user_id, NotificationType.MEMBERSHIP_FROZEN,
                         title, body, data=data)

    def notify_membership_unfrozen(
        self, user_id: int, new_expiry: str
    ) -> Notification:
        title, body, data = _membership_unfrozen_template(new_expiry)
        return self.send(user_id, NotificationType.MEMBERSHIP_UNFROZEN,
                         title, body, data=data)

    # ===================================================================
    # PAYMENT NOTIFICATIONS
    # ===================================================================

    def notify_payment_success(
        self, user_id: int, amount: float, plan: str
    ) -> Notification:
        title, body, data = _payment_success_template(amount, plan)
        return self.send(user_id, NotificationType.PAYMENT_SUCCESS,
                         title, body, channel=NotificationChannel.BOTH, data=data)

    def notify_payment_failed(
        self, user_id: int, reason: Optional[str] = None
    ) -> Notification:
        title, body, data = _payment_failed_template(reason)
        return self.send(user_id, NotificationType.PAYMENT_FAILED,
                         title, body, channel=NotificationChannel.BOTH, data=data)

    def notify_payment_refunded(
        self, user_id: int, amount: float
    ) -> Notification:
        title, body, data = _payment_refunded_template(amount)
        return self.send(user_id, NotificationType.PAYMENT_REFUNDED,
                         title, body, channel=NotificationChannel.BOTH, data=data)

    # ===================================================================
    # CLASS NOTIFICATIONS
    # ===================================================================

    def notify_class_booking_confirmed(
        self, user_id: int, class_name: str, start_time: str,
        remind_before_minutes: int = 60
    ) -> List[Notification]:
        """Send booking confirmation AND schedule a reminder 1h before class."""
        # Immediate confirmation
        title, body, data = _class_booking_confirmed_template(class_name, start_time)
        confirmation = self.send(
            user_id, NotificationType.CLASS_BOOKING_CONFIRMED,
            title, body, data=data
        )

        # Schedule a reminder (only if class is in the future)
        try:
            from datetime import timedelta
            class_dt = datetime.fromisoformat(start_time)
            remind_at = class_dt - timedelta(minutes=remind_before_minutes)

            if remind_at > datetime.utcnow():
                r_title, r_body, r_data = _class_reminder_template(
                    class_name, remind_before_minutes, None
                )
                reminder = self.send(
                    user_id, NotificationType.CLASS_REMINDER,
                    r_title, r_body,
                    channel=NotificationChannel.PUSH,
                    data=r_data,
                    scheduled_at=remind_at,
                )
                return [confirmation, reminder]
        except (ValueError, TypeError):
            pass

        return [confirmation]

    def notify_class_cancelled(
        self, user_ids: List[int], class_name: str,
        reason: Optional[str] = None
    ) -> List[Notification]:
        """Notify all booked members when a class is cancelled."""
        title, body, data = _class_cancelled_template(class_name, reason)
        return [
            self.send(uid, NotificationType.CLASS_CANCELLED,
                      title, body, channel=NotificationChannel.BOTH, data=data)
            for uid in user_ids
        ]

    def notify_waitlist_promoted(
        self, user_id: int, class_name: str, start_time: str
    ) -> Notification:
        title, body, data = _waitlist_promoted_template(class_name, start_time)
        return self.send(user_id, NotificationType.CLASS_WAITLIST_PROMOTED,
                         title, body, channel=NotificationChannel.BOTH, data=data)

    # ===================================================================
    # ATTENDANCE NOTIFICATIONS
    # ===================================================================

    def notify_check_in(
        self, user_id: int, member_name: str, visits_this_month: int
    ) -> Notification:
        title, body, data = _check_in_template(member_name, visits_this_month)
        # Check-in notifications are push-only (immediate, no email needed)
        return self.send(user_id, NotificationType.CHECKIN_SUCCESS,
                         title, body, channel=NotificationChannel.PUSH, data=data)

    def notify_attendance_milestone(
        self, user_id: int, total_visits: int
    ) -> Optional[Notification]:
        """Send milestone notification at 10, 25, 50, 100 visits."""
        milestones = {10, 25, 50, 100, 200, 365}
        if total_visits not in milestones:
            return None
        title, body, data = _attendance_milestone_template(total_visits)
        return self.send(user_id, NotificationType.ATTENDANCE_MILESTONE,
                         title, body, channel=NotificationChannel.BOTH, data=data)

    # ===================================================================
    # WORKOUT NOTIFICATIONS
    # ===================================================================

    def notify_workout_plan_assigned(
        self, user_id: int, plan_name: str, trainer_name: str
    ) -> Notification:
        title, body, data = _workout_plan_assigned_template(plan_name, trainer_name)
        return self.send(user_id, NotificationType.WORKOUT_PLAN_ASSIGNED,
                         title, body, channel=NotificationChannel.PUSH, data=data)

    def notify_personal_best(
        self, user_id: int, exercise: str,
        weight: float, reps: int
    ) -> Notification:
        title, body, data = _personal_best_template(exercise, weight, reps)
        return self.send(user_id, NotificationType.PERSONAL_BEST,
                         title, body, channel=NotificationChannel.PUSH, data=data)

    # ===================================================================
    # SYSTEM NOTIFICATIONS
    # ===================================================================

    def notify_welcome(self, user_id: int, name: str) -> Notification:
        title, body, data = _welcome_template(name)
        return self.send(user_id, NotificationType.ACCOUNT_WELCOME,
                         title, body, channel=NotificationChannel.EMAIL, data=data)

    def send_announcement(
        self, user_ids: List[int], title: str, message: str
    ) -> List[Notification]:
        """Broadcast an announcement to multiple members."""
        n_title, n_body, n_data = _announcement_template(title, message)
        return [
            self.send(uid, NotificationType.GENERAL_ANNOUNCEMENT,
                      n_title, n_body, channel=NotificationChannel.BOTH, data=n_data)
            for uid in user_ids
        ]

    # ===================================================================
    # INBOX / READ
    # ===================================================================

    def get_user_notifications(
        self,
        user_id: int,
        unread_only: bool = False,
        limit: int = 20,
    ) -> List[Notification]:
        """Get a user's notification inbox, newest first."""
        query = self.db.query(Notification).filter(
            Notification.user_id == user_id
        )
        if unread_only:
            query = query.filter(
                Notification.status != NotificationStatus.READ
            )
        return query.order_by(Notification.created_at.desc()).limit(limit).all()

    def mark_as_read(self, notification_id: int, user_id: int) -> Notification:
        """Mark a single notification as read."""
        notif = self.db.query(Notification).filter(
            Notification.id      == notification_id,
            Notification.user_id == user_id,
        ).first()
        if not notif:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail="Notification not found.")
        notif.status  = NotificationStatus.READ
        notif.read_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(notif)
        return notif

    def mark_all_as_read(self, user_id: int) -> int:
        """Mark all unread notifications as read. Returns count updated."""
        updated = self.db.query(Notification).filter(
            Notification.user_id == user_id,
            Notification.status  != NotificationStatus.READ,
        ).all()
        now = datetime.utcnow()
        for n in updated:
            n.status  = NotificationStatus.READ
            n.read_at = now
        self.db.commit()
        return len(updated)

    def get_unread_count(self, user_id: int) -> int:
        """Count unread notifications (for badge display)."""
        return self.db.query(Notification).filter(
            Notification.user_id == user_id,
            Notification.status  != NotificationStatus.READ,
        ).count()
