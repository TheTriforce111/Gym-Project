"""
schemas/notification.py — Notification Request & Response Schemas (Phase 8)
"""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, field_validator
from app.models.notification import NotificationChannel, NotificationStatus, NotificationType


class DeviceTokenRegister(BaseModel):
    """Body for POST /api/notifications/device-token — register FCM token."""
    token:       str
    device_type: Optional[str] = None   # "android", "ios", "web"
    device_name: Optional[str] = None   # "iPhone 15 Pro"
    app_version: Optional[str] = None

    @field_validator("token")
    @classmethod
    def token_not_empty(cls, v):
        if not v.strip():
            raise ValueError("FCM device token cannot be empty.")
        return v.strip()


class AnnouncementRequest(BaseModel):
    """Body for POST /api/notifications/announce — broadcast to all members."""
    title:      str
    message:    str
    user_ids:   Optional[List[int]] = None
    # If None → send to ALL active members
    # If provided → send only to these user IDs

    @field_validator("title", "message")
    @classmethod
    def not_empty(cls, v):
        if not v.strip():
            raise ValueError("Title and message cannot be empty.")
        return v.strip()


class NotificationResponse(BaseModel):
    """A single notification record."""
    id:                int
    user_id:           int
    title:             str
    body:              str
    notification_type: NotificationType
    channel:           NotificationChannel
    status:            NotificationStatus
    is_read:           bool
    retry_count:       int
    failure_reason:    Optional[str]
    sent_at:           Optional[datetime]
    read_at:           Optional[datetime]
    created_at:        datetime
    scheduled_at:      Optional[datetime]

    class Config:
        from_attributes = True


class NotificationSummary(BaseModel):
    """Lightweight notification for inbox list."""
    id:                int
    title:             str
    body:              str
    notification_type: NotificationType
    is_read:           bool
    created_at:        datetime

    class Config:
        from_attributes = True


class UnreadCountResponse(BaseModel):
    """Badge count for the mobile app notification icon."""
    unread_count: int


class MarkReadRequest(BaseModel):
    """Body for POST /api/notifications/mark-read."""
    notification_ids: Optional[List[int]] = None
    # If None → mark ALL as read
    # If provided → mark only these IDs
