"""
tests/test_attendance.py — QR Attendance System Tests (Phase 7)

Run with:
    pytest tests/test_attendance.py -v

Tests cover:
- QR token generation (signed, with expiry)
- Token verification (valid, expired, tampered, wrong user)
- Check-in via QR (success, duplicate, expired token, invalid membership)
- Manual check-in (admin override)
- Check-out with duration calculation
- Admin reports (daily, weekly, monthly, trend)
- Member stats (streak, monthly counts)
- QR invalidation by admin
"""

import base64
import time
import pytest
from datetime import date, datetime, timedelta
from unittest.mock import patch

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.core.security import hash_password
from app.models.user import User, UserRole
from app.models.membership import Membership, MembershipPlan, MembershipStatus
from app.models.attendance import Attendance, QRCodeToken
from app.utils.qr_utils import generate_qr_token, verify_qr_token, get_token_hash

SQLALCHEMY_DATABASE_URL = "sqlite:///./test_attendance.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
Base.metadata.create_all(bind=engine)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield


@pytest.fixture
def db():
    s = TestingSessionLocal()
    yield s
    s.close()


def _make_user(db, email, role):
    u = User(
        full_name=f"{role} User",
        email=email,
        hashed_password=hash_password("Pass1234"),
        role=role,
        is_active=True,
    )
    db.add(u)
    db.commit()
    resp = client.post("/api/auth/login", json={"email": email, "password": "Pass1234"})
    return {"user": u, "token": resp.json()["access_token"]}


def _give_membership(db, user_id, expired=False):
    start = datetime.utcnow()
    end   = (start - timedelta(days=1)) if expired else (start + timedelta(days=30))
    m = Membership(
        user_id=user_id,
        plan=MembershipPlan.MONTHLY,
        status=MembershipStatus.ACTIVE,
        start_date=start,
        end_date=end,
        price_paid=49.99,
    )
    db.add(m)
    db.commit()
    return m


@pytest.fixture
def admin(db):   return _make_user(db, "admin@gym.com",   UserRole.ADMIN)
@pytest.fixture
def trainer(db): return _make_user(db, "trainer@gym.com", UserRole.TRAINER)
@pytest.fixture
def member(db):
    data = _make_user(db, "member@gym.com", UserRole.MEMBER)
    _give_membership(db, data["user"].id)
    return data


# ---------------------------------------------------------------------------
# Token Utility Unit Tests (no HTTP)
# ---------------------------------------------------------------------------

class TestQRTokenUtils:

    def test_token_generation_and_verification(self):
        """Generated token verifies correctly and extracts correct user_id."""
        result = generate_qr_token(user_id=42)
        payload = verify_qr_token(result["token"])

        assert payload is not None
        assert payload["user_id"] == 42
        assert payload["expires_at"] > datetime.utcnow()

    def test_expired_token_rejected(self):
        """A token past its expiry window returns None."""
        from app.utils.qr_utils import QR_TOKEN_EXPIRY_MINUTES
        import hmac as hmac_lib
        import hashlib

        # Build a token with a timestamp 2 hours in the past
        past_unix  = int(time.time()) - (QR_TOKEN_EXPIRY_MINUTES + 60) * 60
        payload    = f"v1:42:{past_unix}"
        from app.core.config import settings
        signature  = hmac_lib.new(
            key=settings.SECRET_KEY.encode(),
            msg=payload.encode(),
            digestmod=hashlib.sha256,
        ).hexdigest()
        raw        = f"{payload}.{signature}"
        old_token  = base64.urlsafe_b64encode(raw.encode()).decode()

        result = verify_qr_token(old_token)
        assert result is None, "Expired token should not verify"

    def test_tampered_token_rejected(self):
        """Modifying the user_id in the token invalidates the signature."""
        result = generate_qr_token(user_id=42)
        token  = result["token"]

        # Decode, change user_id from 42 to 99, re-encode WITHOUT re-signing
        raw      = base64.urlsafe_b64decode(token.encode()).decode()
        tampered = raw.replace(":42:", ":99:")
        bad_token = base64.urlsafe_b64encode(tampered.encode()).decode()

        verified = verify_qr_token(bad_token)
        assert verified is None, "Tampered token must be rejected"

    def test_garbage_input_returns_none(self):
        """Random garbage input doesn't crash, returns None."""
        assert verify_qr_token("not_a_token") is None
        assert verify_qr_token("") is None
        assert verify_qr_token("eyJhbGciOi.fake.payload") is None


# ---------------------------------------------------------------------------
# QR Code Endpoint Tests
# ---------------------------------------------------------------------------

class TestQREndpoints:

    def test_member_gets_qr_code(self, member):
        """Member can retrieve their QR code and base64 image."""
        resp = client.get(
            "/api/attendance/my-qr",
            headers={"Authorization": f"Bearer {member['token']}"}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "token" in data
        assert "qr_image_base64" in data
        assert "expires_at" in data
        assert data["expires_in_minutes"] > 0

        # Token should verify correctly
        payload = verify_qr_token(data["token"])
        assert payload is not None
        assert payload["user_id"] == member["user"].id

    def test_same_token_returned_when_still_valid(self, member):
        """Calling /my-qr twice returns the same token (not regenerated each time)."""
        resp1 = client.get("/api/attendance/my-qr",
                           headers={"Authorization": f"Bearer {member['token']}"})
        resp2 = client.get("/api/attendance/my-qr",
                           headers={"Authorization": f"Bearer {member['token']}"})
        assert resp1.json()["token"] == resp2.json()["token"]

    def test_qr_image_endpoint_returns_png(self, member):
        """PNG image endpoint returns a valid image."""
        resp = client.get(
            "/api/attendance/my-qr/image",
            headers={"Authorization": f"Bearer {member['token']}"}
        )
        assert resp.status_code == 200
        assert resp.headers["content-type"] == "image/png"
        assert len(resp.content) > 100  # PNG has actual bytes

    def test_member_can_refresh_qr(self, member):
        """Refreshing QR generates a new token different from the old one."""
        resp1 = client.get("/api/attendance/my-qr",
                           headers={"Authorization": f"Bearer {member['token']}"})
        old_token = resp1.json()["token"]

        resp2 = client.post("/api/attendance/my-qr/refresh",
                            headers={"Authorization": f"Bearer {member['token']}"})
        assert resp2.status_code == 200
        assert resp2.json()["new_token"] != old_token


# ---------------------------------------------------------------------------
# Check-In Tests
# ---------------------------------------------------------------------------

class TestCheckIn:

    def _get_member_token(self, member_token):
        """Helper: get QR token for check-in."""
        resp = client.get("/api/attendance/my-qr",
                          headers={"Authorization": f"Bearer {member_token}"})
        return resp.json()["token"]

    def test_successful_qr_check_in(self, member, admin):
        """Valid QR token + active membership = successful check-in."""
        qr_token = self._get_member_token(member["token"])

        resp = client.post(
            "/api/attendance/check-in",
            headers={"Authorization": f"Bearer {admin['token']}"},
            json={"token": qr_token}
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["user_id"]    == member["user"].id
        assert data["member_name"] == member["user"].full_name
        assert "membership_plan"   in data
        assert data["visits_this_month"] == 1

    def test_duplicate_check_in_blocked(self, member, admin):
        """Cannot check in twice on the same day."""
        qr_token = self._get_member_token(member["token"])

        client.post("/api/attendance/check-in",
                    headers={"Authorization": f"Bearer {admin['token']}"},
                    json={"token": qr_token})

        resp = client.post("/api/attendance/check-in",
                           headers={"Authorization": f"Bearer {admin['token']}"},
                           json={"token": qr_token})
        assert resp.status_code == 409
        assert "already checked in" in resp.json()["detail"].lower()

    def test_invalid_token_rejected(self, admin):
        """Random garbage token returns 400."""
        resp = client.post(
            "/api/attendance/check-in",
            headers={"Authorization": f"Bearer {admin['token']}"},
            json={"token": "this_is_not_a_valid_token"}
        )
        assert resp.status_code == 400

    def test_no_membership_blocked(self, admin, db):
        """Member with no membership gets 403."""
        no_mem = _make_user(db, "nomem@gym.com", UserRole.MEMBER)
        qr_resp = client.get("/api/attendance/my-qr",
                             headers={"Authorization": f"Bearer {no_mem['token']}"})
        qr_token = qr_resp.json()["token"]

        resp = client.post(
            "/api/attendance/check-in",
            headers={"Authorization": f"Bearer {admin['token']}"},
            json={"token": qr_token}
        )
        assert resp.status_code == 403

    def test_expired_membership_blocked(self, admin, db):
        """Member with expired membership gets 403."""
        exp_member = _make_user(db, "expired@gym.com", UserRole.MEMBER)
        _give_membership(db, exp_member["user"].id, expired=True)

        qr_resp = client.get("/api/attendance/my-qr",
                             headers={"Authorization": f"Bearer {exp_member['token']}"})
        qr_token = qr_resp.json()["token"]

        resp = client.post(
            "/api/attendance/check-in",
            headers={"Authorization": f"Bearer {admin['token']}"},
            json={"token": qr_token}
        )
        assert resp.status_code == 403

    def test_invalidated_qr_blocked(self, member, admin):
        """Admin can invalidate a QR and prevent check-in."""
        qr_token = self._get_member_token(member["token"])

        # Admin invalidates the QR
        client.post(
            f"/api/attendance/invalidate-qr/{member['user'].id}",
            headers={"Authorization": f"Bearer {admin['token']}"}
        )

        # Check-in attempt should fail
        resp = client.post(
            "/api/attendance/check-in",
            headers={"Authorization": f"Bearer {admin['token']}"},
            json={"token": qr_token}
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# Manual Check-In Tests
# ---------------------------------------------------------------------------

class TestManualCheckIn:

    def test_trainer_manual_check_in(self, member, trainer):
        """Trainer can manually check in a member."""
        resp = client.post(
            "/api/attendance/manual-check-in",
            headers={"Authorization": f"Bearer {trainer['token']}"},
            json={"user_id": member["user"].id, "notes": "Phone battery dead"}
        )
        assert resp.status_code == 201
        assert resp.json()["user_id"] == member["user"].id

    def test_member_cannot_do_manual_check_in(self, member):
        """Regular members cannot perform manual check-ins."""
        resp = client.post(
            "/api/attendance/manual-check-in",
            headers={"Authorization": f"Bearer {member['token']}"},
            json={"user_id": member["user"].id}
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# Check-Out Tests
# ---------------------------------------------------------------------------

class TestCheckOut:

    def test_check_out_records_duration(self, member, admin, db):
        """Check-out calculates and stores session duration."""
        # Manually create a check-in record 90 minutes ago
        ninety_min_ago = datetime.utcnow() - timedelta(minutes=90)
        attendance = Attendance(
            user_id       = member["user"].id,
            check_in_time = ninety_min_ago,
            check_in_date = date.today(),
            method        = "qr_scan",
        )
        db.add(attendance)
        db.commit()

        resp = client.post(
            "/api/attendance/check-out",
            headers={"Authorization": f"Bearer {admin['token']}"},
            json={"user_id": member["user"].id}
        )
        assert resp.status_code == 200
        assert resp.json()["duration_minutes"] >= 89  # ~90 minutes


# ---------------------------------------------------------------------------
# Reports Tests
# ---------------------------------------------------------------------------

class TestReports:

    def _check_in_member(self, member_token, admin_token):
        qr = client.get("/api/attendance/my-qr",
                        headers={"Authorization": f"Bearer {member_token}"}).json()["token"]
        client.post("/api/attendance/check-in",
                    headers={"Authorization": f"Bearer {admin_token}"},
                    json={"token": qr})

    def test_daily_report(self, member, admin):
        """Daily report counts today's check-ins correctly."""
        self._check_in_member(member["token"], admin["token"])

        resp = client.get("/api/attendance/report/daily",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        assert resp.json()["total_check_ins"] == 1
        assert resp.json()["unique_members"]  == 1

    def test_weekly_report_has_7_days(self, admin):
        """Weekly report always returns 7 daily entries."""
        resp = client.get("/api/attendance/report/weekly",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        assert len(resp.json()["daily_breakdown"]) == 7

    def test_trend_report(self, member, admin):
        """Trend returns correct number of data points."""
        self._check_in_member(member["token"], admin["token"])

        resp = client.get("/api/attendance/report/trend?days=14",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        assert len(resp.json()["data_points"]) == 14
        assert resp.json()["total"] == 1

    def test_member_summary(self, member, admin):
        """Member summary returns accurate stats."""
        self._check_in_member(member["token"], admin["token"])

        resp = client.get(
            f"/api/attendance/member/{member['user'].id}/summary",
            headers={"Authorization": f"Bearer {admin['token']}"}
        )
        assert resp.status_code == 200
        stats = resp.json()
        assert stats["total_visits"]      == 1
        assert stats["visits_this_month"] == 1
        assert stats["current_streak"]    == 1

    def test_my_summary(self, member, admin):
        """Members can view their own summary."""
        self._check_in_member(member["token"], admin["token"])

        resp = client.get("/api/attendance/me/summary",
                          headers={"Authorization": f"Bearer {member['token']}"})
        assert resp.status_code == 200
        assert resp.json()["total_visits"] == 1

    def test_today_live_feed(self, member, admin):
        """Today endpoint shows live check-ins."""
        self._check_in_member(member["token"], admin["token"])

        resp = client.get("/api/attendance/today",
                          headers={"Authorization": f"Bearer {admin['token']}"})
        assert resp.status_code == 200
        assert len(resp.json()) == 1
