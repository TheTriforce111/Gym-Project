"""
utils/qr_utils.py — QR Code Generation and Token Security (Phase 7)

This module handles two things:

1. TOKEN SECURITY
   - Generating cryptographically signed tokens that encode user identity
   - Verifying those tokens during check-in (signature + expiry check)
   - Why signing? So nobody can forge a QR code for another member.

2. QR IMAGE GENERATION
   - Converting a token string into a scannable PNG QR code image
   - Returning it as raw bytes (for HTTP streaming) or base64 (for mobile)

=== How the Signed Token Works ===

  Token payload: {user_id}:{issued_at_unix_timestamp}
  Signature:     HMAC-SHA256(payload, SECRET_KEY)
  Full token:    base64url( payload + "." + hex_signature )

  Example:
    payload   = "42:1707123456"          (user 42, issued at unix time)
    signature = hmac_sha256(payload, SECRET_KEY)
    token     = base64("42:1707123456.a3f9b2c1...")

  To verify:
    1. Decode base64 → extract payload and signature
    2. Recompute HMAC(payload, SECRET_KEY)
    3. Compare signatures using hmac.compare_digest() (timing-safe)
    4. Check that issued_at + QR_TOKEN_EXPIRY_MINUTES > now

  This means:
    ✅ Only our server can generate valid tokens (only we know SECRET_KEY)
    ✅ A token for user 42 cannot be modified to work for user 99
    ✅ Screenshots of old QR codes stop working after expiry
    ✅ Timing-safe comparison prevents timing attacks
"""

import base64
import hashlib
import hmac
import time
from datetime import datetime, timedelta
from io import BytesIO
from typing import Optional

import qrcode
import qrcode.constants
from PIL import Image

from app.core.config import settings

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

QR_TOKEN_EXPIRY_MINUTES = 60
# QR codes are valid for 60 minutes after generation.
# After that, the member must refresh their app to get a new code.
# This limits the damage if someone screenshots your QR.

QR_TOKEN_VERSION = "v1"
# Version prefix so we can rotate the token format in future without
# breaking existing tokens during a gradual rollout.


# ---------------------------------------------------------------------------
# Token Generation
# ---------------------------------------------------------------------------

def generate_qr_token(user_id: int) -> dict:
    """
    Generate a new signed QR token for a user.

    Returns a dict with:
      token      - the full token string (stored in QR code)
      token_hash - SHA-256 hash of the token (stored in DB for fast lookup)
      issued_at  - when it was issued (datetime)
      expires_at - when it expires (datetime)

    The token is designed to be:
      - Unforgeable (HMAC signed)
      - Time-limited (expires after QR_TOKEN_EXPIRY_MINUTES)
      - Stateless (server can verify without DB lookup, just needs secret)
      - Compact (base64url encoded, fits in a QR code easily)
    """
    issued_unix = int(time.time())

    # Build the payload: version + user_id + issued timestamp
    payload = f"{QR_TOKEN_VERSION}:{user_id}:{issued_unix}"

    # Sign with HMAC-SHA256 using the app's SECRET_KEY
    # hmac.new() creates a message authentication code
    signature = hmac.new(
        key=settings.SECRET_KEY.encode("utf-8"),
        msg=payload.encode("utf-8"),
        digestmod=hashlib.sha256,
    ).hexdigest()
    # hexdigest() = hex string of the 256-bit hash

    # Combine payload and signature, encode as URL-safe base64
    raw = f"{payload}.{signature}"
    token = base64.urlsafe_b64encode(raw.encode("utf-8")).decode("utf-8")

    # Hash the token for DB storage (fast index lookup + privacy)
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()

    issued_at  = datetime.utcfromtimestamp(issued_unix)
    expires_at = issued_at + timedelta(minutes=QR_TOKEN_EXPIRY_MINUTES)

    return {
        "token":      token,
        "token_hash": token_hash,
        "issued_at":  issued_at,
        "expires_at": expires_at,
    }


# ---------------------------------------------------------------------------
# Token Verification
# ---------------------------------------------------------------------------

def verify_qr_token(token: str) -> Optional[dict]:
    """
    Verify a QR token scanned at the gym entrance.

    Returns a dict with {user_id, issued_at, expires_at} if valid.
    Returns None if the token is invalid, expired, or tampered.

    Security properties:
    - Signature verification: recomputes HMAC and compares
    - Timing-safe comparison: hmac.compare_digest() prevents timing attacks
      (A timing attack measures response time differences to guess secret bytes)
    - Expiry check: token is rejected after QR_TOKEN_EXPIRY_MINUTES
    """
    try:
        # Decode base64 to get "payload.signature"
        raw = base64.urlsafe_b64decode(token.encode("utf-8")).decode("utf-8")
        parts = raw.rsplit(".", 1)   # Split on LAST dot only
        if len(parts) != 2:
            return None

        payload, received_sig = parts

        # Recompute the expected signature
        expected_sig = hmac.new(
            key=settings.SECRET_KEY.encode("utf-8"),
            msg=payload.encode("utf-8"),
            digestmod=hashlib.sha256,
        ).hexdigest()

        # Timing-safe comparison — prevents timing-based secret extraction
        if not hmac.compare_digest(expected_sig, received_sig):
            return None  # Signature doesn't match — token was tampered with

        # Parse payload: "v1:user_id:issued_unix"
        payload_parts = payload.split(":")
        if len(payload_parts) != 3 or payload_parts[0] != QR_TOKEN_VERSION:
            return None

        _, user_id_str, issued_unix_str = payload_parts
        user_id    = int(user_id_str)
        issued_unix = int(issued_unix_str)

        issued_at  = datetime.utcfromtimestamp(issued_unix)
        expires_at = issued_at + timedelta(minutes=QR_TOKEN_EXPIRY_MINUTES)

        # Check expiry
        if datetime.utcnow() > expires_at:
            return None  # Token has expired

        return {
            "user_id":    user_id,
            "issued_at":  issued_at,
            "expires_at": expires_at,
        }

    except (ValueError, TypeError, Exception):
        # Any parsing error = invalid token
        return None


def get_token_hash(token: str) -> str:
    """Compute the SHA-256 hash of a token for DB lookup."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# QR Code Image Generation
# ---------------------------------------------------------------------------

def generate_qr_image(data: str, box_size: int = 10) -> bytes:
    """
    Generate a QR code PNG image from a string.

    Parameters:
        data:     The string to encode (our signed token)
        box_size: Size of each QR module in pixels (higher = bigger image)

    Returns raw PNG bytes — send directly as HTTP response or encode as base64.

    QR Code settings:
    - error_correction=H: 30% of code can be damaged/obscured and still scan
      (useful when logo is overlaid on the QR code)
    - version=None: auto-select the smallest version that fits the data
    - border=4: minimum quiet zone (white border) required by QR standard
    """
    qr = qrcode.QRCode(
        version=None,                              # Auto-size
        error_correction=qrcode.constants.ERROR_CORRECT_H,  # High error tolerance
        box_size=box_size,
        border=4,                                  # White border (QR standard minimum)
    )
    qr.add_data(data)
    qr.make(fit=True)

    # Create the image with a clean black-on-white style
    img: Image.Image = qr.make_image(
        fill_color="black",
        back_color="white",
    )

    # Convert to bytes
    buffer = BytesIO()
    img.save(buffer, format="PNG", optimize=True)
    buffer.seek(0)
    return buffer.getvalue()


def generate_qr_image_base64(data: str) -> str:
    """
    Generate a QR code and return it as a base64-encoded string.

    Use this for mobile apps that display QR codes inline:
        <Image source={{ uri: `data:image/png;base64,${qrBase64}` }} />

    For Flutter:
        Image.memory(base64Decode(qrBase64))
    """
    import base64 as b64
    png_bytes = generate_qr_image(data)
    return b64.b64encode(png_bytes).decode("utf-8")


def generate_qr_with_logo(data: str, logo_path: Optional[str] = None) -> bytes:
    """
    Generate a QR code with an optional gym logo overlaid in the center.

    The high error correction (H=30%) allows up to 30% of the QR code
    to be obscured without losing scannability — enough for a small logo.

    If logo_path is None, returns a standard QR code without a logo.
    """
    qr_bytes = generate_qr_image(data, box_size=12)

    if not logo_path:
        return qr_bytes

    try:
        qr_img   = Image.open(BytesIO(qr_bytes)).convert("RGBA")
        logo_img = Image.open(logo_path).convert("RGBA")

        # Resize logo to ~25% of QR code size
        qr_w, qr_h = qr_img.size
        logo_size  = (qr_w // 4, qr_h // 4)
        logo_img   = logo_img.resize(logo_size, Image.LANCZOS)

        # Center the logo on the QR code
        logo_x = (qr_w - logo_size[0]) // 2
        logo_y = (qr_h - logo_size[1]) // 2

        # Add white padding behind logo for better readability
        padding    = 10
        pad_box    = Image.new(
            "RGBA",
            (logo_size[0] + padding*2, logo_size[1] + padding*2),
            "white"
        )
        qr_img.paste(pad_box, (logo_x - padding, logo_y - padding), pad_box)
        qr_img.paste(logo_img, (logo_x, logo_y), logo_img)

        buffer = BytesIO()
        qr_img.convert("RGB").save(buffer, format="PNG", optimize=True)
        buffer.seek(0)
        return buffer.getvalue()

    except Exception:
        # If logo processing fails, return the plain QR code
        return qr_bytes
