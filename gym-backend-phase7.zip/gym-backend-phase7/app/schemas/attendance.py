"""
schemas/attendance.py — Attendance System Request & Response Schemas (Phase 7)

Covers:
- QR token generation responses
- Check-in request and response
- Attendance records (individual and paginated)
- Admin analytics (daily/weekly/monthly reports)
- Manual check-in (for when QR fails)
"""

from datetime import date, datetime
from typing import List, Optional
from pydantic import BaseModel, field_validator

from app.models.attendance import CheckInMethod


# ============================================================
# QR CODE SCHEMAS
# ============================================================

class QRTokenResponse(BaseModel):
    """
    Returned when a member requests their QR code token.
    The frontend uses 'token' to render the QR image,
    or displays 'qr_image_base64' directly as an <img>.
    """
    token:           str       # The signed token string (encoded in the QR image)
    qr_image_base64: str       # Base64-encoded PNG — display directly in app
    expires_at:      datetime  # When this token stops working
    expires_in_minutes: int    # Human-friendly countdown


class QRRefreshResponse(BaseModel):
    """Returned after a QR token is forcibly refreshed."""
    message:     str
    new_token:   str
    expires_at:  datetime


# ============================================================
# CHECK-IN SCHEMAS
# ============================================================

class QRCheckInRequest(BaseModel):
    """
    Body for POST /api/attendance/check-in
    Staff submits the scanned QR token to check in a member.
    """
    token: str
    # The raw token string decoded from the QR image

    notes: Optional[str] = None
    # Optional note: "Member had to show ID instead of QR"


class ManualCheckInRequest(BaseModel):
    """
    Body for POST /api/attendance/manual-check-in
    Admin or staff manually checks in a member by user_id
    (used when the member forgot their phone or QR is broken).
    """
    user_id: int
    notes:   Optional[str] = None
    # Required note explaining why manual check-in was used


class CheckOutRequest(BaseModel):
    """
    Body for POST /api/attendance/check-out
    Records when a member leaves the gym (optional feature).
    """
    user_id: int


# ============================================================
# ATTENDANCE RECORD SCHEMAS
# ============================================================

class AttendanceResponse(BaseModel):
    """A single attendance (check-in) record."""
    id:               int
    user_id:          int
    check_in_time:    datetime
    check_out_time:   Optional[datetime]
    check_in_date:    date
    method:           CheckInMethod
    duration_minutes: Optional[int]
    notes:            Optional[str]
    is_guest:         bool

    class Config:
        from_attributes = True


class CheckInSuccessResponse(BaseModel):
    """
    Returned immediately after a successful check-in.
    Includes member info so the staff screen can show a confirmation.
    """
    message:          str
    user_id:          int
    member_name:      str
    membership_plan:  str          # e.g. "monthly"
    membership_expiry: datetime    # When their membership expires
    check_in_time:    datetime
    visits_this_month: int         # Running total for the current month


# ============================================================
# ADMIN REPORT SCHEMAS
# ============================================================

class DailyAttendanceReport(BaseModel):
    """Summary of check-ins for a single day."""
    date:              date
    total_check_ins:   int
    unique_members:    int          # Distinct user_ids (no duplicates)
    qr_scan_count:     int
    manual_count:      int
    peak_hour:         Optional[int]  # Hour with most check-ins (0-23)
    average_duration_minutes: Optional[float]


class WeeklyAttendanceReport(BaseModel):
    """Seven-day attendance summary."""
    week_start:        date
    week_end:          date
    total_check_ins:   int
    unique_members:    int
    busiest_day:       Optional[str]   # e.g. "Monday"
    daily_breakdown:   List[DailyAttendanceReport]


class MonthlyAttendanceReport(BaseModel):
    """Monthly attendance summary."""
    year:              int
    month:             int
    total_check_ins:   int
    unique_members:    int
    average_daily:     float
    most_active_member_id: Optional[int]


class MemberAttendanceSummary(BaseModel):
    """
    A specific member's attendance stats.
    Shown on the admin member profile page.
    """
    user_id:           int
    total_visits:      int
    visits_this_month: int
    visits_this_week:  int
    average_per_week:  float
    last_visit:        Optional[datetime]
    longest_streak:    int    # Longest consecutive-day streak ever
    current_streak:    int    # Current consecutive-day streak


class AttendanceTrendPoint(BaseModel):
    """One data point in an attendance trend chart."""
    date:        date
    check_ins:   int


class AttendanceTrendResponse(BaseModel):
    """
    Time-series attendance data for charts.
    Used by the admin dashboard to show attendance trends.
    """
    period:      str          # "daily", "weekly", "monthly"
    data_points: List[AttendanceTrendPoint]
    total:       int
    average:     float
