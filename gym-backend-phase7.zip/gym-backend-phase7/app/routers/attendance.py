"""
routers/attendance.py — QR Attendance API Endpoints (Phase 7)

────────────────────────────────────────────────
QR CODE MANAGEMENT
────────────────────────────────────────────────
GET  /api/attendance/my-qr           → Get my QR code (member)
GET  /api/attendance/my-qr/image     → Get QR as PNG stream (member)
POST /api/attendance/my-qr/refresh   → Force-refresh my QR token
POST /api/attendance/invalidate-qr/{user_id} → Disable a member's QR (Admin)

────────────────────────────────────────────────
CHECK-IN / CHECK-OUT
────────────────────────────────────────────────
POST /api/attendance/check-in        → Scan QR to check in (Staff)
POST /api/attendance/manual-check-in → Manual check-in by user_id (Admin/Trainer)
POST /api/attendance/check-out       → Record check-out time (Staff)

────────────────────────────────────────────────
MEMBER HISTORY
────────────────────────────────────────────────
GET  /api/attendance/me              → My check-in history
GET  /api/attendance/me/summary      → My attendance stats (streak, monthly, etc.)

────────────────────────────────────────────────
ADMIN REPORTS
────────────────────────────────────────────────
GET  /api/attendance/today           → Live today's check-ins (Admin)
GET  /api/attendance/report/daily    → Daily report (Admin)
GET  /api/attendance/report/weekly   → Weekly report (Admin)
GET  /api/attendance/report/monthly  → Monthly report (Admin)
GET  /api/attendance/report/trend    → N-day trend for dashboard chart (Admin)
GET  /api/attendance/member/{id}/summary → A member's full stats (Admin)
GET  /api/attendance/member/{id}/history → A member's history (Admin)
"""

from datetime import date
from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
from io import BytesIO
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin, require_trainer
from app.models.user import User
from app.schemas.attendance import (
    AttendanceResponse, AttendanceTrendResponse,
    CheckInSuccessResponse, DailyAttendanceReport,
    ManualCheckInRequest, MonthlyAttendanceReport,
    MemberAttendanceSummary, QRRefreshResponse,
    QRTokenResponse, QRCheckInRequest,
    WeeklyAttendanceReport, CheckOutRequest,
)
from app.services.attendance_service import AttendanceService
from app.utils.qr_utils import generate_qr_image

router = APIRouter()


# ====================================================================
# QR CODE MANAGEMENT
# ====================================================================

@router.get(
    "/my-qr",
    response_model=QRTokenResponse,
    summary="Get my QR code for gym check-in (Member)",
)
def get_my_qr_code(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the member's active QR code token and a base64-encoded PNG image.

    The QR code is:
    - Cryptographically signed (cannot be forged)
    - Valid for 60 minutes (auto-refreshed each app open)
    - Unique per member

    Frontend usage (Flutter):
    ```dart
    final response = await api.get('/api/attendance/my-qr');
    final base64Image = response['qr_image_base64'];
    // Display: Image.memory(base64Decode(base64Image))
    ```

    Frontend usage (React):
    ```jsx
    <img src={`data:image/png;base64,${qrData.qr_image_base64}`} />
    ```
    """
    service = AttendanceService(db)
    return service.get_or_create_qr_token(current_user)


@router.get(
    "/my-qr/image",
    summary="Get my QR code as a PNG image stream (Member)",
    response_class=StreamingResponse,
)
def get_my_qr_image(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the QR code as a raw PNG image stream.
    Use this for browser-based display: <img src="/api/attendance/my-qr/image" />

    For mobile apps, use GET /my-qr instead (returns base64).
    """
    service = AttendanceService(db)
    token_data = service.get_or_create_qr_token(current_user)
    png_bytes  = generate_qr_image(token_data["token"])

    return StreamingResponse(
        BytesIO(png_bytes),
        media_type="image/png",
        headers={
            "Content-Disposition": f"inline; filename=qr_{current_user.id}.png",
            "Cache-Control": "no-cache",  # Always fetch fresh QR
        },
    )


@router.post(
    "/my-qr/refresh",
    response_model=QRRefreshResponse,
    summary="Force-refresh my QR code (Member)",
)
def refresh_my_qr(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Generate a brand-new QR token, immediately invalidating the old one.

    Use when:
    - Member suspects their QR was seen by someone else
    - QR image is too blurry to scan
    - Member wants a fresh code before a visit
    """
    service = AttendanceService(db)
    return service.refresh_qr_token(current_user)


@router.post(
    "/invalidate-qr/{user_id}",
    summary="Disable a member's QR code (Admin)",
)
def invalidate_member_qr(
    user_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Immediately disable a specific member's QR code.
    The member will not be able to check in until they refresh their app.

    Use when:
    - Member is suspended
    - QR code reported as stolen/compromised
    - Investigating fraudulent access
    """
    service = AttendanceService(db)
    service.invalidate_user_qr(user_id=user_id, admin=admin)
    return {
        "message": f"QR code for user #{user_id} has been deactivated.",
        "user_id": user_id,
    }


# ====================================================================
# CHECK-IN / CHECK-OUT
# ====================================================================

@router.post(
    "/check-in",
    response_model=CheckInSuccessResponse,
    status_code=201,
    summary="Process a QR code scan to check in a member (Staff/Admin)",
)
def qr_check_in(
    body: QRCheckInRequest,
    staff: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Process a QR scan at the gym entrance to check in a member.

    Called by:
    - The staff reception app when they scan a member's QR code
    - A self-service kiosk at the gym entrance

    The response includes the member's name and membership expiry
    so the staff screen can show a confirmation card.

    Error responses:
    - 400: QR code is invalid, expired, or malformed
    - 403: Member has no active membership, or QR is disabled
    - 409: Member already checked in today
    - 404: Member account not found
    """
    service = AttendanceService(db)
    return service.process_qr_check_in(
        token=body.token,
        processed_by=staff,
        notes=body.notes,
    )


@router.post(
    "/manual-check-in",
    response_model=CheckInSuccessResponse,
    status_code=201,
    summary="Manually check in a member by ID (Admin/Trainer)",
)
def manual_check_in(
    body: ManualCheckInRequest,
    staff: User = Depends(require_trainer),
    db: Session = Depends(get_db),
):
    """
    Check in a member without QR scanning.

    Use this when:
    - Member forgot their phone
    - QR code is not scanning (damaged screen, poor lighting)
    - Member is a guest or first-timer without the app

    All same rules apply (active membership, one check-in per day).
    The notes field creates an audit trail.
    """
    service = AttendanceService(db)
    return service.process_manual_check_in(
        user_id=body.user_id,
        processed_by=staff,
        notes=body.notes,
    )


@router.post(
    "/check-out",
    response_model=AttendanceResponse,
    summary="Record a member's check-out time (Staff)",
)
def check_out(
    body: CheckOutRequest,
    staff: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Record when a member leaves the gym.
    Automatically calculates their session duration in minutes.

    This is optional — many gyms only track check-in.
    Enable if you want to track how long members spend in the gym.
    """
    service = AttendanceService(db)
    return service.process_check_out(user_id=body.user_id)


# ====================================================================
# MEMBER HISTORY
# ====================================================================

@router.get(
    "/me",
    response_model=List[AttendanceResponse],
    summary="Get my attendance history (Member)",
)
def get_my_attendance(
    limit:     int           = Query(30, ge=1, le=100),
    from_date: Optional[date]= Query(None, description="Filter from this date (YYYY-MM-DD)"),
    to_date:   Optional[date]= Query(None, description="Filter to this date (YYYY-MM-DD)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the current user's gym visit history, most recent first.
    Includes check-in time, method, and duration (if checked out).
    """
    service = AttendanceService(db)
    return service.get_member_history(
        user_id=current_user.id,
        limit=limit,
        from_date=from_date,
        to_date=to_date,
    )


@router.get(
    "/me/summary",
    response_model=MemberAttendanceSummary,
    summary="Get my attendance stats and streak (Member)",
)
def get_my_summary(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the current user's attendance statistics:
    - Total gym visits ever
    - Visits this week / this month
    - Average visits per week (over last 12 weeks)
    - Current and longest consecutive training streaks
    - Last visit date

    Used on the member's home screen to show consistency badges.
    """
    service = AttendanceService(db)
    return service.get_member_summary(user_id=current_user.id)


# ====================================================================
# ADMIN REPORTS
# ====================================================================

@router.get(
    "/today",
    response_model=List[AttendanceResponse],
    summary="Live list of today's check-ins (Admin)",
)
def get_today_check_ins(
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns all check-ins from today in real-time, newest first.
    Used on the admin live dashboard to see who's currently in the gym.
    """
    service = AttendanceService(db)
    return service.get_today_check_ins()


@router.get(
    "/report/daily",
    response_model=DailyAttendanceReport,
    summary="Get daily attendance report (Admin)",
)
def get_daily_report(
    report_date: Optional[date] = Query(
        None,
        description="Date to report on (YYYY-MM-DD). Defaults to today."
    ),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns a summary for a specific day:
    - Total check-ins and unique members
    - QR scan vs manual check-in breakdown
    - Peak hour (which hour had the most visitors)
    - Average session duration

    Defaults to today if no date is provided.
    """
    service = AttendanceService(db)
    return service.get_daily_report(report_date=report_date)


@router.get(
    "/report/weekly",
    response_model=WeeklyAttendanceReport,
    summary="Get weekly attendance report (Admin)",
)
def get_weekly_report(
    week_offset: int = Query(
        0, ge=-12, le=0,
        description="0=this week, -1=last week, -2=two weeks ago"
    ),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns a full week's attendance summary with day-by-day breakdown.
    Includes the busiest day of the week.
    """
    service = AttendanceService(db)
    return service.get_weekly_report(week_offset=week_offset)


@router.get(
    "/report/monthly",
    response_model=MonthlyAttendanceReport,
    summary="Get monthly attendance report (Admin)",
)
def get_monthly_report(
    year:  Optional[int] = Query(None, description="Year (e.g. 2025)"),
    month: Optional[int] = Query(None, ge=1, le=12, description="Month (1-12)"),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns a calendar month's attendance summary.
    Includes the most active member ID for that month.
    Defaults to the current month.
    """
    service = AttendanceService(db)
    return service.get_monthly_report(year=year, month=month)


@router.get(
    "/report/trend",
    response_model=AttendanceTrendResponse,
    summary="Get attendance trend for dashboard chart (Admin)",
)
def get_attendance_trend(
    days: int = Query(30, ge=7, le=365, description="Number of days to look back"),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """
    Returns day-by-day check-in counts for the last N days.
    Use this to render a line chart on the admin dashboard showing
    how gym attendance has changed over time.

    Each data point: { date: "2025-02-10", check_ins: 47 }
    """
    service = AttendanceService(db)
    return service.get_attendance_trend(days=days)


@router.get(
    "/member/{user_id}/summary",
    response_model=MemberAttendanceSummary,
    summary="Get attendance stats for a specific member (Admin)",
)
def get_member_summary(
    user_id: int,
    admin: User  = Depends(require_admin),
    db: Session  = Depends(get_db),
):
    """
    Get the full attendance summary for a specific member.
    Shown on the admin member profile page.
    """
    service = AttendanceService(db)
    return service.get_member_summary(user_id=user_id)


@router.get(
    "/member/{user_id}/history",
    response_model=List[AttendanceResponse],
    summary="Get attendance history for a specific member (Admin)",
)
def get_member_history(
    user_id:   int,
    limit:     int            = Query(50, ge=1, le=200),
    from_date: Optional[date] = Query(None),
    to_date:   Optional[date] = Query(None),
    admin: User  = Depends(require_admin),
    db: Session  = Depends(get_db),
):
    """
    Get the full visit history for a specific member.
    Used by admin when a member disputes their attendance record.
    """
    service = AttendanceService(db)
    return service.get_member_history(
        user_id=user_id,
        limit=limit,
        from_date=from_date,
        to_date=to_date,
    )
