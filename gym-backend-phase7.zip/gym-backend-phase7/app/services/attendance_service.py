"""
services/attendance_service.py — QR Attendance Business Logic (Phase 7)

This service handles:
1. QR Token Management  → generate, store, refresh, invalidate
2. QR Check-In          → validate token + membership + duplicate check
3. Manual Check-In      → staff override when QR unavailable
4. Check-Out            → record when member leaves (optional)
5. Admin Reports        → daily/weekly/monthly stats, trends, member summaries

Security is handled at the token level (see utils/qr_utils.py).
Business rules are enforced here:
  - One check-in per member per day
  - Membership must be active and not expired
  - Token must not be manually invalidated
  - Manual check-in requires admin/staff role
"""

import logging
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from typing import List, Optional

from fastapi import HTTPException, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.attendance import Attendance, CheckInMethod, QRCodeToken
from app.models.membership import Membership, MembershipStatus
from app.models.user import User, UserRole
from app.utils.qr_utils import (
    QR_TOKEN_EXPIRY_MINUTES,
    generate_qr_image_base64,
    generate_qr_token,
    get_token_hash,
    verify_qr_token,
)

logger = logging.getLogger(__name__)


class AttendanceService:
    """
    All attendance and QR code operations.
    Instantiate with a DB session: service = AttendanceService(db)
    """

    def __init__(self, db: Session):
        self.db = db

    # ===================================================================
    # QR TOKEN MANAGEMENT
    # ===================================================================

    def get_or_create_qr_token(self, user: User) -> dict:
        """
        Get the user's current active QR token, or generate a new one.

        Called every time the member opens the "My QR Code" screen.

        Logic:
        - If an active, non-expired token exists → return it
        - If token is expired → generate a fresh one
        - If no token exists yet → generate the first one

        Returns token data + base64 QR image for the frontend.
        """
        existing = self.db.query(QRCodeToken).filter(
            QRCodeToken.user_id   == user.id,
            QRCodeToken.is_active == True,
        ).first()

        # Reuse if still valid
        if existing and existing.expires_at > datetime.utcnow():
            minutes_left = int(
                (existing.expires_at - datetime.utcnow()).total_seconds() / 60
            )
            qr_image = generate_qr_image_base64(existing.token)
            return {
                "token":              existing.token,
                "qr_image_base64":    qr_image,
                "expires_at":         existing.expires_at,
                "expires_in_minutes": minutes_left,
            }

        # Generate fresh token
        return self._generate_and_store_token(user)

    def refresh_qr_token(self, user: User) -> dict:
        """
        Force-generate a new QR token, invalidating the old one.

        Used when:
        - Member suspects their QR was compromised
        - Member's QR is damaged/unreadable and they need a fresh one
        - Admin manually triggers a refresh
        """
        # Invalidate old token if it exists
        old = self.db.query(QRCodeToken).filter(
            QRCodeToken.user_id == user.id
        ).first()
        if old:
            old.is_active = False
            self.db.flush()

        result = self._generate_and_store_token(user)
        logger.info(f"QR token refreshed for user #{user.id}")
        return {
            "message":   "QR code refreshed successfully.",
            "new_token": result["token"],
            "expires_at": result["expires_at"],
        }

    def invalidate_user_qr(self, user_id: int, admin: User) -> None:
        """
        Admin disables a specific member's QR code.
        Use when a member is suspended or QR is reported stolen.
        After invalidation, the member must contact staff to re-enable.
        """
        token = self.db.query(QRCodeToken).filter(
            QRCodeToken.user_id == user_id
        ).first()

        if not token:
            raise HTTPException(
                status_code=404,
                detail=f"No active QR token found for user #{user_id}."
            )

        token.is_active = False
        self.db.commit()

        logger.info(
            f"QR token invalidated for user #{user_id} "
            f"by admin #{admin.id}"
        )

    def _generate_and_store_token(self, user: User) -> dict:
        """
        Internal: generate a signed token and upsert into DB.
        Uses a single-row-per-user upsert pattern.
        """
        token_data = generate_qr_token(user.id)

        # Upsert: update existing row or insert new one
        existing = self.db.query(QRCodeToken).filter(
            QRCodeToken.user_id == user.id
        ).first()

        if existing:
            existing.token      = token_data["token"]
            existing.token_hash = token_data["token_hash"]
            existing.issued_at  = token_data["issued_at"]
            existing.expires_at = token_data["expires_at"]
            existing.is_active  = True
            existing.use_count  = 0
        else:
            new_record = QRCodeToken(
                user_id    = user.id,
                token      = token_data["token"],
                token_hash = token_data["token_hash"],
                issued_at  = token_data["issued_at"],
                expires_at = token_data["expires_at"],
                is_active  = True,
            )
            self.db.add(new_record)

        self.db.commit()

        minutes_left = QR_TOKEN_EXPIRY_MINUTES
        qr_image = generate_qr_image_base64(token_data["token"])

        return {
            "token":              token_data["token"],
            "qr_image_base64":    qr_image,
            "expires_at":         token_data["expires_at"],
            "expires_in_minutes": minutes_left,
        }

    # ===================================================================
    # QR CHECK-IN
    # ===================================================================

    def process_qr_check_in(
        self,
        token: str,
        processed_by: User,
        notes: Optional[str] = None,
    ) -> dict:
        """
        Process a QR code scan and check in the member.

        Validation pipeline (each step raises on failure):
        1. Verify token signature and expiry (cryptographic check)
        2. Look up the token in our DB (confirms it's not invalidated)
        3. Load the member and check they're active
        4. Check the member has an active, non-expired membership
        5. Check they haven't already checked in today
        6. Record the check-in

        Returns a rich success response shown on the staff screen.
        """
        # ---------------------------------------------------------------
        # Step 1: Cryptographic token verification
        # ---------------------------------------------------------------
        token_payload = verify_qr_token(token)

        if token_payload is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired QR code. Ask the member to refresh their app.",
            )

        user_id = token_payload["user_id"]

        # ---------------------------------------------------------------
        # Step 2: DB token lookup (checks it hasn't been invalidated)
        # ---------------------------------------------------------------
        token_hash   = get_token_hash(token)
        stored_token = self.db.query(QRCodeToken).filter(
            QRCodeToken.token_hash == token_hash,
        ).first()

        if not stored_token:
            raise HTTPException(
                status_code=400,
                detail="QR code not recognized. Please ask the member to refresh.",
            )

        if not stored_token.is_active:
            raise HTTPException(
                status_code=403,
                detail="This QR code has been deactivated. Please contact reception.",
            )

        # ---------------------------------------------------------------
        # Step 3: Load member
        # ---------------------------------------------------------------
        member = self.db.query(User).filter(User.id == user_id).first()

        if not member or not member.is_active:
            raise HTTPException(
                status_code=404,
                detail="Member account not found or deactivated.",
            )

        # ---------------------------------------------------------------
        # Step 4: Active membership check
        # ---------------------------------------------------------------
        membership = self._get_valid_membership(user_id)

        # ---------------------------------------------------------------
        # Step 5: Duplicate check-in prevention
        # ---------------------------------------------------------------
        today = date.today()
        already_checked_in = self.db.query(Attendance).filter(
            Attendance.user_id       == user_id,
            Attendance.check_in_date == today,
        ).first()

        if already_checked_in:
            raise HTTPException(
                status_code=409,
                detail=(
                    f"{member.full_name} has already checked in today at "
                    f"{already_checked_in.check_in_time.strftime('%H:%M')}. "
                    "No duplicate check-ins allowed."
                ),
            )

        # ---------------------------------------------------------------
        # Step 6: Record the check-in
        # ---------------------------------------------------------------
        attendance = Attendance(
            user_id         = user_id,
            check_in_time   = datetime.utcnow(),
            check_in_date   = today,
            method          = CheckInMethod.QR_SCAN,
            processed_by_id = processed_by.id,
            notes           = notes,
        )
        self.db.add(attendance)

        # Update token usage stats
        stored_token.last_used_at = datetime.utcnow()
        stored_token.use_count   += 1

        self.db.commit()
        self.db.refresh(attendance)

        # Count visits this month for the success screen
        visits_this_month = self._count_visits_this_month(user_id)

        logger.info(
            f"Check-in: user #{user_id} ({member.full_name}) "
            f"at {attendance.check_in_time.strftime('%H:%M')} "
            f"via {attendance.method}"
        )

        return {
            "message":           f"✅ Welcome, {member.full_name}!",
            "user_id":           user_id,
            "member_name":       member.full_name,
            "membership_plan":   membership.plan.value,
            "membership_expiry": membership.end_date,
            "check_in_time":     attendance.check_in_time,
            "visits_this_month": visits_this_month,
        }

    # ===================================================================
    # MANUAL CHECK-IN
    # ===================================================================

    def process_manual_check_in(
        self,
        user_id: int,
        processed_by: User,
        notes: Optional[str] = None,
    ) -> dict:
        """
        Manually check in a member without QR scanning.
        For use when: member forgot phone, QR code isn't scanning, etc.

        Requires admin or trainer role.
        Notes are mandatory to provide an audit trail reason.
        All same validation rules apply (membership, duplicate check).
        """
        # Manual notes are strongly recommended for audit trail
        if not notes:
            notes = "Manual check-in — no QR code available"

        member = self.db.query(User).filter(User.id == user_id).first()
        if not member or not member.is_active:
            raise HTTPException(status_code=404, detail="Member not found.")

        membership = self._get_valid_membership(user_id)

        today = date.today()
        already_checked_in = self.db.query(Attendance).filter(
            Attendance.user_id       == user_id,
            Attendance.check_in_date == today,
        ).first()

        if already_checked_in:
            raise HTTPException(
                status_code=409,
                detail=f"{member.full_name} has already checked in today.",
            )

        attendance = Attendance(
            user_id         = user_id,
            check_in_time   = datetime.utcnow(),
            check_in_date   = today,
            method          = CheckInMethod.MANUAL,
            processed_by_id = processed_by.id,
            notes           = notes,
        )
        self.db.add(attendance)
        self.db.commit()
        self.db.refresh(attendance)

        visits_this_month = self._count_visits_this_month(user_id)

        logger.info(
            f"Manual check-in: user #{user_id} by staff #{processed_by.id}. "
            f"Reason: {notes}"
        )

        return {
            "message":           f"✅ {member.full_name} manually checked in.",
            "user_id":           user_id,
            "member_name":       member.full_name,
            "membership_plan":   membership.plan.value,
            "membership_expiry": membership.end_date,
            "check_in_time":     attendance.check_in_time,
            "visits_this_month": visits_this_month,
        }

    # ===================================================================
    # CHECK-OUT
    # ===================================================================

    def process_check_out(self, user_id: int) -> Attendance:
        """
        Record when a member leaves the gym.
        Calculates the session duration in minutes.
        """
        today = date.today()
        attendance = self.db.query(Attendance).filter(
            Attendance.user_id        == user_id,
            Attendance.check_in_date  == today,
            Attendance.check_out_time == None,
        ).first()

        if not attendance:
            raise HTTPException(
                status_code=404,
                detail="No active check-in found for today. Cannot check out.",
            )

        now = datetime.utcnow()
        attendance.check_out_time   = now
        attendance.duration_minutes = int(
            (now - attendance.check_in_time).total_seconds() / 60
        )

        self.db.commit()
        self.db.refresh(attendance)

        logger.info(
            f"Check-out: user #{user_id}, "
            f"duration={attendance.duration_minutes} min"
        )
        return attendance

    # ===================================================================
    # MEMBER ATTENDANCE HISTORY
    # ===================================================================

    def get_member_history(
        self,
        user_id: int,
        limit: int = 30,
        from_date: Optional[date] = None,
        to_date: Optional[date] = None,
    ) -> List[Attendance]:
        """Get attendance records for a specific member."""
        query = self.db.query(Attendance).filter(
            Attendance.user_id == user_id
        )
        if from_date:
            query = query.filter(Attendance.check_in_date >= from_date)
        if to_date:
            query = query.filter(Attendance.check_in_date <= to_date)

        return (
            query
            .order_by(Attendance.check_in_time.desc())
            .limit(limit)
            .all()
        )

    def get_member_summary(self, user_id: int) -> dict:
        """
        Get comprehensive attendance stats for one member.
        Shown on the admin member profile page.
        """
        all_records = (
            self.db.query(Attendance)
            .filter(Attendance.user_id == user_id)
            .order_by(Attendance.check_in_date.desc())
            .all()
        )

        now = datetime.utcnow()
        today = now.date()

        visits_this_month = sum(
            1 for r in all_records
            if r.check_in_date.month == now.month
            and r.check_in_date.year  == now.year
        )
        visits_this_week = sum(
            1 for r in all_records
            if r.check_in_date >= (today - timedelta(days=today.weekday()))
        )

        # Average visits per week (over last 12 weeks)
        twelve_weeks_ago = today - timedelta(weeks=12)
        recent = [r for r in all_records if r.check_in_date >= twelve_weeks_ago]
        avg_per_week = round(len(recent) / 12, 1) if recent else 0.0

        last_visit = all_records[0].check_in_time if all_records else None

        # Calculate streaks
        visit_dates = sorted({r.check_in_date for r in all_records}, reverse=True)
        current_streak = self._calculate_current_streak(visit_dates, today)
        longest_streak = self._calculate_longest_streak(visit_dates)

        return {
            "user_id":           user_id,
            "total_visits":      len(all_records),
            "visits_this_month": visits_this_month,
            "visits_this_week":  visits_this_week,
            "average_per_week":  avg_per_week,
            "last_visit":        last_visit,
            "current_streak":    current_streak,
            "longest_streak":    longest_streak,
        }

    # ===================================================================
    # ADMIN REPORTS
    # ===================================================================

    def get_daily_report(self, report_date: Optional[date] = None) -> dict:
        """
        Attendance summary for a single day.
        Defaults to today if no date is given.
        """
        report_date = report_date or date.today()

        records = self.db.query(Attendance).filter(
            Attendance.check_in_date == report_date
        ).all()

        unique_members   = len({r.user_id for r in records})
        qr_scan_count    = sum(1 for r in records if r.method == CheckInMethod.QR_SCAN)
        manual_count     = sum(1 for r in records if r.method == CheckInMethod.MANUAL)

        # Find peak hour (hour with most check-ins)
        if records:
            hour_counts = Counter(r.check_in_time.hour for r in records)
            peak_hour   = hour_counts.most_common(1)[0][0]
        else:
            peak_hour = None

        # Average session duration (for members who checked out)
        durations = [r.duration_minutes for r in records if r.duration_minutes]
        avg_duration = round(sum(durations) / len(durations), 1) if durations else None

        return {
            "date":             report_date,
            "total_check_ins":  len(records),
            "unique_members":   unique_members,
            "qr_scan_count":    qr_scan_count,
            "manual_count":     manual_count,
            "peak_hour":        peak_hour,
            "average_duration_minutes": avg_duration,
        }

    def get_weekly_report(self, week_offset: int = 0) -> dict:
        """
        Attendance summary for a full week (Mon–Sun).
        week_offset: 0=this week, -1=last week, etc.
        """
        today      = date.today()
        monday     = today - timedelta(days=today.weekday())
        week_start = monday + timedelta(weeks=week_offset)
        week_end   = week_start + timedelta(days=6)

        records = self.db.query(Attendance).filter(
            Attendance.check_in_date >= week_start,
            Attendance.check_in_date <= week_end,
        ).all()

        unique_members = len({r.user_id for r in records})

        # Per-day breakdown
        day_names  = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        day_counts = defaultdict(int)
        for r in records:
            day_counts[r.check_in_date] += 1

        busiest = max(day_counts, key=day_counts.get) if day_counts else None
        busiest_name = day_names[busiest.weekday()] if busiest else None

        # Build 7-day daily breakdown
        daily = []
        for i in range(7):
            d = week_start + timedelta(days=i)
            daily.append(self.get_daily_report(d))

        return {
            "week_start":      week_start,
            "week_end":        week_end,
            "total_check_ins": len(records),
            "unique_members":  unique_members,
            "busiest_day":     busiest_name,
            "daily_breakdown": daily,
        }

    def get_monthly_report(
        self,
        year: Optional[int] = None,
        month: Optional[int] = None,
    ) -> dict:
        """Monthly attendance summary."""
        now   = datetime.utcnow()
        year  = year  or now.year
        month = month or now.month

        records = self.db.query(Attendance).filter(
            func.extract("year",  Attendance.check_in_date) == year,
            func.extract("month", Attendance.check_in_date) == month,
        ).all()

        unique_members = len({r.user_id for r in records})

        # Find the most active member
        if records:
            member_counts = Counter(r.user_id for r in records)
            most_active_id = member_counts.most_common(1)[0][0]
        else:
            most_active_id = None

        # Days in the month
        import calendar
        days_in_month = calendar.monthrange(year, month)[1]

        return {
            "year":             year,
            "month":            month,
            "total_check_ins":  len(records),
            "unique_members":   unique_members,
            "average_daily":    round(len(records) / days_in_month, 1),
            "most_active_member_id": most_active_id,
        }

    def get_attendance_trend(
        self,
        days: int = 30,
    ) -> dict:
        """
        Day-by-day check-in counts for the last N days.
        Used to draw a trend chart on the admin dashboard.
        """
        today  = date.today()
        start  = today - timedelta(days=days - 1)

        records = self.db.query(Attendance).filter(
            Attendance.check_in_date >= start
        ).all()

        # Group by date
        counts = defaultdict(int)
        for r in records:
            counts[r.check_in_date] += 1

        # Build full series (fill zeros for days with no check-ins)
        data_points = []
        for i in range(days):
            d = start + timedelta(days=i)
            data_points.append({"date": d, "check_ins": counts.get(d, 0)})

        total   = sum(p["check_ins"] for p in data_points)
        average = round(total / days, 1) if days else 0

        return {
            "period":      "daily",
            "data_points": data_points,
            "total":       total,
            "average":     average,
        }

    def get_today_check_ins(self) -> List[Attendance]:
        """Get all check-ins for today. Used for the live admin dashboard."""
        return (
            self.db.query(Attendance)
            .filter(Attendance.check_in_date == date.today())
            .order_by(Attendance.check_in_time.desc())
            .all()
        )

    # ===================================================================
    # PRIVATE HELPERS
    # ===================================================================

    def _get_valid_membership(self, user_id: int) -> Membership:
        """
        Fetch and validate a user's membership.
        Raises HTTP 403 with a clear message if invalid.
        """
        membership = self.db.query(Membership).filter(
            Membership.user_id == user_id,
            Membership.status  == MembershipStatus.ACTIVE,
        ).first()

        if not membership:
            raise HTTPException(
                status_code=403,
                detail="❌ No active membership. Please visit reception.",
            )

        if membership.end_date < datetime.utcnow():
            raise HTTPException(
                status_code=403,
                detail=(
                    f"❌ Membership expired on {membership.end_date.date()}. "
                    "Please renew at reception."
                ),
            )

        return membership

    def _count_visits_this_month(self, user_id: int) -> int:
        """Count check-ins for the current calendar month."""
        now = datetime.utcnow()
        return self.db.query(Attendance).filter(
            Attendance.user_id == user_id,
            func.extract("year",  Attendance.check_in_date) == now.year,
            func.extract("month", Attendance.check_in_date) == now.month,
        ).count()

    def _calculate_current_streak(
        self, sorted_dates: List[date], today: date
    ) -> int:
        """Count consecutive days ending today or yesterday."""
        if not sorted_dates:
            return 0
        streak = 0
        expected = today
        for d in sorted_dates:
            if d == expected:
                streak  += 1
                expected = expected - timedelta(days=1)
            elif d == today - timedelta(days=1) and streak == 0:
                streak   = 1
                expected = d - timedelta(days=1)
            else:
                break
        return streak

    def _calculate_longest_streak(self, sorted_dates: List[date]) -> int:
        """Find the longest consecutive-day streak in all history."""
        if not sorted_dates:
            return 0
        unique = sorted(set(sorted_dates))
        best = current = 1
        for i in range(1, len(unique)):
            if (unique[i] - unique[i-1]).days == 1:
                current += 1
                best = max(best, current)
            else:
                current = 1
        return best
