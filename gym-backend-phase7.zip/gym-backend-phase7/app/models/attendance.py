"""
models/attendance.py — QR Attendance Database Models (Phase 7)

This file defines TWO tables:

┌──────────────────────────────────────────────────────────────────┐
│  Attendance      → One check-in event per member per visit       │
│  QRCodeToken     → Signed, time-limited QR token per user       │
└──────────────────────────────────────────────────────────────────┘

How the QR attendance system works end-to-end:
  1. Member opens the mobile app → sees their unique QR code
  2. QR code encodes a SIGNED TOKEN (not just user_id)
     - Why signed? So no one can fake a QR code for another member
     - The token contains: user_id + issued_at + signature (HMAC-SHA256)
  3. Staff scans the QR code at the gym entrance
  4. Server validates the token signature and expiry
  5. Server checks the member has an active membership
  6. Server checks they haven't already checked in today
  7. Check-in is recorded as an Attendance record

Security design:
  - Tokens are signed with the app's SECRET_KEY using HMAC-SHA256
  - Tokens expire after QR_TOKEN_EXPIRY_MINUTES (default: 60 min)
  - A new token is generated each time the member opens the app
  - Even if someone screenshots the QR, it stops working after expiry
  - The QRCodeToken table tracks all active tokens per user
    (allowing the admin to invalidate a specific user's QR if needed)
"""

import enum
from datetime import datetime

from sqlalchemy import (
    Boolean, Column, DateTime, Enum,
    ForeignKey, Integer, String, Text, Date
)
from sqlalchemy.orm import relationship

from app.core.database import Base


class CheckInMethod(str, enum.Enum):
    """
    How the member checked in.
    QR_SCAN = scanned at the door (normal)
    MANUAL  = staff manually added the check-in (e.g. phone dead)
    KIOSK   = self-service kiosk at the entrance
    """
    QR_SCAN = "qr_scan"
    MANUAL  = "manual"
    KIOSK   = "kiosk"


class Attendance(Base):
    """
    Records a single gym visit for a member.

    One record per visit — we enforce "one check-in per day" at the
    service layer (not the DB) so the validation message is clear.

    Maps to the 'attendances' table.
    """
    __tablename__ = "attendances"

    id        = Column(Integer, primary_key=True, index=True)

    # --- Who checked in ---
    user_id   = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    # --- When ---
    check_in_time  = Column(DateTime, nullable=False, default=datetime.utcnow)
    check_out_time = Column(DateTime, nullable=True)
    # Check-out is optional — some gyms don't track exits

    check_in_date  = Column(Date, nullable=False)
    # Stored separately so we can quickly query "did this user check in today?"
    # e.g. WHERE user_id=42 AND check_in_date='2025-02-10'
    # This is much faster than DATE(check_in_time)=today on large tables

    # --- How ---
    method    = Column(Enum(CheckInMethod), nullable=False, default=CheckInMethod.QR_SCAN)

    # --- Who processed it ---
    processed_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    # The staff member or admin who scanned/processed the check-in
    # null = self-service (kiosk or auto-scan)

    # --- Duration ---
    duration_minutes = Column(Integer, nullable=True)
    # Calculated when member checks out: (check_out_time - check_in_time) in minutes

    # --- Notes ---
    notes     = Column(String(300), nullable=True)
    # e.g. "Forgot QR code — verified by ID", "Guest pass used"

    # --- Flags ---
    is_guest  = Column(Boolean, default=False)
    # True if this check-in is for a guest (not a regular member)

    # --- Timestamps ---
    created_at = Column(DateTime, default=datetime.utcnow)

    # --- Relationships ---
    user         = relationship("User", foreign_keys=[user_id],         back_populates="attendances")
    processed_by = relationship("User", foreign_keys=[processed_by_id])

    def __repr__(self):
        return (
            f"<Attendance user_id={self.user_id} "
            f"date={self.check_in_date} "
            f"method={self.method}>"
        )


class QRCodeToken(Base):
    """
    Stores the active QR token for each user.

    Why store it? So we can:
    - Invalidate a specific user's QR instantly (e.g. suspended member)
    - Track when a token was last regenerated
    - Audit which tokens have been used

    Each user has ONE active token at a time.
    When a new token is generated, it replaces the old one.

    Maps to the 'qr_code_tokens' table.
    """
    __tablename__ = "qr_code_tokens"

    id         = Column(Integer, primary_key=True, index=True)

    # --- One token per user ---
    user_id    = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    # unique=True enforces one row per user

    # --- The token value ---
    token      = Column(String(512), nullable=False, unique=True)
    # The full signed token string stored in the QR code
    # Format: base64(user_id:issued_at:signature)

    token_hash = Column(String(64), nullable=False, unique=True, index=True)
    # SHA-256 hash of the token — used for fast lookup during scanning
    # We hash it so even if the DB is leaked, tokens can't be cloned
    # (original token is needed to scan, hash alone is useless)

    # --- Validity ---
    issued_at  = Column(DateTime, nullable=False, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    # Token is valid from issued_at until expires_at

    is_active  = Column(Boolean, default=True)
    # False = manually invalidated (admin suspended the member's access)

    # --- Usage tracking ---
    last_used_at  = Column(DateTime, nullable=True)
    use_count     = Column(Integer,  default=0)
    # How many times this specific token has been used for check-in

    # --- Relationships ---
    user = relationship("User", foreign_keys=[user_id])

    def __repr__(self):
        return (
            f"<QRCodeToken user_id={self.user_id} "
            f"active={self.is_active} "
            f"expires={self.expires_at}>"
        )
