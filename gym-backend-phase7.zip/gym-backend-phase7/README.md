# 📡 Phase 7 — QR Attendance System

A secure, cryptographically-signed QR attendance system with member check-in, admin reports, and streak tracking.

---

## 📁 New Files in Phase 7

```
app/
├── models/
│   └── attendance.py           ← 2 models: Attendance, QRCodeToken
├── schemas/
│   └── attendance.py           ← Check-in, report, and analytics schemas
├── routers/
│   └── attendance.py           ← 16 endpoints (QR, check-in, reports)
├── services/
│   └── attendance_service.py   ← All business logic (token mgmt, validation, reports)
└── utils/
    └── qr_utils.py             ← HMAC-SHA256 token signing, QR image generation

tests/
└── test_attendance.py          ← Full test suite incl. token unit tests
```

---

## 📋 Endpoints

| Method | Endpoint                              | Auth          | Description                        |
|--------|---------------------------------------|---------------|------------------------------------|
| GET    | `/api/attendance/my-qr`               | Member        | Get QR token + base64 image        |
| GET    | `/api/attendance/my-qr/image`         | Member        | Get QR as PNG stream               |
| POST   | `/api/attendance/my-qr/refresh`       | Member        | Force-regenerate QR token          |
| POST   | `/api/attendance/invalidate-qr/{id}`  | Admin         | Disable a member's QR              |
| POST   | `/api/attendance/check-in`            | Staff         | Process QR scan → check in         |
| POST   | `/api/attendance/manual-check-in`     | Trainer/Admin | Manual check-in by user ID         |
| POST   | `/api/attendance/check-out`           | Staff         | Record check-out + duration        |
| GET    | `/api/attendance/me`                  | Member        | My visit history                   |
| GET    | `/api/attendance/me/summary`          | Member        | My stats (streak, monthly, etc.)   |
| GET    | `/api/attendance/today`               | Admin         | Live today's check-ins             |
| GET    | `/api/attendance/report/daily`        | Admin         | Daily summary report               |
| GET    | `/api/attendance/report/weekly`       | Admin         | Weekly report with breakdown       |
| GET    | `/api/attendance/report/monthly`      | Admin         | Monthly report                     |
| GET    | `/api/attendance/report/trend`        | Admin         | N-day trend for dashboard chart    |
| GET    | `/api/attendance/member/{id}/summary` | Admin         | A member's full stats              |
| GET    | `/api/attendance/member/{id}/history` | Admin         | A member's visit history           |

---

## 🔐 Token Security Architecture

```
Member opens app → GET /my-qr
                        │
                        ▼
              generate_qr_token(user_id=42)
                        │
                        ▼
    payload  = "v1:42:1707123456"   ← version:user_id:unix_timestamp
    signature = HMAC-SHA256(payload, SECRET_KEY)
    token    = base64url(payload + "." + signature)
                        │
                        ▼
    QR image generated from token string
    Token stored in DB (hashed) with expiry

Staff scans QR → POST /check-in  { token: "..." }
                        │
                        ▼
    verify_qr_token(token):
      1. Decode base64 → extract payload + signature
      2. Recompute HMAC(payload, SECRET_KEY)
      3. hmac.compare_digest(expected, received)  ← timing-safe!
      4. Check expires_at > now
      5. Return {user_id, issued_at, expires_at}
```

**Why HMAC and not JWT?**
- Simpler and smaller — no JSON overhead
- Tokens are short enough to fit in a QR code at low density (easy to scan)
- We control the exact format and expiry logic

---

## ✅ Check-In Validation Pipeline

```
QR Scan received
      │
      ▼
1. verify_qr_token() ──FAIL──► 400 "Invalid or expired QR code"
      │ PASS
      ▼
2. Token in DB & is_active? ──NO──► 400 / 403 "QR not recognized / deactivated"
      │ YES
      ▼
3. Member account exists & is_active? ──NO──► 404 "Account not found"
      │ YES
      ▼
4. Active, non-expired membership? ──NO──► 403 "No active membership"
      │ YES
      ▼
5. Already checked in today? ──YES──► 409 "Already checked in at HH:MM"
      │ NO
      ▼
6. ✅ Create Attendance record → return success card
```

---

## 📊 Admin Reports

```json
// GET /api/attendance/report/daily
{
  "date": "2025-02-10",
  "total_check_ins": 47,
  "unique_members": 44,
  "qr_scan_count": 43,
  "manual_count": 4,
  "peak_hour": 18,           // 6pm was the busiest hour
  "average_duration_minutes": 68.5
}

// GET /api/attendance/report/trend?days=7
{
  "data_points": [
    {"date": "2025-02-04", "check_ins": 38},
    {"date": "2025-02-05", "check_ins": 41},
    {"date": "2025-02-06", "check_ins": 52},
    ...
  ],
  "average": 44.3
}
```

---

## 📱 Flutter Integration

```dart
// Display the QR code on the member's home screen
final response = await api.get('/api/attendance/my-qr');
final bytes    = base64Decode(response['qr_image_base64']);

Image.memory(bytes, width: 250, height: 250)

// Show expiry countdown
final expiresAt  = DateTime.parse(response['expires_at']);
final minutesLeft = expiresAt.difference(DateTime.now()).inMinutes;
Text('Refreshes in $minutesLeft min')

// Auto-refresh when expired
if (minutesLeft <= 0) {
  await refreshQR();
}
```

---

## ➡️ Next: Phase 8 — Notification System

Adds push notifications (Firebase FCM), email notifications, and Celery background workers triggered by key events: membership expiry reminders, class booking confirmations, payment receipts, and attendance milestones.
